#include <cassert>
#include <cstdio>
#include "../WetterHimmel/Gesture.h"
#include "../WetterHimmel/Visibility.h"
int main(){
 TouchGesture g;assert(g.update(true,100,200,0,true)==0);assert(g.update(false,0,0,100,true)==1);assert(g.update(false,0,0,110,true)==0);
 g.update(true,250,200,200,true);g.update(true,100,205,400,true);assert(g.update(false,0,0,500,true)==2);
 g.update(true,100,200,600,true);g.update(true,250,205,800,true);assert(g.update(false,0,0,900,true)==2);
 g.update(true,100,200,1000,true);g.update(true,130,300,1200,true);assert(g.update(false,0,0,1300,true)==0);
 g.update(true,100,200,1400,false);g.update(true,250,200,1500,false);assert(g.update(false,0,0,1600,false)==0);
 g.update(true,100,200,1700,true);g.update(true,150,200,1800,true);g.update(true,100,200,1900,true);assert(g.update(false,0,0,2000,true)==0);
 g.update(true,100,200,UINT32_MAX-100,true);g.update(true,200,201,50,true);assert(g.update(false,0,0,80,true)==2);
 // Small finger movement remains a tap at the original button position.
 g.update(true,100,200,2200,false);g.update(true,120,220,2220,false);
 assert(g.update(false,0,0,2230,false)==0); // brief contact interruption
 g.update(true,118,218,2240,false);assert(g.update(false,0,0,2270,false)==1);
 assert(g.ex==100&&g.ey==200);assert(g.update(false,0,0,2280,false)==0);
 // A second intentional tap must not be discarded by a 180 ms global lock.
 g.update(true,100,200,2300,false);assert(g.update(false,0,0,2340,false)==1);
 // A short, slightly diagonal swipe is accepted; vertical scroll remains cancelled.
 g.update(true,200,200,2400,true);g.update(true,150,225,2500,true);
 assert(g.update(false,0,0,2540,true)==2);
 g.update(true,100,200,2600,true);g.update(true,110,270,2700,true);
 assert(g.update(false,0,0,2740,true)==0);
 // A release was seen, but no idle sample arrived after the grace period.
 g.update(true,80,90,2800,true);g.update(false,0,0,2810,true);
 assert(g.update(true,200,220,2840,true)==1);
 assert(g.eventX==80&&g.eventY==90&&g.tracking&&g.sx==200);
 assert(g.update(false,0,0,2880,true)==1);
 assert(g.eventX==200&&g.eventY==220);
 assert(g.update(false,0,0,2900,true)==0);
 double sun[]={149597870.7,0,0},night[]={-6800,0,0},day[]={6800,0,0},side[]={0,6800,0};
 assert(satelliteVisibility(night,sun,45,-20)==2);
 assert(satelliteVisibility(day,sun,45,-20)==5);
 assert(satelliteVisibility(side,sun,45,-6)==5);
 assert(satelliteVisibility(day,sun,45,0)==4);
 assert(satelliteVisibility(day,sun,-1,-20)==1);
 assert(satelliteVisibility(day,sun,NAN,-20)==0);
 // At apparent Earth's limb, the Sun's disk is partially covered.
 double theta=asin(6378.137/6800.0),limb[]={-6800*cos(theta),6800*sin(theta),0};
 assert(satelliteVisibility(limb,sun,45,-20)==3);
 puts("PASS: tap, both swipe directions, scrolling/menu cancellation, excursion cancellation, timer wrap; umbra, sunlight, penumbra, twilight, horizon, invalid geometry.");
}
