from pathlib import Path
import subprocess,tempfile,os
p=Path(__file__).resolve().parents[1]/'WetterHimmel'
s=(p/'Web.cpp').read_text();number=s[s.index('static bool number('):s.index('bool applyCommand(')];commands=s[s.index('  if(a=="skyCamera")'):s.index('  if (a == "satResume")')]
code='''#include <ArduinoJson.h>
#include <math.h>
#include <string>
#include <cassert>
#include <cstdio>
#include "SkyCamera.h"
using String=std::string;
SkyCamera skyCamera;bool dirty=false;int page=1;struct {int view=0;}cfg;
void setView(int v){cfg.view=v;page=0;dirty=true;}
'''+number+'bool command(JsonDocument &d,String &error){String a=d["action"]|"";\n'+commands+'return false;}\n'+r'''
int main(){JsonDocument d;String error;
d["action"]="skyCamera";d["zoom"]=2;d["panX"]=25;d["panY"]=-20;
assert(command(d,error)&&cfg.view==1&&page==0&&dirty);assert(skyCamera.zoom==2&&skyCamera.panX==25&&skyCamera.panY==-20);auto rev=skyCamera.revision;
int x=180,y=184;skyCamera.transform(x,y);assert(x==225&&y==174);assert(skyCamera.contains(x,y)&&!skyCamera.contains(280,174));
assert(command(d,error)&&skyCamera.revision==rev);
d["zoom"]=5;assert(!command(d,error)&&skyCamera.revision==rev);d["zoom"]=nullptr;assert(!command(d,error));d["zoom"]="2";assert(!command(d,error));
d["zoom"]=1;d["panX"]=324;d["panY"]=-324;assert(command(d,error));assert(skyCamera.panX==0&&skyCamera.panY==0&&skyCamera.zoom==1);
d["action"]="view";d["value"]=0;assert(command(d,error)&&cfg.view==0);d["value"]=1;assert(command(d,error)&&cfg.view==1);d["value"]=2;assert(!command(d,error)&&cfg.view==1);
assert(!skyCamera.set(NAN,0,0));assert(!skyCamera.set(2,INFINITY,0));
puts("PASS: production command validation, view switch, camera transform and bounds, revision, unchanged camera, reset and nonfinite rejection.");}
'''
lib=os.environ.get('ARDUINOJSON_DIR','/home/agent/Arduino/libraries/ArduinoJson-7.4.2/src')
with tempfile.TemporaryDirectory() as td:
 f=Path(td)/'test.cpp';f.write_text(code);b=Path(td)/'test'
 subprocess.run(['g++','-std=c++17','-I'+lib,'-I'+str(p),str(f),'-o',str(b)],check=True)
 subprocess.run([str(b)],check=True)
