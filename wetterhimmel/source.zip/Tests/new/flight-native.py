from pathlib import Path
import subprocess
r=Path(__file__).resolve().parents[2]/'WetterHimmel'
s=(r/'Modern.cpp').read_text();part=s[s.index('static double directionTo'):s.index('bool priorityActive()')]
h=(r/'Modern.h').read_text();types=h[h.index('struct Flight'):h.index('extern ModernSettings')]
cpp='''#include <ArduinoJson.h>
#include <cmath>
#include <cstring>
#include <cassert>
#include <iostream>
using namespace std;
#define DEG_TO_RAD (M_PI/180)
#define RAD_TO_DEG (180/M_PI)
#define sq(x) ((x)*(x))
template<class T>T constrain(T x,T a,T b){return min(b,max(a,x));}
struct Place{double lat,lon;};
'''+types+part+'''
int main(){Place p{0,0};Flight f;JsonDocument d;
assert(!parseFlight(d,f,p,50,false,1800000000));
d["now"]=1800000000;auto ac=d["ac"].to<JsonArray>();
auto a=ac.add<JsonObject>();a["lat"]=.1;a["lon"]=.1;a["seen_pos"]=5;a["alt_baro"]=30000;a["track"]=225;a["gs"]=400;a["flight"]="TEST1 ";
assert(parseFlight(d,f,p,50,true,1800000000));assert(f.found&&f.approaching&&f.positionAt==1799999995);assert(abs(f.altitude-9144)<.01);assert(abs(f.speed-740.8)<.1);assert(string(f.callsign)=="TEST1");
a["track"]=45;assert(parseFlight(d,f,p,50,true,1800000000)&&!f.found);assert(parseFlight(d,f,p,50,false,1800000000)&&f.found);
a["seen_pos"]=100;assert(parseFlight(d,f,p,50,false,1800000000)&&!f.found);
a["seen_pos"]=1;a["alt_baro"]="ground";assert(parseFlight(d,f,p,50,false,1800000000)&&!f.found);
a["alt_baro"]=1000;a["lat"]=30;assert(parseFlight(d,f,p,50,false,1800000000)&&!f.found);
d["now"]=1799990000;assert(!parseFlight(d,f,p,50,false,1800000000));
Hourly hour;JsonDocument hd;hd["time"][0]=1800000000;hd["cloud_cover"][0]=110;hd["precipitation_probability"][0]=50;parseHourly(hd.as<JsonVariantConst>(),hour,1800000000);assert(hour.count==1&&hour.cloud[0]==-1&&hour.rain[0]==50);
cout<<"PASS flight selection, approach geometry, age, units, radius, ground filtering, source clock, hourly missing/range handling\\n";
}
'''
out=Path(__file__).parent; (out/'flight-native.cpp').write_text(cpp)
subprocess.run(['g++','-std=c++17','-I/home/agent/Arduino/libraries/ArduinoJson/src',str(out/'flight-native.cpp'),'-o',str(out/'flight-native')],check=True)
subprocess.run([str(out/'flight-native')],check=True)
