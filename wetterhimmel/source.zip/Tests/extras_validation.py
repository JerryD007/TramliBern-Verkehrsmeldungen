from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1];p=root/'WetterHimmel';s=(p/'Extras.cpp').read_text();app=(p/'App.h').read_text()
def struct(n):
 a=app.index('struct '+n+' {');return app[a:app.index('};',a)+2]
def segment(a,b):return s[s.index(a):s.index(b)]
code='''#include <ArduinoJson.h>
#include <cassert>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <cstdint>
#include <string>
#include "NightSchedule.h"
using std::isfinite;
size_t strlcpy(char*d,const char*s,size_t n){snprintf(d,n,"%s",s);return strlen(s);}
'''+''.join(struct(n) for n in ['Place','WifiProfile','Settings'])+'''
struct ExtraSettings {uint32_t version=1;bool largeMap=false,trails=true,autoNight=false;int start=1320,end=420,dim=35;};
Settings cfg{};ExtraSettings extra;int writes=0,highlightedObject=0,page=0;
struct {size_t putBytes(const char*,const void*,size_t n){writes++;return n;}}prefs;
struct {int revision=0;}skyCamera;
bool displayNight=false,manualNight=false;void extrasTick(){}void applyPlace(){}void uiDisplayBrightness(){}
'''+segment('static bool validExtra','static void sendJson')+segment('static bool extraFromJson','bool extrasCommand')+segment('static void backup','void extrasWeb')+'''
int main(){
 for(int m=0;m<1440;m++){assert(nightScheduled(m,1320,420)==(m>=1320||m<420));assert(nightScheduled(m,600,720)==(m>=600&&m<720));assert(!nightScheduled(m,0,0));}
 cfg.version=2;cfg.placeCount=1;cfg.wifiCount=1;cfg.brightness=180;strcpy(cfg.places[0].name,"Bern");strcpy(cfg.places[0].tz,"CET-1CEST,M3.5.0,M10.5.0/3");cfg.places[0].lat=46.948;cfg.places[0].lon=7.447;strcpy(cfg.wifi[0].ssid,"Test");strcpy(cfg.wifi[0].pass,"abcdefgh");
 JsonDocument d;backup(d);auto original=cfg;
 assert(restore(d));assert(writes==2);assert(memcmp(&original,&cfg,sizeof cfg)==0);
 auto invalid=[&](){writes=0;assert(!restore(d));assert(writes==0);assert(memcmp(&original,&cfg,sizeof cfg)==0);backup(d);};
 d["schema"]=9;invalid();d["config"]["place"]=6;invalid();d["config"]["places"][0]["lat"]=91;invalid();d["extras"]["dim"]=255;invalid();d["extras"]["start"]=1440;invalid();d["config"]["wifi"][0]["pass"]=std::string(65,'x');invalid();d["config"]["labels"]="true";invalid();d["config"].remove("places");invalid();
 puts("PASS: all 1440 minutes across midnight/day/disabled intervals; backup round-trip; invalid schema, ranges, types, lengths and missing fields rejected without writes.");
}
'''
with tempfile.TemporaryDirectory() as t:
 f=Path(t)/'test.cpp';f.write_text(code);binary=Path(t)/'test'
 subprocess.run(['g++','-std=c++17','-I/home/agent/Arduino/libraries/ArduinoJson/src','-I'+str(p),str(f),'-o',str(binary)],check=True);subprocess.run([str(binary)],check=True)
