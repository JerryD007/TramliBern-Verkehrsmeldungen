from pathlib import Path
import re
p=Path(__file__).resolve().parents[1]/'WetterHimmel'
a=(p/'App.cpp').read_text();w=(p/'Web.cpp').read_text();s=(p/'Screen.cpp').read_text();html=(p/'WebPage.h').read_text()
assert 'prefs.begin("wetterwelt", false)' in a
assert 'cfg.version = 2;' in a
assert 'cfg.view < 0 || cfg.view > 1' in a
assert '(cfg.view + 1) % 2' in a
assert 'if (v < 0 || v > 1)' in w
assert not any(x in html+s+w+a for x in ['simTime','planetScreen','PLANETARIUM','action:\'step\'','action:\'time\'','simSkyCanvas'])
assert html.count('data-v="')==2
assert html.index('data-v="0"')>html.index('<dialog id="settings"')
assert 'TouchGesture gesture' in s
assert 'setView(min(1, (int)x / 160))' not in s
assert 'for(int i=0;i<7;i++)' in s
assert 'hitType[i]>=3000' in s
assert 'y >= 366 && y < 434' in s
assert 'sizeof cfg' in a
assert '"cal" + String(cfg.rotation)' in s
# Full source literals are encoded in the embedded font subset.
font=(p/'UiFonts.h').read_text()
for c in 'äöüÄÖÜß°←↑→↓−✓…—': assert '{'+str(ord(c))+',' in font, c
print('PASS: two views; migration guards; NVS namespace/version/calibration keys; satellite hit priority; font glyph coverage.')
