#pragma once
static const char WEB_PAGE[] PROGMEM=R"WWHTML(<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Wetter & Himmel</title><style>
:root{font-family:-apple-system,BlinkMacSystemFont,Arial,sans-serif;color:#edf6ff;background:#081227;color-scheme:dark}*{box-sizing:border-box}body{margin:0 auto;max-width:900px;padding:18px}header{display:flex;justify-content:space-between;align-items:center;gap:12px}h1{font-size:26px}h2{font-size:23px}button,input,select{font:inherit;font-size:17px;border:1px solid #476185;border-radius:10px;padding:12px;color:white;background:#183354;min-height:48px}button{cursor:pointer}button:disabled{opacity:.5;cursor:default}button.active,.primary{background:#057c9b}button.danger{background:#8b3349}input,select{width:100%;margin:7px 0 13px}label{display:block}nav{display:flex;gap:6px;margin:18px 0}nav button{flex:1;padding:12px 3px;font-size:15px}.panel{border-radius:18px;padding:20px;margin:14px 0;background:#122342}.weather{background:linear-gradient(135deg,#0864b6,#084887)}.hero{display:flex;align-items:center;justify-content:space-around}.temp{font-size:64px;font-weight:600}.symbol{font-size:90px}.sub{color:#b2d9ff}.row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.row>*{flex:1}table{width:100%;border-collapse:collapse;font-size:18px}td,th{text-align:right;padding:11px 4px}td:first-child,th:first-child{text-align:left}tbody tr:nth-child(odd){background:#ffffff0b}.small{font-size:15px;color:#bad2ec}.error{background:#653044;border-radius:10px;padding:12px}canvas{width:100%;max-width:480px;display:block;margin:auto;touch-action:pan-y}details{margin:12px 0}summary{cursor:pointer;font-size:20px;padding:10px}dialog{max-height:88dvh;overflow-y:auto;max-width:94vw;width:520px;background:#122342;color:white;border:1px solid #577799;border-radius:15px}dialog::backdrop{background:#000b}a{color:#80deff}.check{display:flex;align-items:center;gap:10px}.check input{width:24px;height:24px;margin:0}.hidden{display:none!important}#toast{position:sticky;bottom:10px;background:#164d67;padding:12px;border-radius:10px}footer{margin-top:24px}button:focus-visible{outline:3px solid #ffdf60}
.satgrid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.satcard{display:flex;align-items:center;gap:8px;text-align:left;width:100%;background:linear-gradient(145deg,#263c60,#101e39);border:1px solid #587ca7;min-height:88px}.satcard b{font-size:20px}.satcard small{display:block;font-size:15px;color:#b9ddf5;margin-top:5px}.saticon{font-size:29px}nav{position:sticky;top:0;z-index:2;background:#081227}nav .active{background:#00b5c6;color:white}.weather{background:linear-gradient(150deg,#0735a4,#0756b6)}#sky{background:linear-gradient(#020819,#09152c)}@media(max-width:380px){.saticon{font-size:21px}.satcard{padding:9px}.satcard b{font-size:18px}}
.dayIcon{padding:4px;min-width:48px;background:transparent}.zoomtools{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.zoomtools button{flex:1}#skyCanvas{touch-action:none}.weatherIcon{width:1.8em;height:1.8em;vertical-align:middle}.symbol .weatherIcon{width:96px;height:96px}.panel{touch-action:pan-y}@media(max-width:420px){body{padding:12px}.panel{padding:14px}.satgrid{grid-template-columns:1fr}.satcard{min-height:76px}.temp{font-size:56px}table{font-size:17px}h1{font-size:22px}}

:root{--card:#172d4c;--line:#3b587b;--ink:#edf6ff;--muted:#b9cee3}body{color:var(--ink)}.panel{box-shadow:0 8px 28px #0003}.hero{justify-content:space-between;gap:12px}.temp{font-size:76px;letter-spacing:-3px}.sub,#feels{color:var(--muted)}#metrics{font-size:15px;color:var(--muted);padding:10px 0;border-top:1px solid #ffffff24}#forecast .today{background:#08798c55;box-shadow:inset 3px 0 #60e5e0}#forecast .today td:first-child{font-weight:700;color:#a8fff0}.dayArrow{padding:6px;min-width:30px;background:transparent;border:0;font-size:25px}.dayIcon{border:0}#weather th{font-size:14px;color:#bad2ec}#weather td{padding:8px 2px}#skyCanvas{max-width:560px;aspect-ratio:1;border-radius:12px;background:#030914}.zoomtools{position:sticky;top:6px;background:#122342ee;padding:6px;border-radius:12px;z-index:1}.zoomtools button{flex:0 0 48px}.zoomtools button:last-child{flex:1}#zoomLevel{font-weight:700;min-width:44px;text-align:center}#gesturehint{min-height:40px;margin-bottom:8px}.satgrid{grid-template-columns:1fr 1fr!important;gap:8px}.satcard{min-height:78px!important;padding:10px;gap:7px;background:var(--card);border-color:var(--line)}.satcard b{font-size:17px}.satcard small{font-size:13px;line-height:1.3;margin-top:4px}.satcard .saticon{display:none}.satcard>span:nth-child(2){min-width:0;flex:1}.satcard>span:last-child{font-size:20px}.satcard.above{border-left:4px solid #72dca6}.satcard.upcoming{border-left:4px solid #6bcdf4}.satcard.unknown{border-left:4px solid #8c9db5}.satcard.above small{color:#9ce7be}.satcard.upcoming small{color:#a6def5}#controlstatus{min-height:20px;margin:6px 0;font-size:14px;transition:opacity .2s}#controlstatus:empty{visibility:hidden}#controlstatus[data-kind="error"]{color:#ffcfb1;border-left:3px solid #ff9b72;padding-left:9px}.daygrid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.daygroup{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px;min-width:0}.daygroup h3{font-size:14px;letter-spacing:.04em;margin:0 0 12px;color:var(--muted)}.dayvalue{font-size:26px;font-weight:700;line-height:1.2;margin:6px 0 12px}.daygroup dl{margin:0}.daygroup dt{font-size:13px;color:var(--muted);margin-top:9px}.daygroup dd{margin:2px 0;font-size:16px}.dayheading{display:flex;justify-content:space-between;gap:10px;align-items:center}.dayheading .weatherIcon{width:60px;height:60px}#dayDetail>button{width:100%;margin-top:16px}#dayText{color:var(--muted)}.night{--card:#141b29;--line:#3d4353;--ink:#c8c0b9;--muted:#a6a1a0;background:#060a12;color-scheme:dark}.night .panel,.night dialog,.night nav,.night .zoomtools{background:#0c1422!important;color:var(--ink)}.night button,.night input,.night select{background:#192231;color:var(--ink);border-color:var(--line)}.night .weather{background:linear-gradient(150deg,#101d32,#12243a)!important}.night .small,.night #metrics,.night #feels{color:var(--muted)}.night .temp,.night h1,.night h2{color:#d7ccc2}.night canvas,.night .weatherIcon{filter:brightness(.68) saturate(.7)}.night .error{background:#38232a}.night #forecast .today{background:#203d4155}.night dialog::backdrop{background:#000d}
@media(max-width:420px){.temp{font-size:64px}.symbol .weatherIcon{width:76px;height:76px}.daygroup{padding:11px}.dayvalue{font-size:23px}.daygroup dd{font-size:15px}.satcard{padding:8px}.satcard b{font-size:16px}#sky{padding:10px}table{font-size:16px}.zoomtools{top:3px}}
@media(max-width:340px){.daygrid{grid-template-columns:1fr}.satgrid{grid-template-columns:1fr!important}}
/* Keep the settings sheet stable while Safari toolbars and live data change. */
#settings{height:82vh;height:82svh;max-height:82vh;max-height:82svh;overscroll-behavior:contain;overflow-anchor:none}
#settings nav{position:static}#settings pre{white-space:pre-wrap;overflow-wrap:anywhere}
#sky{padding:12px;background:linear-gradient(150deg,#102443,#071426)}#sky h2{margin:6px 4px 10px}#skystatus{margin:4px;font-size:13px}#skystatus:empty{display:none}#gesturehint{font-size:13px;min-height:0}header h1{font-size:23px}body{padding-bottom:calc(22px + env(safe-area-inset-bottom))}.planetart{display:block;width:100%;max-height:240px}.artcaption{color:var(--muted);font-size:12px;margin:5px 0 14px}#detailtext{line-height:1.65;font-size:18px}#detail>button{width:100%}.satcard.sight{border:2px solid #ffe449}.satcard.sight small{color:#ffe449}
<!--MODERN_CSS--></style><header><div><h1>Wetter & Himmel</h1><div id="deviceTitle"></div><div id="status">Verbinde mit dem Gerät …</div></div><button onclick="document.getElementById('settings').showModal()">⚙ Menü</button></header><p id="controlstatus" class="small" role="status" aria-live="polite"></p><p class="small" id="swipehint">Wetter / Himmel · zum Wechseln nach links oder rechts wischen</p>
<nav id="mainNav"><button data-v="0" onclick="changeView(0)">Wetter</button><button data-v="1" onclick="changeView(1)">Himmel</button><button data-v="2" onclick="changeView(2)">Flugzeug</button><button onclick="$('settings').showModal()">Einstellungen</button></nav><section id="weather" class="panel weather"><div class="hero"><div class="symbol" id="symbol">☁</div><div><div class="temp" id="temp">—</div><div id="feels"></div></div></div><h2 id="condition">Warte auf Internetdaten</h2><p id="metrics"></p><h3>7-TAGE-VORHERSAGE</h3><p class="small">Wettersymbol antippen für den Tagesbericht.</p><table><thead><tr><th>Tag</th><th></th><th>Min</th><th>Max</th><th>Regen</th><th aria-label="Details"></th></tr></thead><tbody id="forecast"></tbody></table><p class="small" id="weatherstamp"></p><div id="weathererror"></div></section>
<section id="sky" class="panel hidden"><h2>Heutiger Himmel</h2><p id="skystatus" class="small" role="status">Sterne werden geladen …</p><canvas id="skyCanvas" width="448" height="448"></canvas><div class="zoomtools"><button id="zoomOut" aria-label="Himmelskarte verkleinern" onclick="zoomBy(1/1.4)">−</button><span id="zoomLevel" aria-live="polite">1,0×</span><button id="zoomIn" aria-label="Himmelskarte vergrößern" onclick="zoomBy(1.4)">+</button><button onclick="resetZoom()">Gesamtkarte</button><button id="skyExpand" onclick="expandSky()">Karte vergrößern</button></div><p class="small" id="gesturehint"></p><p id="skyinfo"></p><p class="small">◯ Goldener Ring: bei klarem Himmel möglicherweise mit bloßem Auge sichtbar. Keine Garantie – Helligkeit, Lichtverschmutzung und freie Sicht werden nicht berechnet.</p><details><summary>Karte lesen</summary><p class="small">Gesamtkarte: Norden oben · Osten links · Kartenmitte direkt über dir. Beim Verschieben zeigt die Mitte den gewählten Ausschnitt. Milchstraße als schematischer Verlauf. Objekte antippen für Details.</p></details><details><summary>Objekte & Kartenhilfe</summary><div id="objects"></div><p class="small">Die Satellitenfarben kennzeichnen den Horizontstatus, keine garantierte Sichtbarkeit.</p></details><h3>ISS · Tiangong · Hubble · Starlink</h3><div id="satlist" class="satgrid"></div><p id="satpause"></p><button id="satresume" onclick="act({action:'satResume'})">Abruf fortsetzen</button><details><summary>Überflüge & Sichtbarkeit</summary><h3>Nächster möglicherweise sichtbarer Überflug</h3><p id="possiblePass"></p><p class="small">Nur die vier ausgewählten Satelliten. Sonnenlicht und Dämmerung geprüft, keine Sichtbarkeitsgarantie. Raster 30 s.</p><p class="small">Geometrische Überflüge, Raster 30 Sekunden. Keine Garantie optischer Sichtbarkeit; Erdschatten und Dämmerung werden für die aktuelle Position geprüft. Helligkeit und Wolken werden nicht bewertet. Nur Bahndaten bis 7 Tage Alter. Starlink wird regelmäßig aus gültigen Bahndaten neu ausgewählt.</p></details></section>
<details id="explore"><summary>Himmel entdecken · Suche & Favoriten</summary><div id="favoriteList" class="row"></div>
<label>Planet oder Stern suchen<input id="objectSearch" maxlength="40" placeholder="z. B. Saturn oder Sirius"></label>
<div class="row"><button onclick="findObjects()">Suchen</button><button onclick="$('objectSearch').value='';findObjects()">Heute sichtbar</button></div>
<p class="small">„Heute sichtbar“ zeigt Planeten, die jetzt über dem Horizont stehen. Tageslicht und Wolken können die Sicht verhindern.</p><div id="objectResults" role="status"></div>
<button onclick="act({action:'highlight',id:-1})">Markierung entfernen</button></details>
<p id="observingWeather" class="small"></p><details><summary>Beobachtungswetter · nächste Stunden</summary><p id="hourlyStatus" class="small"></p><div id="hourlyList" class="hours"></div></details><!--MODERN_HTML-->
<details><summary>Karte und automatischer Nachtmodus</summary>
<form id="extrasForm"><label class="check"><input id="largeMap" type="checkbox">Größere Karte, Satellitenkarten ausblenden</label>
<label class="check"><input id="trails" type="checkbox">Berechnete Flugbahn: nächste zwei Minuten</label>
<label class="check"><input id="autoNight" type="checkbox">Display automatisch dimmen und rot darstellen</label>
<div class="row"><label>Beginn<input id="nightStart" type="time" required></label><label>Ende<input id="nightEnd" type="time" required></label></div>
<label>Nachthelligkeit (10–100)<input id="nightDim" type="number" min="10" max="100" required></label><button>Speichern</button></form>
<p class="small">Zeiten gelten am eingestellten Standort. Gleiche Start- und Endzeit deaktivieren das Nachtintervall. Safari-Nachtansicht bleibt separat steuerbar.</p></details>
<details><summary>Sicherung und Firmware</summary>
<p class="small">Die Konfigurationssicherung enthält WLAN-Passwörter im Klartext. Privat aufbewahren. SD-Katalog, Touchkalibrierung und Firmware sind nicht enthalten.</p>
<button onclick="exportConfig()">Einstellungen herunterladen</button>
<label>Sicherung wiederherstellen<input id="configFile" type="file" accept=".json,application/json"></label><button onclick="restoreConfig()">Gewählte Sicherung einlesen</button>
<p id="otaInfo" class="small"></p><label>Neue Firmware (.ino.bin)<input id="firmwareFile" type="file" accept=".bin"></label><button id="firmwareButton" onclick="uploadFirmware()">Firmware hochladen</button>
<progress id="firmwareProgress" max="100" value="0"></progress><p id="maintenanceStatus" role="status"></p>
<p class="small">Erste Installation dieser Version mit neuen Partitionen per USB. Später nur passende WetterHimmel.ino.bin verwenden, keine Bootloader-/merged-Datei. Während des Updates Stromversorgung beibehalten.</p></details>
<dialog id="settings"><h2>Einstellungen</h2><nav><button type="button" data-v="0" onclick="changeView(0)">WETTER</button><button type="button" data-v="1" onclick="changeView(1)">HIMMEL</button></nav><button onclick="$('settings').close()">Schließen</button><details open><summary>Standorte</summary><div id="places"></div><button onclick="editPlace(-1)">Standort hinzufügen</button><form id="placeform" class="hidden"><input id="placeid" type="hidden"><label>Name<input id="pname" maxlength="39" required></label><div class="row"><label>Breite<input id="lat" type="number" step="any" min="-90" max="90" required></label><label>Länge<input id="lon" type="number" step="any" min="-180" max="180" required></label></div><label>Höhe über Meer (m)<input id="height" type="number" min="-500" max="9000" required></label><label>Zeitzone<select id="tzPreset"><option value="CET-1CEST,M3.5.0,M10.5.0/3">Bern / Prag / Mitteleuropa</option><option value="GMT0BST,M3.5.0/1,M10.5.0">London</option><option value="UTC0">UTC</option><option value="EST5EDT,M3.2.0,M11.1.0">New York</option><option value="custom">Eigene POSIX-Zeitzone</option></select></label><input id="tz" maxlength="79" required><p class="small">POSIX-Regel statt IANA-Name; Standard enthält automatische Sommerzeit. Die Koordinaten bestimmen den Himmel.</p><button class="primary">Speichern</button></form></details>
<details><summary>WLAN</summary><p id="wifiinfo"></p><button onclick="act({action:'scan'})">Netze suchen</button><div id="networks"></div><form id="wifiform"><label>WLAN-Name<input id="ssid" maxlength="32" autocomplete="off" required></label><label>Passwort<input id="password" type="password" maxlength="63" autocomplete="new-password"></label><button type="button" id="showpass" onclick="const p=document.getElementById('password');p.type=p.type==='password'?'text':'password';this.textContent=p.type==='password'?'Passwort anzeigen':'Passwort verbergen'">Passwort anzeigen</button><button class="primary">Speichern und verbinden</button></form><h3>Gespeicherte Netze</h3><div id="savedwifi"></div><p class="small">Nur 2,4 GHz. Bei iPhone-Hotspot gegebenenfalls „Kompatibilität maximieren“ einschalten. Das Einrichtungsnetz WetterWeltall bleibt erreichbar; sein Passwort steht auf dem Display unter WLAN → Gespeicherte.</p></details>
<details><summary>Anzeige</summary><label class="check"><input id="appNight" type="checkbox" onchange="setAppNight(this.checked)">Nachtansicht nur in dieser App</label><label class="check" style="margin:14px 0"><input id="displayNight" type="checkbox" onchange="act({action:'display',nightDisplay:this.checked})">Nachtansicht auf dem Display</label><p class="small">Getrennte Einstellungen. Am Display werden Farben und Beleuchtung gedimmt; die normale Helligkeit bleibt gespeichert.</p><label>Helligkeit<input id="brightness" type="range" min="20" max="255" onchange="act({action:'display',brightness:+this.value})"></label><label>Automatischer Seitenwechsel<select id="auto" onchange="act({action:'display',autoSeconds:+this.value})"><option value="0">Aus</option><option value="15">15 Sekunden</option><option value="30">30 Sekunden</option><option value="60">60 Sekunden</option></select></label><div id="layers"></div></details><details><summary>Starlink-Katalog</summary><p id="catalogphase" role="status"></p><progress id="catalogprogress" style="width:100%" max="100"></progress><pre id="cataloginfo" style="white-space:pre-wrap;overflow-wrap:anywhere"></pre><p id="catalogerror" class="error"></p><p id="catalogavailability" class="small"></p><button id="catalogrefresh" onclick="act({action:'starlinkRefresh'})">Katalog aktualisieren</button><details><summary>CSV-Datei importieren</summary><p class="small">Ersatzweg ohne HTTPS-Verbindung des Geräts: Starlink-CSV auf dem Handy oder Mac speichern und hier auswählen. Der bisherige Katalog bleibt bis zur erfolgreichen Prüfung erhalten. Gerätezeit und SD-Karte müssen bereit sein.</p><a href="https://celestrak.org/NORAD/elements/gp.php?GROUP=starlink&amp;FORMAT=CSV" target="_blank" rel="noreferrer">Starlink-CSV bei CelesTrak öffnen</a><p class="small">Nur bei Bedarf herunterladen, höchstens einmal pro Aktualisierung (2 Stunden). Eine bereits gespeicherte Datei kann erneut importiert werden. Die Dateiübertragung an dein Gerät hebt keine Abrufsperre auf.</p><input type="file" id="catalogfile" accept=".csv,text/csv"><button id="catalogimport" onclick="importCatalog()">CSV auf Gerät übertragen</button><button id="catalogcancel" class="hidden" onclick="cancelCatalogImport()">Import abbrechen</button><p id="cataloguploadstatus" role="status" aria-live="polite"></p></details><p class="small">Bahndaten werden auf der SD-Karte gespeichert. Automatisch alle 6 Stunden; bei Abruffehlern mindestens 2 Stunden Pause. Eine bestehende Sicherung bleibt bei einem fehlgeschlagenen Download verfügbar. Höchste Position über dem Horizont bedeutet nicht Sichtbarkeit mit bloßem Auge.</p></details><details><summary>Dauerbetrieb</summary><pre id="health" style="white-space:pre-wrap"></pre><a href="/api/health" target="_blank">Messverlauf öffnen / speichern</a><p class="small">Messung seit Neustart. Verlauf: 15-Minuten-Abstände, bis 12 Stunden. Keine automatische Aussage „Dauertest bestanden“.</p></details><details><summary>Diagnose & Quellen</summary><button onclick="act({action:'weatherTest'});toast('Test angefordert; Ergebnis erscheint nach Abschluss unten')">Wetterabruf testen</button><p class="small">Mindestens 30 Sekunden zwischen Tests. Protokolle gelten seit dem letzten Neustart.</p><pre id="diagnostics" style="white-space:pre-wrap;overflow-wrap:anywhere"></pre><p>Wetter: <a href="https://open-meteo.com/" target="_blank" rel="noreferrer">Open-Meteo</a>, CC BY 4.0. Astronomie: Astronomy Engine. Sternkatalog und Linien: d3-celestial. Satelliten: CelesTrak und SGP4.</p><p class="small">Keine Raumtemperaturmessung. Lokale Berechnungen benötigen korrekte Uhrzeit und Standort. Direkte Sonnenbeobachtung nur mit geeignetem Schutz.</p></details></dialog>
<dialog id="detail"><h2 id="detailtitle"></h2><div id="detailart"></div><p id="detailtext" style="white-space:pre-line"></p><button onclick="$('detail').close()">Zurück zu HIMMEL</button></dialog><dialog id="dayDetail"><div class="dayheading"><h2 id="dayTitle"></h2><div id="daySymbol"></div></div><p id="dayText"></p><div id="dayCards" class="daygrid"></div><p id="daySource" class="small"></p><button onclick="$('dayDetail').close()">Zurück zum Wetter</button></dialog><div id="toast" class="hidden" role="status"></div><footer class="small">Wetter & Himmel · Lokale Bedienung · 1.10.0-dev1</footer>
<script>
const $=id=>document.getElementById(id);let state,skyData={stars:[],lines:[],deep:[]},lastSky=0,loading=false,hitSky=[];
function setAppNight(enabled){document.body.classList.toggle('night',enabled);$('appNight').checked=enabled;try{localStorage.setItem('ww-app-night',enabled?'1':'0')}catch(e){}}
try{setAppNight(localStorage.getItem('ww-app-night')==='1')}catch(e){setAppNight(false)}
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function icon(code){
let c=Number(code),shape='';
if(code==null||c<0)shape='<text x="32" y="40" text-anchor="middle" fill="white" font-size="26">?</text>';
else if(c===0)shape='<circle cx="32" cy="30" r="13" fill="#ffd35c"/><path d="M32 5v7m0 36v7M7 30h7m36 0h7M14 12l5 5m26 26 5 5M14 48l5-5m26-26 5-5" stroke="#ffd35c" stroke-width="3"/>';
else if(c===45||c===48)shape='<path d="M12 20h40M6 29h46M14 38h44M7 47h42" stroke="#c6d9e6" stroke-width="5" stroke-linecap="round"/>';
else {if(c<3)shape+='<circle cx="22" cy="20" r="12" fill="#ffd35c"/>';shape+='<path d="M15 39a10 10 0 0 1 0-20 15 15 0 0 1 28-1 11 11 0 1 1 6 21Z" fill="#dae8f1"/>';
if(c>=95)shape+='<path d="M34 37l-9 14h9l-5 11 17-17H35l6-8" fill="#ffd35c"/>';
else if((c>=71&&c<=77)||c===85||c===86)shape+='<g fill="white"><circle cx="20" cy="48" r="3"/><circle cx="34" cy="54" r="3"/><circle cx="47" cy="48" r="3"/></g>';
else if(c>=51)shape+='<path d="M20 45l-4 9m18-9-4 9m18-9-4 9" stroke="#6cd8ff" stroke-width="4" stroke-linecap="round"/>';}
return '<svg class="weatherIcon" viewBox="0 0 64 64" aria-hidden="true">'+shape+'</svg>';}

const num=v=>typeof v==='number'&&Number.isFinite(v)?Math.round(v):'—';
function toast(t){$('toast').textContent=t;$('toast').classList.remove('hidden');setTimeout(()=>$('toast').classList.add('hidden'),6000)}
let actionTail=Promise.resolve(),controlRevision=0,readRevision=0,controlBusy=0,desiredView=null;
let controlTimer=null;const controlErrors=new Map();
function controlStatus(text,kind='progress',key='general'){
 clearTimeout(controlTimer);
 if(kind==='error')controlErrors.set(key,text);
 if(kind==='success')controlErrors.delete(key);
 if(controlErrors.size){$('controlstatus').textContent=Array.from(controlErrors.values()).join(' · ');$('controlstatus').dataset.kind='error';return;}
 $('controlstatus').textContent=text;$('controlstatus').dataset.kind=kind;
 if(kind==='success')controlTimer=setTimeout(()=>{$('controlstatus').textContent='';},3500);
}
function showView(v){if(!state)return;state.view=v;['weather','sky','aircraft'].forEach((n,i)=>$(n).classList.toggle('hidden',i!==v));document.querySelectorAll('[data-v]').forEach(b=>b.classList.toggle('active',+b.dataset.v===v));if(v===1)skyDraw();}
function changeView(v){flushCamera();$('settings').close();return act({action:'view',value:v});}
async function fetchTimed(url,options={}){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);try{const r=await fetch(url,{...options,signal:controller.signal});const body=typeof r.text==='function'?await r.text():JSON.stringify(await r.json());return {ok:r.ok,status:r.status,blob:async()=>new Blob([body],{type:'application/json'}),json:async()=>{if(/^\s*</.test(body))throw Error('Gerät liefert eine Webseite statt API-Daten ('+url+', HTTP '+r.status+'). Verbindung prüfen und Seite neu laden.');return JSON.parse(body)},text:async()=>body};}finally{clearTimeout(timer)}}
async function postCommand(d){
 for(let attempt=0;attempt<2;attempt++){
  const r=await fetchTimed('/api/action',{method:'POST',headers:{'Content-Type':'application/json','X-WW-Token':state.token},body:JSON.stringify(d)});
  if(r.status===403&&attempt===0){const fresh=await fetchTimed('/api/state',{cache:'no-store'});if(!fresh.ok)throw Error('Gerät nicht erreichbar');const data=await fresh.json();state.token=data.token;continue;}
  if(!r.ok)throw Error(await r.text());return await r.json();
 }
 throw Error('Bitte Seite neu laden');
}
function act(d){
 if(!state){controlStatus('Verbindung wird aufgebaut – bitte kurz warten.');return Promise.resolve(false);}
 if(['view','placeSelect','placeSave','display'].includes(d.action))lastSky=0;
 const revision=++controlRevision;readRevision++;
 if(d.action==='view'){desiredView=d.value;showView(d.value);controlStatus('Ansicht in App gewechselt · übertrage auf Display …');}
 controlBusy++;
 const task=actionTail.then(async()=>{
  try{const ack=await postCommand(d);
   if(revision===controlRevision){
    if(d.action==='view'){desiredView=null;showView(Number.isInteger(ack.view)?ack.view:d.value);}
    if(d.action==='skyCamera'){showView(1);}
    controlStatus(d.action==='skyCamera'?(cameraPending?'Weitere Zoomänderung wartet auf Übertragung …':'Zoom und Ausschnitt vom Gerät bestätigt'):d.action==='view'?'Ansicht vom Gerät bestätigt':'Änderung vom Gerät bestätigt',d.action==='skyCamera'&&cameraPending?'progress':'success',d.action);
   }
   return true;
  }catch(e){controlStatus((d.action==='view'?'Ansicht nur in der App geändert. ':d.action==='skyCamera'?'Zoom noch nicht übertragen. ':'')+'Gerät: '+(e.name==='AbortError'?'Zeitlimit – bitte erneut versuchen':e.message),'error',d.action);return false;}
  finally{controlBusy--;readRevision++;}
 });
 actionTail=task.catch(()=>{});
 return task.then(async ok=>{if(!controlBusy)await refresh();return ok;});
}
function planetArt(name){
 const palette={Sonne:['#fff3a0','#ffc341','#ed630b'],Mond:['#eff1ed','#a8acb6','#454f62'],Merkur:['#d8c9b4','#948a7f','#403b3b'],Venus:['#fff2c0','#d7ad6d','#85643d'],Mars:['#ffbf87','#c75d3e','#5b241f'],Jupiter:['#fff1d3','#d4a27b','#77594a'],Saturn:['#fff3c8','#d4bc83','#776749'],Uranus:['#d9ffff','#77d0d9','#2b7c96'],Neptun:['#80b8ff','#326aca','#142969']};
 const p=palette[name];if(!p)return '';const ring=name==='Saturn';let texture='';
 if(['Jupiter','Saturn','Venus','Neptun','Uranus'].includes(name)){for(let i=0;i<9;i++){let y=45+i*14;texture+=`<path d="M98 ${y} Q180 ${y+12} 264 ${y-2} L264 ${y+6} Q180 ${y+20} 98 ${y+8}Z" fill="${i%2?'#ffffff':'#573c30'}" opacity="${name==='Jupiter'?.22:.09}"/>`;}}
 if(name==='Jupiter')texture+='<ellipse cx="204" cy="137" rx="18" ry="9" fill="#b96646" opacity=".85"/><ellipse cx="204" cy="136" rx="12" ry="5" fill="#dc9d71"/>';
 if(['Mond','Merkur','Mars'].includes(name)){[[147,76,12],[193,142,17],[214,85,9],[134,122,7],[175,60,6],[178,108,10]].forEach(([x,y,r])=>{texture+=`<circle cx="${x}" cy="${y}" r="${r}" fill="#322a29" opacity=".16"/><path d="M${x-r*.8} ${y}a${r*.8} ${r*.8} 0 0 1 ${r*1.6} 0" fill="none" stroke="#fff" stroke-opacity=".22"/>`});}
 if(name==='Mars')texture+='<path d="M142 48Q179 26 216 50Q186 63 142 48" fill="#f7e5d2" opacity=".8"/>';
 if(name==='Neptun')texture+='<ellipse cx="202" cy="125" rx="17" ry="6" fill="#123c82" opacity=".7"/><path d="M138 102Q165 110 187 102" fill="none" stroke="#e6f7ff" stroke-width="3" opacity=".65"/>';
 const rings='<ellipse cx="180" cy="110" rx="121" ry="34" transform="rotate(-22 180 110)" fill="none" stroke="#c7b69b" stroke-width="15" opacity=".85"/><ellipse cx="180" cy="110" rx="109" ry="29" transform="rotate(-22 180 110)" fill="none" stroke="#f3dfb7" stroke-width="4"/>';
 return `<svg class="planetart" viewBox="0 0 360 220" role="img" aria-label="Illustration: ${name}" xmlns="http://www.w3.org/2000/svg"><defs><radialGradient id="planetbase" cx="32%" cy="27%" r="78%"><stop stop-color="${p[0]}"/><stop offset=".5" stop-color="${p[1]}"/><stop offset="1" stop-color="${p[2]}"/></radialGradient><radialGradient id="planetshade" cx="30%" cy="30%" r="75%"><stop offset=".4" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".7"/></radialGradient><radialGradient id="planethalo"><stop stop-color="${p[1]}" stop-opacity=".3"/><stop offset="1" stop-color="${p[1]}" stop-opacity="0"/></radialGradient><clipPath id="planetclip"><circle cx="180" cy="110" r="72"/></clipPath><clipPath id="ringfront"><path d="M40 155L314 48V220H40Z"/></clipPath></defs><rect width="360" height="220" rx="18" fill="#071126"/><circle cx="180" cy="110" r="108" fill="url(#planethalo)"/><g fill="#bed8f8" opacity=".6"><circle cx="44" cy="45" r="1"/><circle cx="301" cy="37" r="1.5"/><circle cx="325" cy="162" r="1"/><circle cx="70" cy="186" r="1.2"/></g>${ring?rings:''}<circle cx="180" cy="110" r="72" fill="url(#planetbase)"/><g clip-path="url(#planetclip)">${texture}<circle cx="180" cy="110" r="72" fill="url(#planetshade)"/></g>${ring?`<g clip-path="url(#ringfront)">${rings}</g>`:''}</svg><p class="artcaption">Illustration · nicht maßstabsgetreu${name==='Mond'?' · aktuelle Mondphase siehe Himmelskarte':''}</p>`;
}

function detail(name,txt){$('detailart').innerHTML='';$('detailtitle').textContent=name;$('detailtext').textContent=txt;$('detail').showModal()}
function objdetail(o){if(!state.clockReady){detail(o.name,"Warte auf gültige Uhrzeit über WLAN / NTP");return;}detail(o.name,`Richtung ${['N','NO','O','SO','S','SW','W','NW'][Math.round(o.az/45)%8]} / ${o.az.toFixed(1)}°\nHöhenwinkel ${o.alt.toFixed(1)}°\n${o.alt>=0?'Über':'Unter'} dem Horizont\n${o.mag===undefined?'':`Helligkeit ${o.mag.toFixed(1)} mag\n`}Beobachtung abhängig von Wolken, Licht, Horizont und Ausrüstung.`);$('detailart').innerHTML=planetArt(o.name)}
const precise=v=>typeof v==='number'&&Number.isFinite(v)?v.toLocaleString('de-CH',{maximumFractionDigits:1}):'—';
let openDayDate=null;
function daydetail(i){let w=state?.weather,d=w?.days?.[i];if(!w?.valid||!d)return;openDayDate=d.date;renderDay(d);if(!$('dayDetail').open)$('dayDetail').showModal();}
function renderDay(d){let w=state.weather;
 $('dayTitle').textContent=new Date(d.date+'T12:00:00Z').toLocaleDateString('de-CH',{weekday:'long',day:'numeric',month:'long',timeZone:'UTC'});
 $('daySymbol').innerHTML=icon(d.code);$('dayText').textContent=d.text||'Wetterbeschreibung fehlt';
 const pair=(name,value)=>'<dt>'+esc(name)+'</dt><dd>'+esc(value)+'</dd>';
 const card=(name,value,rows)=>'<section class="daygroup"><h3>'+name+'</h3><p class="dayvalue">'+esc(value)+'</p><dl>'+rows+'</dl></section>';
 $('dayCards').innerHTML=
 card('◒ Temperatur',`${num(d.min)} bis ${num(d.max)} °C`,pair('Gefühlt',`${num(d.feelsMin)} bis ${num(d.feelsMax)} °C`))+
 card('☂ Niederschlag',`${precise(d.precipitation)} mm`,pair('Wahrscheinlichkeit, max.',`${typeof d.rain==='number'&&d.rain>=0?d.rain:'—'} %`)+pair('Stunden mit Niederschlag',`${precise(d.precipitationHours)} h`)+pair('Neuschnee',`${precise(d.snow)} cm`))+
 card('↗ Wind',`${num(d.windMax)} km/h`,pair('Maximum · Richtung',d.windDirection||'—')+pair('Böen maximal',`${num(d.gustMax)} km/h`))+
 card('☀ Sonne',`${typeof d.sunshine==='number'?precise(d.sunshine/3600):'—'} h`,pair('Sonnenschein · Aufgang',d.sunrise||'—')+pair('Untergang',d.sunset||'—')+pair('UV-Index maximal',precise(d.uv)));
 $('daySource').textContent=`${state.places[state.place].name} · Open-Meteo · geladen ${w.fetched}. ${w.age>1800?'Veraltete Vorhersage. ':''}${w.error||''} — bedeutet: keine Angabe. Tageswerte, kein Stundenverlauf.`;
}
let skyZoom=1,skyPanX=0,skyPanY=0,cameraPending=false,cameraTimer=null,cameraSerial=0;
function queueCamera(){cameraPending=true;cameraSerial++;controlStatus('Übertrage Zoom und Ausschnitt …');clearTimeout(cameraTimer);cameraTimer=setTimeout(flushCamera,180);}
function flushCamera(){clearTimeout(cameraTimer);cameraTimer=null;if(!cameraPending||!state)return;const serial=cameraSerial;cameraPending=false;act({action:'skyCamera',zoom:skyZoom,panX:skyPanX,panY:skyPanY}).then(ok=>{if(!ok&&serial===cameraSerial){cameraPending=true;controlStatus('Zoom noch nicht übertragen · Plus/Minus oder Gesamtkarte erneut tippen','error','skyCamera');}});}
function receiveCamera(c){if(!c||cameraPending||controlBusy||skyGesture)return;if(!Number.isFinite(c.zoom)||!Number.isFinite(c.panX)||!Number.isFinite(c.panY))return;skyZoom=Math.max(1,Math.min(4,c.zoom));skyPanX=c.panX;skyPanY=c.panY;clampCamera();}
function clampCamera(){const bound=108*(skyZoom-1);skyPanX=Math.max(-bound,Math.min(bound,skyPanX));skyPanY=Math.max(-bound,Math.min(bound,skyPanY));$('zoomLevel').textContent=skyZoom.toFixed(1).replace('.',',')+'×';$('zoomOut').disabled=skyZoom<=1;$('zoomIn').disabled=skyZoom>=4;$('gesturehint').textContent=skyZoom>1?'Zoom '+skyZoom.toFixed(1).replace('.',',')+'× · Ein Finger verschiebt die Karte. Seitenwechsel außerhalb der Karte.':'Gesamtkarte · Wischen wechselt Wetter / Himmel. Zwei Finger vergrößern.';}
function zoomBy(factor){skyZoom=Math.max(1,Math.min(4,skyZoom*factor));clampCamera();skyDraw();queueCamera();}
function resetZoom(){skyZoom=1;skyPanX=skyPanY=0;clampCamera();skyDraw();queueCamera();}
function mapFromScreen(x,y){return [160+(x-160-skyPanX)/skyZoom,174+(y-174-skyPanY)/skyZoom];}
function canvasPoint(t){let r=$('skyCanvas').getBoundingClientRect();return [48+(t.clientX-r.left)*224/r.width,62+(t.clientY-r.top)*224/r.height];}
function point(az,alt){let r=(90-alt)/90*108,a=az*Math.PI/180;return [160-r*Math.sin(a),174-r*Math.cos(a)]}
function setupCanvas(id){let c=$(id).getContext('2d');c.setTransform(2,0,0,2,-96,-124);c.fillStyle='#030914';c.fillRect(48,62,224,224);c.translate(160+skyPanX,174+skyPanY);c.scale(skyZoom,skyZoom);c.translate(-160,-174);c.font='11px sans-serif';return c}
function skyDraw(id='skyCanvas'){if(!state||$('settings').open)return;const c=setupCanvas(id);hitSky=[];if(!state.clockReady){c.fillStyle="white";c.fillText("Warte auf Uhrzeit über WLAN / NTP",24,170);return;}c.strokeStyle='#6eb5e8';for(let r of [108]){c.beginPath();c.arc(160,174,r,0,7);c.stroke()}c.fillStyle='#fff';[['N',157,79],['S',157,277],['O',55,178],['W',253,178]].forEach(a=>c.fillText(...a));
 if(state.lines){c.strokeStyle='#284561';skyData.lines.forEach(([x,y,a,b])=>{c.beginPath();c.moveTo(x,y);c.lineTo(a,b);c.stroke()})}if(state.milky&&skyData.mw){c.strokeStyle='#18263c';c.lineWidth=9;c.lineCap='round';let prev=null;skyData.mw.forEach(p=>{if(!p){prev=null;return;}if(prev){c.beginPath();c.moveTo(...prev);c.lineTo(...p);c.stroke()}prev=p});c.lineWidth=1;}c.fillStyle='#e9f6ff';skyData.stars.forEach(([x,y,m,az,alt,id,name])=>{c.fillStyle=m<3.5?'#edf6ff':'#687e98';hitSky.push({x,y,o:{name:name||'Stern',az,alt,mag:m}});c.beginPath();c.arc(x,y,m<1.5?1.4:m<3.5?.85:.6,0,7);c.fill();if(m<1.5){c.strokeStyle='#355981';c.beginPath();c.arc(x,y,2.8,0,7);c.stroke()}});

 skyData.deep.forEach(o=>{c.strokeStyle='#d797f4';c.strokeRect(o.x-3,o.y-3,6,6);hitSky.push({x:o.x,y:o.y,o})});
 const boxes=[];if(state.labels){c.fillStyle='#78a7d5';c.font='10px sans-serif';(skyData.constellations||[]).slice(0,5).forEach(([x,y,name])=>{c.fillText(name,x,y);boxes.push({x,y,w:c.measureText(name).width})});c.font='11px sans-serif';}const visible=[...state.objects,...(state.satellites?state.sats.filter(o=>o.valid&&(!o.starlink||state.starlink)):[])].filter(o=>o.alt>=0);
 function mapLabel(o,x,y){const w=c.measureText(o.name).width;for(const [dx,dy] of [[9,-8],[9,16],[-w-9,-8],[-w-9,16]]){let xx=x+dx,yy=y+dy;if(xx<52||xx+w>269||yy<84||yy>265)continue;if(boxes.some(b=>xx<b.x+b.w+3&&xx+w+3>b.x&&yy-11<b.y+3&&yy+3>b.y-11))continue;if(visible.some(q=>{let [a,b]=point(q.az,q.alt);return a>xx-5&&a<xx+w+5&&b>yy-16&&b<yy+5}))continue;const ink=c.fillStyle;c.fillStyle='#081321';c.fillRect(xx-3,yy-12,w+6,16);c.fillStyle=ink;c.fillText(o.name,xx,yy);boxes.push({x:xx,y:yy,w});break;}}
 visible.forEach(o=>{let [x,y]=point(o.az,o.alt);const color=({Sonne:'#ffe449',Mond:'#edf3ff',Merkur:'#bdbdbd',Venus:'#ffefce',Mars:'#fa783d',Jupiter:'#e5af6f',Saturn:'#e9d699',Uranus:'#72e1e8',Neptun:'#5684ff'})[o.name]||'#63d8ff';c.fillStyle=color;if(o.catalog){if(sightCandidate(o)){c.strokeStyle='#ffe449';c.lineWidth=1.5;c.beginPath();c.arc(x,y,14,0,Math.PI*2);c.stroke();c.lineWidth=1;}c.fillRect(x-2,y-4,4,8);c.fillStyle=o.starlink?'#ffe449':'#29caff';c.fillRect(x-10,y-3,6,6);c.fillRect(x+4,y-3,6,6);}else if(o.name==='Mond'){let a=Math.acos(1-2*state.moon/100)*(state.moonWaxing?1:-1);for(let yy=-6;yy<=6;yy++)for(let xx=-6;xx<=6;xx++){let z=1-(xx*xx+yy*yy)/36;if(z<0)continue;c.fillStyle=xx/6*Math.sin(a)-Math.sqrt(z)*Math.cos(a)>0?'#e6ebf2':'#343e51';c.fillRect(x+xx,y+yy,1,1)}}else{if(o.name==='Saturn'){c.strokeStyle=color;c.lineWidth=1.2;c.beginPath();c.ellipse(x,y,12,4,-.35,0,7);c.stroke();c.lineWidth=1;}c.beginPath();c.arc(x,y,6,0,7);c.fill();c.fillStyle='#ffffff55';c.beginPath();c.arc(x-1.5,y-1.5,2,0,7);c.fill();}c.fillStyle=o.catalog?(o.starlink?'#ffe449':'#63d8ff'):color;if(state.labels)mapLabel(o,x,y);hitSky.push({x,y,o,primary:true})});skyOverlays(c);}
$('skyCanvas').onclick=e=>{if(Date.now()<suppressClickUntil)return;let [sx,sy]=canvasPoint(e),[x,y]=mapFromScreen(sx,sy);let hits=hitSky.filter(h=>Math.hypot(h.x-x,h.y-y)<(h.primary?24:12)/skyZoom);hits.sort((a,b)=>(b.primary?1:0)-(a.primary?1:0)||Math.hypot(a.x-x,a.y-y)-Math.hypot(b.x-x,b.y-y));let h=hits[0];if(h){if(h.o.catalog)satdetail(h.o.index);else objdetail(h.o)}};
async function refresh(){if(loading||controlBusy)return;loading=true;const revision=readRevision,requestStarted=performance.now();try{
 const r=await fetchTimed('/api/state',{cache:'no-store'});if(r.status===503){$('status').textContent='Datenabruf läuft · Anzeige bleibt erhalten';return;}if(!r.ok)throw Error('Gerät nicht erreichbar');const fresh=await r.json();
 if(revision!==readRevision)return;
 state=fresh;for(const sat of state.sats||[])sat.sightUntil=requestStarted+Math.max(0,Math.min(20,Number(sat.sightSeconds)||0))*1000;if(desiredView!==null)state.view=desiredView;receiveCamera(state.skyCamera);render();
 if(state.view===1&&!$('settings').open&&Date.now()-lastSky>25000){try{const r=await fetchTimed('/api/sky',{cache:'no-store'});if(r.status===503){$('skystatus').textContent='Datenabruf läuft · Karte bleibt erhalten';return;}if(!r.ok)throw Error('HTTP '+r.status);const next=await r.json();if(!Array.isArray(next.stars)||!Array.isArray(next.lines)||!Array.isArray(next.deep))throw Error('Unvollständige Kartendaten');if(revision===readRevision){skyData=next;lastSky=Date.now();$('skystatus').textContent=next.stars.length?'':'Keine Sterne empfangen · neuer Versuch folgt';if(!next.stars.length)lastSky=0;skyDraw();}}catch(e){$('skystatus').textContent='Sternkarte konnte nicht aktualisiert werden · erneuter Versuch';$('skystatus').title=e.message;}}
 }catch(e){$('status').textContent='Verbindung unterbrochen – erneuter Versuch';$('status').title=e.message;}finally{loading=false}}
$('settings').addEventListener('close',()=>{skyDraw();refresh();});
const htmlCache=new Map();
function setHtmlIfChanged(id,html){if(htmlCache.get(id)===html)return;$(id).innerHTML=html;htmlCache.set(id,html);}
function render(){renderExtras();renderModern();let s=state,w=s.weather;$('displayNight').checked=!!s.nightDisplay;if($('dayDetail').open){let d=w.valid&&w.days.find(d=>d.date===openDayDate);if(d)renderDay(d);else{$('dayDetail').close();openDayDate=null;}}let h=s.health;$('health').textContent=h?`Laufzeit: ${(h.uptime/3600).toFixed(1)} h\nWLAN-Abbrüche: ${h.disconnects}\nWLAN-Verbindungen: ${h.connections}\nWetter: ${h.weatherOK} erfolgreich / ${h.weatherFailed} fehlgeschlagen\nStarlink: ${h.catalogOK} erfolgreich / ${h.catalogFailed} fehlgeschlagen\nFreier Heap: ${h.heap} Byte\nKleinster beobachteter großer Block: ${h.minBlock} Byte\nLängste Schleifenpause: ${h.maxLoopMs} ms\nMesspunkte: ${h.samples}\nReset-Ursache (ESP-Code): ${h.resetReason}`:'Warte auf Messwerte';renderCatalog(s.starlinkCatalog);$('status').textContent=`${s.places[s.place].name} · ${s.time} · ${s.connected?'WLAN':'Einrichtungsnetz'}`;['weather','sky','aircraft'].forEach((n,i)=>$(n).classList.toggle('hidden',i!==s.view));document.querySelectorAll('[data-v]').forEach(b=>b.classList.toggle('active',+b.dataset.v===s.view));setHtmlIfChanged('symbol',icon(w.valid?w.code:-1));$('temp').textContent=w.valid?num(w.temp)+'°C':'—';$('feels').textContent=w.valid?'Gefühlt '+num(w.feels)+'°C':'';$('condition').textContent=w.valid?w.text:'Warte auf Internetdaten';$('metrics').textContent=w.valid?`Feuchte ${num(w.humidity)}% · Wind ${w.direction} ${num(w.wind)} km/h`:'';
 setHtmlIfChanged('forecast',w.valid?w.days.map((d,i)=>`<tr class="${i===0?'today':''}"><td>${i===0?'Heute':['So','Mo','Di','Mi','Do','Fr','Sa'][new Date(d.date+'T12:00:00Z').getUTCDay()]}</td><td><button class="dayIcon" onclick="daydetail(${i})" aria-label="Tagesbericht ${esc(d.date)}">${icon(d.code)}</button></td><td>${num(d.min)}°</td><td>${num(d.max)}°</td><td>${d.rain<0?'—':d.rain+'%'}</td><td><button class="dayArrow" onclick="daydetail(${i})" aria-label="Tagesbericht ${esc(d.date)}">›</button></td></tr>`).join(''):'');$('weatherstamp').textContent=w.valid?`Internetwetter · geladen ${w.fetched} · Datenzeit ${w.observed}`:'';$('weathererror').className=w.error||w.age>1800?'error':'';$('weathererror').textContent=[w.age>1800?'Veraltete Wetterdaten':null,w.error].filter(Boolean).join(' · ');
 $('skyinfo').textContent=!s.clockReady?'Warte auf WLAN / NTP':`Mond ${s.moon}% · ${s.moonWaxing?'zunehmend':'abnehmend'} · Nächster Sonnenaufgang ${s.sunrise} · Untergang ${s.sunset}`;
 setHtmlIfChanged('objects',(s.clockReady?s.objects:[]).map((o,i)=>`<button onclick="objdetail(state.objects[${i}])" style="margin:3px">${esc(o.name)} · ${o.alt.toFixed(0)}°</button>`).join(''));setHtmlIfChanged('satlist',['ISS','Tiangong','Hubble','Starlink'].map((name,i)=>`<button class="satcard ${satTone(s.sats[i])}" onclick="satdetail(${i})"><span class="saticon">${i===2?'🔭':'🛰️'}</span><span><b>${name}</b><small>${i===3&&!s.sats[i].valid?esc(s.starlinkStatus):satstatus(s.sats[i])}</small></span><span>›</span></button>`).join(''));$('satpause').textContent=s.satPaused?`${s.satPauseReason} · Frühestens ${s.satHoldUntil}`:'Automatischer Abruf · gespeicherte Bahndaten werden weiterverwendet';$('satresume').classList.toggle('hidden',!s.satPaused);skyDraw();
 setHtmlIfChanged('places',s.places.map(p=>`<div class="row"><button onclick="act({action:'placeSelect',id:${p.id}})">${p.id===s.place?'✓ ':''}${esc(p.name)}</button><button onclick="editPlace(${p.id})">Bearbeiten</button><button onclick="if(confirm('Standort löschen?'))act({action:'placeDelete',id:${p.id}})">×</button></div>`).join(''));$('wifiinfo').textContent=s.message+' · '+s.ip;setHtmlIfChanged('networks',s.networks.map((n,i)=>`<button style="margin:3px" onclick="$('ssid').value=state.networks[${i}];$('password').focus()">${esc(n)}</button>`).join(''));setHtmlIfChanged('savedwifi',s.wifi.map(p=>`<div class="row"><button onclick="act({action:'wifiConnect',id:${p.id}})">${esc(p.ssid)}</button><button onclick="if(confirm('WLAN löschen?'))act({action:'wifiDelete',id:${p.id}})">Löschen</button></div>`).join(''));if(document.activeElement!==$('brightness'))$('brightness').value=s.brightness;if(document.activeElement!==$('auto'))$('auto').value=s.autoSeconds;
 setHtmlIfChanged('layers',[['labels','Objektnamen'],['lines','Sternbildlinien'],['milky','Milchstraße'],['satellites','Satelliten'],['starlink','Starlink automatisch']].map(([k,n])=>`<label class="check" style="margin:14px 0"><input type="checkbox" ${s[k]?'checked':''} onchange="act({action:'display',${k}:this.checked})">${n}</label>`).join(''));$('diagnostics').textContent=`Version ${s.version}\n${s.connected?'WLAN verbunden: '+s.ssid:'Keine Verbindung zum WLAN-Router'}\nWLAN-Status: ${s.wifiStatus??'—'} · Signal: ${s.rssi==null?'—':s.rssi+' dBm'}\nNTP: ${s.clockReady?'Uhrzeit vorhanden':'wartet'}\nFreier Heap: ${s.heap} Byte\nMinimum Heap: ${s.minHeap} Byte\nWetteralter: ${w.age} Sekunden\n${w.error}\nStarlink: ${s.starlinkStatus}\nKatalog: ${s.starlinkCount} Satelliten\nSuchlauf: ${s.starlinkScanMs} ms\n\nLETZTER WETTERABRUF\n${s.weatherDiagnostic||'Noch kein Diagnoseprotokoll'}\nLETZTER FEHLGESCHLAGENER ABRUF\n${s.weatherLastFailure||'Noch kein Fehlerprotokoll'}`;}
function catalogText(c){if(!c)return 'Katalogdiagnose noch nicht verfügbar';return `SD-Karte: ${c.sdReady?'erkannt':'nicht bereit'}
Gespeichert: ${c.stored} Satelliten${c.backup?' (Sicherung)':''}
Für letzten Suchlauf nutzbar: ${c.usable}
Katalog geladen: ${c.fetched}
Empfangen: ${(c.bytes/1024).toFixed(1)} KB${c.total?' / '+(c.total/1024).toFixed(1)+' KB':''}
Neue Einträge: ${c.accepted} · übersprungen: ${c.rejected}
Letzter HTTPS-Abruf (gespeichert): ${c.attemptAt}
HTTPClient: ${c.lastHttp??c.http} · TLS: ${c.lastTls??c.tls}${(c.lastTls??c.tls)?' · '+(c.lastTlsText||c.tlsText||''):''}
Letzter Abruffehler: ${c.lastError||'Keiner gespeichert'}
${c.interrupted?'Abruf ohne protokollierten Abschluss · Wartezeit bleibt erhalten':c.restored?'Abrufdiagnose aus vorherigem Start geladen':''}
Nächster Abruf: ${c.next}
Grund: ${c.waitReason||'Noch kein gespeicherter Abrufgrund'}`}
let catalogUploadActive=false,catalogUploadCancel=false;
function cancelCatalogImport(){catalogUploadCancel=true;$('cataloguploadstatus').textContent='Import wird abgebrochen …';}
async function importCatalog(){
 if(catalogUploadActive)return;
 const file=$('catalogfile').files[0],status=$('cataloguploadstatus');
 if(!file||!file.size||file.size>30000000){status.textContent='Bitte eine CSV-Datei mit höchstens 30 MB auswählen.';return;}
 if(!state){status.textContent='Bitte auf die Geräteverbindung warten.';return;}
 catalogUploadActive=true;catalogUploadCancel=false;$('catalogcancel').classList.remove('hidden');
 $('catalogimport').disabled=true;$('catalogfile').disabled=true;$('catalogrefresh').disabled=true;
 let session=0,heldControl=false;
 const call=async(query,body)=>{const r=await fetchTimed('/api/starlink/import?'+query,{method:'POST',headers:{'X-WW-Token':state.token,'Content-Type':'application/octet-stream'},body:body||''});if(!r.ok)throw Error(await r.text());return r.json();};
 try{
  await actionTail;controlBusy++;heldControl=true;readRevision++;
  status.textContent='Import vorbereiten …';
  session=(await call('op=start&size='+file.size)).session;
  for(let offset=0;offset<file.size;offset+=4096){
   if(catalogUploadCancel)throw Error('Import abgebrochen.');
   const block=await file.slice(offset,Math.min(file.size,offset+4096)).arrayBuffer();
   const result=await call('op=chunk&id='+session+'&offset='+offset,block);
   if(result.received!==Math.min(file.size,offset+4096))throw Error('Übertragung nicht vollständig bestätigt.');
   status.textContent='Übertragen: '+Math.floor(result.received*100/file.size)+' %';
  }
  if(catalogUploadCancel)throw Error('Import abgebrochen.');
  await call('op=finish&id='+session);session=0;status.textContent='CSV-Katalog geprüft und gespeichert.';
 }catch(e){
  status.textContent='Import nicht bestätigt: '+e.message+' Der zuletzt gültige Katalog bleibt erhalten.';
  if(session)try{await call('op=cancel&id='+session);}catch(ignore){}
 }finally{
  if(heldControl)controlBusy=Math.max(0,controlBusy-1);readRevision++;catalogUploadActive=false;
  $('catalogcancel').classList.add('hidden');$('catalogfile').disabled=false;
  await refresh();$('catalogimport').disabled=!state?.starlinkCatalog?.canImport;
 }
}
function renderCatalog(c){$('catalogphase').textContent=c?.phase==='Noch kein Download'?'Seit Neustart kein Download · gespeicherte Wartezeit gilt':c?.phase||'Warte auf Katalogstatus';$('cataloginfo').textContent=catalogText(c);$('catalogerror').textContent=c?.error||'';$('catalogerror').classList.toggle('hidden',!c?.error);$('catalogrefresh').disabled=!c?.canRefresh||catalogUploadActive;$('catalogimport').disabled=catalogUploadActive||!c?.canImport;$('catalogfile').disabled=catalogUploadActive;$('catalogavailability').textContent=c?.busy?(c.importing?'Dateiimport läuft':'Download läuft'):state.satPaused?'Abrufe pausiert: '+state.satPauseReason:!state.starlink?'Starlink unter Anzeige einschalten':!state.connected?'WLAN-Verbindung erforderlich':!state.clockReady?'Warte auf Uhrzeit':c?.canRefresh?'Abruf möglich':'Wartezeit bis '+(c?.next||'zum nächsten Abruf');let p=$('catalogprogress');p.hidden=!c?.busy;if(c?.total)p.value=Math.min(100,c.bytes/c.total*100);else p.removeAttribute('value');}
function sightCandidate(o){return !!(state?.clockReady&&o?.valid&&o.alt>0&&Number.isFinite(o.sightUntil)&&performance.now()<o.sightUntil)}
function expireSightMarks(){
 if(!state?.sats)return;
 let changed=false;for(const o of state.sats)if(o.sightUntil&&performance.now()>=o.sightUntil){o.sightUntil=0;changed=true;}
 if(!changed)return;
 htmlCache.delete('satlist');
 document.querySelectorAll('#satlist .satcard').forEach((el,i)=>{let o=state.sats[i];el.className='satcard '+satTone(o);el.querySelector('small').innerHTML=satstatus(o);});
 if($('detail').open&&state.sats.some(o=>o.name===$('detailtitle').textContent))$('detailtext').textContent=$('detailtext').textContent.replace('◯ Bei klarem Himmel möglicherweise mit bloßem Auge sichtbar','Sichtmarkierung abgelaufen – neue Prüfung erforderlich');
 skyDraw();
}
setInterval(expireSightMarks,1000);
document.addEventListener('visibilitychange',expireSightMarks);
function satTone(o){return sightCandidate(o)?'sight':!state.clockReady||!o.valid?'unknown':o.alt>=0?'above':'upcoming'}
function satstatus(o){return sightCandidate(o)?'◯ Mit bloßem Auge möglich*':!state.clockReady?'Warte auf Uhrzeit':!o.valid?'Daten fehlen / veraltet':esc(o.countdown||'Überflug wird berechnet')}
function satdetail(i){let o=state.sats[i];if(i===3&&!o.valid){detail('Starlink automatisch',`${state.starlinkStatus}\n${catalogText(state.starlinkCatalog)}\n${state.starlinkCatalog?.error||''}`);return;}
let pass=o.valid&&o.passReady;
detail(o.name,`${o.countdown||'Warte auf Bahndaten'}
${sightCandidate(o)?'◯ Bei klarem Himmel möglicherweise mit bloßem Auge sichtbar':o.valid?(o.sightSeconds>0?'Sichtbarkeitsprüfung nicht mehr aktuell':o.visibility||'Sichtbarkeit noch ungeprüft'):'Keine aktuelle Sichtbarkeitsprüfung'}

${o.valid?`Jetzt: ${o.bearing} · Höhe ${o.alt.toFixed(1)}°`:''}
${pass?`${o.ongoing?'Laufender Überflug, erfasst ab':'Beginn'}: ${o.rise}
Ende: ${o.set}
${o.ongoing?'Erfasste Dauer':'Dauer'}: ${Math.floor(o.duration/60)} min ${o.duration%60} s
Maximale Höhe ${o.ongoing?'im erfassten Teil ':''}: ${o.max.toFixed(0)}°
Richtung: ${o.direction}`:'Noch kein vollständiger Überflug berechnet (Suche bis 48 h).'}

*Goldener Ring / Sichtchance: geometrisch über dem Horizont, voll von der Sonne beleuchtet und Sonne mindestens 6° unter dem Horizont. Schätzung für die aktuelle Position, keine Helligkeits- oder Wolkenprognose. Auch markierte Satelliten können zu schwach für das bloße Auge sein. Erdschattenmodell mit kugelförmiger Erde. Zeiten im 30-Sekunden-Raster.
Bahndaten: ${o.epoch}
NORAD ${o.catalog}
${o.error||''}`);}
let swipeStart=null,suppressClickUntil=0;
for(const panel of document.querySelectorAll('section.panel')){
 panel.addEventListener('touchstart',e=>{if(e.touches.length!==1||e.target.closest('button,input,select,a')){swipeStart=null;return;}let t=e.touches[0];swipeStart={x:t.clientX,y:t.clientY,t:Date.now(),view:state?.view};},{passive:true});
 function trySwipe(e,t){if(!swipeStart||!t)return;let s=swipeStart;if(!state||state.view!==s.view){swipeStart=null;return;}let dx=t.clientX-s.x,dy=t.clientY-s.y;
 if(Math.abs(dy)>35&&Math.abs(dy)>Math.abs(dx)){swipeStart=null;return;}
 if(Date.now()-s.t<1800&&Math.abs(dx)>=55&&Math.abs(dx)*2>3*Math.abs(dy)){swipeStart=null;if(e.cancelable)e.preventDefault();suppressClickUntil=Date.now()+500;changeView((state.view+1)%3);}
 }
 panel.addEventListener('touchmove',e=>{if(e.touches.length===1)trySwipe(e,e.touches[0]);else swipeStart=null;},{passive:false});
 panel.addEventListener('touchend',e=>{trySwipe(e,e.changedTouches[0]);swipeStart=null;},{passive:false});
 panel.addEventListener('touchcancel',()=>swipeStart=null,{passive:true});
 panel.addEventListener('click',e=>{if(Date.now()<suppressClickUntil){e.stopImmediatePropagation();e.preventDefault();}},true);
}
let skyGesture=null;
const canvas=$('skyCanvas');
function beginPinch(e){let a=canvasPoint(e.touches[0]),b=canvasPoint(e.touches[1]),mid=[(a[0]+b[0])/2,(a[1]+b[1])/2];skyGesture={kind:'pinch',distance:Math.max(1,Math.hypot(a[0]-b[0],a[1]-b[1])),zoom:skyZoom,anchor:mapFromScreen(...mid)};}
function ownGesture(e){e.stopPropagation();if(e.cancelable)e.preventDefault();swipeStart=null;}
canvas.addEventListener('touchstart',e=>{
 if(e.touches.length===2){ownGesture(e);beginPinch(e);suppressClickUntil=Date.now()+700;}
 else if(e.touches.length>2){ownGesture(e);skyGesture={kind:'blocked'};}
 else if(skyGesture){ownGesture(e);}
 else if(e.touches.length===1&&skyZoom>1){ownGesture(e);let pt=canvasPoint(e.touches[0]);skyGesture={kind:'pan',start:pt,x:skyPanX,y:skyPanY,moved:false};}
},{passive:false});
canvas.addEventListener('touchmove',e=>{
 if(!skyGesture)return;ownGesture(e);
 if(skyGesture.kind==='pinch'&&e.touches.length===2){let a=canvasPoint(e.touches[0]),b=canvasPoint(e.touches[1]),g=skyGesture;skyZoom=Math.max(1,Math.min(4,g.zoom*Math.hypot(a[0]-b[0],a[1]-b[1])/g.distance));skyPanX=(a[0]+b[0])/2-160-(g.anchor[0]-160)*skyZoom;skyPanY=(a[1]+b[1])/2-174-(g.anchor[1]-174)*skyZoom;clampCamera();skyDraw();}
 else if(skyGesture.kind==='pan'&&e.touches.length===1){let p=canvasPoint(e.touches[0]),g=skyGesture,dx=p[0]-g.start[0],dy=p[1]-g.start[1];if(Math.hypot(dx,dy)>4)g.moved=true;if(g.moved){skyPanX=g.x+dx;skyPanY=g.y+dy;clampCamera();skyDraw();}}
},{passive:false});
canvas.addEventListener('touchend',e=>{if(!skyGesture)return;ownGesture(e);let g=skyGesture;
 if(g.kind==='pan'&&!g.moved&&e.touches.length===0&&e.changedTouches[0]){suppressClickUntil=0;canvas.onclick({...e.changedTouches[0],clientX:e.changedTouches[0].clientX,clientY:e.changedTouches[0].clientY});}
 if(g.kind==='pinch'||(g.kind==='pan'&&g.moved))queueCamera();
 suppressClickUntil=Date.now()+700;
 skyGesture=e.touches.length?{kind:'blocked'}:null;
},{passive:false});
canvas.addEventListener('touchcancel',e=>{ownGesture(e);if(skyGesture)queueCamera();skyGesture=null;suppressClickUntil=Date.now()+700;},{passive:false});
clampCamera();
function editPlace(id){let p=id<0?{name:'',lat:46.948,lon:7.4474,height:540,tz:'CET-1CEST,M3.5.0,M10.5.0/3'}:state.places[id];$('placeid').value=id;for(let k of ['lat','lon','height','tz'])$(k).value=p[k];$('pname').value=p.name;$('placeform').classList.remove('hidden');$('pname').focus()}
$('tzPreset').onchange=e=>{if(e.target.value!=='custom')$('tz').value=e.target.value};$('placeform').onsubmit=e=>{e.preventDefault();act({action:'placeSave',id:+$('placeid').value,name:$('pname').value,lat:+$('lat').value,lon:+$('lon').value,height:+$('height').value,tz:$('tz').value})};$('wifiform').onsubmit=e=>{e.preventDefault();act({action:'wifiSave',ssid:$('ssid').value,password:$('password').value});$('password').value=''};setInterval(refresh,5000);refresh();
let extraFormDirty=false;
$('extrasForm').addEventListener('input',()=>extraFormDirty=true);
function minuteText(n){return String(Math.floor(n/60)).padStart(2,'0')+':'+String(n%60).padStart(2,'0')}
function parseMinute(v){let a=v.split(':').map(Number);return a[0]*60+a[1]}
function renderExtras(){const e=state.extras;if(!e)return;
 if(!extraFormDirty){for(const k of ['largeMap','trails','autoNight'])$(k).checked=e[k];$('nightStart').value=minuteText(e.start);$('nightEnd').value=minuteText(e.end);$('nightDim').value=e.dim;}
 $('satlist').classList.toggle('hidden',e.largeMap);$('skyCanvas').style.maxWidth=e.largeMap?'640px':'480px';
 const w=state.weather;$('observingWeather').textContent=w.valid&&w.age>=0&&w.age<=1800?`Beobachtungswetter: Wolken ${w.cloud==null?'—':Math.round(w.cloud)+' %'} · ${w.text}. Niederschlagswahrscheinlichkeit heute: ${w.days?.[0]?.rain==null?'—':w.days[0].rain+' %'} (Tagesprognose).`:'Beobachtungswetter fehlt oder ist älter als 30 Minuten.';
 $('otaInfo').textContent=e.otaAvailable?`WLAN-Updates bereit · maximal ${e.otaBytes} Byte.`:'USB-Installation mit neuer Partitionstabelle erforderlich.';$('firmwareButton').disabled=!e.otaAvailable;
}
$('extrasForm').onsubmit=async e=>{e.preventDefault();try{const ok=await act({action:'extras',largeMap:$('largeMap').checked,trails:$('trails').checked,autoNight:$('autoNight').checked,start:parseMinute($('nightStart').value),end:parseMinute($('nightEnd').value),dim:Number($('nightDim').value)});if(ok)extraFormDirty=false;await refresh();}catch(err){$('maintenanceStatus').textContent=err.message}};
async function findObjects(){const out=$('objectResults');out.textContent='Suche läuft …';try{const r=await fetchTimed('/api/objects?q='+encodeURIComponent($('objectSearch').value));if(!r.ok)throw Error('Suche fehlgeschlagen');const d=await r.json();out.replaceChildren();for(const o of d.objects){const b=document.createElement('button');b.textContent=`${o.name} · ${o.direction} · ${o.alt.toFixed(1)}°${o.alt<0?' · unter Horizont':''}`;b.disabled=o.alt<0;b.onclick=async()=>{await act({action:'highlight',id:o.id});await refresh();};out.append(b);const fav=document.createElement('button');fav.textContent=state.modern?.favorites?.includes(o.id)?'★ Entfernen':'☆ Merken';fav.onclick=()=>toggleFavorite(o.id);out.append(fav)}if(!d.objects.length)out.textContent='Keine passenden Objekte oder Uhrzeit fehlt.';}catch(e){out.textContent=e.message}}
async function maintenance(url,body){const r=await fetchTimed(url,{method:'POST',headers:{'X-WW-Token':state.token,'Content-Type':'application/json'},body});if(!r.ok)throw Error(await r.text());return r}
async function exportConfig(){try{const r=await maintenance('/api/backup','{}');const blob=await r.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='WetterHimmel_Einstellungen.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);$('maintenanceStatus').textContent='Sicherung heruntergeladen.';}catch(e){$('maintenanceStatus').textContent=e.message}}
async function restoreConfig(){try{const f=$('configFile').files[0];if(!f||f.size>12000)throw Error('JSON-Sicherung bis 12.000 Byte auswählen');const body=await f.text();JSON.parse(body);if(!confirm('Gespeicherte Standorte, WLANs und Anzeigeeinstellungen durch diese Sicherung ersetzen?'))return;const r=await maintenance('/api/restore',body);$('maintenanceStatus').textContent=await r.text();extraFormDirty=false;await refresh();}catch(e){$('maintenanceStatus').textContent=e.message}}
async function uploadFirmware(){
 const f=$('firmwareFile').files[0],out=$('maintenanceStatus');if(!state||!f||!f.name.endsWith('.bin')||f.size>state.extras.otaBytes||f.size<288){out.textContent='Passende WetterHimmel.ino.bin auswählen.';return;}
 try{const bytes=new Uint8Array(await f.arrayBuffer());const raw=new TextDecoder('latin1').decode(bytes);const match=raw.match(/WW_RELEASE:([0-9]+\.[0-9]+\.[0-9]+-[a-z0-9]+)/);if(bytes[0]!==0xe9||bytes[12]!==0||bytes[13]!==0||!raw.includes('WETTERHIMMEL_OTA_LAYOUT_1_9_ESP32')||!match)throw Error('Keine kompatible WetterHimmel-Firmware mit prüfbarer Version');
 const version=match[1];if(!confirm('Firmware '+version+' installieren und neu starten?'))return;
 $('firmwareButton').disabled=true;const pair=await maintenance('/api/pair','{}');const d={url:location.origin,key:(await pair.json()).key};const before=await fleetRequest(d,'/fleet/info');
 await uploadTo(d,f,out,true);await verifyRestart(d,before,version,out);out.textContent+=' · Safari neu laden.';
 }catch(e){out.textContent='Nicht bestätigt: '+e.message;}finally{$('firmwareButton').disabled=false;}
}
function skyOverlays(c){if(!state.extras)return;
 if(state.extras.trails)for(const path of state.paths||[]){const ps=path.points.map(([az,alt])=>point(az,alt));if(ps.length<2)continue;c.strokeStyle='#66d7f0';c.lineWidth=1;c.beginPath();ps.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));c.stroke();const p=ps[ps.length-1],q=ps[ps.length-2],a=Math.atan2(p[1]-q[1],p[0]-q[0]);c.beginPath();for(const sign of [-1,1]){c.moveTo(...p);c.lineTo(p[0]-6*Math.cos(a+sign*.5),p[1]-6*Math.sin(a+sign*.5))}c.stroke();}
 if(state.extras.highlight>=0&&state.extras.highlightAlt>=0){const [x,y]=point(state.extras.highlightAz,state.extras.highlightAlt);c.strokeStyle='#ffe76a';c.lineWidth=1.5;for(const r of [11,14]){c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.stroke()}c.lineWidth=1;}
}

// MODERN_JS
</script></html>
)WWHTML";
