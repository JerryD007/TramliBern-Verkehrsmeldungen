#pragma once
#include "App.h"
#define WW_VERSION "1.10.0-dev1"
struct ModernSettings {
 uint32_t version=1;char name[33]="WetterHimmel";
 bool aircraft=true,approaching=false,priority=false;
 int radius=50,showSeconds=20,cooldownSeconds=300,sleepMinutes=0;
 int favorites[16];int favoriteCount=0;
};
struct Flight {
 bool checked=false,found=false,approaching=false;
 char callsign[17]={},type[17]={},hex[9]={},error[96]={};
 float distance=NAN,altitude=NAN,speed=NAN,track=NAN,azimuth=NAN;
 time_t received=0,positionAt=0;
};
struct Hourly {time_t fetched=0;time_t at[12]={};int8_t cloud[12]={},rain[12]={};int count=0;};
extern ModernSettings modern;
extern Flight flight;
extern Hourly hourly;
extern bool displayAsleep;
extern String deviceBoot,deviceKey;
extern uint32_t renderMaxUs,touchMaxGapMs;
bool priorityActive();
void modernBegin();void modernTick();void modernState(JsonDocument &d);void modernWeb();
bool modernCommand(JsonDocument &d,String &error);
void modernJson(JsonObject d,const ModernSettings &m);bool modernRead(JsonVariantConst d,ModernSettings &m);
void wakeDisplay();bool touchSleepGate(bool down);
void manualInteraction();bool flightFresh();
bool parseFlight(JsonDocument &d,Flight &out,const Place &p,int radius,bool approaching,time_t now);
void parseHourly(JsonVariantConst h,Hourly &out,time_t now);
void modernDiagnostic(JsonDocument &d);
void visiblePassTick();void visiblePassJson(JsonObject d);
void sourceStarted(int kind);void sourceFinished(int kind,int http,uint32_t duration,const char*error,const char*trace);
void sourceJson(JsonObject d);
