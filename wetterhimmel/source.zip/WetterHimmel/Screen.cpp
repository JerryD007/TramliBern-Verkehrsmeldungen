#include "App.h"
#include "Modern.h"
#ifndef UI_HOST_PREVIEW
#include "Extras.h"
#endif
#include "Starlink.h"
#include "Catalog.h"
#include "UiFonts.h"
#include "Paint.h"
#include "Gesture.h"
#include "Visibility.h"
#include "StarNames.h"
static Paint paint(lcd);
#ifndef UI_DIRECT_PREVIEW
static LGFX_Sprite skyBuffer(&lcd);
// One 224x224, 4-bit sprite (25088 pixel bytes), allocated only when needed.
static bool skyPixelsReady=false;
static uint32_t mapRetryAt=0;
static bool skyBufferReady=false;
static bool networkOwnsMemory=false;
static bool mapDeferred=false;
#endif
// Called exclusively by the main loop, before publishing a network job.
void uiNetworkMemory(bool active) {
#ifndef UI_DIRECT_PREVIEW
  networkOwnsMemory=active;
  if(active && skyPixelsReady) {
    // Main-loop ownership: no render can be in progress when the job is queued.
    // The LCD retains its pixels; only the off-screen workspace is released.
    skyBuffer.deleteSprite();
    skyPixelsReady=false;
    mapDeferred=true;
  }
  if(!active && mapDeferred) {mapRetryAt=millis();dirty=true;}
#endif
}
static const uint16_t bg = 0x0843, blue = 0x0254, white = 0xFFFF, muted = 0xB67F, cyan = 0x07FF;
static String input, title, wifiName;
static int purpose = 0, keyLayout = 0, networkPage = 0, profile = 0;
static bool shifted = false, held = false, showPassword = false;
static Place draft{};
static int editPlace = -1;
static int16_t hitX[1100], hitY[1100], hitType[1100];
static int hitCount=0;
static String objectQuery;static int objectOffset=0,objectChoices[6],objectMatches=0;
static float mapScale(){return extra.largeMap?(304.0f/224.0f):1.25f;}
static int mapCenterY(){return extra.largeMap?230:198;}
static int labelBackground=-1;
static uint16_t textBackground(int x,int y) {
  if(labelBackground>=0)return (uint16_t)labelBackground;
  if(y<30||y>=436)return 0x10C7;
  if(page==0 && cfg.view==0) {
    if(y>=230&&y<256)return 0x0351;
    if(y>=256&&y<412&&((y-230)/26)%2==0)return 0x0AB6;
    int i=y-30;return ((5+(4-5)*i/406)&248)<<8 | ((100+(54-100)*i/406)&252)<<3 | ((190+(121-190)*i/406)>>3);
  }
  if((page==0&&cfg.view==1)||page==12) {
    if(y>=366&&y<434)return 0x116C;
    return 0;
  }
  return bg;
}
// Embedded UTF-8 font subset: independent of the limited built-in fonts.
static uint16_t nextCode(const String &s, unsigned &i) {
  uint8_t c = s[i++];
  if (c < 128) return c;
  uint16_t v = c & (c < 224 ? 31 : 15);
  int n = c < 224 ? 1 : 2;
  while (n-- && i < s.length()) v = (v << 6) | (s[i++] & 63);
  return v;
}
static const UiGlyph *glyph(const UiFont &f, uint16_t c) {
  for (unsigned j = 0; j < f.count; j++) if (f.glyphs[j].code == c) return &f.glyphs[j];
  for (unsigned j = 0; j < f.count; j++) if (f.glyphs[j].code == '?') return &f.glyphs[j];
  return &f.glyphs[0];
}
static int width(String s, const UiFont &f = uiFont14) {
  int w = 0; unsigned i = 0;
  while (i < s.length()) w += glyph(f, nextCode(s, i))->advance;
  return w;
}
static void label(String s, int x, int y, const UiFont &f, uint16_t col) {
  unsigned i = 0;
  while (i < s.length()) {
    auto g = glyph(f, nextCode(s, i));
    for(int yy=0;yy<f.height;yy++) for(int xx=0;xx<g->width;xx++) {
      int b=yy*g->width+xx; uint8_t packed=f.bits[g->offset+b/2];
      int alpha=b%2?packed&15:packed>>4;if(!alpha)continue;
      uint16_t back=textBackground(x+xx,y+yy);
      int rr=(((col>>11)&31)*alpha+((back>>11)&31)*(15-alpha))/15;
      int gg=(((col>>5)&63)*alpha+((back>>5)&63)*(15-alpha))/15;
      int bb=((col&31)*alpha+(back&31)*(15-alpha))/15;
      paint.drawPixel(x+xx,y+yy,(rr<<11)|(gg<<5)|bb);
    }
    x += g->advance;
  }
}
static void text(String s, int x, int y, int size = 1, uint16_t col = white) {
  label(s, x, y, size == 2 ? uiFont20 : uiFont14, col);
}
static uint16_t rgb(int r, int g, int b) { return ((r & 248) << 8) | ((g & 252) << 3) | (b >> 3); }
static void gradient(int y, int h, int r, int g, int b, int rr, int gg, int bb) {
  for (int i=0;i<h;i++) paint.drawFastHLine(0,y+i,320,rgb(r+(rr-r)*i/h,g+(gg-g)*i/h,b+(bb-b)*i/h));
}
static void button(String s, int x, int y, int w, int h, uint16_t col = 0x192C) {
  paint.fillRoundRect(x,y,w,h,7,col);
  paint.drawRoundRect(x,y,w,h,7,col == 0x051B ? 0x5EFF : 0x426F);
  const UiFont &f = width(s) <= w-10 ? uiFont14 : uiFont11;
  int previous=labelBackground;labelBackground=col;
  label(s,x+(w-width(s,f))/2,y+(h-f.height)/2,f,white);labelBackground=previous;
}
// Shaded RGB565 spheres. No large framebuffer or PSRAM required.
static void sphere(int cx,int cy,int r,int kind) {
  const int colors[][3]={{255,213,50},{196,202,218},{146,146,158},{236,196,126},{220,101,65},{216,171,121},{217,197,147},{113,216,225},{66,121,228},{40,148,225}};
  kind=constrain(kind,0,9);
  for (int y=-r;y<=r;y++) for (int x=-r;x<=r;x++) {
    float d=float(x*x+y*y)/(r*r); if(d>1) continue;
    float z=sqrtf(1-d), light=0.27f+0.73f*max(0.0f,(-0.4f*x-0.55f*y)/r+0.75f*z);
    if(kind==0) light=0.82f+0.18f*z;
    float band=1;
    if(kind==5 || kind==6) band=0.82f+0.18f*sinf(y*1.1f);
    int red=colors[kind][0], green=colors[kind][1], blueC=colors[kind][2];
    if(kind==9 && sinf(x*0.9f+y*0.5f)+cosf(y*1.2f-x*0.3f)>0.9f) {red=68;green=181;blueC=117;}
    if(kind==1) band=0.83f+0.17f*sinf(x*1.8f+y)*sinf(y*1.6f);
    paint.drawPixel(cx+x,cy+y,rgb(red*light*band,green*light*band,blueC*light*band));
  }
}
static void glowSun(int x,int y,int r) {
  for(int k=r+9;k>r;k--) paint.drawCircle(x,y,k,rgb(35+(r+9-k)*8,25+(r+9-k)*5,20));
  sphere(x,y,r,0);
}
static void back() { button("ZURÜCK", 8, 424, 304, 46, 0xA986); }
static void icon(int c,int x,int y,int r) {
  if(c<0) {text("—",x-5,y-8);return;}
  if(c<=2) {
    sphere(x+r/5,y-r/4,r,0);
    if(c==0)for(int k=0;k<8;k++){double a=k*pi/4;paint.drawLine(x+r/5+(r+3)*cos(a),y-r/4+(r+3)*sin(a),x+r/5+(r+6)*cos(a),y-r/4+(r+6)*sin(a),0xFFE0);}
  }
  if(c>0) {
    for(int yy=-r;yy<=r;yy++)for(int xx=-r;xx<=r;xx++) {
      float u=float(xx)/r,v=float(yy)/r;
      bool cloud=(sq(u+0.45f)+sq(v-0.35f)<0.36f)||(sq(u-0.05f)+sq(v+0.02f)<0.49f)||(sq(u-0.55f)+sq(v-0.37f)<0.24f)||(v>0.3f&&v<0.86f&&u>-.45f&&u<.55f);
      if(cloud){
        float bump=max(0.0f,1.0f-min(sq(u+0.45f)+sq(v-0.35f),min(sq(u-0.05f)+sq(v+0.02f),sq(u-0.55f)+sq(v-0.37f)))*2.0f);
        int shade=constrain(int(190+54*sqrtf(bump)-22*v),165,250);
        paint.drawPixel(x+xx,y+yy,rgb(shade-7,shade,min(255,shade+15)));}
    }
  }
  if(c==45||c==48)for(int k=0;k<2;k++)paint.drawFastHLine(x-r,y+r+2+k*3,r*2,muted);
  else if((c>=71&&c<=77)||c==85||c==86)for(int k=-1;k<=1;k++){int xx=x+k*5,yy=y+r+4;paint.drawLine(xx-2,yy,xx+2,yy,white);paint.drawLine(xx,yy-2,xx,yy+2,white);}
  else if(c>=50)for(int k=-1;k<=1;k++)paint.drawLine(x+k*5,y+r+2,x+k*5-2,y+r+5,cyan);
  if(c>=95){paint.drawLine(x+2,y+r,x-2,y+r+4,0xFFE0);paint.drawLine(x-2,y+r+4,x+1,y+r+4,0xFFE0);paint.drawLine(x+1,y+r+4,x-3,y+r+8,0xFFE0);}
}
void keyboard(String name, String value, int why) {
  title = name;
  input = value;
  purpose = why;
  showPassword = false;
  keyLayout = 0;
  shifted = false;
  page = 10;
  dirty = true;
}
static uint32_t surfaceRevision=0;
static void calibrate() {
  ++surfaceRevision;
  paint.fillScreen(bg);
  text("Touchkalibrierung", 20, 40, 2);
  text("Bitte die Markierungen antippen.", 12, 80);
  uint16_t c[8];
  lcd.calibrateTouch(c, white, bg, 16);
  prefs.putBytes(("cal" + String(cfg.rotation)).c_str(), c, sizeof c);
  dirty = true;
}
void uiBegin() {
  lcd.init();
  lcd.setRotation(cfg.rotation);
  uiDisplayBrightness();
  lcd.setTextWrap(false);
#ifndef UI_DIRECT_PREVIEW
  skyBuffer.setPsram(false);
  skyBuffer.setColorDepth(4);
  skyBufferReady=skyBuffer.createPalette(skyPalette,16);
  // Do not reserve the pixel buffer at startup or while showing weather.
#endif
  uint16_t c[8];
  String key = "cal" + String(cfg.rotation);
  if (prefs.getBytesLength(key.c_str()) == sizeof c) {
    prefs.getBytes(key.c_str(), c, sizeof c);
    lcd.setTouchCalibrate(c);
  } else
    calibrate();
}
static String observingWeather(){return weather.valid&&clockReady()&&time(nullptr)-weather.fetched<=1800?
    "Wolken "+(isfinite(weather.cloud)?String(weather.cloud,0)+"%":String("—"))+" · Regen heute "+(weather.days[0].rain>=0?String(weather.days[0].rain)+"%":String("—")):String("Beobachtungswetter fehlt / veraltet");}
static void nav() {
 paint.fillRect(0,436,320,44,0x10C7);labelBackground=0x10C7;
 if(cfg.view==1){button("Objekte",8,438,110,26,0x0254);button("Gesamtkarte",194,438,118,26,0x0254);if(!extra.largeMap)label(observingWeather(),8,466,uiFont11,muted);}
 else{label("Tag antippen: ausführlicher Bericht",14,444,uiFont11,white);label("Wischen: Wetter / Himmel / Flugzeug",65,462,uiFont11,muted);}
 labelBackground=-1;
}
static void header() {
  paint.fillRect(0,0,320,30,0x10C7);
  String place=cfg.places[cfg.place].name;
  while(width(place,uiFont14)>147 && place.length()) { int n=place.length()-1; while(n>0 && ((uint8_t)place[n]&0xC0)==0x80) n--; place.remove(n); }
  label(place,8,5,uiFont14,white);
  label(clockReady()?stamp(time(nullptr)):"--:--",180,5,uiFont14,white);
  uint16_t c=WiFi.status()==WL_CONNECTED?white:0xFD20;
  for(int r=5;r<=13;r+=4)for(int a=225;a<=315;a+=3)paint.drawPixel(249+r*cos(a*DEG_TO_RAD),23+r*sin(a*DEG_TO_RAD),c);
  paint.fillCircle(249,23,1,c);
  for(int a=0;a<360;a+=45) {int x=292+10*cos(a*DEG_TO_RAD),y=15+10*sin(a*DEG_TO_RAD);paint.fillRect(x-2,y-2,5,5,white);}
  paint.fillCircle(292,15,9,white);paint.fillCircle(292,15,4,0x10C7);

}
static String value(float v) {return isfinite(v)?String(roundf(v)==0?0:v,0):String("—");}
static void weatherScreen() {
  gradient(30,406,5,100,190,4,54,121);
  if (!weather.valid) {
    text("Wetterstation",14,55,2); text("Warte auf Internetdaten …",14,115);
    text("Menü → WLAN / Standort",14,145); text(weather.error,14,185);
    text("Einrichtungsnetz: WetterWeltall",14,240);
    text("Passwort: "+apPassword,14,270);
    text("Safari: http://192.168.4.1",14,300);return;
  }
  icon(weather.code,55,70,32);
  String temp=value(weather.temp)+"°C";
  label(temp,310-width(temp,width(temp,uiFont56)<196?uiFont56:uiFont46),30,width(temp,uiFont56)<196?uiFont56:uiFont46,white);
  text("Gefühlt "+value(weather.feels)+" °C",140,94,1,muted);
  String description=weatherText(weather.code);
  label(description,14,119,width(description,uiFont20)<292?uiFont20:uiFont14,white);
  text("Feuchte "+value(weather.humidity)+" %",14,148);text("Wind "+bearing(weather.direction)+" "+value(weather.wind)+" km/h",14,168);
  text("7 TAGE · TAG ANTIPPEN",14,191);
  label("Tag",14,213,uiFont11,muted); label("Min",156,213,uiFont11,muted);
  label("Max",213,213,uiFont11,muted); label("Regen",250,213,uiFont11,muted);
  for(int i=0;i<7;i++) {
    int y=231+i*26;
    if(i==0){paint.fillRect(0,y-1,320,26,0x0351);paint.fillRect(0,y-1,4,26,cyan);}else if(i%2==0)paint.fillRect(0,y-1,320,26,0x0AB6);
    auto &d=weather.days[i]; struct tm tm{}; int yy=2026,mm=1,dd=1;
    sscanf(d.date,"%d-%d-%d",&yy,&mm,&dd);
    tm.tm_year=yy-1900;tm.tm_mon=mm-1;tm.tm_mday=dd;tm.tm_hour=12;tm.tm_isdst=-1;mktime(&tm);
    const char *wd[]={"So","Mo","Di","Mi","Do","Fr","Sa"};
    text(i==0?"Heute":wd[tm.tm_wday],14,y,2);
    icon(d.code,108,y+10,9);
    String lo=value(d.min)+"°", hi=value(d.max)+"°";
    label(lo,179-width(lo,uiFont20),y,uiFont20,muted);label(hi,235-width(hi,uiFont20),y,uiFont20,white);
    String rain=d.rain<0?"—":String(d.rain)+"%";label(rain,292-width(rain,uiFont20),y,uiFont20,muted);paint.drawLine(304,y+7,309,y+12,muted);paint.drawLine(309,y+12,304,y+17,muted);
  }
  String age="Internetwetter · Stand "+stamp(weather.fetched);
  if(!clockReady()) age="Uhrzeit fehlt · gespeicherte Daten";
  if(clockReady() && time(nullptr)-weather.fetched>1800) age="Daten älter als 30 Min. · "+stamp(weather.fetched);
  label(age,(320-width(age,uiFont11))/2,414,uiFont11,muted);
  if(weather.error[0]) label("Abruf fehlgeschlagen · gespeicherte Daten",12,421,uiFont11,0xFFE0);
}
static int selectedDay=0;
static String decimalValue(float v){return isfinite(v)?String(v,1):String("—");}
static void dayScreen(){
 if(!weather.valid||selectedDay<0||selectedDay>6){text("Keine Tagesdaten",12,80);back();return;}
 auto &d=weather.days[selectedDay];text("Tagesbericht",12,40,2);icon(d.code,282,65,21);
 text(String(d.date),12,70);label(weatherText(d.code),12,96,uiFont14,white);
 const uint16_t card=0x116C;for(int row=0;row<2;row++)for(int col=0;col<2;col++)paint.fillRoundRect(8+156*col,122+132*row,148,row?143:124,9,card);
 labelBackground=card;
 label("TEMPERATUR",18,132,uiFont11,muted);
 String range=value(d.min)+" bis "+value(d.max)+"°C";label(range,18,156,width(range,uiFont20)<129?uiFont20:uiFont14,white);
 label("Gefühlt",18,193,uiFont11,muted);label(value(d.feelsMin)+" bis "+value(d.feelsMax)+" °C",18,213,uiFont14,white);
 label("NIEDERSCHLAG",174,132,uiFont11,muted);label(decimalValue(d.precipitation)+" mm",174,156,uiFont20,cyan);
 label("Max. "+(d.rain<0?String("—"):String(d.rain)+" %")+" · "+value(d.precipitationHours)+" h",174,190,uiFont11,white);
 label("Neuschnee",174,210,uiFont11,muted);label(decimalValue(d.snow)+" cm",174,225,uiFont11,white);
 label("WIND",18,264,uiFont11,muted);label(value(d.windMax)+" km/h",18,287,uiFont20,white);
 label("Maximum · "+bearing(d.windDirection),18,321,uiFont11,muted);label("Böen "+value(d.gustMax)+" km/h",18,349,uiFont14,white);
 label("SONNE",174,264,uiFont11,muted);label(decimalValue(d.sunshine/3600)+" h",174,287,uiFont20,0xFFE0);
 label("Sonnenschein",174,316,uiFont11,muted);
 label("↑ "+(d.sunrise?stamp(d.sunrise):String("—"))+"  ↓ "+(d.sunset?stamp(d.sunset):String("—")),174,338,uiFont11,white);
 label("UV max. "+decimalValue(d.uv),174,365,uiFont11,white);labelBackground=-1;
 bool stale=!clockReady()||time(nullptr)-weather.fetched>1800;
 label(stale?"Veraltete Vorhersage":String("Open-Meteo · geladen ")+stamp(weather.fetched),12,405,uiFont11,stale?0xFFE0:muted);back();
}
static bool projectMap(double az,double alt,int &x,int &y){
  if(!project(az,alt,x,y))return false;
  skyCamera.transform(x,y);return true;
}
static void addHit(int x, int y, int type) {
  if (hitCount < 1100 && skyCamera.contains(x,y)) {
    hitX[hitCount] = lround(160+(x-160)*mapScale());
    hitY[hitCount] = lround(mapCenterY()+(y-174)*mapScale());
    hitType[hitCount++] = type;
  }
}
// Prefer nearby planets/satellites to the dense background star field.
static int skyHitTarget(int x,int y) {
  int best=-1,bestDistance=0,bestPriority=-1;
  for(int i=0;i<hitCount;i++) {
    bool primary=(hitType[i]>=0&&hitType[i]<objectCount)||hitType[i]>=3000;
    int radius=primary?26:15,dx=x-hitX[i],dy=y-hitY[i],distance=dx*dx+dy*dy;
    int priority=primary?1:0;
    if(distance<=radius*radius && (priority>bestPriority || (priority==bestPriority&&distance<bestDistance))) {
      best=hitType[i];bestDistance=distance;bestPriority=priority;
    }
  }
  return best;
}
struct LabelBox {int x,y,w,h;};
static LabelBox labelBoxes[24];
static int labelCount=0;
static bool mapLabel(String name,int x,int y,uint16_t color) {
  int w=width(name,uiFont11), h=14;
  const int dx[]={14,14,-14,-14,0,0},dy[]={-19,10,-19,10,-29,18};
  for(int k=0;k<6;k++) {
    int xx=k==4||k==5?x-w/2:k>=2?x-w+dx[k]:x+dx[k], yy=y+dy[k];
    if(xx<48||xx+w>272||yy<78||yy+h>272) continue;
    bool free=true;
    for(int j=0;j<labelCount;j++) {auto b=labelBoxes[j]; if(xx<b.x+b.w+3&&xx+w+3>b.x&&yy<b.y+b.h+3&&yy+h+3>b.y) free=false;}
    // Keep labels away from every solar-system marker, even those drawn later.
    for(int j=0;j<objectCount;j++) {int u,v; if(projectMap(objects[j].az,objects[j].alt,u,v)&&u>xx-13&&u<xx+w+13&&v>yy-10&&v<yy+h+10) free=false;}
    if(free && labelCount<24) {labelBoxes[labelCount++]={xx,yy,w,h};paint.fillRoundRect(xx-2,yy-1,w+4,h+2,2,0x0843);label(name,xx,yy,uiFont11,color);return true;}
  }
  return false;
}
static void moonIcon(int cx,int cy,int r) {
  double a=moonPhase*DEG_TO_RAD;
  for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++) {
    double xx=(double)x/r,yy=(double)y/r,z2=1-xx*xx-yy*yy;
    if(z2<0)continue;
    double light=xx*sin(a)-sqrt(z2)*cos(a);
    int v=light>0?190+int(50*sqrt(z2)):46;
    paint.drawPixel(cx+x,cy+y,rgb(v,v,v+min(9,255-v)));
  }
}
static void satelliteIcon(int x,int y,int kind) {
  paint.drawLine(x-18,y,x+18,y,0xBDF7);
  if(kind==2) {
    paint.fillRoundRect(x-10,y-5,22,10,3,0xBDF7);
    paint.fillCircle(x-10,y,5,0x4208);paint.drawCircle(x-10,y,5,white);
    paint.fillRect(x-3,y-15,10,8,0x2C9B);paint.fillRect(x-3,y+7,10,8,0x2C9B);
  } else {
    paint.fillRoundRect(x-4,y-7,8,14,2,0xD6BA);
    for(int side=-1;side<=1;side+=2) {
      int xx=x+(side<0?-21:8);paint.fillRect(xx,y-11,13,22,0x1B57);
      paint.drawRect(xx,y-11,13,22,0x75DF);
      for(int k=1;k<4;k++)paint.drawFastHLine(xx,y-11+k*5,13,0x4C9D);
      paint.drawFastVLine(xx+6,y-11,22,0x4C9D);
    }
  }
}
static void satelliteCards() {
 const char *names[]={"ISS","Tiangong","Hubble","Starlink"};
 for(int k=0;k<4;k++){
  auto &sat=satellites[k];bool fresh=clockReady()&&sat.valid&&llabs((int64_t)time(nullptr)-sat.epoch)<=7*86400;
  int x=4+(k%2)*160,y=366+(k/2)*35;
  bool sight=satelliteCandidateSeconds(sat,clockReady(),time(nullptr))>0;
  uint16_t accent=sight?0xFFE0:!fresh?muted:sat.alt>=0?0x7FEA:cyan;
  paint.fillRoundRect(x,y,152,32,5,0x116C);paint.fillCircle(x+9,y+11,3,accent);labelBackground=0x116C;
  label(names[k],x+18,y+1,uiFont14,white);
  String status=!clockReady()?"Uhrzeit fehlt":!fresh?"Bahndaten fehlen":sight?"Sichtchance*":sat.alt>=0?"Über dem Horizont":satelliteCountdown(sat);
  if(width(status,uiFont11)>128)status="Überflug wird gesucht";
  label(status,x+18,y+18,uiFont11,accent);labelBackground=-1;
 }
}
static void sampleChartTouch() {
#ifndef UI_HOST_PREVIEW
  lcd.endWrite();uiPollTouch();lcd.startWrite();
#endif
}
static void skyScreen(bool full=true) {
  static uint64_t lastMap=0;
  static String lastCards,lastInfo;
  if(full) {gradient(30,406,0,0,0,0,0,0);label("Himmel · Ring = Sichtchance*",10,36,uiFont14,white);}
  uint64_t mapKey=(uint64_t)(clockReady()?time(nullptr)/30:0);
  mapKey=mapKey*31+skyCamera.revision;mapKey=mapKey*31+displayNight;
  mapKey=mapKey*31+generation;mapKey=mapKey*31+objectCount;
  mapKey=mapKey*31+(cfg.labels|cfg.lines<<1|cfg.milky<<2|cfg.satellites<<3|cfg.starlink<<4);
  String cards=String(clockReady())+":"+String((long)(time(nullptr)/60));
  for(int i=0;i<SAT_COUNT;i++) {
    auto &sat=satellites[i];bool fresh=clockReady() && sat.valid && llabs((int64_t)time(nullptr)-sat.epoch)<=7*86400;
    int x=0,y=0;
    if(fresh && cfg.satellites && (i<3 || cfg.starlink) && projectMap(sat.az,sat.alt,x,y)) {mapKey=mapKey*31+x;mapKey=mapKey*31+y;}
    bool sight=satelliteCandidateSeconds(sat,clockReady(),time(nullptr))>0;
    mapKey=mapKey*31+sight;cards+=String(sight);
    cards+=String(fresh)+":"+String(sat.alt>=0)+":"+stamp(sat.rise)+":"+String(sat.valid);
  }
  if(!extra.largeMap&&(full || cards!=lastCards)) {satelliteCards();lastCards=cards;}
  String info=String((1-cos(moonPhase*DEG_TO_RAD))*50,0)+":"+eventStamp(sunrise)+":"+eventStamp(sunset);
  if(!extra.largeMap&&(full || info!=lastInfo)) {
    for(int y=340;y<365;y++)paint.drawFastHLine(0,y,320,textBackground(0,y));
    if(clockReady()) {
      label("Mond "+String((1-cos(moonPhase*DEG_TO_RAD))*50,0)+" % · "+(moonPhase<180?"zunehmend":"abnehmend"),10,340,uiFont11,muted);
      label("↑ "+eventStamp(sunrise)+"  ↓ "+eventStamp(sunset),10,353,uiFont11,muted);
    }
    lastInfo=info;
  }
#ifndef UI_DIRECT_PREVIEW
  // Preserve the displayed chart while HTTPS owns the temporary workspace.
  bool deferred=mapDeferred;
#else
  bool deferred=false;
#endif
  String observing=observingWeather();
  static String lastObserving;
  if(full||observing!=lastObserving){int yy=extra.largeMap?394:466;paint.fillRect(0,yy,320,14,bg);label(observing,8,yy,uiFont11,muted);lastObserving=observing;}
  mapKey=mapKey*31+(highlightedObject+1);mapKey=mapKey*31+extra.trails;
  if(!full && !deferred && mapKey==lastMap)return;
  lastMap=mapKey;
  if (!clockReady()) {
    text("Warte auf Uhrzeit",60,120);text("über WLAN / NTP",60,145);
    return;
  }
#ifndef UI_DIRECT_PREVIEW
  if(!networkOwnsMemory) {
    if(!skyBufferReady)skyBufferReady=skyBuffer.createPalette(skyPalette,16);
    if(skyBufferReady && !skyPixelsReady)
      skyPixelsReady=skyBuffer.createSprite(224,224)!=nullptr;
  }
  if(networkOwnsMemory || !skyBufferReady || !skyPixelsReady) {
    mapDeferred=true;
    mapRetryAt=millis()+1000;
    // Do not destroy an existing chart on a temporary allocation failure.
    if(full) {hitCount=0;text(networkOwnsMemory?"Karte nach Datenabruf":"Karte wartet auf Speicher",40,120);}
    return;
  }
  mapDeferred=false;
  for(unsigned i=0;i<16;i++)skyBuffer.setPaletteColor(i,nightInk(skyPalette[i],displayNight));
  paint.targetAt(skyBuffer,48,62,true);
#endif
  labelCount=0; hitCount=0;
  // Prepare the complete map off-screen. Never clear the displayed map first.
  for(int y=62;y<286;y++)paint.drawFastHLine(48,y,224,textBackground(48,y));
  int cx=160,cy=174;skyCamera.transform(cx,cy);
  paint.drawCircle(cx,cy,lround(108*skyCamera.zoom),0x8CFA);
  int compassX[]={155,155,54,252},compassY[]={68,265,167,167};const char* compass[]={"N","S","O","W"};
  for(int i=0;i<4;i++){skyCamera.transform(compassX[i],compassY[i]);if(skyCamera.contains(compassX[i],compassY[i]))text(compass[i],compassX[i],compassY[i]);}
  hitCount = 0;
  if (cfg.milky) {
    int px = -1, py = -1;
    for (int latitude = -10; latitude <= 10; latitude += 2) {
    sampleChartTouch();
    px=-1;py=-1;
    for (int i = 0; i <= 360; i += 3) {
      astro_spherical_t s{ASTRO_SUCCESS, (double)latitude, (double)i, 1};
      auto t = Astronomy_TimeFromDays((double)viewTime() / 86400 - 10957.5);
      auto eq = Astronomy_EquatorFromVector(
          Astronomy_RotateVector(Astronomy_Rotation_GAL_EQJ(), Astronomy_VectorFromSphere(s, t)));
      double a, h;
      starHorizontal(eq.ra, eq.dec, a, h);
      int x, y;
      if (projectMap(a, h, x, y)) {
        if (px >= 0)
          for(int band=-2;band<=2;band++)paint.drawLine(px, py+band, x, y+band, rgb(10+(10-abs(latitude))/2,17+(10-abs(latitude)),28+(10-abs(latitude))*2));
        px = x;
        py = y;
      } else
        px = -1;
    }
  }
  }
  if (cfg.lines)
    for (auto &s : constellationLines) {
      double a, h, b, k;
      int x, y, u, v;
      starHorizontal(s.ra1, s.dec1, a, h);
      starHorizontal(s.ra2, s.dec2, b, k);
      if (projectMap(a, h, x, y) && projectMap(b, k, u, v))
        paint.drawLine(x, y, u, v, 0x212D);
    }
  int i = 0;
  for (auto &s : stars) {
    if((i%16)==0)sampleChartTouch();
    double a, h;
    int x, y;
    starHorizontal(s.ra, s.dec, a, h);
    if (projectMap(a, h, x, y)) {
      if(s.mag < 1.5) { paint.drawPixel(x-2,y,0x6B73);paint.drawPixel(x+2,y,0x6B73);paint.drawPixel(x,y-2,0x6B73);paint.drawPixel(x,y+2,0x6B73); paint.fillCircle(x,y,1,white); }
      else paint.drawPixel(x,y,s.mag < 3.5 ? white : 0x6B73);
      addHit(x, y, 100 + i);
    }
    i++;
  }
  i = 0;
  for (auto &s : deepSky) {
    double a, h;
    int x, y;
    starHorizontal(s.ra, s.dec, a, h);
    if (projectMap(a, h, x, y)) {
      paint.drawCircle(x, y, 2, 0x6B73);
      // Deep-sky names appear on tap; keep the chart uncluttered.
      addHit(x, y, 2000 + i);
    }
    i++;
  }
  if(extra.trails&&cfg.satellites&&clockReady())for(int n=0;n<SAT_COUNT;n++){
    sampleChartTouch();
    if((n==3&&!cfg.starlink)||!satellites[n].valid||satellites[n].alt<0)continue;
    int px=0,py=0,oldx=0,oldy=0;bool previous=false,segment=false;
    for(int dt=0;dt<=120;dt+=20){double az,alt;int x,y;
      if(!satelliteFuture(n,time(nullptr)+dt,az,alt)||!projectMap(az,alt,x,y))break;
      if(previous){paint.drawLine(px,py,x,y,cyan);oldx=px;oldy=py;segment=true;}px=x;py=y;previous=true;
    }
    if(segment){double a=atan2(py-oldy,px-oldx);for(int sign:{-1,1})paint.drawLine(px,py,px-lround(6*cos(a+sign*.5)),py-lround(6*sin(a+sign*.5)),cyan);}
  }
  for (i = 0; i < objectCount; i++) {
    auto &o = objects[i];
    int x, y;
    if (projectMap(o.az, o.alt, x, y)) {
      if(o.kind==0) glowSun(x,y,5); else if(o.kind==1) moonIcon(x,y,7); else {
        if(o.kind==6){
          for(int band=0;band<2;band++)for(int a=0;a<180;a++){
            double t=a*pi/90;double u=(12+band)*cos(t),v=4*sin(t);
            paint.drawPixel(x+lround(u*.94+v*.342),y+lround(-u*.342+v*.94),0xEED0);
          }
        }
        sphere(x,y,7,o.kind);
        if(o.kind==6)for(int a=0;a<90;a++){
          double t=a*pi/90,u=13*cos(t),v=4*sin(t);
          paint.drawPixel(x+lround(u*.94+v*.342),y+lround(-u*.342+v*.94),0xEED0);
        }
      }
      if (cfg.labels) mapLabel(o.name,x,y,o.color);
      addHit(x, y, i);
    }
  }
  if (cfg.satellites && cfg.view == 1)
    for (i = 0; i < SAT_COUNT; i++) {
      if (i >= 3 && !cfg.starlink)
        continue;
      auto &s = satellites[i];
      int x, y;
      if (s.valid && llabs((int64_t)time(nullptr)-s.epoch)<=7*86400 && projectMap(s.az, s.alt, x, y)) {
        if(satelliteCandidateSeconds(s,clockReady(),time(nullptr)))paint.drawCircle(x,y,16,0xFFE0);
        paint.fillRect(x-3,y-5,7,11,white);
        paint.fillRect(x-13,y-4,8,9,i==3?uint16_t(0xFFE0):cyan);paint.fillRect(x+6,y-4,8,9,i==3?uint16_t(0xFFE0):cyan);
        if (cfg.labels) mapLabel(i==3?String("Starlink"):String(s.name),x,y,i==3?uint16_t(0xFFE0):cyan);
        addHit(x, y, 3000 + i);
      }
    }
  if(cfg.labels) {
    int count=0;
    for(auto &s:constellationLabels) {
      double a,h;int x,y;starHorizontal(s.ra,s.dec,a,h);
      if(h>15 && projectMap(a,h,x,y) && count<3 && mapLabel(s.name,x,y,0x7CBA)) count++;
    }
  }
#ifndef UI_DIRECT_PREVIEW
  if(highlightedObject>=0){double az,alt;String name;int x,y;
    if(objectCoordinates(highlightedObject,az,alt,name)&&projectMap(az,alt,x,y)){paint.drawCircle(x,y,11,0xFFE0);paint.drawCircle(x,y,13,0xFFE0);}}
  paint.targetAt(lcd);
  skyBuffer.setPivot(112,112);
  skyBuffer.pushRotateZoom(160,mapCenterY(),0,mapScale(),mapScale());
  // Wait for any pending DMA before releasing the image memory.
  lcd.waitDMA();
  // Keep the fixed pixel buffer and tiny palette for the next frame.
#endif
}
static void satActions() {
  if(satPaused)button("Fortsetzen",8,375,148,40,0x051B);

}
static void planetPicture(int kind) {
  const int cx=160,cy=143,r=65;
  auto rings=[&](bool front){
    for(int band=0;band<6;band++)for(int i=0;i<720;i++){
      double t=i*pi/360;if(front&&sin(t)<0)continue;
      double x=(99+band)*cos(t),y=(28+band*.4)*sin(t);
      paint.drawPixel(cx+lround(x*.94+y*.342),cy+lround(-x*.342+y*.94),band<2?uint16_t(0xB551):uint16_t(0xEED0));
    }
  };
  if(kind==6)rings(false);
  if(kind==0)glowSun(cx,cy,r);else if(kind==1)moonIcon(cx,cy,r);else sphere(cx,cy,r,kind);
  if(kind==6)rings(true);
  label("Illustration · nicht maßstabsgetreu",40,213,uiFont11,muted);
}
static void planetDetail(bool full) {
  auto &o=objects[selected];
  static String previous[7];
  String rows[]={"Richtung "+bearing(o.az)+" / "+String(o.az,1)+"°",
    "Höhenwinkel "+String(o.alt,1)+"°", "Helligkeit "+String(o.mag,1)+" mag",
    o.alt>=0?String("Über dem Horizont"):String("Unter dem Horizont"),
    o.kind==1?"Beleuchtet: "+String((1-cos(moonPhase*DEG_TO_RAD))*50,0)+" %":String(""),
    "Beobachtung abhängig von Wolken,", "Licht, Horizont und Ausrüstung."};
  const int ys[]={244,274,304,339,364,387,403};
  if(full){text(o.name,12,43,2);planetPicture(o.kind);back();}
  for(int i=0;i<7;i++)if(full||previous[i]!=rows[i]){
    paint.fillRect(10,ys[i],302,i>=4?16:24,bg);
    if(i>=4)label(rows[i],12,ys[i],uiFont11,i>=5?muted:white);else text(rows[i],12,ys[i]);
    previous[i]=rows[i];
  }
  if(o.kind==0&&full)label("Sonne nur mit geeignetem Schutz!",12,364,uiFont11,0xFFE0);
}
static void objectDetail(bool full=true) {
  if(selected>=0&&selected<objectCount){planetDetail(full);return;}

  if(full)back();
  if (selected >= 3000) {
    auto &s = satellites[selected - 3000];
    if(full){
      label(selected==3003?String("Starlink automatisch"):String(s.name),12,43,uiFont14,white);
      paint.fillRoundRect(238,48,28,40,4,0xBDF7);
      paint.fillRect(208,57,24,24,0x249B);paint.fillRect(272,57,24,24,0x249B);
    }
    String rows[11];rows[0]="NORAD "+String(s.catalog);
    bool fresh=clockReady()&&s.valid&&llabs((int64_t)time(nullptr)-s.epoch)<=7*86400;
    if(!fresh){
      rows[1]=selected==3003?starlinkStatus.substring(0,42):!clockReady()?String("Warte auf WLAN / NTP"):s.valid?String("Bahndaten sind veraltet"):String("Noch keine Bahndaten");
      rows[2]="Position / Überflug nicht verfügbar";
      if(selected==3003){rows[3]="Katalog: "+String(starlinkCount)+" Satelliten";rows[4]="Suchlauf: "+String(starlinkScanMs)+" ms";rows[5]="Automatische Auswahl per Standort";}
      else {rows[3]=String(s.error).substring(0,38);rows[4]=satPaused?"Abruf pausiert":"Nächster Abruf automatisch";rows[5]="Frühestens "+eventStamp(satelliteRetry(selected-3000));rows[6]=satPauseReason.substring(0,36);}
    }else{
      bool pass=s.set>time(nullptr);
      rows[1]="Azimut "+String(s.az,1)+"° · Höhe "+String(s.alt,1)+"°";
      rows[2]=satelliteCountdown(s);
      rows[3]=satelliteCandidateSeconds(s,clockReady(),time(nullptr))?"Sichtchance mit bloßem Auge*":visibilityLabel(s.visibility==5?0:llabs((int64_t)time(nullptr)-s.visibilityAt)<=20?s.visibility:0);
      rows[4]=pass?(s.passOngoing?"Läuft · erfasst ":"Beginn ")+stamp(s.rise,true):String("Suche: bis 48 Stunden voraus");
      rows[5]="Ende "+(pass?stamp(s.set,true):String("—"));
      rows[6]=pass?(s.passOngoing?"Erfasste Dauer ":"Dauer ")+String((s.set-s.rise)/60)+" min · max. "+String(s.maxAlt,0)+"°":String("Dauer / Höhe noch offen");
      rows[7]=pass?bearing(s.startAz)+" → "+bearing(s.endAz):String("Richtung noch offen");
      rows[8]="*Bei klarem Himmel möglich.";
      rows[9]="Keine Garantie: Helligkeit unbekannt.";
      rows[10]="Beleuchtet; Sonne mindestens 6° tief.";
    }
    static String previous[11];static bool paused=false;
    const int ys[]={72,106,138,170,202,234,266,298,322,342,360};
    for(int i=0;i<11;i++)if(full||previous[i]!=rows[i]){
      paint.fillRect(10,ys[i],i==0?190:302,i>=8?17:24,bg);
      if(i>=8||i==1)label(rows[i],12,ys[i],uiFont11,muted);else text(rows[i],12,ys[i],1,i==3?cyan:white);
      previous[i]=rows[i];
    }
    if(full||paused!=satPaused){paint.fillRect(8,380,304,36,bg);if(satPaused)button("Fortsetzen",8,380,148,36,0x051B);paused=satPaused;}
    return;
  }
  if (selected == 20) {
    text("Erde", 12, 65, 2);
    text("Unser Beobachtungsort", 12, 110);
    return;
  }
  double az, alt, mag;
  String name;
  if (selected >= 2000) {
    auto &s = deepSky[selected - 2000];
    name = s.name;
    mag = s.mag;
    starHorizontal(s.ra, s.dec, az, alt);
  } else if (selected >= 100) {
    auto &s = stars[selected - 100];
    name = starName(selected-100);
    mag = s.mag;
    starHorizontal(s.ra, s.dec, az, alt);
  } else {
    auto &o = objects[selected];
    name = o.name;
    az = o.az;
    alt = o.alt;
    mag = o.mag;
  }
  if(full)text(name,12,57,2);
  String rows[]={"Richtung "+bearing(az)+" / "+String(az,1)+"°",
    "Höhenwinkel "+String(alt,1)+"°","Helligkeit "+String(mag,1)+" mag",
    alt>=0?String("Über dem Horizont"):String("Unter dem Horizont"),
    "Beobachtung abhängig von Wolken,","Licht, Horizont und Ausrüstung."};
  const int ys[]={110,145,180,230,273,298};static String previous[6];
  for(int i=0;i<6;i++)if(full||previous[i]!=rows[i]){paint.fillRect(10,ys[i],302,24,bg);text(rows[i],12,ys[i]);previous[i]=rows[i];}

}
static const char *letters[] = {"q", "w", "e", "r", "t", "z", "u", "i", "o", "p",
                                "a", "s", "d", "f", "g", "h", "j", "k", "l", "ü",
                                "y", "x", "c", "v", "b", "n", "m", "ö", "ä", "ß"};
static const char *symbols[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0",
                                "!", "@", "#", "$", "%", "&", "*", "(", ")", "?",
                                "-", "_", ".", ",", ":", ";", "/", "+", "=", "\""};
static void keyboardDraw() {
  text(title, 8, 43, 2);
  paint.drawRect(8, 80, 304, 70, muted);
  String shown = input;
  if (purpose == 2 && !showPassword) {
    shown = "";
    for (unsigned i = 0; i < input.length(); i++)
      shown += "*";
  }
  text(shown.substring(shown.length() > 32 ? shown.length() - 32 : 0), 14, 105);
  text("Zeichen: " + String(input.length()), 12, 159, 1, muted);
  if (purpose == 2)
    button(showPassword ? "Verbergen" : "Anzeigen", 172, 154, 140, 32);
  for (int k = 0; k < 30; k++) {
    String s = keyLayout ? symbols[k] : letters[k];
    if (shifted && !keyLayout)
      {s.toUpperCase();if(s=="ä")s="Ä";if(s=="ö")s="Ö";if(s=="ü")s="Ü";}
    button(s, k % 10 * 32 + 1, 198 + k / 10 * 47, 30, 43);
  }
  button(shifted ? "abc" : "ABC", 3, 342, 67, 39);
  button(keyLayout ? "abc" : "123", 74, 342, 67, 39);
  button("Leer", 145, 342, 83, 39);
  button("DEL", 232, 342, 85, 39);
  button("Abbruch", 8, 405, 145, 54, 0xA986);
  button("OK", 163, 405, 149, 54, 0x0414);
}
static void objectListScreen(){
    button(objectQuery.length()?objectQuery:"Heute sichtbar · Suchen",8,42,304,34,0x0254);
    String q=objectQuery;q.toLowerCase();objectMatches=0;for(int &choice:objectChoices)choice=-1;
    if(clockReady())for(int id=0;id<100+(int)(sizeof stars/sizeof stars[0]);id++){
      if(id>=objectCount&&id<100)continue;double az,alt;String name;if(!objectCoordinates(id,az,alt,name))continue;
      String lower=name;lower.toLowerCase();if(q.length()?lower.indexOf(q)<0:(id<2||id>=100||alt<0))continue;
      int row=objectMatches++-objectOffset;if(row<0||row>=6)continue;objectChoices[row]=id;
      label(name,12,82+48*row,uiFont14,alt>=0?white:muted);
      label(bearing(az)+" · "+String(alt,1)+"°"+(alt<0?" · unter Horizont":" · markieren"),12,104+48*row,uiFont11,muted);
    }
    if(!objectMatches)label(clockReady()?"Keine passenden Objekte":"Warte auf Uhrzeit",12,90,uiFont14,muted);
    button("<",8,380,145,36);button(">",163,380,149,36);back();

}
static void flightScreen(bool force){
 static String last;String key=String(flight.received)+flight.error+String(flightFresh())+String(modern.aircraft);
 if(!force&&key==last)return;last=key;paint.fillRect(0,30,320,406,0);labelBackground=0;
 label("Nächstes Flugzeug",12,42,uiFont20,white);
 label(String(modern.radius)+" km · "+(modern.approaching?"Nähert sich":"Nächstes"),12,72,uiFont14,cyan);
 // Compact vector aircraft silhouette, no image allocation.
 paint.fillTriangle(160,105,150,220,170,220,white);paint.fillTriangle(160,140,90,190,230,190,white);
 paint.fillTriangle(160,200,130,225,190,225,white);paint.fillCircle(91,189,3,0xf800);
 if(!modern.aircraft)label("Ansicht ausgeschaltet",12,248,uiFont20,muted);
 else if(!flight.checked&&!flight.error[0])label("Flugdaten werden geladen",12,248,uiFont14,muted);
 else if(flight.found){
  label(flight.callsign[0]?flight.callsign:flight.hex,12,245,uiFont20,white);
  label(flight.type[0]?flight.type:"Typ nicht verfügbar",12,277,uiFont14,muted);
  label(String(flight.distance,1)+" km · "+bearing(flight.azimuth),12,306,uiFont20,cyan);
  label((isfinite(flight.altitude)?String(flight.altitude,0):String("—"))+" m baro",12,336,uiFont14,white);
  label((isfinite(flight.speed)?String(flight.speed,0):String("—"))+" km/h · "+bearing(flight.track),12,360,uiFont14,white);
  label(flightFresh()?"Position aktuell":"Position veraltet",12,390,uiFont14,flightFresh()?cyan:0xf800);
 }else label(flight.error[0]?"Datenquelle nicht erreichbar":"Kein passendes Flugzeug",12,248,uiFont14,flight.error[0]?0xf800:muted);
 labelBackground=-1;
}
void uiDraw() {
  struct RenderTimer{uint32_t at=micros();~RenderTimer(){renderMaxUs=max(renderMaxUs,micros()-at);}} timer;
  static int lastPage=-1,lastView=-1,lastPlace=-1,lastSelected=-1;
  static uint32_t lastDetailGeneration=UINT32_MAX;
  static time_t lastFetched=0,lastMinute=-1;
  static int lastWifi=-1;static String lastError;static bool lastValid=false,lastStale=false;
  bool stale=weather.valid && (!clockReady() || time(nullptr)-weather.fetched>1800);
  static bool lastNight=false;
  static uint32_t lastSurfaceRevision=UINT32_MAX;
  static String lastMenuKey;
  String menuKey=String(cfg.brightness)+":"+String(cfg.labels)+String(cfg.lines)+String(cfg.milky)+String(cfg.satellites)+String(cfg.autoSeconds)+String(cfg.place)+String(cfg.placeCount)+String(cfg.wifiCount);
  if(page==12)menuKey+=objectQuery+String(objectOffset)+String((long)(time(nullptr)/60));
  if(page==2){menuKey+=message+String(nearbyCount);for(int i=0;i<nearbyCount;i++)menuKey+=nearby[i];}
  if(page==3)for(int i=0;i<cfg.wifiCount;i++)menuKey+=cfg.wifi[i].ssid;
  if(page==5||page==9)for(int i=0;i<cfg.placeCount;i++)menuKey+=cfg.places[i].name;
  if(page==7){menuKey+=String(satPaused);for(int i=0;i<3;i++)menuKey+=String(satellites[i].valid)+stamp(satellites[i].rise)+String(satellites[i].error);}
  bool stableMenu=page>0&&page!=8&&page!=11&&page==lastPage&&displayNight==lastNight&&surfaceRevision==lastSurfaceRevision&&menuKey==lastMenuKey;
  if(stableMenu){
    if(time(nullptr)/60!=lastMinute||WiFi.status()!=lastWifi){lcd.startWrite();header();lcd.endWrite();lastMinute=time(nullptr)/60;lastWifi=WiFi.status();}
    return;
  }
  lastMenuKey=menuKey;
  bool samePlanet=page==8&&lastPage==8&&selected>=0&&selected<objectCount&&selected==lastSelected&&cfg.place==lastPlace&&displayNight==lastNight&&generation==lastDetailGeneration&&surfaceRevision==lastSurfaceRevision;
  bool sameDetail=page==8&&lastPage==8&&selected==lastSelected&&cfg.place==lastPlace&&displayNight==lastNight&&generation==lastDetailGeneration&&surfaceRevision==lastSurfaceRevision;
  bool sameDay=page==11&&lastPage==11&&cfg.place==lastPlace&&displayNight==lastNight&&surfaceRevision==lastSurfaceRevision&&weather.fetched==lastFetched;
  lastSelected=selected;lastDetailGeneration=generation;
  lastSurfaceRevision=surfaceRevision;
  static bool lastLarge=false;bool layoutSame=lastLarge==extra.largeMap;lastLarge=extra.largeMap;
  bool same=layoutSame&&displayNight==lastNight && page==0 && lastPage==0 && cfg.view==lastView && cfg.place==lastPlace;
  bool weatherSame=same && cfg.view==0 && lastFetched==weather.fetched && lastError==weather.error && lastValid==weather.valid && lastStale==stale;
  lastPage=page;lastView=cfg.view;lastPlace=cfg.place;lastFetched=weather.fetched;lastError=weather.error;lastValid=weather.valid;lastStale=stale;
  lastNight=displayNight;
  lcd.startWrite();
  if(weatherSame && weather.valid) {header();lcd.endWrite();return;}
  if(page!=0&&!sameDetail&&!sameDay) paint.fillScreen(bg);
  if((!same&&!sameDetail&&!sameDay) || time(nullptr)/60!=lastMinute || WiFi.status()!=lastWifi)header();
  lastMinute=time(nullptr)/60;lastWifi=WiFi.status();
  if (page == 0) {
    if (cfg.view == 0)
      weatherScreen();
    else if (cfg.view == 1)
      skyScreen(!same);
    else if(cfg.view==2)flightScreen(!same);

    static uint32_t lastNavCamera=UINT32_MAX;
    if(!same||lastNavCamera!=skyCamera.revision){nav();lastNavCamera=skyCamera.revision;}
  } else if(page==12){objectListScreen();
  } else if (page == 11) {
    if(!sameDay)dayScreen();
  } else if (page == 1) {
    text("Einstellungen", 12, 42, 2);
    button("WLAN", 8, 78, 304, 42);
    button("Standorte", 8, 127, 304, 42);
    button("Anzeige / Ebenen", 8, 176, 304, 42);
    button("Satelliten", 8, 225, 304, 42);
    button("Touch neu kalibrieren", 8, 274, 304, 42);
    button("Display um 180° drehen", 8, 323, 304, 42);
    button("WETTER",4,374,100,40,0x0254);
    button("HIMMEL",108,374,100,40,0x0254);button("FLUG",212,374,104,40,0x0254);
    back();
  } else if (page == 2) {
    text("WLAN", 8, 39, 2);
    text(String(message).substring(0, 42), 8, 67);
    button("Suchen", 8, 89, 145, 36);
    button("Gespeicherte", 163, 89, 149, 36);
    for (int i = 0; i < 5; i++) {
      int k = networkPage * 5 + i;
      if (k < nearbyCount)
        button(nearby[k].substring(0, 30), 8, 133 + 43 * i, 304, 39);
    }
    button("<", 8, 353, 66, 35);
    button("Manuell", 80, 353, 160, 35);
    button(">", 246, 353, 66, 35);
    label("AP WetterWeltall · 192.168.4.1",8,393,uiFont11,white);
    back();
  } else if (page == 3) {
    text("Gespeicherte WLANs", 8, 43, 2);
    for (int i = 0; i < cfg.wifiCount; i++)
      button(cfg.wifi[i].ssid, 8, 83 + i * 45, 304, 40);
    text("AP-Passwort:", 8, 364);
    text(apPassword, 8, 387);
    back();
  } else if (page == 4) {
    text(cfg.wifi[profile].ssid, 8, 55, 2);
    button("Verbinden", 8, 115, 304, 50);
    button("Passwort ändern", 8, 180, 304, 50);
    button("WLAN löschen", 8, 245, 304, 50, 0xA986);
    back();
  } else if (page == 5) {
    text("Standorte", 8, 43, 2);
    for (int i = 0; i < cfg.placeCount; i++)
      button(String(i == cfg.place ? "✓ " : "") + cfg.places[i].name, 8, 80 + i * 44, 240, 40,
             i == cfg.place ? 0x0414 : 0x21AA);
    for (int i = 0; i < cfg.placeCount; i++)
      button("…", 253, 80 + i * 44, 59, 40);
    button("Neuer Standort", 8, 359, 304, 44);
    back();
  } else if (page == 6) {
    text("Anzeige", 8, 43, 2);
    button("Helligkeit −", 8, 81, 145, 40);
    button("Helligkeit +", 163, 81, 149, 40);
    button(String("Namen: ") + (cfg.labels ? "Ein" : "Aus"), 8, 132, 304, 40);
    button(String("Sternbildlinien: ") + (cfg.lines ? "Ein" : "Aus"), 8, 181, 304, 40);
    button(String("Milchstraße: ") + (cfg.milky ? "Ein" : "Aus"), 8, 230, 304, 40);
    button(String("Satelliten: ") + (cfg.satellites ? "Ein" : "Aus"), 8, 279, 304, 40);
    button("Auto-Wechsel: " + (cfg.autoSeconds ? String(cfg.autoSeconds) + " s" : "Aus"), 8, 328,
           304, 40);
    button("Gesamtkarte",8,378,148,36);
    button(displayNight?"Nacht: Ein":"Nacht: Aus",164,378,148,36);
    back();
  } else if (page == 7) {
    text("Satelliten", 8, 43, 2);
    for (int i = 0; i < 3; i++) {
      auto &s = satellites[i];
      button(s.name, 8, 85 + i * 100, 304, 42);
      text(s.valid ? "Start " + stamp(s.rise, true) : "Noch keine Bahndaten", 8, 135 + i * 100);
      if (s.error[0])
        text(s.error, 8, 154 + i * 100, 1, 0xFFE0);
    }
    button("Starlink →", 8, 383, 148, 34, 0x681A);
    button(satPaused ? "API fortsetzen" : "API aktiv", 164, 383, 148, 34);
    back();
  } else if (page == 8)
    objectDetail(!sameDetail);
  else if (page == 9) {
    text(cfg.places[editPlace].name, 8, 55, 2);
    button("Bearbeiten", 8, 120, 304, 48);
    button("Löschen", 8, 185, 304, 48, 0xA986);
    back();
  } else if (page == 10)
    keyboardDraw();
  lcd.endWrite();
}
static void submit() {
  if(purpose==9){objectQuery=input;objectOffset=0;page=12;return;}
  String err;
  JsonDocument d;
  if (purpose == 1) {
    wifiName = input;
    keyboard("WLAN-Passwort", "", 2);
    return;
  }
  if (purpose == 2) {
    if (saveWifi(wifiName, input))
      { page = 2; input = ""; showPassword = false; }
    else
      title = message;
  }
  if (purpose == 4) {
    strlcpy(draft.name, input.c_str(), 40);
    keyboard("Breite −90 bis 90", String(draft.lat, 6), 5);
    return;
  }
  if (purpose == 5) {
    char *end;
    double v = strtod(input.c_str(), &end);
    if (*end || !isfinite(v) || v < -90 || v > 90) {
      title = "Ungültige Breite";
      return;
    }
    draft.lat = v;
    keyboard("Länge −180 bis 180", String(draft.lon, 6), 6);
    return;
  }
  if (purpose == 6) {
    char *end;
    double v = strtod(input.c_str(), &end);
    if (*end || !isfinite(v) || v < -180 || v > 180) {
      title = "Ungültige Länge";
      return;
    }
    draft.lon = v;
    keyboard("Höhe über Meer (m)",String(draft.height,0),9);
    return;
  }
  if(purpose==9){char *end;double h=strtod(input.c_str(),&end);if(*end||!isfinite(h)||h< -500||h>9000){title="Höhe −500 bis 9000 m";return;}draft.height=h;keyboard("Zeitzone (POSIX)",draft.tz,7);return;}
  if (purpose == 7) {
    if (input.isEmpty() || input.length() > 79) {
      title = "Zeitzone prüfen";
      return;
    }
    strlcpy(draft.tz, input.c_str(), 80);
    if (editPlace < 0) {
      if (cfg.placeCount == 6) {
        title = "Maximal 6 Standorte";
        return;
      }
      editPlace = cfg.placeCount++;
    }
    cfg.places[editPlace] = draft;
    cfg.place = editPlace;
    saveSettings();
    applyPlace();
    page = 5;
  }
}
struct QueuedTouch {int event,x,y,page,view;};
static QueuedTouch touchQueue[8];
static uint8_t touchQueueRead=0,touchQueueWrite=0;
// Sampling never dispatches actions: safe inside astronomy calculations.
void uiPollTouch() {
  static TouchGesture gesture;static int beganPage=0,beganView=0;
  int32_t x=0,y=0;bool down=lcd.getTouch(&x,&y);
  if(touchSleepGate(down)){gesture=TouchGesture();touchQueueRead=touchQueueWrite;return;}
  int eventPage=beganPage,eventView=beganView;
  uint32_t sequence=gesture.sequence;
  int event=gesture.update(down,x,y,millis(),beganPage==0&&gesture.sy>=44);
  if(sequence!=gesture.sequence){beganPage=page;beganView=cfg.view;}
  if(!event)return;
  uint8_t next=(touchQueueWrite+1)%8;
  if(next==touchQueueRead)return; // bounded queue; never repeat an action
  touchQueue[touchQueueWrite]={event,gesture.eventX,gesture.eventY,eventPage,eventView};
  touchQueueWrite=next;
}
void uiTick() {
#ifndef UI_DIRECT_PREVIEW
  if(mapDeferred && !networkOwnsMemory && page==0 && cfg.view==1 &&
      (int32_t)(millis()-mapRetryAt)>=0) {
    mapRetryAt=millis()+1000;
    dirty=true;
  }
#endif
  uiPollTouch();
  if(touchQueueRead==touchQueueWrite)return;
  QueuedTouch t=touchQueue[touchQueueRead];touchQueueRead=(touchQueueRead+1)%8;
  if(t.page!=page||t.view!=cfg.view)return;
  manualInteraction();
  if(t.event==2){setView((cfg.view+1)%(modern.aircraft?3:2));return;}
  int x=t.x,y=t.y;
  ++surfaceRevision;
  dirty = true;
  if (page == 10) {
    if (purpose == 2 && x >= 172 && x < 312 && y >= 154 && y < 186) {
      showPassword = !showPassword;
    } else if (y >= 198 && y < 339) {
      int k = (y - 198) / 47 * 10 + x / 32;
      if (k >= 0 && k < 30 && input.length() < 79) {
        String s = keyLayout ? symbols[k] : letters[k];
        if (shifted && !keyLayout)
          {s.toUpperCase();if(s=="ä")s="Ä";if(s=="ö")s="Ö";if(s=="ü")s="Ü";}
        input += s;
      }
    } else if (y >= 342 && y < 383) {
      if (x < 72)
        shifted = !shifted;
      else if (x < 144)
        keyLayout = !keyLayout;
      else if (x < 230)
        input += " ";
      else if (input.length()) {
        int n = input.length() - 1;
        while (n > 0 && ((uint8_t)input[n] & 0xC0) == 0x80)
          n--;
        input.remove(n);
      }
    } else if (y >= 405) {
      if (x < 160)
        page = 1;
      else
        submit();
    }
    return;
  }
  if (y < 44 && x >= 260) {
    page = 1;
    return;
  }
  if (page && y >= 424) {
    page = (page == 8 || page == 11 || page == 12 || page == 1) ? 0 : 1;
    selected = -1;
    return;
  }
  if(page==12){
    if(y>=42&&y<76){keyboard("Objekt suchen",objectQuery,9);return;}
    if(y>=80&&y<368){int k=(y-80)/48;double az,alt;String name;int id=objectChoices[k];
      if(id>=0&&objectCoordinates(id,az,alt,name)&&alt>=0){highlightedObject=id;setView(1);skyCamera.set(1,0,0);skyCamera.revision++;}return;}
    if(y>=380&&y<418){objectOffset=max(0,objectOffset+(x<160?-6:6));if(objectOffset>=objectMatches)objectOffset=0;return;}return;
  }
  if (page == 0) {
    if(cfg.view==1&&x<120&&y>=438&&y<464){page=12;objectOffset=0;objectQuery="";return;}
    if(cfg.view==0 && weather.valid && y>=230 && y<412){selectedDay=(y-230)/26;page=11;return;}
    if(cfg.view==1&&x>=194&&y>=438&&y<464){skyCamera.set(1,0,0);dirty=true;return;}
    if (y >= 436) return;
    if (cfg.view == 1 && !extra.largeMap && y >= 366 && y < 434) {
      int slot=min(1,(int)x/160)+(y>=401?2:0);
      {selected=3000+slot;page=8;}
      return;
    }
    if (cfg.view == 1) {
      int target=skyHitTarget(x,y);
      if(target>=0){selected=target;page=8;}
    }
    return;
  }
  if (page == 1) {
    if(y>=374 && y<418){setView(x<107?0:x<214?1:2);return;}
    if (y >= 78 && y < 120) {
      page = 2;
      scanStart();
    } else if (y < 169 && y >= 127)
      page = 5;
    else if (y < 218 && y >= 176)
      page = 6;
    else if (y < 267 && y >= 225)
      page = 7;
    else if (y >= 274 && y < 316)
      calibrate();
    else if (y >= 323 && y < 365) {
      cfg.rotation = cfg.rotation == 0 ? 2 : 0;
      saveSettings();
      lcd.setRotation(cfg.rotation);
      calibrate();
    }
  } else if (page == 2) {
    if (y >= 89 && y < 125) {
      if (x < 160)
        scanStart();
      else
        page = 3;
    } else if (y >= 133 && y < 348) {
      int k = networkPage * 5 + (y - 133) / 43;
      if (k < nearbyCount) {
        wifiName = nearby[k];
        keyboard("Passwort: " + wifiName, "", 2);
      }
    } else if (y >= 353 && y < 388) {
      if (x < 75)
        networkPage = max(0, networkPage - 1);
      else if (x > 240)
        networkPage = min(3, networkPage + 1);
      else
        keyboard("WLAN-Name (SSID)", "", 1);
    }
  } else if (page == 3 && y >= 83 && y < 353) {
    int i = (y - 83) / 45;
    if (i < cfg.wifiCount) {
      profile = i;
      page = 4;
    }
  } else if (page == 4) {
    if (y >= 115 && y < 165) {
      connectProfile(profile);
      page = 2;
    } else if (y >= 180 && y < 230) {
      wifiName = cfg.wifi[profile].ssid;
      keyboard("Neues Passwort", "", 2);
    } else if (y >= 245 && y < 295) {
      deleteWifi(profile);
      page = 3;
    }
  } else if (page == 5) {
    if (y >= 80 && y < 344) {
      int i = (y - 80) / 44;
      if (i < cfg.placeCount) {
        if (x < 250) {
          cfg.place = i;
          saveSettings();
          applyPlace();
        } else {
          editPlace = i;
          page = 9;
        }
      }
    } else if (y >= 359 && y < 403) {
      draft = cfg.places[cfg.place];
      editPlace = -1;
      keyboard("Standortname", "", 4);
    }
  } else if (page == 6) {
    if(y>=378&&y<414){if(x<160){skyCamera.set(1,0,0);setView(1);}else setDisplayNight(!displayNight);return;}
    if (y >= 81 && y < 121) {
      cfg.brightness = constrain(cfg.brightness + (x < 160 ? -20 : 20), 20, 255);
      uiDisplayBrightness();
    } else if (y >= 132 && y < 172)
      cfg.labels = !cfg.labels;
    else if (y >= 181 && y < 221)
      cfg.lines = !cfg.lines;
    else if (y >= 230 && y < 270)
      cfg.milky = !cfg.milky;
    else if (y >= 279 && y < 319)
      cfg.satellites = !cfg.satellites;
    else if (y >= 328 && y < 368)
      cfg.autoSeconds = cfg.autoSeconds == 0    ? 15
                        : cfg.autoSeconds == 15 ? 30
                        : cfg.autoSeconds == 30 ? 60
                                                : 0;
    saveSettings();
  } else if (page == 7) {
    if (y >= 383 && y < 417) {
      if (x < 160)
        {selected=3003;page=8;}
      else
        resumeSatellites();
    } else if (y >= 85 && y < 383) {
      selected = 3000 + (y - 85) / 100;
      page = 8;
    }
  } else if(page==8 && selected>=3000 && satPaused && x<160 && y>=375 && y<415)resumeSatellites();
  else if (page == 9) {
    if (y >= 120 && y < 168) {
      draft = cfg.places[editPlace];
      keyboard("Standortname", draft.name, 4);
    } else if (y >= 185 && y < 233 && cfg.placeCount > 1) {
      for (int i = editPlace; i < cfg.placeCount - 1; i++)
        cfg.places[i] = cfg.places[i + 1];
      cfg.placeCount--;
      cfg.place = 0;
      saveSettings();
      applyPlace();
      page = 5;
    }
  }
}
