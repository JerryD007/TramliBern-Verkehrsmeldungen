#pragma once
#include <stdint.h>
#include <stdlib.h>
// A release is confirmed after 30 ms. An observed gap can complete a gesture
// even when the next sample is already down; keep that new contact separately.
struct TouchGesture {
 bool tracking=false,gapObserved=false;
 int sx=0,sy=0,ex=0,ey=0,maxMove=0,eventX=0,eventY=0;
 uint32_t started=0,lastSeen=0,sequence=0;
 void begin(int x,int y,uint32_t now){tracking=true;gapObserved=false;sx=ex=x;sy=ey=y;maxMove=0;started=lastSeen=now;++sequence;}
 int finish(uint32_t now,bool allowSwipe){
  tracking=false;gapObserved=false;eventX=ex;eventY=ey;
  int dx=abs(ex-sx),dy=abs(ey-sy);
  if(allowSwipe&&now-started<1800&&dx>=45&&dx*2>dy*3)return 2;
  if(maxMove<=24){eventX=ex=sx;eventY=ey=sy;return 1;}
  return 0;
 }
 int update(bool down,int x,int y,uint32_t now,bool allowSwipe){
  if(down){
   int event=0;
   if(tracking&&gapObserved&&now-lastSeen>=30)event=finish(now,allowSwipe);
   if(!tracking)begin(x,y,now);
   else{lastSeen=now;gapObserved=false;ex=x;ey=y;int m=abs(x-sx)>abs(y-sy)?abs(x-sx):abs(y-sy);if(m>maxMove)maxMove=m;}
   return event;
  }
  if(!tracking)return 0;
  gapObserved=true;
  if(now-lastSeen<30)return 0;
  return finish(now,allowSwipe);
 }
};
