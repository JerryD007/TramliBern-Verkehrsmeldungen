#include "MemoryProbe.h"
#include <esp_heap_caps.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
// One weather worker. The failure callback can also run on the other core.
// No logging, heap calls, String creation, or blocking operation in the hook.
static portMUX_TYPE probeMux=portMUX_INITIALIZER_UNLOCKED;
static TaskHandle_t owner=nullptr;
static MemoryProbeResult result;
static bool registered=false;
static uint8_t phase=0;
static void allocationFailed(size_t bytes,uint32_t caps,const char *name) {
  TaskHandle_t current=xTaskGetCurrentTaskHandle();
  portENTER_CRITICAL_SAFE(&probeMux);
  if(owner) {
    auto &f=current==owner?result.worker:result.other;
    if(f.count==0) {
      f.bytes=bytes;f.caps=caps;f.phase=phase;
      unsigned i=0;
      if(name)for(;i+1<sizeof f.allocator && name[i];i++)f.allocator[i]=name[i];
      f.allocator[i]=0;
    }
    if(f.count!=UINT32_MAX)++f.count;
  }
  portEXIT_CRITICAL_SAFE(&probeMux);
}
void memoryProbeInit(){registered=heap_caps_register_failed_alloc_callback(allocationFailed)==ESP_OK;}
void memoryProbeBegin(){
  portENTER_CRITICAL_SAFE(&probeMux);
  result={};result.registered=registered;phase=1;owner=xTaskGetCurrentTaskHandle();
  portEXIT_CRITICAL_SAFE(&probeMux);
}
void memoryProbePhase(uint8_t value){
  portENTER_CRITICAL_SAFE(&probeMux);phase=value;portEXIT_CRITICAL_SAFE(&probeMux);
}
MemoryProbeResult memoryProbeEnd(){
  portENTER_CRITICAL_SAFE(&probeMux);
  owner=nullptr;auto copy=result;
  portEXIT_CRITICAL_SAFE(&probeMux);
  return copy;
}
