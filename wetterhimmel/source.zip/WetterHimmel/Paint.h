#pragma once
#include "NightPalette.h"
#include "SkyPalette.h"
extern bool displayNight;
// Force all RGB565 values, including integer expressions, through uint16_t.
// LovyanGFX interprets wider integer arguments as RGB888.
#ifdef UI_HOST_PREVIEW
using PaintTarget=Display;
#else
using PaintTarget=lgfx::LGFXBase;
#endif
class Paint {
  PaintTarget *target;
  int ox=0,oy=0;bool indexed=false;
  uint16_t ink(uint16_t c){return indexed?skyPaletteIndex(c):nightInk(c,displayNight);}
public:
  explicit Paint(PaintTarget &device):target(&device){}
  void targetAt(PaintTarget &device,int x=0,int y=0,bool palette=false){target=&device;ox=x;oy=y;indexed=palette;}
  void drawPixel(int x,int y,uint16_t c){target->drawPixel(x-ox,y-oy,ink(c));}
  void drawFastHLine(int x,int y,int w,uint16_t c){target->drawFastHLine(x-ox,y-oy,w,ink(c));}
  void drawFastVLine(int x,int y,int h,uint16_t c){target->drawFastVLine(x-ox,y-oy,h,ink(c));}
  void drawLine(int x,int y,int u,int v,uint16_t c){target->drawLine(x-ox,y-oy,u-ox,v-oy,ink(c));}
  void drawRect(int x,int y,int w,int h,uint16_t c){target->drawRect(x-ox,y-oy,w,h,ink(c));}
  void fillRect(int x,int y,int w,int h,uint16_t c){target->fillRect(x-ox,y-oy,w,h,ink(c));}
  void drawRoundRect(int x,int y,int w,int h,int r,uint16_t c){target->drawRoundRect(x-ox,y-oy,w,h,r,ink(c));}
  void fillRoundRect(int x,int y,int w,int h,int r,uint16_t c){target->fillRoundRect(x-ox,y-oy,w,h,r,ink(c));}
  void drawCircle(int x,int y,int r,uint16_t c){target->drawCircle(x-ox,y-oy,r,ink(c));}
  void fillTriangle(int x,int y,int u,int v,int a,int b,uint16_t c){target->fillTriangle(x-ox,y-oy,u-ox,v-oy,a-ox,b-oy,ink(c));}
  void fillCircle(int x,int y,int r,uint16_t c){target->fillCircle(x-ox,y-oy,r,ink(c));}
  void fillScreen(uint16_t c){target->fillScreen(ink(c));}
};
