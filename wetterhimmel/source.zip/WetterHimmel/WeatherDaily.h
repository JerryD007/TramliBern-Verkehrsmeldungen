#pragma once
// Missing values remain NAN/-1/0, never a fabricated zero forecast.
static void parseWeatherDay(Day &out, JsonVariant a, int i, int utcOffset) {
  auto num=[](JsonVariant v)->float {return v.is<double>() && isfinite(v.as<double>()) ? v.as<float>() : NAN;};
  time_t t=a["time"][i].as<time_t>()+utcOffset;
  struct tm tm{};gmtime_r(&t,&tm);strftime(out.date,sizeof out.date,"%Y-%m-%d",&tm);
  out.min=num(a["temperature_2m_min"][i]);out.max=num(a["temperature_2m_max"][i]);
  out.code=a["weather_code"][i].is<int>()?a["weather_code"][i].as<int>():-1;
  out.rain=a["precipitation_probability_max"][i].is<int>()?a["precipitation_probability_max"][i].as<int>():-1;
  out.feelsMin=num(a["apparent_temperature_min"][i]);out.feelsMax=num(a["apparent_temperature_max"][i]);
  out.precipitation=num(a["precipitation_sum"][i]);out.precipitationHours=num(a["precipitation_hours"][i]);
  out.snow=num(a["snowfall_sum"][i]);out.windMax=num(a["wind_speed_10m_max"][i]);
  out.gustMax=num(a["wind_gusts_10m_max"][i]);out.windDirection=num(a["wind_direction_10m_dominant"][i]);
  out.sunshine=num(a["sunshine_duration"][i]);out.uv=num(a["uv_index_max"][i]);
  out.sunrise=a["sunrise"][i].is<int64_t>()?a["sunrise"][i].as<time_t>():0;
  out.sunset=a["sunset"][i].is<int64_t>()?a["sunset"][i].as<time_t>():0;
}
