#include "App.h"
#include "Modern.h"
#include "Starlink.h"
#include "RetryPolicy.h"
#include "Certificates.h"
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <esp_wifi.h>
#include "WeatherTrace.h"
#include "WeatherDaily.h"
char weatherDiagnostic[1200] = "Noch kein Wetterabruf seit Start.";
char weatherLastFailure[1200] = "Noch kein fehlgeschlagener Diagnoseabruf.";
bool satPaused = false;
time_t satHoldUntil=0;
String satPauseReason;
static uint32_t satGap=0;
bool scanRunning = false, scanRequested = false;
String nearby[20];
int nearbyCount = 0;
static uint32_t scanAt = 0, attemptAt = 0, nextWeather = 0, nextSat[SAT_COUNT] = {};
static int attempt = -1;
static bool beginPending = false, disconnectPending = false;
static bool wasConnected = false, busy = false;
bool networkBusy(){return busy;}
struct Job {
  int kind;
  uint32_t generation;
  Place place;
  int catalog;int radius;bool approaching;
};
struct Result {
  int kind;
  uint32_t generation;
  Weather weather;Hourly hourly;Flight flight;
  int catalog;
  char omm[1600], error[96];
  char diagnostic[1200];
  uint32_t duration;
  int httpStatus;
  uint32_t retrySeconds;
};
static QueueHandle_t jobs, results;
static uint32_t nextAircraft=0;
static bool getUrl(String url, String &data, String &error, int &httpStatus, uint32_t &retrySeconds, char *diagnostic = nullptr) {
  httpStatus=0; retrySeconds=7200;
  WeatherTrace trace(diagnostic, error);
  WiFiClientSecure client; // Destroy TLS before the final memory measurement.
  if (diagnostic) {
    IPAddress resolved;
    uint32_t dnsStart = millis();
    String host=url.substring(8);host=host.substring(0,host.indexOf('/'));
    int dnsResult = WiFi.hostByName(host.c_str(), resolved);
    trace.add("DNS %s: %s (%lu ms)\n",host.c_str(), dnsResult == 1 ? resolved.toString().c_str() : "FEHLGESCHLAGEN", (unsigned long)(millis()-dnsStart));
    if (dnsResult != 1) { error = "DNS-Aufloesung fehlgeschlagen"; return false; }
  }
  client.setCACertBundle(rootBundle, sizeof rootBundle);
  client.setTimeout(25000);
  HTTPClient h;
  h.setConnectTimeout(8000);
  h.setTimeout(25000);
  h.useHTTP10(true);
  h.setFollowRedirects(HTTPC_DISABLE_FOLLOW_REDIRECTS);
  if (!h.begin(client, url)) {
    error = "HTTPS Start fehlgeschlagen";
    return false;
  }
  h.addHeader("User-Agent", "WetterWeltall/1.0 private-ESP32");
  const char *wanted[]={"Retry-After"};h.collectHeaders(wanted,1);
  if(diagnostic)memoryProbePhase(2); // Includes TCP/TLS handshake and response headers.
  int status = h.GET();httpStatus=status;
  if(diagnostic)trace.memory("Nach GET, TLS noch offen");
  if(diagnostic)memoryProbePhase(3);
  if (diagnostic) {
    trace.add("HTTPClient: %d\n",status);
    if(status>0)trace.add("TLS: Verbindung aufgebaut; HTTP-Antwort empfangen\n");
    else {
      char tlsText[192] = {};
      int tlsCode = client.lastError(tlsText, sizeof tlsText);
      if(tlsCode<0)trace.add("TLS-Code: %d\nTLS-Detail: %.160s\n",tlsCode,tlsText);
      else trace.add("TLS: Kein negativer TLS-Fehlercode verfügbar\n");
    }
  }
  String retry=h.header("Retry-After");
  if(retry.length()) {
    char *end;unsigned long seconds=strtoul(retry.c_str(),&end,10);
    if(!*end) retrySeconds=max((uint32_t)7200,(uint32_t)min(seconds,2592000UL));
    else {struct tm tm{}; if(strptime(retry.c_str(),"%a, %d %b %Y %H:%M:%S GMT",&tm)) {
      auto t=Astronomy_MakeTime(tm.tm_year+1900,tm.tm_mon+1,tm.tm_mday,tm.tm_hour,tm.tm_min,tm.tm_sec);
      int64_t delay=(int64_t)((t.ut+10957.5)*86400)-time(nullptr);
      if(delay>7200) retrySeconds=(uint32_t)min(delay,(int64_t)2592000);
    }}
  }
  if (status != 200) {
    error = status == HTTPC_ERROR_READ_TIMEOUT ? "Zeitlimit beim Datenabruf (-11)" :
            status < 0 ? "Verbindung fehlgeschlagen (" + String(status) + ")" : "HTTP " + String(status);
    h.end();
    return false;
  }
  int length = h.getSize();
  if (length > 24000) {
    error = "Antwort zu gross";
    h.end();
    return false;
  }
  data = "";
  data.reserve(length > 0 ? length : 4096);
  auto stream = h.getStreamPtr();
  uint32_t until = millis();
  while ((h.connected() || stream->available()) &&
         (length < 0 || data.length() < (unsigned)length)) {
    while (stream->available()) {
      char c = stream->read();
      data += c;
      until = millis();
      if (data.length() > 24000) {
        error = "Antwortlimit";
        h.end();
        return false;
      }
    }
    if (millis() - until > 25000) {
      error = "Antwort unvollstaendig";
      h.end();
      return false;
    }
    vTaskDelay(1);
  }
  h.end();
  if (length >= 0 && data.length() != (unsigned)length) {
    error = "Antwort unvollstaendig";
    return false;
  }
  return true;
}
bool loadOmm(Satellite &s, const String &json) {
  JsonDocument d;
  if (deserializeJson(d, json))
    return false;
  JsonVariant o = d.is<JsonArray>() ? d[0].as<JsonVariant>() : d.as<JsonVariant>();
  if (o["NORAD_CAT_ID"].as<int>() != s.catalog || o["OBJECT_NAME"].isNull())
    return false;
  const char *fields[] = {"MEAN_MOTION",    "ECCENTRICITY",      "INCLINATION",
                          "RA_OF_ASC_NODE", "ARG_OF_PERICENTER", "MEAN_ANOMALY",
                          "BSTAR",          "MEAN_MOTION_DOT",   "MEAN_MOTION_DDOT"};
  for (auto k : fields)
    if (!o[k].is<double>() || !isfinite(o[k].as<double>()))
      return false;
  double mm = o["MEAN_MOTION"], ecc = o["ECCENTRICITY"], inc = o["INCLINATION"];
  if (mm <= 0 || mm > 20 || ecc < 0 || ecc >= 1 || inc < 0 || inc > 180)
    return false;
  int y, m, day, h, min;
  double sec;
  String epoch = o["EPOCH"] | "";
  if (sscanf(epoch.c_str(), "%d-%d-%dT%d:%d:%lf", &y, &m, &day, &h, &min, &sec) != 6 || y < 2000 ||
      y > 2099 || m < 1 || m > 12 || day < 1 || day > 31)
    return false;
  OmmElements elements{y,
                       m,
                       day,
                       h,
                       min,
                       sec,
                       mm,
                       ecc,
                       inc,
                       o["RA_OF_ASC_NODE"],
                       o["ARG_OF_PERICENTER"],
                       o["MEAN_ANOMALY"],
                       o["BSTAR"],
                       o["MEAN_MOTION_DOT"],
                       o["MEAN_MOTION_DDOT"]};
  TLE tle{};
  if (!initOmm(&tle, &elements))
    return false;
  s.tle = tle;
  s.epoch = tle.epoch / 1000;
  strlcpy(s.name, o["OBJECT_NAME"] | "Satellit", sizeof s.name);
  s.valid = true;
  s.alt = -90;
  return true;
}
static void fetchTask(void *) {
  Job j;
  for (;;) {
    if (xQueueReceive(jobs, &j, portMAX_DELAY) != pdTRUE)
      continue;
    uint32_t jobStarted=millis();
    Result r{};
    r.kind = j.kind;
    r.generation = j.generation;
    r.catalog = j.catalog;
    String data, error;
    if (j.kind == 0) {
      String u = "https://api.open-meteo.com/v1/forecast?latitude=" + String(j.place.lat, 6) +
                 "&longitude=" + String(j.place.lon, 6) +
                 "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,"
                 "cloud_cover,wind_speed_10m,wind_direction_10m&daily=weather_code,temperature_2m_"
                 "max,temperature_2m_min,precipitation_probability_max,apparent_temperature_min,apparent_temperature_max,"
                 "precipitation_sum,precipitation_hours,snowfall_sum,wind_speed_10m_max,wind_gusts_10m_max,"
                 "wind_direction_10m_dominant,sunshine_duration,uv_index_max,sunrise,sunset&forecast_days=7&timezone="
                 "auto&timeformat=unixtime&hourly=cloud_cover,precipitation_probability&forecast_hours=12";
      if (getUrl(u, data, error, r.httpStatus, r.retrySeconds, r.diagnostic)) {
        JsonDocument d;
        auto e = deserializeJson(d, data);
        auto c = d["current"];
        auto a = d["daily"];
        bool valid = !e && a["time"].size() == 7 && c["time"].is<int64_t>();
        for(int i=0;i<7;i++) valid=valid && a["time"][i].is<int64_t>();
        if (!valid)
          error = "Wetterformat ungueltig";
        else {
          auto &w = r.weather;
          parseHourly(d["hourly"],r.hourly,time(nullptr));
          w.valid = true;
          w.fetched = time(nullptr);
          w.observed = c["time"].as<time_t>();
          auto num=[](JsonVariant v)->float{return v.is<double>() && isfinite(v.as<double>())?v.as<float>():NAN;};
          w.temp = num(c["temperature_2m"]);
          w.feels = num(c["apparent_temperature"]);
          w.humidity = num(c["relative_humidity_2m"]);
          w.wind = num(c["wind_speed_10m"]);
          w.direction = num(c["wind_direction_10m"]);
          w.cloud = num(c["cloud_cover"]);
          w.code = c["weather_code"].is<int>()?c["weather_code"].as<int>():-1;
          for (int i = 0; i < 7; i++) {
            parseWeatherDay(w.days[i],a,i,d["utc_offset_seconds"].as<int>());
          }
        }
      }
    } else if(j.kind==9){
      String u="https://opendata.adsb.fi/api/v3/lat/"+String(j.place.lat,5)+"/lon/"+String(j.place.lon,5)+"/dist/"+String((int)ceil(j.radius/1.852));
      if(getUrl(u,data,error,r.httpStatus,r.retrySeconds,r.diagnostic)){
       JsonDocument filter;filter["now"]=true;filter["msg"]=true;
       for(const char*k:{"lat","lon","seen_pos","alt_baro","gs","track","flight","hex","t"})filter["ac"][0][k]=true;
       JsonDocument d;if(deserializeJson(d,data,DeserializationOption::Filter(filter))||!parseFlight(d,r.flight,j.place,j.radius,j.approaching,time(nullptr)))error="Flugzeugdaten ungueltig";
      }
    } else if(j.kind==8) {starlinkDownload(error,r.httpStatus,r.retrySeconds);
    } else {
      String u =
          "https://celestrak.org/NORAD/elements/gp.php?CATNR=" + String(j.catalog) + "&FORMAT=JSON";
      if (getUrl(u, data, error, r.httpStatus, r.retrySeconds)) {
        if (data.length() >= sizeof r.omm)
          error = "OMM-Antwort zu gross";
        else {
          Satellite test{};
          test.catalog = j.catalog;
          if (!loadOmm(test, data))
            error = "Keine gültigen OMM-Bahndaten";
          else
            strlcpy(r.omm, data.c_str(), sizeof r.omm);
        }
      }
    }
    if (j.kind == 0) {
      size_t used = strlen(r.diagnostic);
      snprintf(r.diagnostic + used, sizeof r.diagnostic - used, "Ergebnis: %s\n", error.length() ? error.c_str() : "Wetterdaten erfolgreich geladen und geprueft");
      Serial.println(r.diagnostic);
    }
    r.duration=millis()-jobStarted;
    strlcpy(r.error, error.c_str(), sizeof r.error);
    xQueueSend(results, &r, portMAX_DELAY);
  }
}
void fetchSoon() { nextWeather = 0; }
// WLAN scheduling ported from TramvajPraha v0.9.11 App.cpp (tickApp).
// Scans are requested by the user, queued until HTTPS is idle, and never periodic.
void scanStart() {
  if (scanRunning || scanRequested) return;
  scanRequested = true;
  scanAt = millis();
  message = "WLAN-Suche vorgemerkt";
  dirty = true;
}
void connectProfile(int i) {
  if (i < 0 || i >= cfg.wifiCount)
    return;
  if (scanRunning) {
    esp_wifi_scan_stop();
    WiFi.scanDelete();
    scanRunning = false;
  }
  scanRequested = false;
  attempt = i;
  attemptAt = millis();
  // Return the web action acknowledgement before changing the radio connection.
  disconnectPending = true;
  wasConnected = false;
  beginPending = true; // Let the disconnect finish without blocking touch or web.
  message = "Verbinde: " + String(cfg.wifi[i].ssid);
  dirty = true;
}
bool saveWifi(String s, String p) {
  if (s.isEmpty() || s.length() > 32 || p.length() > 63 || (!p.isEmpty() && p.length() < 8)) {
    message = "SSID/Passwort prüfen";
    return false;
  }
  int i = 0;
  while (i < cfg.wifiCount && s != cfg.wifi[i].ssid)
    i++;
  if (i == 6) {
    message = "Maximal 6 WLANs";
    return false;
  }
  if (i == cfg.wifiCount)
    cfg.wifiCount++;
  strlcpy(cfg.wifi[i].ssid, s.c_str(), 33);
  strlcpy(cfg.wifi[i].pass, p.c_str(), 65);
  saveSettings();
  connectProfile(i);
  return true;
}
void deleteWifi(int i) {
  if (i < 0 || i >= cfg.wifiCount)
    return;
  bool active = beginPending || WiFi.SSID() == cfg.wifi[i].ssid;
  for (int k = i; k < cfg.wifiCount - 1; k++)
    cfg.wifi[k] = cfg.wifi[k + 1];
  cfg.wifiCount--;
  memset(&cfg.wifi[cfg.wifiCount], 0, sizeof(WifiProfile));
  saveSettings();
  attempt = -1;
  beginPending = disconnectPending = false;
  if (active)
    WiFi.disconnect(false, true);
}
time_t satelliteRetry(int index) {
  if(index==3)return max(starlinkNext,satHoldUntil);
  if(index<0 || index>=SAT_COUNT) return 0;
  String id=String(satellites[index].catalog);
  time_t due=prefs.getLong64(("sr"+id).c_str(),0);
  if(!due) {time_t prev=prefs.getLong64(("sa"+id).c_str(),0);if(prev)due=prev+(satellites[index].valid?21600:7200);}
  return max(due,satHoldUntil);
}
void resumeSatellites() {
  if(!clockReady() || time(nullptr)<satHoldUntil) {
    message="Wartezeit bis "+eventStamp(satHoldUntil);dirty=true;return;
  }
  satPaused = false;
  satPauseReason="";
  prefs.putString("satReason","");
  prefs.putBool("satPause", false);
  dirty = true;
}
bool requestStarlinkCatalog(String &error) {
  if(!cfg.starlink){error="Bitte Starlink automatisch unter Anzeige einschalten";return false;}
  if(WiFi.status()!=WL_CONNECTED||!clockReady()){error="WLAN und Uhrzeit erforderlich";return false;}
  if(starlinkCatalogStatus().busy){error="Katalog wird bereits geladen";return false;}
  if(satPaused){error="Satellitenabrufe pausiert: "+satPauseReason;return false;}
  time_t due=max(starlinkNext,satHoldUntil);
  if(time(nullptr)<due){error="Nächster Katalogabruf ab "+eventStamp(due);return false;}
  starlinkNext=0;
  message="Starlink-Abruf vorgemerkt; Wetter hat Vorrang";dirty=true;return true;
}
void netBegin() {
  memoryProbeInit();
  satPaused = prefs.getBool("satPause", false);
  satHoldUntil=prefs.getLong64("satHold",0);
  satPauseReason=prefs.getString("satReason",satPaused?"Gespeicherte Pause: bitte fortsetzen":"");
  apPassword = prefs.getString("apPass", "");
  if (apPassword.length() < 12) {
    apPassword = String(esp_random(), HEX) + String(esp_random(), HEX) + "Ww";
    prefs.putString("apPass", apPassword);
  }
  WiFi.persistent(false);
  WiFi.mode(WIFI_AP_STA);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(false); // This state machine owns reconnects.
  WiFi.softAP("WetterWeltall", apPassword.c_str());
  configTzTime(cfg.places[cfg.place].tz, "pool.ntp.org", "time.cloudflare.com", "time.google.com");
  if (prefs.getBytesLength("weather") == sizeof weather &&
      prefs.getInt("weatherPlace", -1) == cfg.place)
    prefs.getBytes("weather", &weather, sizeof weather);
  for (int i = 0; i < 3; i++) {
    String key = "omm" + String(i);
    String t = prefs.getString(key.c_str(), "");
    if (t.length())
      loadOmm(satellites[i], t);
  }

  jobs = xQueueCreate(1, sizeof(Job));
  results = xQueueCreate(1, sizeof(Result));
  if (!jobs || !results || xTaskCreate(fetchTask, "data", 18000, nullptr, 1, nullptr) != pdPASS) {
    message = "Daten-Task: Speichermangel";
    busy = true;
  }
  // Try the last successful saved network directly; do not scan all channels first.
  if (cfg.wifiCount) connectProfile(0);
}
void netTick() {
  uint32_t now = millis();
  if (disconnectPending && !busy && !starlinkImportBusy() && now - attemptAt >= 500) {
    WiFi.disconnect(false, false);
    disconnectPending = false;
    attemptAt = now;
  }
  if (beginPending && !disconnectPending && now - attemptAt >= 150) {
    beginPending = false;
    if (attempt >= 0 && attempt < cfg.wifiCount)
      WiFi.begin(cfg.wifi[attempt].ssid, cfg.wifi[attempt].pass);
    attemptAt = now;
  }
  if (scanRequested && !busy && !starlinkImportBusy() && !beginPending) {
    scanRequested = false;
    WiFi.scanDelete();
    nearbyCount = 0;
    scanRunning = WiFi.scanNetworks(true, false) != WIFI_SCAN_FAILED;
    message = scanRunning ? "WLAN-Suche läuft" : "WLAN-Suche fehlgeschlagen";
    dirty = true;
  }
  if (scanRequested && now - scanAt >= 30000) {
    scanRequested = false;
    message = "WLAN-Suche: Datenabruf noch beschäftigt. Bitte erneut versuchen.";
    dirty = true;
  }
  if (scanRunning) {
    int n = WiFi.scanComplete();
    if (n >= 0) {
      nearbyCount = 0;
      for (int i = 0; i < n && nearbyCount < 20; i++) {
        String s = WiFi.SSID(i);
        bool found = s.isEmpty();
        for (int k = 0; k < nearbyCount; k++)
          if (nearby[k] == s)
            found = true;
        if (!found)
          nearby[nearbyCount++] = s;
      }
      WiFi.scanDelete();
      scanRunning = false;
      message = String(nearbyCount) + " WLANs gefunden";
      dirty = true;
    } else if (n == WIFI_SCAN_FAILED || now - scanAt > 30000) {
      esp_wifi_scan_stop();
      WiFi.scanDelete();
      scanRunning = false;
      message = "WLAN-Suche: Zeitlimit";
      dirty = true;
    }
  }
  bool connected = !beginPending && WiFi.status() == WL_CONNECTED;
  if (connected)
    beginPending = disconnectPending = false;
  if (connected && !wasConnected) {
    message = "Verbunden: " + WiFi.SSID();
    nextWeather = 0;
    for (int i = 1; i < cfg.wifiCount; i++)
      if (WiFi.SSID() == cfg.wifi[i].ssid) {
        WifiProfile p = cfg.wifi[i];
        for (int k = i; k > 0; k--)
          cfg.wifi[k] = cfg.wifi[k - 1];
        cfg.wifi[0] = p;
        saveSettings();
        break;
      }
    attempt = 0;
    dirty = true;
  }
  if (!connected && wasConnected) {
    attemptAt = now;
    attempt = -1; // Successful profile is first: retry it before other saved networks.
    message = "Verbindung unterbrochen";
    dirty = true;
  }
  wasConnected = connected;
  // Same bounded round-robin as Praha: every 30 s, only when scan/fetch are idle.
  // Keep a working connection untouched; after a loss start with last successful profile.
  if (!connected && !beginPending && cfg.wifiCount && now - attemptAt >= 30000 &&
      !scanRunning && !scanRequested && !busy && !starlinkImportBusy())
    connectProfile((attempt + 1) % cfg.wifiCount);
  Result r;
  if (results && xQueueReceive(results, &r, 0) == pdTRUE) {
    busy = false;
    healthResult(r.kind,!r.error[0]);
    sourceFinished(r.kind,r.httpStatus,r.duration,r.error,r.diagnostic);
    uiNetworkMemory(false);
    if (r.kind == 0 && r.generation == generation) {
      strlcpy(weatherDiagnostic, r.diagnostic, sizeof weatherDiagnostic);
      if (r.error[0]) strlcpy(weatherLastFailure, r.diagnostic, sizeof weatherLastFailure);
      if (!r.error[0]) {
        weather = r.weather;hourly=r.hourly;
        prefs.putBytes("weather", &weather, sizeof weather);
        prefs.putInt("weatherPlace", cfg.place);
      } else
        strlcpy(weather.error, r.error, sizeof weather.error);
    }
    if(r.kind==9&&r.generation==generation){if(!r.error[0])flight=r.flight;else strlcpy(flight.error,r.error,sizeof flight.error);nextAircraft=now+(r.error[0]?(r.httpStatus==429?r.retrySeconds*1000:300000):30000);}
    if((r.kind>0&&r.kind<=3)||r.kind==8) {
      // Negative transport codes are NOT HTTP responses. No permanent pause.
      satGap=now+60000;
      if(pauseForHttp(r.httpStatus)) {
        satPaused=true;satHoldUntil=time(nullptr)+r.retrySeconds;
        satPauseReason="HTTP "+String(r.httpStatus)+" · Datenquelle prüfen";
        prefs.putBool("satPause",true);prefs.putLong64("satHold",satHoldUntil);
        prefs.putString("satReason",satPauseReason);message=satPauseReason;
      }
      time_t due=time(nullptr)+satelliteDelay(r.error[0]!=0,r.retrySeconds);
      prefs.putLong64(("sr"+String(r.catalog)).c_str(),due);
      if(r.kind<=3)nextSat[r.kind-1]=now+(r.error[0]?7200000:21600000);
      if(r.kind==8){
        auto c=starlinkCatalogStatus();
        // Local SD failures did not contact CelesTrak: retry card check in one minute.
        starlinkNext=c.attempted?c.lastFetch.next:time(nullptr)+60;
        prefs.putLong64("slNext",starlinkNext);
        if(r.error[0])starlinkStatus=r.error;
      }
    }
    if (r.kind > 0 && r.kind<=3 && r.catalog == satellites[r.kind - 1].catalog) {
      auto &s = satellites[r.kind - 1];
      strlcpy(s.error, r.error, sizeof s.error);
      if(r.error[0] && !s.valid) nextSat[r.kind-1]=now+7200000;
      if (!r.error[0] && loadOmm(s, r.omm)) {
        s.fetched = time(nullptr);
        prefs.putString(("omm" + String(r.kind - 1)).c_str(), r.omm);
        resetSatPrediction();
      }
    }
    dirty = true;
  }
  if (connected && clockReady() && !busy && !scanRunning && !scanRequested && !starlinkImportBusy()) {
    Job j{};
    j.generation = generation;
    j.place = cfg.places[cfg.place];
    bool send = false;
    if (nextWeather == 0 || (int32_t)(now - nextWeather) >= 0) {
      nextWeather = now + 900000;
      j.kind = 0;
      send = true;
    } else if (!satPaused && (satGap==0 || (int32_t)(now-satGap)>=0))
      for (int i = 0; i < 3; i++)
        if (nextSat[i] == 0 || (int32_t)(now - nextSat[i]) >= 0) {
          String key = "sa" + String(satellites[i].catalog);
          time_t due=satelliteRetry(i);
          int64_t remaining=(int64_t)due-time(nullptr);
          if(remaining>0) {nextSat[i]=now+(uint32_t)min(remaining,(int64_t)86400)*1000;continue;}
          prefs.putLong64(key.c_str(), time(nullptr));
          prefs.putLong64(("sr"+String(satellites[i].catalog)).c_str(),time(nullptr)+7200);
          nextSat[i] = now + 21600000;
          j.kind = i + 1;
          j.catalog = satellites[i].catalog;
          send = true;
          break;
        }
    if(!send && cfg.starlink && !satPaused && time(nullptr)>=starlinkNext && time(nullptr)>=satHoldUntil && (satGap==0 || (int32_t)(now-satGap)>=0)) {
      j.kind=8;send=true;starlinkNext=time(nullptr)+7200;starlinkStatus="Katalog wird geladen";starlinkCatalogQueued();
    }
    if(!send&&modern.aircraft&&(nextAircraft==0||(int32_t)(now-nextAircraft)>=0)){j.kind=9;j.radius=modern.radius;j.approaching=modern.approaching;send=true;nextAircraft=now+30000;}
    if (send && jobs) {
      uiNetworkMemory(true);
      if (xQueueSend(jobs, &j, 0) == pdTRUE){busy=true;sourceStarted(j.kind);}
      else {
        uiNetworkMemory(false);
        if(j.kind==8){starlinkCatalogCancel();starlinkNext=time(nullptr)+60;prefs.putLong64("slNext",starlinkNext);}
      }
    }
  }
}
