#pragma once
#include <esp_heap_caps.h>
#include <stdarg.h>
#include "MemoryProbe.h"
// Owned by the network worker; published only through the result queue.
// Fixed-size output avoids a growing diagnostic String on a low-memory device.
class WeatherTrace {
  char *out;
  String &error;
  uint32_t started;
public:
  WeatherTrace(char *buffer, String &failure) : out(buffer), error(failure), started(millis()) {
    if (!out) return;
    out[0] = 0;
    time_t now = time(nullptr);
    struct tm utc{};
    gmtime_r(&now, &utc);
    char date[32];
    strftime(date, sizeof date, "%Y-%m-%d %H:%M:%S UTC", &utc);
    add("Start: %s\nUptime: %lu s; WLAN %d; %d dBm\nIP %s; GW %s; DNS %s\n", date,
        (unsigned long)(started / 1000), (int)WiFi.status(), (int)WiFi.RSSI(),
        WiFi.localIP().toString().c_str(), WiFi.gatewayIP().toString().c_str(), WiFi.dnsIP().toString().c_str());
    memory("Vor Abruf");
    memoryProbeBegin();
  }
  void add(const char *format, ...) {
    if (!out) return;
    size_t used = strlen(out);
    if (used >= 1199) return;
    va_list args;
    va_start(args, format);
    vsnprintf(out + used, 1200 - used, format, args);
    va_end(args);
  }
  void memory(const char *phase) {
    if (!out) return;
    add("%s: Heap %lu; max. intern/8-Bit %lu Byte\n", phase,
        (unsigned long)ESP.getFreeHeap(),
        (unsigned long)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT));
  }
  ~WeatherTrace() {
    if (!out) return;
    auto probe=memoryProbeEnd();
    add("Heap-Hook: %s; Phase 1=Setup, 2=GET/TLS, 3=Antwort\n",probe.registered?"aktiv":"NICHT aktiv");
    auto report=[&](const char *name,const MemoryFailure &f) {
      add("%s: %lu Fehler",name,(unsigned long)f.count);
      if(f.count)add("; erster %lu Byte, Caps 0x%lx, Phase %u, %s",(unsigned long)f.bytes,(unsigned long)f.caps,f.phase,f.allocator);
      add("\n");
    };
    report("Abruf-Task",probe.worker);report("Andere Tasks",probe.other);
    add("Abruf-Stack Minimum frei: %lu Byte\n",(unsigned long)uxTaskGetStackHighWaterMark(nullptr));
    memory("Nach TLS-Freigabe");
    add("Dauer: %lu ms\n", (unsigned long)(millis() - started));
  }
};
