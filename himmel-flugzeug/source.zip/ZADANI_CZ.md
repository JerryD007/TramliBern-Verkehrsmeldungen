# Zadání: Himmel & Flugzeug pro ESP32

Rozšířit existující funkční projekt o propracovanou oblohu a sledování letadel. Zachovat osvědčené ovládání, automatické Wi‑Fi připojení, aktualizace přes Safari a uložená uživatelská data.

Projekt bude mít **dvě hlavní obrazovky**:

1. **Himmel** – obloha, planety, hvězdy a družice.
2. **Flugzeug** – nejbližší nebo přibližující se letadlo.

Uživatelské rozhraní bude německy. Dokumentace a návod budou česky.

## 1. Hardware a orientace displeje

- Použít stávající ESP32 a dotykový displej ST7796 s rozlišením **480 × 320 bodů**.
- Displej orientovat **na ležato, USB‑C vpravo**.
- Správně přizpůsobit vykreslování, souřadnice dotyku a směry gest.
- Zachovat uloženou kalibraci. Nejprve ověřit, zda ji lze správně převést pro novou orientaci; novou kalibraci vyžadovat pouze tehdy, pokud bude nutná.
- Po zapnutí nebo restartu se displej vždy rozsvítí.
- Automatické zhasnutí zůstane volitelné, standardně vypnuté.

## 2. Odstranění počasí

Odstranit:

- obrazovku Wetter;
- předpověď počasí a denní detail;
- hodinový přehled oblačnosti a srážek;
- pravidelné požadavky na meteorologický server;
- nepotřebné meteorologické buffery, časovače a ovládací prvky.

Zachovat **stanoviště, zeměpisné souřadnice, časové pásmo a synchronizaci času** – potřebují je astronomické výpočty a letadla.

Při přechodu ze starší verze bezpečně převést volbu poslední obrazovky. Původní nastavení Wetter nesmí způsobit prázdnou obrazovku nebo chybný start.

## 3. Vzhled a grafický styl

- Černé pozadí a dobře čitelný bílý text.
- Hlavní akcent tyrkysový, doplňkový žlutý.
- **Decentní červená** pro upozornění, vybrané grafické detaily a noční režim.
- Šedá pouze pro vedlejší informace.
- Bez barevných přechodů v ovládacím rozhraní.
- Převážně jedna až dvě akcentní barvy na obrazovce.
- Velká dotyková tlačítka, jasná hierarchie informací a minimum trvale zobrazených ovládacích prvků.

Grafiku přizpůsobit skutečnému rozlišení displeje. Přednost má čitelnost a plynulé ovládání.

## 4. Himmel – hlavní mapa oblohy

**Mapa bude dominantní částí obrazovky.** Hlavička a ovládání mají zabírat co nejméně místa.

### Mapa a ovládání

- Zobrazit hvězdy, souhvězdí, planety a podporované družice.
- Zachovat přehlednou orientaci: sever nahoře, východ vlevo, zenit uprostřed.
- Označit světové strany a obzor.
- Hlavní hvězdy zvýraznit, slabší hvězdy zobrazovat decentně.
- Spojnice souhvězdí vykreslovat tenké a nenápadné.
- Mléčnou dráhu znázornit jemně, pokud to dovolí paměť a rychlost vykreslování.
- Omezit překrývání názvů s objekty a čarami.
- Zobrazit měřítko přiblížení a tlačítko **Gesamtkarte**.
- Umožnit rozšířenou mapu se skrytými informačními panely.

Na ESP32 jednoznačně rozlišit klepnutí, přepnutí obrazovky a ovládání zoomu. V Safari umožnit přiblížení dvěma prsty; na stávajícím dotykovém panelu použít ovládání odpovídající jeho skutečným možnostem.

### Planety a detaily

- Použít rozpoznatelné ilustrace planet.
- Saturn musí mít dobře viditelný prstenec.
- Zachovat charakteristické barvy a výrazné obrysy.
- Zvětšit dotykové oblasti planet.
- Při překryvu preferovat planetu před hvězdou; mezi blízkými planetami vybrat nejbližší symbol.

Detail objektu bude obsahovat:

- velkou ilustraci nebo odpovídající symbol;
- název;
- směr a azimut;
- výšku nad obzorem;
- jasnost, pokud ji lze pro daný objekt určit;
- informaci, zda je nad obzorem;
- přidání do oblíbených.

### Vyhledávání a oblíbené

- Hledat planety a hvězdy podle názvu.
- Zvolený objekt zvýraznit na mapě.
- Nabídnout seznam **Heute über dem Horizont**.
- Oblíbené objekty zachovat po restartu a zahrnout do zálohy nastavení.

Označení „nad obzorem“ nesmí automaticky znamenat „viditelný pouhým okem“.

## 5. Družice a Starlink

Zachovat **ISS, Tiangong, Hubble a automatický výběr Starlinku**. Konkrétní dostupnost přeletů závisí na stanovišti a dráze družice.

### Zobrazení

- Družice zakreslit přímo do mapy.
- Přidat šipku vypočteného směru pohybu a krátký následující úsek dráhy.
- Pod mapou zobrazit kompaktní přehled; podrobnosti otevřít klepnutím.
- Rozlišovat:
  - nad obzorem;
  - potenciálně viditelná;
  - pod obzorem;
  - zastaralá nebo chybějící dráhová data.

Potenciální viditelnost posuzovat podle osvětlení družice, polohy Slunce a výšky nad obzorem. **Bez meteorologických dat nelze posoudit oblačnost; označení nebude zárukou skutečného spatření.**

### Následující přelet

Zobrazovat:

- název družice;
- začátek a odpočet;
- směr objevení a pohybu;
- maximální výšku nad obzorem;
- odhadované trvání;
- rozdíl mezi geometrickým přeletem a potenciálně viditelnou částí.

Jasně uvést, pro které družice se předpověď počítá. U Starlinku nesmí aplikace tvrdit, že prohledala celý katalog, pokud pracuje pouze s vybranými kandidáty.

### Optimalizace Starlinku

- Zachovat uložený katalog na SD kartě.
- Změřit zvlášť čtení katalogu, výpočty a čekání.
- Podle výsledků optimalizovat hledání a paměť.
- Vybranou družici průběžně přepočítávat pro aktuální čas.
- Oddělit stáří dráhových dat od stáří vypočtené polohy.
- Neprodlužovat limity jen proto, aby stará poloha působila aktuálně.
- Výpočty nesmějí blokovat dotyk, menu ani Safari.

## 6. Flugzeug – letadla v okolí

Vytvořit graficky propracovanou obrazovku s výraznou siluetou letadla a dobře čitelnými údaji.

### Výběr letadla

Nabídnout dva režimy:

- **Nächstes Flugzeug** – nejbližší letadlo ke stanovišti.
- **Im Anflug** – letadlo přibližující se ke stanovišti.

„Přibližující se“ znamená zmenšující se vzdálenost ke stanovišti, nikoli automaticky přistání na blízkém letišti.

Výchozí dosah navrhnout na **50 km**, s možností změny podle možností datového zdroje.

### Údaje a grafika

- Volací znak nebo označení letu.
- Typ letadla, pokud jej zdroj poskytuje.
- Vzdálenost od stanoviště.
- Výška s označením jejího významu, například barometrická.
- Rychlost.
- Směr letu a směr od stanoviště k letadlu.
- Čas poslední polohy a stáří dat.

Doplnit jednoduchý situační pohled:

- stanoviště uprostřed;
- sever a směrové značky;
- symbol letadla ve správném směru;
- šipka pohybu;
- případně krátká historie skutečně přijatých poloh.

Historii nesmí nahrazovat vymyšlená trajektorie. Siluetu konkrétní kategorie letadla použít jen při spolehlivém určení typu; jinak neutrální symbol.

Odletové a cílové letiště zobrazovat pouze tehdy, pokud jsou dostupné z ověřeného zdroje.

### Stavové situace

Jednoznačně odlišit:

- aktuální polohu;
- zastaralou polohu;
- načítání;
- chybu zdroje;
- žádné letadlo v nastaveném dosahu.

Před implementací ověřit podmínky leteckého zdroje, pokrytí, limity a dostupnou četnost aktualizací.

## 7. Přepínání obrazovek a priorita letadel

- Ruční přepnutí Himmel / Flugzeug dotykem a přes Safari.
- Volitelné automatické střídání.
- Nastavitelná délka zobrazení obou obrazovek.
- Volitelná priorita vhodného blízkého letadla.
- Po skončení priority návrat k předchozí obrazovce.
- Nastavitelná prodleva mezi prioritními zobrazeními.

Automatická priorita nesmí:

- přerušit práci v menu nebo detailu;
- sama probudit zhasnutý displej;
- neustále přepínat mezi několika letadly;
- zobrazit starou polohu jako aktuální.

## 8. Moderní webová aplikace v Safari

Web poběží **přímo na ESP32**. Nebude vyžadovat trvale zapnutý počítač, registraci ani externí server pro ovládání.

Hlavní části:

- **Himmel**
- **Flugzeug**
- **Einstellungen**
- **Diagnose**

Na iPhonu i Macu zachovat stejný grafický styl.

### Přehled zařízení

Seznam zařízení otevřít až po kliknutí na **Geräte**. Názvy například Wohnzimmer, Arbeitszimmer a Schlafzimmer nebudou trvale zabírat hlavní obrazovku.

Umožnit:

- přidání a úpravu názvu a adresy;
- přehled dostupnosti a verze;
- otevření ovládání konkrétního zařízení;
- správu více zařízení tohoto projektu.

Nevytvářet univerzální správce jiných ESP32 projektů.

## 9. Aktualizace přes Safari

- Zachovat samostatnou aktualizaci každého zařízení souborem `.ino.bin`.
- Doplnit řízenou hromadnou aktualizaci vybraných kompatibilních zařízení z Macu.
- Před nahráním ověřit projekt, desku, firmware a OTA kapacitu.
- Zobrazovat průběh pro každé zařízení zvlášť.
- Rozlišit přenos, zpracování aktualizace, restart a opětovné připojení podle skutečně dostupných údajů.
- Úspěch potvrdit až po odpovědi správného zařízení s očekávanou verzí.
- Selhání jednoho zařízení nesmí zastavit přehled ostatních.

Počítač musí zůstat zapnutý pouze po dobu hromadné aktualizace. **Vývoj ani automatické testy samy nepřehrají běžící zařízení.**

## 10. Wi‑Fi, nastavení a zhasnutí

- Trvale ukládat více Wi‑Fi sítí.
- Automaticky se připojit k dostupné uložené síti.
- Po výpadku obnovit spojení a případně vyzkoušet další uloženou síť.
- V Safari umožnit správu sítí a zobrazení/skrytí zadávaného hesla.
- Zachovat existující přístupové údaje, nastavení a katalog.
- Doplnit zálohu a obnovu nových nastavení.

Automatické zhasnutí:

- standardně vypnuté;
- nastavitelná doba nečinnosti;
- první dotyk pouze probudí displej;
- tlačítka **DISPLAY AUSSCHALTEN** a **DISPLAY AUFWECKEN** v Safari;
- datové úlohy pokračují i při zhasnutí.

Noční režim oddělit od úplného zhasnutí.

## 11. Diagnostika

Zobrazovat srozumitelný stav a umožnit stažení podrobného diagnostického balíčku:

| Oblast          | Sledované údaje                                              |
| --------------- | ------------------------------------------------------------ |
| Provoz          | Verze, doba běhu, restarty a dostupný důvod restartu         |
| Paměť           | Volný a minimální heap, největší blok, chyby alokace         |
| Wi‑Fi           | Signál, výpadky, opětovná připojení                          |
| Datové zdroje   | Poslední úspěch, stáří dat, délka požadavků, HTTP/TLS chyby  |
| Displej a dotyk | Délka vykreslování, dlouhé prodlevy, dostupné údaje o dotyku |
| Družice         | Stáří drah a poloh, průběh a délka hledání                   |
| Letadla         | Stáří polohy, stav zdroje, výběr sledovaného letadla         |
| Aktualizace     | Průběh, výsledek a verze ověřená po restartu                 |

Záznamy budou časově označené, paměťově omezené a bez hesel či přístupových klíčů. Úspěšný požadavek nesmí být doprovázen zavádějícím hlášením chyby.

## 12. Vývoj, testy a předání

1. Uchovat zálohu funkční verze.
2. Pracovat v samostatné testovací větvi.
3. Nejprve připravit náhledy **obou obrazovek v nové orientaci** a odpovídajícího webu.
4. Implementovat změny a ověřit kompilaci, Flash, RAM a OTA prostor.
5. Otestovat migraci nastavení ze staršího WetterHimmel.
6. Prověřit souběh sítě, astronomických výpočtů, displeje, dotyku a Safari.
7. Samostatně provést zkoušky na skutečném ESP32 a dlouhodobý provoz.

Předání přímo v ChatGPT:

- kompletní **ZIP se zdroji, zálohou a výsledky testů**;
- samostatný skutečně zkompilovaný **`.ino.bin`**;
- případný soubor potřebný k ověření hromadné aktualizace;
- **český PDF návod** s přesným nastavením Arduino IDE;
- seznam provedených automatických testů a dosud neprovedených zkoušek na zařízení.

**Podmínka přijetí:** obě obrazovky musí fungovat v orientaci USB‑C vpravo, bez nechtěného blikání a blokování ovládání. Skutečnou kvalitu dotyku, plynulost a dlouhodobou stabilitu lze potvrdit až zkouškou na fyzickém ESP32.