# Přijaté zadání dev5
Himmel zůstává hlavní obrazovkou, počasí se nevrací. Zachovat Wi-Fi profily, nastavení, dotykovou kalibraci, favority, SD katalog a OTA rozložení.

Safari: radar severem nahoru, kruhy dosahu, nejbližší seznam, detail s odděleným směrem k letadlu a směrem pohybu, připnutí letu a poslední známá poloha. Trasy z ADSBDB se shodou volacího znaku a identity; neslibovat živé potvrzení plánované trasy.

Mein Hangar: ICAO identita, první a poslední pozorování, počty průletů, dostupná registrace, znak a typ. SD historie přežije OTA a restart. Deset zachycení má dát jeden průlet; doložený návrat druhý. Výpadek ani restart nesmí sám zvýšit počet. Nejméně 15 minut doložené absence, konzervativní bezpečnostní rezerva do 2 minut. Vyhledávání, řazení, stránkování a detail. Kontrolované zápisy, obnovení starší platné kopie po neúplném zápisu. Chyba SD viditelná, živé letadlo pokračuje v dostupném omezeném režimu.

Displej: německé popisky, 480x320, čtyři informační pole družic místo velkých navigačních tlačítek. Přepínání přes menu a gesto. Žádné překrytí Favoriten stavem mapy. Automatická letecká obrazovka jen při vhodném aktuálním letu. Zachovat volitelné probouzení a ochranu menu.

Černá, bílá, tyrkysová; žlutý výběr a decentní červené chyby/OTA, bez přechodů. Diagnostika bez hesel, včetně SD, průletů, RAM, TLS a vykreslování. Testovací větev a záloha; nikdy automaticky neflashovat. Předání kompletní ZIP, skutečně kompilovaný samostatný .ino.bin a český PDF návod. Automatické a fyzické testy odděleně.
