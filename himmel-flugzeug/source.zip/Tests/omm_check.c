#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "../WetterHimmel/src/sgp4/Omm.h"
int main(){OmmElements e={2026,11,9,1,38,43.507968,15.70227576,0.00011051,53.1445,83.5322,337.1588,22.9381,0.0026209785,0.00337374,0};TLE a={0},b={0};assert(initOmm(&a,&e));char l1[]="1 44714U 19074B   26313.06855912  .00337374  00000+0  26210-2 0  9991",l2[]="2 44714  53.1445  83.5322 0001105 337.1588  22.9381 15.70227576386845";parseLines(&b,l1,l2);double ra[3],rb[3],v[3];
for(int t=0;t<=1440;t+=1440){getRV(&a,t,ra,v);getRV(&b,t,rb,v);double d=sqrt(pow(ra[0]-rb[0],2)+pow(ra[1]-rb[1],2)+pow(ra[2]-rb[2],2));printf("OMM/TLE Starlink delta at %d min: %.6f km\n",t,d);assert(d<0.1);}
assert(a.epoch>1700000000000LL);e.meanMotion=-1;assert(!initOmm(&a,&e));puts("PASS: real Starlink OMM vs TLE and invalid motion rejection");}
