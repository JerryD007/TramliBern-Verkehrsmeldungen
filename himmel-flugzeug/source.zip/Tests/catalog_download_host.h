
#pragma once
#include <ArduinoJson.h>
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <map>
#include <vector>
#include <string>
#include <fstream>
using std::min;using std::max;using std::isfinite;
class String:public std::string{public:using std::string::string;String(const std::string&s):std::string(s){}String(int n):std::string(std::to_string(n)){}bool isEmpty()const{return empty();}bool startsWith(const char *s)const{return rfind(s,0)==0;}};
size_t strlcpy(char*d,const char*s,size_t n){if(n)snprintf(d,n,"%s",s);return strlen(s);}
extern "C" {
#include "../WetterHimmel/src/astro/astronomy.h"
#include "../WetterHimmel/src/sgp4/Omm.h"
#include "../WetterHimmel/src/sgp4/TLE.h"
}
struct Place{};struct Satellite{};
using SemaphoreHandle_t=int;using QueueHandle_t=int;using portMUX_TYPE=int;
#define portMUX_INITIALIZER_UNLOCKED 0
#define portMAX_DELAY 0xffffffff
#define pdTRUE 1
static int held=0;
void portENTER_CRITICAL(int*){}void portEXIT_CRITICAL(int*){}
int xSemaphoreTake(int,uint32_t timeout){if(held&&timeout==0)return 0;assert(held==0);held++;return pdTRUE;}void xSemaphoreGive(int){assert(held==1);held--;}
uint32_t clockMs=0;uint32_t millis(){return clockMs;}void vTaskDelay(int){clockMs++;}
#define VSPI 0
#define FILE_WRITE 1
struct SPIClass{SPIClass(int){}void begin(int,int,int,int){}};
std::map<std::string,std::vector<uint8_t>> disk;
bool sdWorks=true,writeWorks=true,failActivation=false;
struct File{
 std::vector<uint8_t>*data=nullptr;size_t pos=0;
 operator bool()const{return data!=nullptr;}
 size_t read(uint8_t*b,size_t n){if(!data)return 0;n=min(n,data->size()-min(pos,data->size()));memcpy(b,data->data()+pos,n);pos+=n;return n;}
 size_t write(const uint8_t*b,size_t n){if(!data||!writeWorks)return 0;if(pos+n>data->size())data->resize(pos+n);memcpy(data->data()+pos,b,n);pos+=n;return n;}
 bool seek(size_t p){pos=p;return data!=nullptr;}size_t size(){return data?data->size():0;}
 void flush(){}void close(){data=nullptr;}
};
struct SDClass{
 bool begin(int,SPIClass&,int){return sdWorks;}
 bool exists(const char*p){return disk.count(p);}
 bool mkdir(const char*p){disk[p]={};return true;}
 bool remove(const char*p){return disk.erase(p);}
 bool rename(const char*a,const char*b){if(failActivation&&std::string(a).find("new.bin")!=std::string::npos)return false;if(!disk.count(a)||disk.count(b))return false;disk[b]=disk[a];disk.erase(a);return true;}
 File open(const char*p,int mode=0){if(mode)disk[p];if(!disk.count(p))return {};return {&disk[p],0};}
}SD;
std::string payload, retryHeader;int responseCode=200,tlsError=0,httpCalls=0,declaredLength=-1;
struct Stream{size_t pos=0;int read(uint8_t*b,size_t n){assert(held==0);size_t z=min(n,payload.size()-pos);memcpy(b,payload.data()+pos,z);pos+=z;return z;}int available(){return payload.size()-pos;}int read(){return pos<payload.size()?(unsigned char)payload[pos++]:-1;}};
struct WiFiClientSecure{void setCACertBundle(const uint8_t*,size_t){}void setTimeout(int){}int lastError(char*b,size_t n){strlcpy(b,tlsError?"SSL allocation failed":"",n);return tlsError;}};
#define HTTPC_DISABLE_FOLLOW_REDIRECTS 0
struct HTTPClient{
 Stream stream;void useHTTP10(bool){}void setTimeout(int){}void setConnectTimeout(int){}void setFollowRedirects(int){}
 bool begin(WiFiClientSecure&,const char*){return true;}void addHeader(const char*,const char*){}void collectHeaders(const char**,int){}
 int GET(){httpCalls++;return responseCode;}String header(const char*){return retryHeader;}int getSize(){return declaredLength;}
 Stream*getStreamPtr(){return &stream;}bool connected(){return stream.available()>0;}void end(){}
 static String errorToString(int){return "connection failed";}
};
static const uint8_t rootBundle[]={0};

std::map<std::string,std::vector<uint8_t>> nv;
struct Preferences{
 std::string ns="main";bool begin(const char *n,bool){ns=n;return true;}void end(){}
 size_t putBytes(const char *k,const void *p,size_t n){auto b=(const uint8_t*)p;nv[ns+":"+k]=std::vector<uint8_t>(b,b+n);return n;}
 size_t getBytesLength(const char*k){return nv[ns+":"+k].size();}
 size_t getBytes(const char*k,void*p,size_t n){auto &b=nv[ns+":"+k];n=min(n,b.size());if(n)memcpy(p,b.data(),n);return n;}
 void putLong64(const char*k,int64_t n){putBytes(k,&n,sizeof n);}
 int64_t getLong64(const char*k,int64_t fallback){int64_t n=fallback;if(getBytesLength(k)==sizeof n)getBytes(k,&n,sizeof n);return n;}
}prefs;
bool dirty=false,fetchBusy=false,validClock=true;
bool networkBusy(){return fetchBusy;}bool clockReady(){return validClock;}
uint32_t esp_random(){static uint32_t id=100;return ++id;}

// Reproducible age checks for the dated fixture, independent of the test machine date.
static time_t catalogTestTime(time_t *out){time_t fixed=1794371042;if(out)*out=fixed;return fixed;}
#define time catalogTestTime

#include <atomic>
#include <memory>
unsigned hangarServices=0;
void hangarWork(){assert(held==0);++hangarServices;}
void networkCatalogStreaming(bool){}
