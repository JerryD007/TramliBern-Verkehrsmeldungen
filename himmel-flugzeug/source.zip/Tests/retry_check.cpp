#include <initializer_list>
#include "../WetterHimmel/RetryPolicy.h"
#include <cassert>
#include <cstdio>
int main(){
 for(int status : {-11,-1,-5,0,200}) assert(!pauseForHttp(status));
 for(int status : {301,403,404,429,500,503}) assert(pauseForHttp(status));
 assert(satelliteDelay(true,0)==7200);assert(satelliteDelay(true,86400)==86400);
 assert(satelliteDelay(false,0)==21600);
 puts("PASS: negative transport errors never pause; HTTP failures pause; 2h retry floor; 6h refresh; Retry-After respected.");
}
