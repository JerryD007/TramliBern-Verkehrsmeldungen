from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]/'WetterHimmel'
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'test.cpp').write_text(r'''#include "Visibility.h"
#include <cassert>
#include <limits>
int main(){
 const long now=1794500000;
 auto test=[&](bool clock,bool valid,long epoch,long checked,double alt,int v){return satelliteCandidateSeconds(clock,valid,now,epoch,checked,alt,v);};
 assert(test(1,1,now,now,45,5)==20);
 assert(test(1,1,now,now-19,45,5)==1);
 assert(!test(1,1,now,now-20,45,5));
 assert(!test(1,1,now,now+1,45,5));
 assert(!test(0,1,now,now,45,5));assert(!test(1,0,now,now,45,5));
 for(int v=0;v<5;v++)assert(!test(1,1,now,now,45,v));
 assert(!test(1,1,now-604801,now,45,5));assert(!test(1,1,now+604801,now,45,5));
 assert(!test(1,1,0,now,45,5));assert(!test(1,1,now,0,45,5));
 assert(!test(1,1,now,now,0,5));assert(!test(1,1,now,now,-1,5));
 assert(!test(1,1,now,now,std::numeric_limits<double>::quiet_NaN(),5));
 // Sun on +X: satellite on illuminated versus shadow side of Earth.
 double sun[]={149600000,0,0},lit[]={6800,0,0},dark[]={-6800,0,0};
 assert(satelliteVisibility(lit,sun,40,-10)==5);
 assert(satelliteVisibility(lit,sun,40,0)==4);
 assert(satelliteVisibility(dark,sun,40,-10)==2);
 assert(satelliteVisibility(lit,sun,-5,-10)==1);
}
''');subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-I'+str(root),str(p/'test.cpp'),'-o',str(p/'test')],check=True);subprocess.run([str(p/'test')],check=True)
# Exercise the actual diagnostic branch with representative library returns.
s=(root/'Network.cpp').read_text();a=s.index('  if (diagnostic) {',s.index('int status = h.GET()'));b=s.index('  String retry=',a)
branch=s[a:b]
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'test.cpp').write_text(r'''#include <string>
#include <cassert>
#include <cstdarg>
#include <cstdio>
struct Trace{std::string text;void add(const char *fmt,...){char b[512];va_list a;va_start(a,fmt);vsnprintf(b,sizeof b,fmt,a);va_end(a);text+=b;}};
struct Client{int code,calls=0;int lastError(char *b,size_t n){calls++;snprintf(b,n,"test error");return code;}};
std::string run(int status,int code,int &calls){bool diagnostic=true;Trace trace;Client client{code};
'''+branch+r'''calls=client.calls;return trace.text;}
int main(){int calls;auto t=run(200,49,calls);assert(calls==0&&t.find("TLS-Code")==t.npos&&t.find("aufgebaut")!=t.npos);
 t=run(429,49,calls);assert(calls==0&&t.find("HTTPClient: 429")!=t.npos);
 t=run(-1,-16,calls);assert(calls==1&&t.find("TLS-Code: -16")!=t.npos);
 t=run(-1,49,calls);assert(t.find("Kein negativer")!=t.npos&&t.find("TLS-Code: 49")==t.npos);
}
''');subprocess.run(['g++','-std=c++17',str(p/'test.cpp'),'-o',str(p/'test')],check=True);subprocess.run([str(p/'test')],check=True)
print('PASS: production sight predicate, shadow/daylight/horizon, invalid/stale/future timestamps and TTL boundaries; production TLS diagnostic branch for HTTP200/429 and negative/positive library returns.')
