from pathlib import Path
import subprocess,tempfile,os,json
p=Path(__file__).resolve().parents[1];src=p/'WetterHimmel'
s=(src/'Web.cpp').read_text();a=s.index('  web.on("/api/sky"');b=s.index('  web.on("/api/action"',a);handler=s[a:b];handler=handler[handler.index('[] {')+4:handler.rfind('});')]
astr=(src/'Astronomy.cpp').read_text();project=astr[astr.index('bool project('):astr.index('void skyUpdate()')]
code=r'''
#include <ArduinoJson.h>
#include <string>
#include <cmath>
#include <cstdio>
#include <cassert>
#include <algorithm>
#include "Catalog.h"
#include "StarNames.h"
extern "C" {
#include "src/astro/astronomy.h"
}
using String=std::string;using std::isfinite;
#define DEG_TO_RAD (3.14159265358979323846/180)
#define CONTENT_LENGTH_UNKNOWN -1
struct MockWeb {std::string body;size_t largest=0;unsigned chunks=0;void sendHeader(const char*,const char*){}void setContentLength(int){}void send(int,const char*,const char*){}void sendContent(const String &s){body+=s;largest=std::max(largest,s.size());chunks++;}}web;
bool webMemoryAvailable(){return true;}
void yield(){}bool ready=true;bool clockReady(){return ready;}
struct Config{bool lines=true,labels=true,milky=true;}cfg;
long viewTime(){return 1794414720;}
static astro_time_t at;static astro_rotation_t precession;
static astro_observer_t observer(){return Astronomy_MakeObserver(46.948,7.447,540);}
'''+project+'\nvoid serve(){'+handler+'}\n'+r'''
int main(){at=Astronomy_TimeFromDays((double)viewTime()/86400-10957.5);precession=Astronomy_Rotation_EQJ_EQD(&at);serve();JsonDocument d;assert(!deserializeJson(d,web.body));unsigned expected=0;for(auto &s:stars){double a,h;int x,y;starHorizontal(s.ra,s.dec,a,h);if(project(a,h,x,y))expected++;}fprintf(stderr,"actual=%zu expected=%u body=%zu\n",d["stars"].size(),expected,web.body.size());assert(d["stars"].size()==expected&&expected>0);assert(d["lines"].size()>20);assert(d["constellations"].size()>0);assert(web.largest<1536&&web.chunks>10);
 printf("%s",web.body.c_str());fprintf(stderr,"PASS: streamed real sky: %u stars, %u lines; maximum chunk %zu bytes, %u chunks.\n",expected,unsigned(d["lines"].size()),web.largest,web.chunks);
 ready=false;web.body.clear();serve();d.clear();assert(!deserializeJson(d,web.body));assert(d["stars"].size()==0&&d["deep"].is<JsonArray>());
}
'''
Path('/tmp/sky-host.cpp').write_text(code)
with tempfile.TemporaryDirectory() as tmp:
 d=Path(tmp);(d/'test.cpp').write_text(code);obj=d/'astro.o';subprocess.run(['gcc','-O2','-c',str(src/'src/astro/astronomy.c'),'-o',str(obj)],check=True)
 subprocess.run(['g++','-std=c++17','-O2','-I'+str(src),'-I'+os.environ['ARDUINOJSON_INCLUDE'],str(d/'test.cpp'),str(obj),'-lm','-o',str(d/'test')],check=True)
 with open('/tmp/sky182.json','w') as out:subprocess.run([str(d/'test')],stdout=out,check=True)
