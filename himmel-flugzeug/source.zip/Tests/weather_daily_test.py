from pathlib import Path
import subprocess,tempfile,os
root=Path(__file__).resolve().parents[1]
app=(root/'WetterHimmel/App.h').read_text()
day=app[app.index('struct Day {'):app.index('struct Weather {')]
code='''#include <ArduinoJson.h>
#include <math.h>
#include <ctime>
#include <cassert>
#include <cstdio>
'''+day+'\n#include "WeatherDaily.h"\n'+r'''
int main(){JsonDocument doc;auto e=deserializeJson(doc,R"JSON({"time":[1794265200],"temperature_2m_min":[3],"temperature_2m_max":[9],"weather_code":[61],"precipitation_probability_max":[80],"precipitation_sum":[7.5],"precipitation_hours":[4],"snowfall_sum":[0],"wind_speed_10m_max":[22],"wind_gusts_10m_max":[41],"wind_direction_10m_dominant":[225],"sunshine_duration":[7200],"sunrise":[1794291900],"sunset":[1794326400],"uv_index_max":[1.2],"apparent_temperature_min":[1],"apparent_temperature_max":[7]})JSON");assert(!e);Day d{};parseWeatherDay(d,doc.as<JsonVariant>(),0,3600);
assert(std::string(d.date)=="2026-11-10");assert(d.min==3&&d.max==9&&d.rain==80&&d.code==61);assert(d.precipitation==7.5f&&d.precipitationHours==4&&d.snow==0);assert(d.windMax==22&&d.gustMax==41&&d.windDirection==225);assert(d.sunshine==7200&&d.sunrise==1794291900&&d.sunset==1794326400);assert(d.feelsMin==1&&d.feelsMax==7&&fabs(d.uv-1.2)<.001);
doc["temperature_2m_min"][0]=nullptr;doc["precipitation_sum"][0]=nullptr;doc.remove("sunshine_duration");doc.remove("sunrise");doc.remove("weather_code");doc.remove("precipitation_probability_max");parseWeatherDay(d,doc.as<JsonVariant>(),0,3600);assert(isnan(d.min)&&isnan(d.precipitation)&&isnan(d.sunshine));assert(d.sunrise==0&&d.code==-1&&d.rain==-1);
puts("PASS: production daily parser, local date offset, units, integer/float fields, missing/null values and missing sunrise.");}
'''
lib=Path(os.environ.get('ARDUINOJSON_DIR','/home/agent/Arduino/libraries/ArduinoJson-7.4.2/src'))
with tempfile.TemporaryDirectory() as td:
 f=Path(td)/'test.cpp';f.write_text(code);binary=Path(td)/'test'
 subprocess.run(['g++','-std=c++17','-I'+str(lib),'-I'+str(root/'WetterHimmel'),str(f),'-o',str(binary)],check=True)
 subprocess.run([str(binary)],check=True)
