from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[1];src=(root/'WetterHimmel/Screen.cpp').read_text()
a=src.index('struct QueuedTouch');b=src.index('  ++surfaceRevision;',a)
code='''#include <cassert>
#include <cstdio>
#include <cstdint>
#include "Gesture.h"
bool touchSleepGate(bool){return false;}void manualInteraction(){}struct{bool aircraft=false;}modern;
uint32_t now=0;uint32_t millis(){return now;}
bool mapDeferred=false,networkOwnsMemory=false,dirty=false;uint32_t mapRetryAt=0;
bool down=false;int px=0,py=0,page=0,actions=0,lastX=0,lastY=0;
struct {int view=1;}cfg;
struct {bool getTouch(int32_t*x,int32_t*y){*x=px;*y=py;return down;}}lcd;
void setView(int v){cfg.view=v;}
'''+src[a:b]+'''actions++;lastX=x;lastY=y;
}
void sample(bool d,int x,int y,uint32_t t){down=d;px=x;py=y;now=t;uiPollTouch();}
int main(){
 mapDeferred=true;now=1000;mapRetryAt=1000;uiTick();assert(dirty&&mapRetryAt==2000);
 dirty=false;now=1001;uiTick();assert(!dirty);
 networkOwnsMemory=true;now=3000;uiTick();assert(!dirty);
 networkOwnsMemory=false;page=1;uiTick();assert(!dirty);
 page=0;uiTick();assert(dirty);mapDeferred=false;
 // Polling during computation captures both taps without running UI actions.
 sample(true,292,15,100);sample(false,0,0,110);
 sample(true,140,200,140);sample(false,0,0,180);
 assert(actions==0);assert(touchQueueWrite==2);
 uiTick();assert(actions==1&&lastX==292&&lastY==15);
 uiTick();assert(actions==2&&lastX==140&&lastY==200);
 uiTick();assert(actions==2);
 // A command captured on a departed page cannot activate another page.
 sample(true,50,90,200);sample(false,0,0,240);page=1;
 uiTick();assert(actions==2);
 // Finite queue, no memory growth under prolonged stalled dispatch.
 for(int i=0;i<20;i++){sample(true,50,90,300+i*80);sample(false,0,0,340+i*80);}
 assert((touchQueueWrite+8-touchQueueRead)%8==7);
 for(int i=0;i<20;i++)uiTick();assert(actions==9);
 puts("PASS: production touch queue preserves rapid separated taps during computation, dispatches once, rejects departed-page input and stays bounded.");
}
'''
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);(p/'test.cpp').write_text(code)
 subprocess.run(['g++','-std=c++17','-I'+str(root/'WetterHimmel'),str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
