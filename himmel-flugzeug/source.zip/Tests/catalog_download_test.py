from pathlib import Path
import subprocess,tempfile,os,sys,json,struct,re
p=Path(__file__).resolve().parents[1];t=p/'Tests';src=p/'WetterHimmel'
s=(src/'Starlink.cpp').read_text().split('struct HorizonFrame')[0]
s='\n'.join(line for line in s.splitlines() if not line.startswith('#include'))
h=(src/'Starlink.h').read_text();h=h[h.index('struct StarlinkFetchTrace'):]
main=r'''
static void reset(){
 disk.clear();nv.clear();sdWorks=writeWorks=true;failActivation=false;mounted=false;lock=1;held=0;clockMs=0;
 responseCode=200;tlsError=0;httpCalls=0;declaredLength=-1;retryHeader="";catalogStatus={};importActive=false;active=true;fetchBusy=false;validClock=true;starlinkNext=0;
}
static bool download(const std::string &data,String &e){payload=data;declaredLength=data.size();int status;uint32_t retry;e="";return starlinkDownload(e,status,retry);}
int main(int argc,char**argv){
 std::ifstream f(argv[1]);std::string fixture((std::istreambuf_iterator<char>(f)),{});
 String error;int status;uint32_t retry,id=0;
 {
 char text[]="\"STARLINK, \"\"TEST\"\"\",42,";char *parts[40];assert(StarlinkCsv::split(text,parts)==3);assert(!strcmp(parts[0],"STARLINK, \"TEST\""));assert(!strcmp(parts[1],"42"));assert(!strcmp(parts[2],""));
 char broken[]="\"open";assert(StarlinkCsv::split(broken,parts)==-1);double number;assert(!StarlinkCsv::real("NaN",number));assert(!StarlinkCsv::real("1x",number));assert(!StarlinkCsv::real("1e999",number));
 }
 reset();assert(download(std::string("\xef\xbb\xbf")+fixture,error));
 assert(download(fixture.substr(0,fixture.size()-2),error));
 assert(!download("OBJECT_NAME,OBJECT_NAME\nSTARLINK-A,STARLINK-A\n",error));
 assert(!download(std::string(1025,'x')+"\n",error));
 reset();assert(download(fixture,error));auto c=starlinkCatalogStatus();assert(c.stored==3&&c.accepted==3&&!c.busy&&c.attempted&&c.error[0]==0);assert(held==0);
 Header hdr{};assert(validFile("/wetterhimmel/catalog.bin",hdr));auto old=disk["/wetterhimmel/catalog.bin"];
 catalogStatus={};restoreTrace();assert(catalogStatus.restored&&catalogStatus.lastFetch.http==200&&catalogStatus.lastFetch.bytes==fixture.size()&&!catalogStatus.lastFetch.interrupted);
 assert(download(fixture,error));assert(disk["/wetterhimmel/backup.bin"]==old);
 // Structurally broken CSV does not replace existing data.
 assert(!download(fixture+"broken,row\n",error));assert(disk["/wetterhimmel/catalog.bin"]==old);
 assert(!download("<!doctype html>not a catalog",error));assert(disk["/wetterhimmel/catalog.bin"]==old);
 reset();disk["/wetterhimmel/catalog.bin"]={1,2};disk["/wetterhimmel/backup.bin"]=old;failActivation=true;
 assert(!download(fixture,error));assert(disk["/wetterhimmel/backup.bin"]==old);assert(held==0);
 reset();responseCode=429;retryHeader="10000";payload=fixture;assert(!starlinkDownload(error,status,retry));assert(status==429&&retry==10000);
 catalogStatus={};restoreTrace();assert(catalogStatus.lastFetch.http==429&&catalogStatus.lastFetch.error[0]&&catalogStatus.lastFetch.next>=time(nullptr)+9998);
 reset();responseCode=-1;tlsError=-32512;assert(!starlinkDownload(error,status,retry));catalogStatus={};restoreTrace();assert(catalogStatus.lastFetch.tls==-32512&&strstr(catalogStatus.lastFetch.tlsText,"allocation"));
 reset();StarlinkFetchTrace pending{};pending.at=time(nullptr);pending.next=pending.at+7200;pending.interrupted=true;persistTrace(pending);restoreTrace();assert(catalogStatus.lastFetch.interrupted&&catalogStatus.lastFetch.next==pending.next);
 reset();sdWorks=false;assert(!starlinkDownload(error,status,retry));assert(httpCalls==0&&!starlinkCatalogStatus().attempted);
 reset();writeWorks=false;assert(!starlinkDownload(error,status,retry));assert(httpCalls==0&&!starlinkCatalogStatus().busy);
 reset();payload=fixture;declaredLength=payload.size()+10;assert(!starlinkDownload(error,status,retry));assert(!disk.count("/wetterhimmel/catalog.bin"));
 // Upload in arbitrarily split chunks, independently of HTTPS cooldown and with no network call.
 reset();starlinkNext=time(nullptr)+7200;auto due=starlinkNext;error="";StarlinkFetchTrace previous{};previous.at=time(nullptr);previous.http=-1;previous.tls=-32512;strlcpy(previous.error,"Früherer TLS-Fehler",sizeof previous.error);persistTrace(previous);restoreTrace();
 assert(starlinkImportStart(fixture.size(),id,error));auto session=id;assert(held==1);
 assert(!starlinkImportChunk(id+1,0,(const uint8_t*)fixture.data(),5,error));
 assert(!starlinkImportChunk(id,1,(const uint8_t*)fixture.data(),5,error));
 for(size_t pos=0;pos<fixture.size();pos+=7){error="";assert(starlinkImportChunk(id,pos,(const uint8_t*)fixture.data()+pos,min((size_t)7,fixture.size()-pos),error));}
 error="";assert(starlinkImportFinish(id,error));assert(!importActive&&held==0&&httpCalls==0&&starlinkNext>=due);assert(starlinkCatalogStatus().stored==3);restoreTrace();assert(catalogStatus.lastFetch.tls==-32512);
 old=disk["/wetterhimmel/catalog.bin"];
 assert(starlinkImportStart(fixture.size(),id,error));assert(!starlinkImportFinish(session,error));
 error="";assert(starlinkImportChunk(id,0,(const uint8_t*)fixture.data(),10,error));
 error="";assert(!starlinkImportFinish(id,error));assert(disk["/wetterhimmel/catalog.bin"]==old&&held==0);
 error="";assert(starlinkImportStart(fixture.size(),id,error));assert(starlinkImportCancel(id,error));assert(disk["/wetterhimmel/catalog.bin"]==old);
 error="";assert(starlinkImportStart(fixture.size(),id,error));clockMs+=120001;importTick();assert(!importActive&&held==0&&disk["/wetterhimmel/catalog.bin"]==old);
 std::string stale=fixture;size_t at=0;while((at=stale.find("2026-",at))!=std::string::npos){stale.replace(at,5,"2001-");at+=5;}
 error="";assert(starlinkImportStart(stale.size(),id,error));assert(starlinkImportChunk(id,0,(const uint8_t*)stale.data(),stale.size(),error));assert(!starlinkImportFinish(id,error));assert(disk["/wetterhimmel/catalog.bin"]==old);
 fetchBusy=true;assert(!starlinkImportStart(fixture.size(),id,error));fetchBusy=false;
 held=1;assert(!starlinkImportStart(fixture.size(),id,error));held=0;
 validClock=false;assert(!starlinkImportStart(fixture.size(),id,error));validClock=true;
 assert(!starlinkImportStart(30000001,id,error));
 if(argc>2){std::ifstream live(argv[2]);std::string csv((std::istreambuf_iterator<char>(live)),{});reset();assert(download(csv,error));auto r=starlinkCatalogStatus();printf("FULL FIXTURE: %u bytes, %u accepted, %u rejected, %u stored.\n",r.bytes,r.accepted,r.rejected,r.stored);assert(r.accepted==11199&&r.rejected==0);
  if(argc>3){std::ifstream expected(argv[3],std::ios::binary);auto &bytes=disk["/wetterhimmel/catalog.bin"];
   for(uint32_t i=0;i<r.stored;i++){double want[16];assert(expected.read((char*)want,sizeof want));Record record{};memcpy(&record,bytes.data()+sizeof(Header)+i*sizeof(Record),sizeof record);
    const auto &v=record.orbit;double got[]={double(record.id),double(v.year),double(v.month),double(v.day),double(v.hour),double(v.minute),v.second,v.meanMotion,v.eccentricity,v.inclination,v.raan,v.argPerigee,v.meanAnomaly,v.bstar,v.ndot,v.nddot};
    for(int k=0;k<16;k++)assert(got[k]==want[k]);
   }puts("PASS: all 11199 stored CSV orbital records exactly match source JSON IDs, epochs and nine orbital values (independent Python numeric reference).");
  }
  // All accepted elements retain original precision; import the same full file too.
  uint32_t session;error="";assert(starlinkImportStart(csv.size(),session,error));
  for(size_t pos=0;pos<csv.size();pos+=4096)assert(starlinkImportChunk(session,pos,(const uint8_t*)csv.data()+pos,min((size_t)4096,csv.size()-pos),error));
  assert(starlinkImportFinish(session,error));assert(starlinkCatalogStatus().stored==11199);assert(httpCalls==1);
 }
 puts("PASS: production CSV download and local chunk import; SD failures; backup/activation safety; truncation by length/schema; HTTP429/Retry-After; TLS diagnostic and interrupted attempt across restart; upload sessions/offsets/abort/timeout/busy gates; no HTTP on import.");
}
'''
with tempfile.TemporaryDirectory() as d:
 d=Path(d);source=d/'test.cpp';source.write_text('#include "catalog_download_host.h"\n#include "../WetterHimmel/StarlinkSelection.h"\n#include "../WetterHimmel/StarlinkCsv.h"\n'+h+'\n'+s+'\n'+main)
 objs=[]
 for f in [*src.glob('src/sgp4/*.c'),src/'src/astro/astronomy.c']:
  o=d/(f.stem+'.o');subprocess.run(['gcc','-O2','-c',str(f),'-o',str(o)],check=True);objs.append(str(o))
 dep=os.environ.get('ARDUINOJSON_INCLUDE','/home/agent/Arduino/libraries/ArduinoJson-7.4.2/src')
 subprocess.run(['g++','-std=c++17','-O2','-I'+str(t),'-I'+dep,str(source),*objs,'-lm','-o',str(d/'test')],check=True)
 args=sys.argv[1:]
 if len(args)>1:
  original=json.loads(Path(args[1]).read_text())
  keys=['MEAN_MOTION','ECCENTRICITY','INCLINATION','RA_OF_ASC_NODE','ARG_OF_PERICENTER','MEAN_ANOMALY','BSTAR','MEAN_MOTION_DOT','MEAN_MOTION_DDOT']
  exact=d/'original-values.bin'
  with exact.open('wb') as out:
   for row in original:
    epoch=re.fullmatch(r'(\d+)-(\d+)-(\d+)T(\d+):(\d+):([\d.]+)',row['EPOCH']);assert epoch
    values=[row['NORAD_CAT_ID'],*map(float,epoch.groups()),*[row[k] for k in keys]]
    out.write(struct.pack('<16d',*values))
  args=[args[0],str(exact)]
 subprocess.run([str(d/'test'),str(t/'fixtures/starlink-test.csv'),*args],check=True,timeout=120)
