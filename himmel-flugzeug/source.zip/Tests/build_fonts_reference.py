from PIL import Image,ImageFont,ImageDraw
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'WetterHimmel'
chars=list(range(32,127))+list(range(160,256))+[0x2014,0x2190,0x2191,0x2192,0x2193,0x2212,0x2713,0x2026]
out=['#pragma once','#include <stdint.h>','// DejaVu Sans raster subset; see vendor/DEJAVU_LICENSE.txt.', 'struct UiGlyph { uint16_t code; uint32_t offset; uint8_t width, advance; };','struct UiFont { const UiGlyph *glyphs; const uint8_t *bits; uint16_t count; uint8_t height; };']
for size,bold in [(11,False),(14,False),(20,True),(46,False),(56,False)]:
 f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold' if bold else '')+'.ttf',size)
 height=size+3; bits=[]; glyph=[]
 for c in (chars if size<46 else [32,45,46,48,49,50,51,52,53,54,55,56,57,67,176,0x2014]):
  s=chr(c); w=max(1,round(f.getlength(s))); im=Image.new('L',(w,height)); ImageDraw.Draw(im).text((0,-2),s,font=f,fill=255)
  off=len(bits); vals=list(im.getdata()); bits += [((vals[i]//17)<<4) | (vals[i+1]//17 if i+1<len(vals) else 0) for i in range(0,len(vals),2)]
  glyph.append((c,off,w,w))
 assert len(bits)<262144
 out+=['static const uint8_t uiBits%d[] PROGMEM = {'%size+','.join(map(str,bits))+'};','static const UiGlyph uiGlyphs%d[] PROGMEM = {'%size+','.join('{'+','.join(map(str,g))+'}' for g in glyph)+'};',f'static const UiFont uiFont{size} = {{uiGlyphs{size}, uiBits{size}, {len(glyph)}, {height}}};']
(p/'UiFonts.h').write_text('\n'.join(out))
