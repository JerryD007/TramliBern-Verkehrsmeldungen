const {JSDOM,VirtualConsole}=require('jsdom'),fs=require('fs'),path=require('path'),assert=require('assert');
const server=structuredClone(require('./fixtures/state.cjs'));server.skyCamera={zoom:1,panX:0,panY:0,revision:0};
let busyState=false,busySky=false,skyGets=0;
let holdState=false,releaseState=null,failPost=false,posts=[],errors=[],denied=0;
const response=(status,data)=>({status,ok:status===200,text:async()=>typeof data==='string'?data:JSON.stringify(data)});
const tick=()=>new Promise(r=>setTimeout(r,20));
const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
const ctx=new Proxy({measureText:()=>({width:30})},{get:(o,k)=>o[k]||(()=>{}),set:(o,k,v)=>(o[k]=v,true)});
const dom=new JSDOM(fs.readFileSync(path.join(__dirname,'../WetterHimmel/WebPage.h'),'utf8').split('R"WWHTML(')[1].split(')WWHTML"')[0],{url:'http://device.test',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
 w.HTMLCanvasElement.prototype.getContext=()=>ctx;w.HTMLDialogElement.prototype.showModal=function(){this.open=true};w.HTMLDialogElement.prototype.close=function(){this.open=false};
 w.fetch=async(url,opt={})=>{
  if(url==='/api/state'){if(busyState)return response(503,'Datenabruf laeuft');const snapshot=structuredClone(server);if(holdState){holdState=false;return await new Promise(resolve=>releaseState=()=>resolve(response(200,snapshot)));}return response(200,snapshot);}
  if(url==='/api/sky'){skyGets++;return busySky?response(503,'Datenabruf laeuft'):response(200,{stars:[],lines:[],deep:[]});}
  if(url==='/api/action'){
   if(failPost)throw Error('Testverbindung ausgefallen');
   if(opt.headers['X-WW-Token']!==server.token){denied++;return response(403,'Bitte Seite neu laden');}
   const cmd=JSON.parse(opt.body);posts.push(cmd);
   if(cmd.action==='view')server.view=cmd.value;if(cmd.action==='display'&&typeof cmd.nightDisplay==='boolean')server.nightDisplay=cmd.nightDisplay;
   if(cmd.action==='skyCamera'){server.skyCamera={zoom:cmd.zoom,panX:cmd.panX,panY:cmd.panY,revision:server.skyCamera.revision+1};server.view=1;}
   return response(200,{ok:true,view:server.view,skyCamera:server.skyCamera});
  }throw Error('Unexpected URL '+url);
 };
}});
(async()=>{
 const w=dom.window,d=w.document;await tick();
 // Polling must retain menu controls, focus, scroll and unsaved text.
 const menu=d.getElementById('settings');menu.showModal();menu.scrollTop=120;
 const ids=['places','networks','savedwifi','layers'];
 const nodes=ids.map(id=>d.getElementById(id).firstElementChild);
 const password=d.getElementById('password');password.value='unsaved-password';password.focus();
 for(let i=0;i<3;i++)await w.refresh();
 ids.forEach((id,i)=>assert.strictEqual(d.getElementById(id).firstElementChild,nodes[i],id+' recreated'));
 assert.strictEqual(d.activeElement,password);assert.equal(password.value,'unsaved-password');assert.equal(menu.scrollTop,120);
 const auto=d.getElementById('auto');auto.focus();const edited=[...auto.options].find(o=>+o.value!==server.autoSeconds);auto.value=edited.value;await w.refresh();assert.equal(auto.value,edited.value);
 server.networks.push('New network');await w.refresh();assert(d.getElementById('networks').textContent.includes('New network'));
 assert.strictEqual(d.getElementById('places').firstElementChild,nodes[0]);
 const normalFetch=w.fetch;w.fetch=async()=>response(200,'<!doctype html><html>unexpected page</html>');
 await assert.rejects(async()=>{const r=await w.fetchTimed('/api/state');await r.json()},/Webseite statt API-Daten/);w.fetch=normalFetch;
 menu.close();console.log('PASS: stable menu nodes, focus, unsaved password, scroll, active select, changed network list, explicit HTML-response error.');
 // Busy status must retain content, state, edited inputs and a usable menu.
 const forecast=d.getElementById('forecast').innerHTML;
 busyState=true;menu.showModal();password.value='keep-during-tls';
 await w.refresh();assert.equal(d.getElementById('forecast').innerHTML,forecast);
 assert(menu.open&&password.value==='keep-during-tls');
 assert(d.getElementById('status').textContent.includes('Datenabruf läuft'));
 await w.changeView(1);assert.equal(server.view,1); // Commands still work.
 busyState=false;busySky=true;menu.close();await w.refresh();
 assert(d.getElementById('skystatus').textContent.includes('Karte bleibt erhalten'));
 const previous=skyGets;busySky=false;await w.refresh();assert(skyGets>previous);
 await w.changeView(0);
 console.log('PASS: HTTP 503 keeps forecast, menu and edits; commands work during busy polling; deferred sky request retries on next refresh.');
 // Real menu onclick (not direct API call), and immediate visible navigation.
 d.querySelector('[data-v="1"]').click();assert(!d.getElementById('sky').classList.contains('hidden'));await tick();assert.equal(server.view,1);
 d.querySelector('[data-v="0"]').click();await tick();assert.equal(server.view,0);
 // Poll begun before command must never revert the command's visible state.
 holdState=true;const old=w.refresh();await tick();assert(releaseState);await w.changeView(1);releaseState();await old;assert.equal(server.view,1);assert(!d.getElementById('sky').classList.contains('hidden'));
 // Device restart invalidates token. One 403 then renew and retry, preserving validation.
 server.token='after-device-restart';await w.changeView(0);assert.equal(denied,1);assert.equal(server.view,0);
 // Failed device command leaves app usable and explicitly states lack of confirmation.
 failPost=true;await w.changeView(1);assert.equal(server.view,0);assert(!d.getElementById('sky').classList.contains('hidden'));assert(d.getElementById('controlstatus').textContent.includes('nur in der App'));
 await w.refresh();assert(!d.getElementById('sky').classList.contains('hidden'));failPost=false;await w.changeView(1);assert.equal(server.view,1);
 // Zoom coalescing, camera transfer and final navigation ordering.
 w.zoomBy(2);w.flushCamera();await tick();assert.equal(server.skyCamera.zoom,2);assert(d.getElementById('controlstatus').textContent.includes('bestätigt'));
 w.zoomBy(1.5);await w.changeView(0);assert.equal(server.skyCamera.zoom,3);assert.equal(server.view,0);assert(!d.getElementById('weather').classList.contains('hidden'));
 // Diagonal horizontal move triggers once even if touchend is cancelled by browser.
 const panel=d.getElementById('weather');function touch(type,points,changed=[]){let e=new w.Event(type,{bubbles:true,cancelable:true});Object.defineProperty(e,'touches',{value:points.map(([x,y])=>({clientX:x,clientY:y}))});Object.defineProperty(e,'changedTouches',{value:changed.map(([x,y])=>({clientX:x,clientY:y}))});panel.dispatchEvent(e);}
 const count=posts.length;touch('touchstart',[[200,100]]);touch('touchmove',[[100,160]]);touch('touchcancel',[]);await tick();assert.equal(server.view,1);assert.equal(posts.length,count+1);
 // App night mode is local, display mode uses a separate device command.
 const beforeNight=posts.length;w.setAppNight(true);assert(d.body.classList.contains('night'));assert.equal(w.localStorage.getItem('ww-app-night'),'1');assert.equal(posts.length,beforeNight);
 await w.act({action:'display',nightDisplay:true});assert.equal(server.nightDisplay,true);w.setAppNight(false);assert.equal(server.nightDisplay,true);assert(!d.body.classList.contains('night'));
 assert.equal(d.querySelectorAll('#forecast .today').length,1);assert.equal(d.querySelectorAll('.dayArrow').length,7);w.daydetail(0);assert.equal(d.querySelectorAll('.daygroup').length,4);
 w.controlStatus('Testfehler','error','test');w.controlStatus('Anderer Erfolg','success','other');assert(d.getElementById('controlstatus').textContent.includes('Testfehler'));
 await new Promise(r=>setTimeout(r,3600));assert(d.getElementById('controlstatus').textContent.includes('Testfehler'));
 w.controlStatus('Behoben','success','test');await new Promise(r=>setTimeout(r,3600));assert.equal(d.getElementById('controlstatus').textContent,'');
 console.log('PASS: independent app/display night controls, local persistence, Today highlight, seven detail arrows, four day sections, persistent per-action errors and success timeout.');
 assert.deepEqual(errors,[]);console.log('PASS: actual menu buttons, immediate view, stale poll exclusion, token renewal, honest offline state and retry, zoom transfer, command ordering, swipe on touchmove/cancel.');dom.window.close();
})().catch(e=>{console.error(e);dom.window.close();process.exitCode=1});
