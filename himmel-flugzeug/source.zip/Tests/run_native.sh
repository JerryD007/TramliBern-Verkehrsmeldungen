#!/bin/sh
set -eu
cd "$(dirname "$0")"
test_build_dir=$(mktemp -d)
trap 'rm -rf "$test_build_dir"' EXIT
for name in catalog_stream starlink_selection retry_check gesture_visibility; do
  g++ -std=c++17 "$name.cpp" -o "$test_build_dir/$name"
  "$test_build_dir/$name"
done
for name in astro_check omm_check; do
  gcc -O2 "$name.c" ../WetterHimmel/src/sgp4/*.c ../WetterHimmel/src/astro/astronomy.c -lm -o "$test_build_dir/$name"
  "$test_build_dir/$name"
done
python3 invariants.py
python3 radar_swipe_test.py
