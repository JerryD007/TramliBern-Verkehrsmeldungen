from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[1];s=(root/'WetterHimmel/Extras.cpp').read_text();a=s.index(' for(const char* endpoint:{"/api/firmware"');handler=s[a:s.rfind('\n}')]
code=r'''
#include <cstdint>
#include <cstring>
#include <cassert>
#include <string>
#include <functional>
#include <vector>
#include <cstdio>
class String:public std::string{public:using std::string::string;String(const std::string&s):std::string(s){}bool endsWith(const char*s){size_t n=strlen(s);return size()>=n&&compare(size()-n,n,s)==0;}};
constexpr int HTTP_POST=1,U_FLASH=0,UPLOAD_FILE_START=1,UPLOAD_FILE_WRITE=2,UPLOAD_FILE_END=3,UPLOAD_FILE_ABORTED=4;
constexpr uint32_t ESP_APP_DESC_MAGIC_WORD=0xabcd5432;
struct esp_app_desc_t{uint32_t magic_word;char padding[252];};
struct esp_partition_t{size_t size=1966080;uint32_t address=0x1f0000;};using Partition=esp_partition_t;Partition partition,running{1966080,0x10000};
Partition* esp_ota_get_running_partition(){return &running;}bool partitionAvailable=true;
Partition* esp_ota_get_next_update_partition(void*){return partitionAvailable?&partition:nullptr;}
struct Upload{int status;String filename="WetterHimmel.ino.bin";size_t currentSize=0,totalSize=0;uint8_t*buf=nullptr;};
struct Web{Upload u;String token="secret",response;int code=0;std::function<void()> done,chunk;Upload& upload(){return u;}String header(const char*){return token;}void send(int c,const char*,String s){code=c;response=s;}void on(const char*,int,std::function<void()> a,std::function<void()> b){done=a;chunk=b;}}web;
String csrf="secret",uploadError;bool firmwareUploading=false;uint32_t restartAt=0,uploadAt=0;uint32_t millis(){return 100;}
bool busy=false;bool networkBusy(){return busy;}bool starlinkImportBusy(){return false;}
struct Prefs { void putString(const char*,std::string){} } prefs;
bool uploadAuthorized(){return web.token==csrf;}
bool authorized(){if(web.token==csrf)return true;web.send(403,"","");return false;}
struct Updater{int begins=0,ends=0,aborts=0;bool failEnd=false,failWrite=false;size_t wrote=0;bool begin(size_t,int){begins++;wrote=0;return true;}size_t write(uint8_t*,size_t n){wrote+=n;return failWrite?0:n;}bool end(bool){ends++;return !failEnd;}void abort(){aborts++;}const char*errorString(){return "update failure";}}Update;
'''+s[s.index('static const char firmwareMarker'):s.index('static bool manualNight')]+'''
'''+s[s.index('static const esp_partition_t *otaTarget'):s.index('void extrasState')]+'''
void setup(){
'''+handler+r'''
}
void status(int x){web.u.status=x;web.chunk();}
void start(){restartAt=0;status(UPLOAD_FILE_START);}
void feed(std::vector<uint8_t>&b,size_t total){web.u.buf=b.data();web.u.currentSize=b.size();web.u.totalSize=total;status(UPLOAD_FILE_WRITE);}
int main(){setup();
 web.token="bad";start();assert(!firmwareUploading&&Update.begins==0);web.done();assert(web.code==403);
 web.token="secret";partitionAvailable=false;start();assert(!firmwareUploading);partitionAvailable=true;
 partition.address=running.address;start();assert(!firmwareUploading);partition.address=0x1f0000;partition.size=0x300000;start();assert(!firmwareUploading);partition.size=1966080;
 busy=true;start();assert(!firmwareUploading);busy=false;
 web.u.filename="bootloader.txt";start();assert(!firmwareUploading);web.u.filename="WetterHimmel.ino.bin";
 std::vector<uint8_t> b(320);esp_app_desc_t desc{};desc.magic_word=ESP_APP_DESC_MAGIC_WORD;memcpy(b.data()+32,&desc,sizeof desc);
 start();feed(b,0);status(UPLOAD_FILE_END);web.done();assert(web.code==400&&restartAt==0); // other app, no marker
 start();std::vector<uint8_t> tiny(10);feed(tiny,0);web.done();assert(web.code==400&&restartAt==0);
 start();feed(b,0);std::vector<uint8_t> first(firmwareMarker,firmwareMarker+10),second(firmwareMarker+10,firmwareMarker+strlen(firmwareMarker));feed(first,320);feed(second,330);status(UPLOAD_FILE_END);web.done();assert(web.code==200&&restartAt==2100&&Update.ends==1);
 start();feed(b,0);status(UPLOAD_FILE_ABORTED);web.done();assert(web.code==400&&restartAt==0);
 start();feed(b,0);feed(first,320);feed(second,330);Update.failEnd=true;status(UPLOAD_FILE_END);web.done();assert(web.code==400&&restartAt==0);Update.failEnd=false;
 Update.failWrite=true;start();feed(b,0);web.done();assert(web.code==400&&restartAt==0);
 puts("PASS: production OTA handlers reject missing auth, busy state, absent OTA slot, wrong extension/header/project marker; marker across chunks accepted; abort/write failure never schedules reboot.");
}
'''
with tempfile.TemporaryDirectory() as t:
 f=Path(t)/'test.cpp';f.write_text(code);binary=Path(t)/'test';subprocess.run(['g++','-std=c++17',str(f),'-o',str(binary)],check=True);subprocess.run([str(binary)],check=True)
