from pathlib import Path
import tempfile,subprocess
r=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as d:
 p=Path(d)
 (p/'Arduino.h').write_text('''#pragma once
#include <stdint.h>
#define ADC_11db 3
extern uint32_t now,mv;extern int calls;
inline uint32_t millis(){return now;}
inline void analogReadResolution(int n){if(n!=12)__builtin_abort();}
inline void analogSetPinAttenuation(int pin,int a){if(pin!=34||a!=ADC_11db)__builtin_abort();}
inline uint32_t analogReadMilliVolts(int pin){if(pin!=34)__builtin_abort();++calls;return mv;}
''')
 (p/'test.cpp').write_text('''#include <cassert>
#include "Battery.h"
uint32_t now=0,mv=2095;int calls=0;
int main(){batteryBegin();assert(calls==1);assert(battery.millivolts==0);
for(int i=0;i<8;i++){now=i*125;batteryTick();}
assert(battery.millivolts==4190&&battery.band==3);int old=calls;now=900;batteryTick();assert(calls==old);
battery.update(3790);assert(battery.band==3);battery.update(3749);assert(battery.band==2);
battery.update(3490);assert(battery.band==2);battery.update(3449);assert(battery.band==1);
battery.update(3500);assert(battery.band==2);battery.update(3800);assert(battery.band==3);
battery.update(0);assert(battery.band==0&&battery.millivolts==0);battery.update(4500);assert(battery.millivolts==0);
now=6000;mv=0;batteryTick();assert(!battery.millivolts);
now=UINT32_MAX-100;mv=2095; // a fresh driver deadline is tested separately below
BatteryReading b;b.update(4190);assert(b.revision==1);b.update(4190);assert(b.revision==1);
}''')
 subprocess.run(['g++','-std=c++17','-I'+str(p),'-I'+str(r/'WetterHimmel'),str(p/'test.cpp'),str(r/'WetterHimmel/Battery.cpp'),'-o',str(p/'t')],check=True);subprocess.run([str(p/'t')],check=True)
app=(r/'WetterHimmel/App.cpp').read_text();assert app.index('batteryBegin();')<app.index('netBegin();')
s=(r/'WetterHimmel/Screen.cpp').read_text();assert 'batteryRevision!=battery.revision' in s
assert '4190' not in (r/'WetterHimmel/Battery.cpp').read_text()
assert 'batteryJson(d);' in (r/'WetterHimmel/Modern.cpp').read_text()
print('PASS: production ADC sampling, divider x2, initial/invalid state, voltage bands/hysteresis, revision, startup before TLS, header updates')
# The driver's entire read batch must not run in one call or catch up in a loop.
driver=(r/'WetterHimmel/Battery.cpp').read_text();assert 'while(' not in driver and 'delay(' not in driver
# One 8-sample batch is scheduled incrementally, not 8 immediate ADC calls.
assert 'if(++samples==8)' in driver and 'sampleAt=now+125' in driver
