#include "../../WetterHimmel/SkyCamera.h"
SkyCamera skyCamera;
bool displayNight=false;
void uiDisplayBrightness(){}
#pragma once
#include <cstdint>
constexpr double pi=3.141592653589793;
#include <algorithm>
#include <cmath>
#include <ctime>
#include <cstring>
#include <string>
#include <vector>
#include <fstream>
#include <cstdio>
static time_t previewNow=1794256200;
inline time_t previewTime(time_t *out){time_t t=previewNow;if(out)*out=t;return t;}
#define time previewTime
using std::isfinite;using std::min;using std::max;
#define PROGMEM
#define DEG_TO_RAD (M_PI/180.0)
#define RAD_TO_DEG (180.0/M_PI)
#define sq(x) ((x)*(x))
template<class T> T constrain(T v,T a,T b){return min(b,max(a,v));}
class String:public std::string {public: using std::string::string;String(const std::string &s):std::string(s){} String(int n):std::string(std::to_string(n)){}String(double v,int places){char b[64];snprintf(b,64,"%.*f",places,v);assign(b);}String substring(unsigned a,unsigned b=99999)const{return substr(min(a,(unsigned)size()),min(b-a,(unsigned)size()-min(a,(unsigned)size())));}void toLowerCase(){for(char &c:*this)c=tolower((unsigned char)c);}int indexOf(const String&s)const{auto n=find(s);return n==npos?-1:n;}void remove(unsigned n){erase(n);} };
size_t strlcpy(char*d,const char*s,size_t n){snprintf(d,n,"%s",s);return strlen(s);}
extern "C" {
#include "../../WetterHimmel/src/astro/astronomy.h"
}
class Display {public:int writes=0;bool quantized=false;std::vector<uint16_t> pixels=std::vector<uint16_t>(320*480);
void drawPixel(int x,int y,uint16_t c){writes++;if(quantized){int r=(c>>13)&7,g=(c>>8)&7,b=(c>>3)&3;c=((r*31/7)<<11)|((g*63/7)<<5)|(b*31/3);}if(x>=0&&x<320&&y>=0&&y<480)pixels[y*320+x]=c;}
void drawFastVLine(int x,int y,int h,uint16_t c){for(int i=0;i<h;i++)drawPixel(x,y+i,c);}
void drawFastHLine(int x,int y,int w,uint16_t c){for(int i=0;i<w;i++)drawPixel(x+i,y,c);}
void fillRect(int x,int y,int w,int h,uint16_t c){for(int i=0;i<h;i++)drawFastHLine(x,y+i,w,c);}
void fillScreen(uint16_t c){fillRect(0,0,320,480,c);}
void drawLine(int x,int y,int xx,int yy,uint16_t c){int dx=abs(xx-x),sx=x<xx?1:-1,dy=-abs(yy-y),sy=y<yy?1:-1,err=dx+dy;for(;;){drawPixel(x,y,c);if(x==xx&&y==yy)break;int e=2*err;if(e>=dy){err+=dy;x+=sx;}if(e<=dx){err+=dx;y+=sy;}}}
void fillCircle(int x,int y,int r,uint16_t c){for(int yy=-r;yy<=r;yy++){int w=sqrt(r*r-yy*yy);drawFastHLine(x-w,y+yy,2*w+1,c);}}
void drawEllipse(int x,int y,int rx,int ry,uint16_t c){for(int k=0;k<3600;k++){double a=k*M_PI/1800;drawPixel(x+lround(rx*cos(a)),y+lround(ry*sin(a)),c);}}
void drawCircle(int x,int y,int r,uint16_t c){drawEllipse(x,y,r,r,c);}
void drawRect(int x,int y,int w,int h,uint16_t c){drawLine(x,y,x+w-1,y,c);drawLine(x,y+h-1,x+w-1,y+h-1,c);drawLine(x,y,x,y+h-1,c);drawLine(x+w-1,y,x+w-1,y+h-1,c);}
void fillRoundRect(int x,int y,int w,int h,int r,uint16_t c){for(int yy=0;yy<h;yy++){int d=yy<r?r-yy-1:yy>=h-r?yy-(h-r):0;int inset=d?r-(int)sqrt(r*r-d*d):0;drawFastHLine(x+inset,y+yy,w-2*inset,c);}}
void drawRoundRect(int x,int y,int w,int h,int r,uint16_t c){drawFastHLine(x+r,y,w-2*r,c);drawFastHLine(x+r,y+h-1,w-2*r,c);drawLine(x,y+r,x,y+h-r-1,c);drawLine(x+w-1,y+r,x+w-1,y+h-r-1,c);for(int k=0;k<360;k++){double a=k*DEG_TO_RAD;int xx=(cos(a)<0?x+r:x+w-r-1)+r*cos(a);int yy=(sin(a)<0?y+r:y+h-r-1)+r*sin(a);drawPixel(xx,yy,c);}}
void waitDMA(){}void init(){}void setRotation(int){}void setBrightness(int){}void setTextWrap(bool){}void setTouchCalibrate(uint16_t*){}void calibrateTouch(uint16_t*,int,int,int){}
void save(const char*path){std::ofstream f(path,std::ios::binary);f<<"P6\n320 480\n255\n";for(auto c:pixels){unsigned char b[3]={(unsigned char)((c>>11)*255/31),(unsigned char)(((c>>5)&63)*255/63),(unsigned char)((c&31)*255/31)};f.write((char*)b,3);}}
};
struct Place{char name[40];double lat,lon,height;char tz[80];};
struct Settings{Place places[6];int place=0,view=0,brightness=255,rotation=0;bool milky=true,lines=true,labels=true,satellites=true,starlink=true;};
struct Weather{bool valid;time_t fetched;float temp,feels,humidity,wind,direction,cloud;int code;struct Day{char date[12];float min,max;int code,rain;float feelsMin,feelsMax,precipitation,precipitationHours,snow,windMax,gustMax,windDirection,sunshine,uv;time_t sunrise,sunset;}days[7];char error[96];};
struct SkyObject{char name[36];double az,alt,mag,x,y;uint16_t color;int kind;};
struct Satellite{char name[40]{};bool valid=false,passOngoing=false;time_t epoch=0,rise=0,set=0,visibilityAt=0;double az=0,alt=0,maxAlt=0,startAz=0,endAz=0;int catalog=0,visibility=0;char error[80]{};};
struct Prefs{int getBytesLength(const char*){return 0;}void putBytes(const char*,void*,int){}void getBytes(const char*,void*,int){}};
struct WIFI{int status(){return 1;}};
#define WL_CONNECTED 1
constexpr int SAT_COUNT=4;
Display lcd;Settings cfg;Weather weather;Prefs prefs;WIFI WiFi;SkyObject objects[24];Satellite satellites[7];int objectCount=0,page=0;bool dirty=true;time_t simTime=0;double moonPhase=0,sunAlt=0;time_t sunrise=0,sunset=0;
bool clockReady(){return true;}time_t viewTime(){return simTime?simTime:1794256200;}
String apPassword="preview-password";

String stamp(time_t,bool=false);

#define UI_HOST_PREVIEW
#include <cassert>
static bool expectAtomic=false;
static bool fakeAllocationFailure=false;
static int spriteAllocations=0,spriteDeletes=0;
class LGFX_Sprite:public Display {
 Display *parent;
public:
 LGFX_Sprite(Display *p):parent(p){}
 void setPsram(bool){}
 void setColorDepth(int bits){quantized=bits==8;}
 uint16_t palette[16]{};
 bool createPalette(const uint16_t *c,unsigned n){for(unsigned i=0;i<n;i++)palette[i]=c[i];return true;}
 void setPaletteColor(unsigned i,uint16_t c){palette[i]=c;}
 void setBuffer(void*,int,int,int){allocated=true;}
 bool allocated=false;
 void *createSprite(int,int){assert(!allocated);if(fakeAllocationFailure)return nullptr;allocated=true;spriteAllocations++;return pixels.data();}
 void deleteSprite(){assert(allocated);allocated=false;spriteDeletes++;}
 void setPivot(int,int){}
 void pushRotateZoom(float cx,float cy,float angle,float zx,float zy){assert(allocated);assert(angle==0&&zx==zy);int edge=lround(224*zx);if(expectAtomic)assert(parent->writes==0);for(int yy=0;yy<edge;yy++)for(int xx=0;xx<edge;xx++)parent->drawPixel(cx-edge/2+xx,cy-edge/2+yy,palette[pixels[int(yy/zy)*320+int(xx/zx)]&15]);}
 void pushSprite(int x,int y){assert(allocated);if(expectAtomic)assert(parent->writes==0);for(int yy=0;yy<224;yy++)for(int xx=0;xx<224;xx++)parent->drawPixel(x+xx,y+yy,pixels[yy*320+xx]);}
};
uint32_t generation=0;

String starlinkStatus="Bahndaten fehlen";uint32_t starlinkCount=0,starlinkScanMs=0;

String satelliteCountdown(const Satellite&s){return s.valid?"Jetzt am Himmel":"Daten fehlen";}

bool satPaused=false;String satPauseReason="";time_t satelliteRetry(int){return 0;}

struct ExtraSettings {bool largeMap=false,trails=false,autoNight=false;int start=1320,end=420,dim=35;}extra;
int highlightedObject=-1;
bool objectCoordinates(int,double&,double&,String&);
bool trailFixture=false;bool satelliteFuture(int,time_t t,double &az,double &alt){if(!trailFixture)return false;az=180+(t-previewNow)/5.0;alt=45+(t-previewNow)/12.0;return true;}

static uint32_t hostMillis=0;uint32_t millis(){return hostMillis;}
