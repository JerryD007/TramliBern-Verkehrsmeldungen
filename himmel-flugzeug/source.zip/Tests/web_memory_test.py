from pathlib import Path
import tempfile,subprocess,os
root=Path(__file__).resolve().parents[1];s=(root/'WetterHimmel/Web.cpp').read_text()
helpers=s[s.index('bool webMemoryAvailable()'):s.index('void stateJson(')]
a=s.index('web.on("/api/state"');b=s.index('web.on("/api/health"',a);handler=s[a:b];handler=handler[handler.index('[] {')+4:handler.rfind('});')]
code=r'''
#include <ArduinoJson.h>
#include <string>
#include <cassert>
#include <cstdio>
#include <algorithm>
struct Web {
 int status=0;size_t length=0,maxChunk=0,chunks=0;std::string body,retry;
 void sendHeader(const char*k,const char*v){if(std::string(k)=="Retry-After")retry=v;}
 void setContentLength(size_t n){length=n;}
 void send(int status,const char*,const char*s){this->status=status;body=s;}
 void sendContent(const char*s,size_t n){body.append(s,n);maxChunk=std::max(maxChunk,n);chunks++;}
}web;
bool busy=false;bool networkBusy(){return busy;}int stateCalls=0;
'''+helpers+r'''
void stateJson(JsonDocument &d){stateCalls++;d["payload"]=std::string(20000,'x');}
void stateHandler(){'''+handler+r'''}
struct Reject:ArduinoJson::Allocator{void*allocate(size_t){return nullptr;}void deallocate(void*){}void*reallocate(void*,size_t){return nullptr;}}reject;
int main(){
 busy=true;stateHandler();assert(web.status==503&&web.retry=="2"&&stateCalls==0&&web.chunks==0);
 busy=false;web={};stateHandler();assert(web.status==200&&stateCalls==1&&web.maxChunk<=512&&web.chunks>30&&web.length==web.body.size());
 JsonDocument roundtrip;assert(!deserializeJson(roundtrip,web.body));assert(roundtrip["payload"].as<std::string>()==std::string(20000,'x'));
 for(int size:{0,1,500,511,512,513,1024,20000}){
  web={};JsonDocument d;d["utf8"]="Saturn · Höhe 45°";d["value"]=std::string(size,'"');webReplyJson(d);
  assert(web.status==200&&web.length==web.body.size()&&web.maxChunk<=512);
  JsonDocument parsed;assert(!deserializeJson(parsed,web.body));assert(parsed["value"].as<std::string>()==std::string(size,'"'));assert(parsed["utf8"]=="Saturn · Höhe 45°");
 }
 web={};JsonDocument d(&reject);d["value"]=1;assert(d.overflowed());webReplyJson(d);assert(web.status==503&&web.chunks==0);
 puts("PASS: actual state handler skips JSON construction while network busy; 512-byte output chunks preserve large/escaped/UTF8 JSON with exact Content-Length; overflow rejects incomplete documents.");
}
'''
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);(p/'test.cpp').write_text(code)
 subprocess.run(['g++','-std=c++17','-I'+os.environ['ARDUINOJSON_INCLUDE'],str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
