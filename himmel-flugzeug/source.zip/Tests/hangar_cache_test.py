from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1]
code=r'''
#include "HangarHome.h"
#include <cassert>
#include <algorithm>
#include <vector>
#include <cstdio>
#include <map>
#include <string>
using namespace Hangar;
std::vector<Record> all;
void check(Home &h){auto sorted=all;std::sort(sorted.begin(),sorted.end(),[](auto&a,auto&b){return before(a,b,false);});assert(h.total==all.size());assert(h.size==std::min(size_t(12),all.size()));for(unsigned i=0;i<h.size;++i)assert(!memcmp(&h.rows[i],&sorted[i],offsetof(Record,crc)+sizeof(uint32_t)));h.crc=h.checksum();assert(h.valid());}
int main(){Home h;long now=1800000000;
for(unsigned i=0;i<452;++i){Record r;snprintf(r.hex,sizeof r.hex,"%06x",i);r.passes=1;r.first=r.last=r.frame=now+i;r.crc=checksum(r);all.push_back(r);h.observe(r,true);check(h);}
for(unsigned i=0;i<10000;++i){unsigned index=(i*137)%all.size();auto &r=all[index];r.last=r.frame=now+500+i;snprintf(r.callsign,sizeof r.callsign,"TEST%u",i);if(i%37==0)++r.passes;r.crc=checksum(r);h.observe(r,false);check(h);}
for(unsigned i=0;i<sizeof(Home);++i){Home bad=h;((unsigned char*)&bad)[i]^=1;if(i<offsetof(Home,crc)+sizeof(h.crc))assert(!bad.valid());}
Home empty;empty.crc=empty.checksum();assert(empty.valid());printf("PASS first-page cache: 452 initial records, 10000 updates, exact top-12/count, corruption rejected, empty history\n");
}
'''
with tempfile.TemporaryDirectory() as t:
 p=Path(t);(p/'test.cpp').write_text(code)
 subprocess.run(['g++','-std=c++17','-O2','-Wall','-Wextra','-I'+str(r/'WetterHimmel'),str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
s=(r/'WetterHimmel/Hangar.cpp').read_text()
assert s.index('if(context.home&&!context.invalidated)')<s.index('if(!writeRecord(path,r))')
assert 'if(context.home&&context.invalidated)writeHome(home)' in s
print('PASS mutation ordering: index invalidated before authoritative updates; publish after whole successful batch')
helpers=s[s.index('bool readHome('):s.index('void failure(')]
io=r'''
#include "HangarHome.h"
#include <map>
#include <vector>
#include <string>
#include <algorithm>
#include <cassert>
using namespace std;
map<string,vector<uint8_t>> disk;int limit=-1;
struct File{string path;size_t pos=0;bool open=false;operator bool()const{return open;}size_t size(){return disk[path].size();}size_t read(uint8_t*p,size_t n){auto&v=disk[path];n=min(n,v.size()-min(pos,v.size()));memcpy(p,v.data()+pos,n);pos+=n;return n;}size_t write(const uint8_t*p,size_t n){if(limit>=0)n=min(n,size_t(limit));disk[path].assign(p,p+n);return n;}void close(){}void flush(){}};
struct Store{File open(const char*p,const char*m){if(m[0]=='w'){disk[p].clear();return {p,0,true};}return {p,0,disk.count(p)>0};}bool remove(const char*p){return disk.erase(p)>0;}}SD;
#define FILE_READ "r"
const char *homePath="cache";unsigned cacheErrors=0;
'''+helpers+r'''
int main(){Hangar::Home h,out;disk["history"]={1,2,3};assert(!readHome(out));assert(writeHome(h));assert(readHome(out)&&out.total==0);
for(unsigned i=0;i<sizeof h;i++){limit=i;assert(!writeHome(h));assert(!readHome(out));assert(disk["history"]==vector<uint8_t>({1,2,3}));}limit=-1;assert(writeHome(h));disk[homePath][10]^=1;assert(!readHome(out));assert(writeHome(h)&&readHome(out));}
'''
with tempfile.TemporaryDirectory() as t:
 p=Path(t);(p/'io.cpp').write_text(io)
 subprocess.run(['g++','-std=c++17','-O2','-I'+str(r/'WetterHimmel'),str(p/'io.cpp'),'-o',str(p/'io')],check=True)
 subprocess.run([str(p/'io')],check=True)
print('PASS production index IO: every truncated write rejected, corruption/recovery, authoritative history untouched')
