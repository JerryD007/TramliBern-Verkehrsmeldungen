import subprocess as sp,ssl,socket,threading,json,pathlib,tempfile,urllib.request,tarfile,hashlib,sys,shutil
root=pathlib.Path(__file__).resolve().parents[1]
tmp=pathlib.Path(tempfile.mkdtemp(prefix='tls-cert-'))
for name in ['trusted','other']:
 sp.run(['openssl','req','-x509','-newkey','ec','-pkeyopt','ec_paramgen_curve:secp384r1','-nodes','-keyout',str(tmp/(name+'.key')),'-out',str(tmp/(name+'.pem')),'-days','2','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost'],check=True,stdout=sp.DEVNULL,stderr=sp.DEVNULL)

# Build three exact upstream configurations; no ESP32 hardware results are implied.
build=pathlib.Path(tempfile.mkdtemp(prefix='tls-memory-test-'))
archive=build/'source.tar.gz'
url='https://codeload.github.com/espressif/mbedtls/tar.gz/98ae8db06b8acc1dc1c6b1f78c2719cb776f4147'
with urllib.request.urlopen(url,timeout=90) as response:archive.write_bytes(response.read())
assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'cb8ad966e999b9d79655015de0080a129283907022e9ba60d7a99a5fa15fa56e'
with tarfile.open(archive) as t:t.extractall(build,filter='data')
source=next(build.glob('mbedtls-*'))
config=source/'include/mbedtls/mbedtls_config.h'
s=config.read_text().replace('//#define MBEDTLS_PLATFORM_MEMORY','#define MBEDTLS_PLATFORM_MEMORY').replace('#define MBEDTLS_SSL_PROTO_TLS1_3','//#define MBEDTLS_SSL_PROTO_TLS1_3');config.write_text(s)
for size in [16,4,2]:
 sp.run([sys.executable,'-m','cmake','-S',str(source),'-B',str(build/f'tls{size}'),'-DENABLE_PROGRAMS=OFF','-DENABLE_TESTING=OFF',f'-DCMAKE_C_FLAGS=-DMBEDTLS_SSL_IN_CONTENT_LEN=16384 -DMBEDTLS_SSL_OUT_CONTENT_LEN={(4 if size==2 else size)*1024} -DMBEDTLS_ECP_WINDOW_SIZE={2 if size==2 else 6}'],check=True,stdout=sp.DEVNULL)
 sp.run([sys.executable,'-m','cmake','--build',str(build/f'tls{size}'),'-j4'],check=True,stdout=sp.DEVNULL)

ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.maximum_version=ssl.TLSVersion.TLSv1_2;ctx.load_cert_chain(tmp/'trusted.pem',tmp/'trusted.key');ctx.set_ecdh_curve('secp384r1')
from cryptography import x509
from cryptography.hazmat.primitives import serialization,hashes
from datetime import datetime,timezone
key=serialization.load_pem_private_key((tmp/'trusted.key').read_bytes(),password=None)
name=x509.Name([x509.NameAttribute(x509.NameOID.COMMON_NAME,'localhost')])
expired=x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(123).not_valid_before(datetime(2020,1,1,tzinfo=timezone.utc)).not_valid_after(datetime(2020,1,2,tzinfo=timezone.utc)).add_extension(x509.SubjectAlternativeName([x509.DNSName('localhost')]),critical=False).sign(key,hashes.SHA256())
(tmp/'expired.pem').write_bytes(expired.public_bytes(serialization.Encoding.PEM))
expired_ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);expired_ctx.maximum_version=ssl.TLSVersion.TLSv1_2;expired_ctx.load_cert_chain(tmp/'expired.pem',tmp/'trusted.key')
results={}
for size in [16,4,2]:
 exe=tmp/f'client{size}'
 sp.run(['cc','-I'+str(source/'include'),str(root/'Tests/tls_memory_client.c'),str(build/f'tls{size}/library/libmbedtls.a'),str(build/f'tls{size}/library/libmbedx509.a'),str(build/f'tls{size}/library/libmbedcrypto.a'),'-o',str(exe)],check=True)
 results[size]=[]
 for cert,host,valid in [('trusted','localhost',1),('trusted','wrong.invalid',0),('other','localhost',0),('expired','localhost',0)]+[('trusted','localhost',1)]*5:
  listener=socket.socket();listener.bind(('127.0.0.1',0));listener.listen();port=listener.getsockname()[1]
  def serve():
   try:
    raw,_=listener.accept();raw.settimeout(10)
    with (expired_ctx if cert=='expired' else ctx).wrap_socket(raw,server_side=True) as s:
     remaining=65536
     while remaining:
      b=s.recv(min(remaining,16384))
      if not b:return
      assert b==b'\x5a'*len(b);remaining-=len(b)
     s.sendall(b'\xa5'*65536)
   except ssl.SSLError:pass
   finally:listener.close()
  t=threading.Thread(target=serve);t.start()
  p=sp.run([str(exe),str(port),str(tmp/(cert+'.pem')),host,str(valid)],text=True,capture_output=True,timeout=20);t.join(timeout=12)
  assert p.returncode==0,(p.stdout,p.stderr);results[size].append(json.loads(p.stdout))
assert results[16][0]['setup']-results[4][0]['setup']==12288,results
# The buffer allocation is exact; full handshakes include independently
# generated ephemeral keys/signatures and need not have identical peaks.
# Require reduction across ALL successful repetitions, not just the first.
peaks={k:[v['handshakePeak'] for v in rows if v['result']==0] for k,rows in results.items()}
assert max(peaks[4])<min(peaks[16]),results
assert max(peaks[2])<min(peaks[4]),results
assert all(v['remaining']==0 for rows in results.values() for v in rows),results
(root/'Tests/new/tls-memory-host.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))

shutil.rmtree(build);shutil.rmtree(tmp)
