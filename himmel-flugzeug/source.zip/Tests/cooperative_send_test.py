from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1]
s='''#include <cassert>
#include <cstring>
#include "CooperativeSend.h"
int main(){uint8_t data[2049],out[2049];for(int i=0;i<2049;i++)data[i]=i;size_t offset=0;unsigned calls=0,polls=0,now=0,pauses=0;
auto poll=[&](){++polls;};auto clock=[&](){return now;};auto pause=[&](){++now;++pauses;};
auto writer=[&](const uint8_t*p,size_t n)->int{assert(n<=512);++calls;if(calls%3==0)return 0;size_t k=n>73?73:n;memcpy(out+offset,p,k);offset+=k;return k;};
assert(cooperativeSend(data,sizeof data,writer,poll,clock,pause));assert(offset==sizeof data&&!memcmp(data,out,sizeof data)&&polls>=calls&&pauses>0);
now=0xfffffff0u;polls=0;pauses=0;assert(!cooperativeSend(data,2,[](const uint8_t*,size_t){return 0;},poll,clock,pause));assert(pauses==5000&&polls==5001);
assert(!cooperativeSend(data,2,[](const uint8_t*,size_t){return -1;},poll,clock,pause));
assert(!cooperativeSend(data,2,[](const uint8_t*,size_t){return 3;},poll,clock,pause));
}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'t.cpp').write_text(s);subprocess.run(['g++','-std=c++17','-I'+str(r/'WetterHimmel'),str(p/'t.cpp'),'-o',str(p/'t')],check=True);subprocess.run([str(p/'t')],check=True)
print('PASS: byte-exact short writes, bounded chunks, polling under backpressure, timeout through millis rollover, disconnect/error handling')
