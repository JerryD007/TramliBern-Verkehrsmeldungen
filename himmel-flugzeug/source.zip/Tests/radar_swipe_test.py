from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1];s=(root/'WetterHimmel/Screen.cpp').read_text()
assert 'full||(page>0&&page!=8&&page!=15&&changed)' in s
poll=s[s.index('struct QueuedTouch'):s.index('static void action(int a)')]
a=s.index(' if(t.event==2&&');dispatch=s[a:s.index('\n int x=t.x',a)]
code='''#include <cassert>
#include <cstdint>
#include <algorithm>
#include "Gesture.h"
using std::min;using std::max;int constrain(int x,int a,int b){return max(a,min(x,b));}
int page=0;struct{int view=1,brightness=255;}cfg;struct{bool aircraft=true;}modern;
bool dirty=false,down=false;int px=0,py=0,surfaceRevision=0;uint32_t now=0;
uint32_t millis(){return now;}bool touchSleepGate(bool){return false;}void manualInteraction(){}void uiDisplayBrightness(){}void saveSettings(){}
void runTouch(uint32_t){}
void setView(int v){cfg.view=v;page=0;}
struct{bool getTouch(int32_t*x,int32_t*y){*x=px;*y=py;return down;}}lcd;
'''+poll+'''
void dispatch(){if(qr==qw)return;auto t=queue[qr];qr=(qr+1)%8;if(t.page!=page||t.view!=cfg.view)return;
'''+dispatch+'''}
void sample(bool d,int x,int y){down=d;px=x;py=y;now+=70;uiPollTouch();}
void swipe(int dx){sample(true,220,150);sample(true,220+dx,150);sample(false,0,0);assert(qr!=qw);assert(queue[qr].event==2);dispatch();}
int main(){
 for(int repeat=0;repeat<10;repeat++){
 page=0;cfg.view=1;swipe(-100);assert(page==0&&cfg.view==2);swipe(-100);assert(page==15);swipe(-100);assert(page==0&&cfg.view==1);
 swipe(100);assert(page==15);swipe(100);assert(page==0&&cfg.view==2);swipe(100);assert(page==0&&cfg.view==1);
 }
 page=15;sample(true,120,160);sample(false,0,0);assert(queue[qr].event==1);dispatch();assert(page==15);
 page=1;sample(true,220,150);sample(true,100,150);sample(false,0,0);assert(qr==qw);
 page=15;modern.aircraft=false;swipe(-100);assert(page==0&&cfg.view==1);
}
'''
with tempfile.TemporaryDirectory() as t:
 p=Path(t);(p/'test.cpp').write_text(code);subprocess.run(['g++','-std=c++17','-I'+str(root/'WetterHimmel'),str(p/'test.cpp'),'-o',str(p/'test')],check=True);subprocess.run([str(p/'test')],check=True)
print('PASS production touch polling + swipe dispatch: both directions, 60 transitions, radar tap, menu isolation, disabled aircraft exit')
