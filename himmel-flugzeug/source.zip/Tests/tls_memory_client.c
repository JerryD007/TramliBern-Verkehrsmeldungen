#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "mbedtls/platform.h"
#include "mbedtls/net_sockets.h"
#include "mbedtls/ssl.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/x509_crt.h"
static size_t live,peak;
static void *alloc_count(size_t n,size_t z){if(z&&n>SIZE_MAX/z)return NULL;size_t b=n*z;size_t*p=calloc(1,b+sizeof(size_t));if(!p)return NULL;*p=b;live+=b;if(live>peak)peak=live;return p+1;}
static void free_count(void *p){if(p){size_t*q=(size_t*)p-1;live-=*q;free(q);}}
int main(int argc,char **argv){
 if(argc!=5)return 2;mbedtls_platform_set_calloc_free(alloc_count,free_count);
 mbedtls_ssl_context ssl;mbedtls_ssl_config conf;mbedtls_x509_crt ca;mbedtls_ctr_drbg_context rng;mbedtls_entropy_context ent;mbedtls_net_context net;
 mbedtls_ssl_init(&ssl);mbedtls_ssl_config_init(&conf);mbedtls_x509_crt_init(&ca);mbedtls_ctr_drbg_init(&rng);mbedtls_entropy_init(&ent);mbedtls_net_init(&net);
 int r=mbedtls_ctr_drbg_seed(&rng,mbedtls_entropy_func,&ent,(const unsigned char*)"test",4);
 if(!r)r=mbedtls_x509_crt_parse_file(&ca,argv[2]);
 if(!r)r=mbedtls_ssl_config_defaults(&conf,MBEDTLS_SSL_IS_CLIENT,MBEDTLS_SSL_TRANSPORT_STREAM,MBEDTLS_SSL_PRESET_DEFAULT);
 mbedtls_ssl_conf_authmode(&conf,MBEDTLS_SSL_VERIFY_REQUIRED);mbedtls_ssl_conf_ca_chain(&conf,&ca,NULL);mbedtls_ssl_conf_rng(&conf,mbedtls_ctr_drbg_random,&rng);
 if(!r)r=mbedtls_ssl_setup(&ssl,&conf);size_t setup=live;
 if(!r)r=mbedtls_ssl_set_hostname(&ssl,argv[3]);
 if(!r)r=mbedtls_net_connect(&net,"127.0.0.1",argv[1],MBEDTLS_NET_PROTO_TCP);
 mbedtls_ssl_set_bio(&ssl,&net,mbedtls_net_send,mbedtls_net_recv,NULL);
 if(!r)r=mbedtls_ssl_handshake(&ssl);size_t hs=peak;int expect=atoi(argv[4]);size_t sent=0,received=0;unsigned char b[16384];memset(b,0x5a,sizeof b);
 if(!r&&expect){while(sent<65536){int n=mbedtls_ssl_write(&ssl,b,sizeof b);if(n<=0){r=n?n:-1;break;}sent+=n;}while(!r&&received<65536){int n=mbedtls_ssl_read(&ssl,b,sizeof b);if(n<=0){r=n?n:-1;break;}for(int i=0;i<n;i++)if(b[i]!=0xa5)r=-1;received+=n;}}
 unsigned flags=mbedtls_ssl_get_verify_result(&ssl);int okay=expect?(!r&&!flags&&sent==65536&&received==65536):(r<0&&flags!=0);
 mbedtls_ssl_free(&ssl);mbedtls_ssl_config_free(&conf);mbedtls_x509_crt_free(&ca);mbedtls_ctr_drbg_free(&rng);mbedtls_entropy_free(&ent);mbedtls_net_free(&net);
 printf("{\"setup\":%zu,\"handshakePeak\":%zu,\"remaining\":%zu,\"sent\":%zu,\"received\":%zu,\"result\":%d,\"flags\":%u}\n",setup,hs,live,sent,received,r,flags);return !(okay&&live==0);
}
