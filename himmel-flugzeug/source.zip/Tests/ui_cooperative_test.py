from pathlib import Path
import tempfile,subprocess
r=Path(__file__).resolve().parents[1];s=(r/'WetterHimmel/Screen.cpp').read_text()
body=s[s.index('static bool sampleChartTouch()'):s.index('static void skyScreen')]
source='''#include <cassert>
struct Device{void endWrite(){}void startWrite(){}}lcd;
struct Paint{bool restored=false;void targetAt(Device&){restored=true;}}paint;
bool pending=false,dirty=false,mapDeferred=false;int hitCount=42,mapRetryAt=0;
void uiPollTouch(){}bool uiInputPending(){return pending;}int millis(){return 123;}
'''+body+'''
int main(){assert(!sampleChartTouch());assert(hitCount==42&&!dirty);pending=true;
assert(sampleChartTouch());assert(dirty&&mapDeferred&&paint.restored&&hitCount==0&&mapRetryAt==123);}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'t.cpp').write_text(source);subprocess.run(['g++',str(p/'t.cpp'),'-o',str(p/'t')],check=True);subprocess.run([str(p/'t')],check=True)
assert 'if(i%24==0&&sampleChartTouch())return;' in s
assert 'Object taps wait for the completed map' in s
assert 'webServiceUi();' in (r/'WetterHimmel/Web.cpp').read_text()
print('PASS: production render interruption restores LCD target, marks redraw, leaves object taps for completed hit map; web transfer services input')
