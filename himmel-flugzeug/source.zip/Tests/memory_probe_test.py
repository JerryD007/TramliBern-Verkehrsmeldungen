from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]/'WetterHimmel'
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);(p/'freertos').mkdir()
 (p/'freertos/FreeRTOS.h').write_text('''#pragma once
#include <cstdint>
using portMUX_TYPE=int;
#define portMUX_INITIALIZER_UNLOCKED 0
#define portENTER_CRITICAL_SAFE(x) ((void)0)
#define portEXIT_CRITICAL_SAFE(x) ((void)0)
''')
 (p/'freertos/task.h').write_text('''#pragma once
using TaskHandle_t=void*;
extern TaskHandle_t currentTask;
inline TaskHandle_t xTaskGetCurrentTaskHandle(){return currentTask;}
inline unsigned uxTaskGetStackHighWaterMark(void*){return 4321;}
''')
 (p/'esp_heap_caps.h').write_text('''#pragma once
#include <cstddef>
#include <cstdint>
#define ESP_OK 0
#define MALLOC_CAP_INTERNAL 0x800
#define MALLOC_CAP_8BIT 4
using esp_alloc_failed_hook_t=void(*)(size_t,uint32_t,const char*);
extern esp_alloc_failed_hook_t hook;
extern int registration;
inline int heap_caps_register_failed_alloc_callback(esp_alloc_failed_hook_t h){hook=h;return registration;}
inline unsigned heap_caps_get_largest_free_block(unsigned){return 12345;}
''')
 (p/'test.cpp').write_text('''#include <cassert>
#include <cstdio>
#include <cstring>
#include <string>
#include <ctime>
#include "esp_heap_caps.h"
#include "freertos/task.h"
#include "MemoryProbe.h"
TaskHandle_t currentTask=(void*)1;
esp_alloc_failed_hook_t hook=nullptr;int registration=0;
struct String:std::string {using std::string::string;size_t length()const{return size();}};
struct IP {String toString(){return "255.255.255.255";}};
struct {int status(){return 3;}int RSSI(){return -99;}IP localIP(){return {};}IP gatewayIP(){return {};}IP dnsIP(){return {};}}WiFi;
struct {unsigned getFreeHeap(){return 99999;}}ESP;
uint32_t millis(){return 999999;}
#include "WeatherTrace.h"
int main(){
 memoryProbeInit();hook(5,4,"ignored");memoryProbeBegin();memoryProbePhase(2);
 hook(16384,0x804,"heap_caps_calloc");hook(32,4,"later");
 currentTask=(void*)2;hook(999,8,"other");currentTask=(void*)1;
 auto r=memoryProbeEnd();assert(r.registered&&r.worker.count==2&&r.other.count==1);
 assert(r.worker.bytes==16384&&r.worker.caps==0x804&&r.worker.phase==2);
 assert(std::string(r.worker.allocator)=="heap_caps_calloc");
 hook(3,4,"after end");r=memoryProbeEnd();assert(r.worker.count==2);
 memoryProbeBegin();r=memoryProbeEnd();assert(!r.worker.count&&!r.other.count);
 registration=-1;memoryProbeInit();memoryProbeBegin();r=memoryProbeEnd();assert(!r.registered);
 registration=0;memoryProbeInit();char out[1200];String error("error");
 {WeatherTrace trace(out,error);
 trace.add("DNS api.open-meteo.com: 255.255.255.255 (99999 ms)\\n");
 memoryProbePhase(2);hook(0xffffffff,0xffffffff,"very_long_allocator_name_must_be_bounded");
 currentTask=(void*)2;hook(0xffffffff,0xffffffff,"other_long_allocator_name_bounded");currentTask=(void*)1;
 trace.memory("Nach GET, TLS noch offen");
 trace.add("HTTPClient: -1\\nTLS-Code: -16\\nTLS-Detail: %.160s\\n",std::string(160,'x').c_str());
 }
 assert(strstr(out,"Abruf-Task: 1 Fehler"));assert(strstr(out,"Andere Tasks: 1 Fehler"));
 assert(strstr(out,"4321 Byte"));assert(strstr(out,"Nach TLS-Freigabe"));assert(strstr(out,"Dauer:"));
 assert(strlen(out)+120<sizeof out); // room for parser/result line
 puts(out);
 puts("PASS: first failure retained, task separation, phase/capabilities/size, bounded names, reset, disabled-hook status, trace fits 1200 bytes with result reserve.");
}
''')
 subprocess.run(['g++','-std=c++17','-I'+str(p),'-I'+str(root),str(p/'test.cpp'),str(root/'MemoryProbe.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
