from pathlib import Path
p=Path(__file__).resolve().parents[1]/'WetterHimmel'
a=(p/'App.cpp').read_text();w=(p/'Web.cpp').read_text();s=(p/'Screen.cpp').read_text();html=(p/'WebPage.h').read_text();n=(p/'Network.cpp').read_text()
assert 'prefs.begin("wetterwelt", false)' in a and 'cfg.version = 2;' in a
assert 'cfg.view < 1 || cfg.view > 2' in a
assert 'if (v < 1 || v > 2)' in w
assert 'id="weather"' not in html and 'api.open-meteo.com' not in n
assert 'cfg.rotation == 3 ? 3 : 1' in a
assert '"cal" + String(cfg.rotation)' in s and '"cal0","cal2"' in s
assert 'sizeof cfg' in a
assert not any(token in a+n for token in ['prefs.clear(', 'nvs_flash_erase('])
font=(p/'UiFonts.h').read_text()
for c in 'äöüÄÖÜß°←↑→↓−✓…—': assert '{'+str(ord(c))+',' in font, c
print('PASS structural guards: two views, no weather endpoint, preserved namespace/schema/calibration, no settings erase, font glyph coverage')
