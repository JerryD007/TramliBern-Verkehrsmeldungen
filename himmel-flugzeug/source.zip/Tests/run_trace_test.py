from pathlib import Path
import tempfile,subprocess
r=Path(__file__).resolve().parents[1]
s='''#include <cassert>
#include <cstdint>
#include "RunTrace.h"
int main(){RunPoint a[2]{};assert(runNewest(a)==-1);
runStore(a,11,100,3);assert(runNewest(a)==0&&a[0].phase==11);
runStore(a,3,150,0);assert(runNewest(a)==1&&a[1].at==150);
// Simulate reset during incomplete write: keep last committed slot.
a[0].check=0;a[0].phase=7;assert(runNewest(a)==1);
runStore(a,9,200,0);assert(runNewest(a)==0&&a[0].phase==9);
a[0].at^=1;assert(runNewest(a)==1);
a[1].seq=0xffffffffu;a[1].check=runCheck(a[1]);runStore(a,12,250,0);assert(runNewest(a)==0&&a[0].seq==0);
}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'t.cpp').write_text(s);subprocess.run(['g++','-std=c++17','-I'+str(r/'WetterHimmel'),str(p/'t.cpp'),'-o',str(p/'t')],check=True);subprocess.run([str(p/'t')],check=True)
s=(r/'WetterHimmel/Screen.cpp').read_text();b=s[s.index('void uiRenderYield(){'):s.index('\n#endif',s.index('void uiRenderYield(){'))]
t='''#include <cassert>
#include <cstdint>
static bool renderActive=false,renderPolling=false;static unsigned renderPollAt=0,renderOps=0,now=100,polls=0;
unsigned millis(){return now;}
struct LCD{int depth=1;void endWrite(){assert(depth==1);--depth;}void startWrite(){assert(depth==0);++depth;}}lcd;
void uiPollTouch(){assert(lcd.depth==0);++polls;}
'''+b+'''\nint main(){for(int i=0;i<64;i++)uiRenderYield();assert(!polls);renderActive=true;for(int i=0;i<32;i++)uiRenderYield();assert(polls==1&&lcd.depth==1);for(int i=0;i<64;i++)uiRenderYield();assert(polls==1);now+=12;for(int i=0;i<32;i++)uiRenderYield();assert(polls==2);renderPolling=true;now+=100;for(int i=0;i<32;i++)uiRenderYield();assert(polls==2);}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'t.cpp').write_text(t);subprocess.run(['g++',str(p/'t.cpp'),'-o',str(p/'t')],check=True);subprocess.run([str(p/'t')],check=True)
assert 'void webServiceUi(){uiPollTouch();}' in s
print('PASS: committed RTC snapshots, corruption/interrupted write/sequence rollover; production render poll cadence and transaction release; no recursive web UI dispatch')
# Exercise boot persistence against the production implementation with simulated RTC/NVS.
body=(r/'WetterHimmel/RunTrace.cpp').read_text()
body='\n'.join(x for x in body.splitlines() if not x.startswith('#include'))
source='''#include <cassert>
#include <cstdint>
#include <cstring>
#include <vector>
#include "RunTrace.h"
#define RTC_NOINIT_ATTR
static unsigned now=0,reason=1,writes=0;static std::vector<unsigned char> stored;
uint32_t millis(){return now;}int esp_reset_reason(){return reason;}
struct Preferences{bool begin(const char*n,bool){assert(!strcmp(n,"hf-crash"));return true;}size_t getBytesLength(const char*){return stored.size();}size_t getBytes(const char*,void*p,size_t n){memcpy(p,stored.data(),n);return n;}size_t putBytes(const char*,const void*p,size_t n){stored.assign((const unsigned char*)p,(const unsigned char*)p+n);++writes;return n;}void end(){}};
struct JsonObject{struct Value{template<class T>Value&operator=(T){return *this;}template<class T>T to(){return T();}};Value operator[](const char*){return {};}};
'''+body+'''
int main(){runBegin();assert(!writes);now=100;runPhase(11,8);runWorker(23,9);now=150;runPhase(2);assert(longestPhase==1&&longestPhaseMs==100);runPhase(11,8);
reason=4;runBegin();assert(writes==1&&lastCrash.reason==4&&lastCrash.main.phase==11&&lastCrash.main.aux==8&&lastCrash.worker.aux==9);
// A later normal reboot must retain the last fault and avoid flash writes.
reason=1;lastCrash={};runBegin();assert(writes==1&&lastCrash.main.phase==11);
// No valid retained marker: do not replace a known fault with garbage.
memset(retained,0,sizeof retained);reason=4;runBegin();assert(writes==1&&lastCrash.main.phase==11);
}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'t.cpp').write_text(source);subprocess.run(['g++','-std=c++17','-I'+str(r/'WetterHimmel'),str(p/'t.cpp'),'-o',str(p/'t')],check=True);subprocess.run([str(p/'t')],check=True)
print('PASS: production boot capture persists fault once, normal reboot retains record, invalid RTC rejected; stage durations tracked')
