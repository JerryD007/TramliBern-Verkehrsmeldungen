from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
code=r'''
#include "RouteSchedule.h"
#include <cassert>
int main(){
 RouteSchedule s;
 assert(s.ready("OTHER1","abcdef",0));s.begin("OTHER1","abcdef",0);s.finish(false,1000);
 assert(!s.ready("SAS588","123456",29999));
 assert(s.ready("SAS588","123456",30000)); // another flight is not blocked five minutes
 assert(!s.ready("OTHER1","abcdef",30000));
 s.begin("SAS588","123456",30000);assert(!s.ready("NEW1","000001",90000));s.finish(true,32000);
 assert(!s.ready("SAS588","123456",151999));assert(s.ready("SAS588","123456",152000));
 assert(!s.ready("OTHER1","abcdef",300999));assert(s.ready("OTHER1","abcdef",301000));
 assert(s.ready("SAS588","654321",60000)); // ICAO is part of identity
 assert(s.ready("SAS589","123456",60000)); // callsign is part of identity
 RouteSchedule wrap;wrap.begin("SAS588","123456",0xfffff000u);wrap.finish(false,0xfffff100u);
 assert(!wrap.ready("SAS588","123456",0x10000u));assert(wrap.ready("SAS588","123456",0x60000u));
 assert(wrap.ready("SAS589","123456",0x10000u));
 // Eviction is bounded; even new identities cannot bypass the global spacing.
 RouteSchedule churn;for(unsigned i=0;i<20;i++){char call[17];snprintf(call,sizeof call,"FLT%u",i);unsigned now=i*30000;assert(churn.ready(call,"abcdef",now));churn.begin(call,"abcdef",now);churn.finish(false,now+100);assert(!churn.ready("NEXT1","123456",now+101));}
 static_assert(sizeof(RouteSchedule)<=160,"bounded RAM budget");
}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'test.cpp').write_text(code)
 subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror','-I'+str(root/'WetterHimmel'),str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
n=(root/'WetterHimmel/Network.cpp').read_text()
assert 'nextRoute' not in n
assert 'routeSchedule.ready(flight.callsign,flight.hex,now)' in n
assert 'if(r.kind==10||r.kind==11)' in n
assert 'time(nullptr)>=routeHoldUntil' in n
accepted=n[n.index('if (xQueueSend(jobs, &j, 0) == pdTRUE)'):]
assert 'routeSchedule.begin(j.callsign,j.hex,now)' in accepted
print('PASS: failed different flight does not delay SAS588, per-identity cooldown, global rate guard, pending job, wraparound, bounded eviction, queue acceptance and manual-result integration')
