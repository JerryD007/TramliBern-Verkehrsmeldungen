from pathlib import Path
import re
r=Path(__file__).resolve().parents[1]
old=(r/'Tests/fixtures/ui-fonts-original.h').read_text();new=(r/'WetterHimmel/UiFonts.h').read_text();count=0
for size,height in [(11,14),(14,17),(20,23),(46,49),(56,59)]:
 def load(s):
  bits=list(map(int,re.search(r'uiBits'+str(size)+r'\[\] PROGMEM = \{(.*?)\};',s)[1].split(',')))
  rows=[list(map(int,x.split(','))) for x in re.findall(r'\{([^}]+)\}',re.search(r'uiGlyphs'+str(size)+r'\[\] PROGMEM = \{(.*?)\};',s)[1])]
  return bits,rows
 a,aa=load(old);b,bb=load(new);assert len(aa)==len(bb)
 for x,y in zip(aa,bb):
  c,o,w,advance=x;cc,oo,ww,adv=y;assert (c,w,advance)==(cc,ww,adv)
  expected=[(a[o+i//2]>>(0 if i%2 else 4))&15 for i in range(w*height)]
  actual=[]
  while len(actual)<len(expected):
   token=b[oo];oo+=1;actual.extend([token&15]*((token>>4)+1))
  assert actual==expected,(size,c)
  count+=1
print('PASS: exact alpha pixels and metrics for',count,'glyphs across five fonts; no lossy image changes')
