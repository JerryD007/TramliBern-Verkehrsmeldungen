from pathlib import Path
import subprocess,tempfile
p=Path(__file__).resolve().parents[1]/'WetterHimmel'
s=(p/'App.cpp').read_text();functions=s[s.index('void uiDisplayBrightness()'):s.index('String message')]
code='''#include <algorithm>
#include <string>
#include <cassert>
#include <cstdio>
#include "NightPalette.h"
using std::min;bool displayAsleep=false;bool displayNight=false,dirty=false;
struct {int brightness=180;}cfg;
struct {bool autoNight=false;int dim=35;}extra;
struct {int brightness=0;void setBrightness(int b){brightness=b;}}lcd;
struct {bool saved=false;void putBool(const char *key,bool value){assert(std::string(key)=="nightDisplay");saved=value;}}prefs;
'''+functions+'''
int main(){uiDisplayBrightness();assert(lcd.brightness==180);
setDisplayNight(true);assert(displayNight&&prefs.saved&&dirty&&lcd.brightness==55&&cfg.brightness==180);
setDisplayNight(false);assert(!displayNight&&!prefs.saved&&lcd.brightness==180);
cfg.brightness=40;setDisplayNight(true);assert(lcd.brightness==40);
extra.autoNight=true;extra.dim=25;uiDisplayBrightness();assert(lcd.brightness==25);
assert(nightInk(0xffff,false)==0xffff&&nightInk(0,true)==0);auto c=nightInk(0xffff,true);assert(((c>>11)&31)==24&&((c>>5)&63)==0&&(c&31)==0);
puts("PASS: production display-night persistence and brightness cap; restores normal brightness; palette dimming leaves day colors unchanged.");}
'''
with tempfile.TemporaryDirectory() as td:
 f=Path(td)/'test.cpp';f.write_text(code);b=Path(td)/'test'
 subprocess.run(['g++','-std=c++17','-I'+str(p),str(f),'-o',str(b)],check=True);subprocess.run([str(b)],check=True)
