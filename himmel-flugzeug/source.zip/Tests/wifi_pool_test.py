from pathlib import Path
import tempfile,subprocess,re
r=Path(__file__).resolve().parents[1]
code='''#include "WiFiMemory.h"
#include <cassert>
struct Config{int static_tx_buf_num=16,dynamic_tx_buf_num=32,tx_buf_type=0,cache_tx_buf_num=4,static_rx_buf_num=10,dynamic_rx_buf_num=32,unchanged=42;};
int main(){Config c;configureWiFiMemory(c);assert(c.static_tx_buf_num==0&&c.dynamic_tx_buf_num==8&&c.tx_buf_type==1);assert(c.cache_tx_buf_num==4&&c.static_rx_buf_num==4&&c.dynamic_rx_buf_num==8&&c.unchanged==42);}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'t.cpp').write_text(code);subprocess.run(['g++','-I'+str(r/'WetterHimmel'),str(p/'t.cpp'),'-o',str(p/'t')],check=True);subprocess.run([str(p/'t')],check=True)
net=(r/'WetterHimmel/Network.cpp').read_text()
start=net.index('void netBegin()');assert net.index('esp_wifi_init(&wifiConfig)',start)<net.index('WiFi.mode(WIFI_AP_STA)',start)
assert 'WiFi.mode(WIFI_OFF)' not in net
sdk=(r/'Tests/fixtures/wifi-init-idf-b66b5448.c').read_text()
assert re.search(r'esp_err_t esp_wifi_init\(const wifi_init_config_t \*config\)\s*\{\s*if \(s_wifi_inited\) \{\s*return ESP_OK;',sdk)
print('PASS: production pool configuration, preinitialization order, no WiFi OFF path; pinned SDK duplicate initialization preserves configuration')
