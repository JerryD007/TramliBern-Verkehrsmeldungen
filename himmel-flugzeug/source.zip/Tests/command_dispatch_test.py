from pathlib import Path
import tempfile,subprocess
s=(Path(__file__).resolve().parents[1]/'WetterHimmel/Web.cpp').read_text()
a=s.index('bool applyCommand(');b=s.index('  if(a=="extras"',a)
production=s[a:b]+'return false;\n}\n'
code='''#include <string>
#include <cassert>
using String=std::string;
struct Value{String s;String operator|(const char*){return s;}};
struct JsonDocument{String action;Value operator[](const char*){return {action};}};
String dispatched;
bool modernCommand(JsonDocument &d,String &error){dispatched=d.action;error="handler reached";return true;}
'''+production+'''int main(){for(auto action:{"modern","wake","sleep","hangar","webRoute"}){JsonDocument d{action};String error;dispatched="";assert(applyCommand(d,error));assert(dispatched==action);assert(error=="handler reached");}JsonDocument d{"unknown"};String error;dispatched="";assert(!applyCommand(d,error));assert(dispatched.empty());}
'''
with tempfile.TemporaryDirectory() as t:
 p=Path(t);(p/'test.cpp').write_text(code);subprocess.run(['g++','-std=c++17',str(p/'test.cpp'),'-o',str(p/'test')],check=True);subprocess.run([str(p/'test')],check=True)
print('PASS production dispatcher: modern, wake, sleep, hangar, webRoute reach handler; unknown does not')
