from pathlib import Path
import tempfile,subprocess
p=Path(__file__).resolve().parents[1]/'WetterHimmel/Screen.cpp'
s=p.read_text();a=s.index('static int skyHitTarget');b=s.index('struct LabelBox',a)
code="""#include <cassert>
#include <cstdio>
int objectCount=9,hitCount=4;
int hitX[]={100,120,140,200},hitY[]={100,100,100,200},hitType[]={123,6,8,3000};
"""+s[a:b]+"""
int main(){assert(skyHitTarget(100,100)==6);assert(skyHitTarget(142,100)==8);
assert(skyHitTarget(225,200)==3000);assert(skyHitTarget(260,200)==-1);
hitCount=1;assert(skyHitTarget(100,100)==123);assert(skyHitTarget(116,100)==-1);
puts("PASS: nearby planet beats background star, nearest overlapping planet wins, satellite expanded target, empty map rejects tap.");}
"""
with tempfile.TemporaryDirectory() as t:
 f=Path(t)/'hit.cpp';f.write_text(code);binary=Path(t)/'hit';subprocess.run(['g++',str(f),'-o',str(binary)],check=True);subprocess.run([str(binary)],check=True)
