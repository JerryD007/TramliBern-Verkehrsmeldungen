from pathlib import Path
import subprocess,tempfile,os
p=Path(__file__).resolve().parents[1];t=p/'Tests';src=p/'WetterHimmel'
host=(t/'catalog_download_host.h').read_text()
app=(src/'App.h').read_text()
def struct(name):
 a=app.index('struct '+name+' {');return app[a:app.index('};',a)+2]
host=host.replace('struct Place{};struct Satellite{};',struct('Place')+'\n'+struct('Satellite'))
host=host.replace('uint32_t clockMs=0;', 'unsigned reads=0;uint32_t readCost=0;uint32_t clockMs=0;')
host=host.replace('size_t read(uint8_t*b,size_t n){','size_t read(uint8_t*b,size_t n){reads++;clockMs+=readCost;')
host=host.replace('time_t fixed=1794371042;', 'time_t fixed=1794371042+clockMs/1000;')
host+='''
uint32_t micros(){return clockMs*1000;}String eventStamp(time_t){return "";}String bearing(double){return "";}
#define sq(x) ((x)*(x))
#define DEG_TO_RAD (3.14159265358979323846/180)
#define RAD_TO_DEG (180/3.14159265358979323846)
#define pdPASS 1
struct Config {Place places[1]={{"Bern",46.948,7.447,540,""}};int place=0,view=1;bool starlink=true;}cfg;
constexpr int SAT_COUNT=4;Satellite satellites[4]{};uint32_t generation=1;
void resetStarlinkPrediction(){}
int xSemaphoreCreateMutex(){return 1;}
int xTaskCreatePinnedToCore(void(*)(void*),const char*,int,void*,int,void*,int){return pdPASS;}
struct Queue {size_t size;std::vector<uint8_t> data;};std::vector<Queue> queues(1);
int xQueueCreate(int,size_t size){queues.push_back({size,{}});return queues.size()-1;}
int xQueueSend(int q,const void*p,int){auto b=(const uint8_t*)p;queues[q].data.assign(b,b+queues[q].size);return pdTRUE;}
int xQueueOverwrite(int q,const void*p){return xQueueSend(q,p,0);}
struct EndScan{};
int xQueueReceive(int q,void*p,uint32_t wait){auto &v=queues[q];if(v.data.empty()){if(wait==portMAX_DELAY)throw EndScan{};return 0;}memcpy(p,v.data.data(),v.size);v.data.clear();return pdTRUE;}
'''
s='\n'.join(x for x in (src/'Starlink.cpp').read_text().splitlines() if not x.startswith('#include'))
satcode=(src/'Satellites.cpp').read_text();s+='\n'+satcode[satcode.index('static bool satPosition'):satcode.index('static int predictionSat')]+'\n'+satcode[satcode.index('bool satelliteFuture'):];
h=(src/'Starlink.h').read_text();h=h[h.index('struct StarlinkFetchTrace'):]
main=r'''
int main(int argc,char**argv){
 starlinkBegin();std::ifstream file(argv[1]);payload.assign(std::istreambuf_iterator<char>(file),{});declaredLength=payload.size();String error;int status;uint32_t retry;
 assert(starlinkDownload(error,status,retry));
 // Inject SD latency so the scan exceeds the former 15-second deadline.
 reads=0;readCost=50;Request req{cfg.places[0],generation};xQueueSend(requests,&req,0);pending=true;
 try{scanner(nullptr);}catch(EndScan&){}
 assert(reads<710);assert(clockMs>30000);assert(catalogStatus.sdReady);assert(catalogStatus.usable>11000);
 starlinkTick();auto &sat=satellites[3];assert(sat.valid);assert(sat.alt>=0);
 auto tle=sat.tle;double az,alt;assert(position(tle,time(nullptr),cfg.places[0],az,alt));assert(fabs(az-sat.az)<1e-8&&fabs(alt-sat.alt)<1e-8);
 // Selection remains usable >20 s after the scan, with current coordinates.
 double oldAz=sat.az;clockMs+=25000;starlinkTick();assert(sat.valid);tle=sat.tle;assert(position(tle,time(nullptr),cfg.places[0],az,alt));assert(fabs(az-sat.az)<1e-8&&fabs(alt-sat.alt)<1e-8);assert(fabs(oldAz-sat.az)>0.01);
 // Site changes invalidate old-site selection; stale queue answers cannot restore it.
 generation++;starlinkTick();assert(!sat.valid);
 // Buffered frame and ordinary single-position calculations agree.
 OmmElements orbit{};StarlinkCsv parser;std::ifstream csv(argv[1]);char ch;bool got=false;
 while(csv.get(ch)){int r=parser.feed(ch,orbit);if(r==1){got=true;break;}}
 // Position comparison uses the real selected orbit (including SGP4).
 tle=sat.tle;TLE second=tle;HorizonFrame frame(time(nullptr),cfg.places[0]);double a2,h2;
 assert(framedPosition(tle,time(nullptr),frame,az,alt));assert(position(second,time(nullptr),cfg.places[0],a2,h2));assert(fabs(az-a2)<1e-10&&fabs(alt-h2)<1e-10);
 sat.valid=true;auto before=sat;double fa,fh;time_t future=time(nullptr)+60;assert(satelliteFuture(3,future,fa,fh));tle=sat.tle;assert(position(tle,future,cfg.places[0],az,alt));assert(fabs(az-fa)<1e-8&&fabs(alt-fh)<1e-8);assert(memcmp(&before,&sat,sizeof sat)==0);assert(!satelliteFuture(-1,future,fa,fh));
 printf("PASS: future satellite propagation agrees with reference and does not mutate live state.\n");
 printf("PASS: 11199-record production scan, %u SD reads; simulated >30s scan yields current selection; live refresh beyond old 20s TTL; generation invalidation; frame equivalence.\n",reads);
}
'''
# CSV is exercised by the production downloader above; no separate parser API needed.
main=main[0:main.index(' OmmElements orbit{};')]+main[main.index(' // Position comparison'):]
with tempfile.TemporaryDirectory() as tmp:
 d=Path(tmp);(d/'host.h').write_text(host);code=d/'test.cpp';code.write_text('#include "host.h"\n#include "Visibility.h"\n#include "StarlinkSelection.h"\n#include "StarlinkCsv.h"\n'+h+'\n'+s+'\n'+main)
 objs=[]
 for f in [*src.glob('src/sgp4/*.c'),src/'src/astro/astronomy.c']:
  o=d/(f.stem+'.o');subprocess.run(['gcc','-O2','-c',str(f),'-o',str(o)],check=True);objs.append(str(o))
 dep=os.environ['ARDUINOJSON_INCLUDE']
 subprocess.run(['g++','-std=c++17','-O2','-I'+str(t),'-I'+str(src),'-I'+dep,str(code),*objs,'-lm','-o',str(d/'scan')],check=True)
 subprocess.run([str(d/'scan'),str(p/'Startkatalog/Starlink_2026-11-11.csv')],check=True)
