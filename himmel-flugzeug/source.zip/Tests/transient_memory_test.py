from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[1]
code=r'''#include "TransientBuffer.h"
#include <cassert>
#include <cstdlib>
static bool fail=false;static int live=0;
void* operator new[](std::size_t n,const std::nothrow_t&) noexcept {if(fail)return nullptr;return std::malloc(n);}
void operator delete[](void*p) noexcept {std::free(p);}
void operator delete[](void*p,std::size_t) noexcept {std::free(p);}
struct Record {char bytes[128];Record(){++live;}~Record(){--live;}};
void scan(bool early){TransientBuffer<Record,32> w;assert(w);assert(live==32);w.get()[31].bytes[127]=1;if(early)return;assert(w.get()[31].bytes[127]==1);}
int main(){for(int i=0;i<100;i++){scan(i%2);assert(live==0);}fail=true;{TransientBuffer<Record,32> w;assert(!w);assert(live==0);}fail=false;scan(false);assert(live==0);}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'test.cpp').write_text(code)
 subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror','-I'+str(root/'WetterHimmel'),str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
s=(root/'WetterHimmel/Starlink.cpp').read_text();n=(root/'WetterHimmel/Network.cpp').read_text()
assert 'Record block[8]' in s and 'uint32_t candidates[16]' in s
assert 'scan.reset();xQueueOverwrite' in s
assert '(hangarBusy()||starlinkScanning())?0:pdMS_TO_TICKS(20)' in n
print('PASS: transient buffer cleanup plus bounded scan storage contract')
