#include "../WetterHimmel/JsonObjectStream.h"
#include <cassert>
#include <string>
#include <cstdio>
int run(const std::string &s,int &objects){JsonObjectStream p;objects=0;for(char c:s){int r=p.feed(c);if(r<0)return -1;if(r==1)objects++;}return p.ended?1:0;}
int main(){int n;assert(run("[{\"a\":\"}\\\"{\"},{\"b\":{\"x\":2}}]",n)==1&&n==2);assert(run("[{\"a\":1}",n)==0);assert(run("[{},]",n)==-1);assert(run("[{}{}]",n)==-1);assert(run("["+std::string(5000,'{'),n)==-1);std::string s="[";for(int i=0;i<11201;i++){if(i)s+=",";s+="{\"NORAD_CAT_ID\":123456,\"OBJECT_NAME\":\"STARLINK-TEST\"}";}s+="]";assert(run(s,n)==1&&n==11201);printf("PASS: bounded framing of 11201 objects, quoted braces, truncation, overflow, malformed separators; parser bytes=%zu\n",sizeof(JsonObjectStream));}
