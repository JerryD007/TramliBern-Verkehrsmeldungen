#include <stdio.h>
#include <math.h>
#include <assert.h>
#include "../WetterHimmel/src/astro/astronomy.h"
#include "../WetterHimmel/src/sgp4/TLE.h"
int main(){
 astro_time_t t=Astronomy_MakeTime(2026,11,9,13,51,54);astro_observer_t obs=Astronomy_MakeObserver(46.948,7.4474,0);
 astro_equatorial_t e=Astronomy_Equator(BODY_SUN,&t,obs,EQUATOR_OF_DATE,ABERRATION);astro_horizon_t h=Astronomy_Horizon(&t,obs,e.ra,e.dec,REFRACTION_NORMAL);
 printf("Sun az %.9f alt %.9f\n",h.azimuth,h.altitude);assert(fabs(h.azimuth-219.45016595479035)<(1.0/60));assert(fabs(h.altitude-16.964746561204194)<(1.0/60));
 astro_time_t epoch=Astronomy_TimeFromDays(0);assert(fabs(epoch.ut)<1e-9);
 TLE tle={0};char l1[]="1 00005U 58002B   00179.78495062  .00000023  00000-0  28098-4 0  4753";char l2[]="2 00005  34.2682 348.7242 1859667 331.7664  19.3264 10.82419157413667";
 parseLines(&tle,l1,l2);double r[3],v[3];getRV(&tle,0,r,v);printf("SGP4 r %.8f %.8f %.8f; epoch %lld\n",r[0],r[1],r[2],(long long)tle.epoch);assert(tle.epoch>900000000000LL);assert(!tle.sgp4Error);assert(fabs(r[0]-7022.46529266)<0.0001);assert(fabs(r[1]+1400.08296755)<0.0001);assert(fabs(r[2]-0.03995155)<0.0001);
 puts("PASS: API comparison, epoch conversion and Vallado SGP4 reference");return 0;}
