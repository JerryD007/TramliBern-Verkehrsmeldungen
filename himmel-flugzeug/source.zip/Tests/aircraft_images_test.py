from pathlib import Path
import subprocess,tempfile,json
r=Path(__file__).resolve().parents[1]
source='''#include <cassert>
#include <cstdint>
#include "AircraftImages.h"
struct Painter {
 unsigned pixels=0,calls=0;
 void drawFastHLine(int x,int y,int n,uint16_t){
  assert(x>=8&&x+n<=218&&n>0&&y>=80&&y<146);pixels+=n;++calls;
 }
};
int main(){
 for(unsigned p=0;p<28;++p)for(unsigned l=0;l<9;++l){
  Painter painter;int i=AircraftImages::select(p,l);
  assert(AircraftImages::draw(painter,p,l,8,80)==(i>=0));
  assert(painter.pixels==(i>=0?210*66:0));
 }
 for(const auto&s:AircraftImages::sprites){
  assert(s.size>32);unsigned x=0,y=0;
  for(unsigned a=32;a<s.size;++a){
   x+=(s.data[a]>>4)+1;assert(x<=210);if(x==210){x=0;++y;}}
  assert(x==0&&y==66);
 }
 assert(AircraftImages::select(2,1)==0);
 assert(AircraftImages::select(4,1)==-1);
 assert(AircraftImages::select(13,4)==3);
 assert(AircraftImages::select(7,6)==5);
}
'''
with tempfile.TemporaryDirectory() as t:
 p=Path(t);(p/'test.cpp').write_text(source)
 subprocess.run(['g++','-std=c++17','-I'+str(r/'WetterHimmel'),str(p/'test.cpp'),str(r/'WetterHimmel/AircraftImages.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
 js=(r/'Web/aircraft-art.js').read_text()+'\n'+(r/'Web/aircraft-images.js').read_text()+'''\nconst assert=require('node:assert/strict');
const cases=[['A320','SWR123',0],['A20N','EZS94TH',1],['A320','DLH12',2],['B789','KLM12',3],['B788','BAW12',4],['A388','UAE12',5],['EC45','RGA10',6]];
for(const [type,callsign,id] of cases){const l=AircraftArt.scheme(callsign);assert.equal(AircraftImages.select(AircraftArt.resolve(type,false,true),l),id);assert(AircraftImages.html({type,callsign}).includes('data-aircraft-image='));}
for(const f of [{type:'A333',callsign:'SWR123'},{type:'ZZZZ',callsign:'SWR123'},{type:'A320',callsign:'SWR123',airline:'Lufthansa'},{type:'A320',callsign:'HBJRH'},{type:'A320',callsign:'SWRABC'}])assert(!AircraftImages.html(f).includes('data-aircraft-image='));
assert(!AircraftImages.html({type:'<script>',callsign:'<img onerror=evil()>'}).includes('onerror'));
'''
 import re
 packets=[list(map(int,body.split(','))) for body in re.findall(r'data\d+\[\]=\{([^}]+)\}',(r/'WetterHimmel/AircraftImages.cpp').read_text())]
 js+='\nfor(const p of '+json.dumps(packets)+'){assert.equal(AircraftImages.decode(Uint8Array.from(p)).length,210*66*4);assert.throws(()=>AircraftImages.decode(Uint8Array.from(p.slice(0,-1))))};assert.throws(()=>AircraftImages.decode(new Uint8Array(33)));'
 (p/'test.cjs').write_text(js);subprocess.run(['node',str(p/'test.cjs')],check=True)
h=(r/'WetterHimmel/AircraftImages.h').read_text()
assert all(x not in h for x in ['malloc(','new ','String ','HTTP','SD.'])
web=(r/'Web/preview.html').read_text();assert (r/'Web/aircraft-images.js').read_text() in web
print('PASS: all 7 sprites; 252 profile/livery combinations; bounds, row integrity, fallback, JS/C++ matching, no dynamic allocation or fetch in renderer')
