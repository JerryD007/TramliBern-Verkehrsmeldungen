from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1]
s=(r/'WetterHimmel/Astronomy.cpp').read_text();body=s[s.index('void starHorizontal('):s.index('void skyUpdate(')]
code=r'''
#include "astronomy.h"
#include <math.h>
#include <assert.h>
#include <stdio.h>
static astro_time_t at;static astro_rotation_t horizon;
'''+body+r'''
int main(){double worst=0;unsigned count=0;
for(double days: {0.,5000.,9800.,10000.})for(double lat:{-80.,-30.,0.,46.948,80.})for(double lon:{-120.,7.4474,150.}){
 at=Astronomy_TimeFromDays(days);auto obs=Astronomy_MakeObserver(lat,lon,540);horizon=Astronomy_Rotation_EQJ_HOR(&at,obs);auto pre=Astronomy_Rotation_EQJ_EQD(&at);
 for(double ra=0;ra<24;ra+=.4)for(double dec=-85;dec<90;dec+=7){
  double az,alt;starHorizontal(ra,dec,az,alt);
  astro_spherical_t sphere{ASTRO_SUCCESS,dec,ra*15,1};auto v=Astronomy_RotateVector(pre,Astronomy_VectorFromSphere(sphere,at));auto eq=Astronomy_EquatorFromVector(v);auto h=Astronomy_Horizon(&at,obs,eq.ra,eq.dec,REFRACTION_NORMAL);
  double da=fabs(az-h.azimuth);if(da>180)da=360-da;double dh=fabs(alt-h.altitude);worst=fmax(worst,fmax(da,dh));assert(da<1e-7&&dh<1e-7);++count;
 }
}printf("PASS %u positions; maximum difference %.12g degrees; original refraction preserved\n",count,worst);}
'''
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);(p/'test.cpp').write_text('#include <initializer_list>\n'+code)
 subprocess.run(['gcc','-O2','-c',str(r/'WetterHimmel/src/astro/astronomy.c'),'-o',str(p/'astro.o')],check=True)
 subprocess.run(['g++','-std=c++17','-O2','-I'+str(r/'WetterHimmel/src/astro'),str(p/'test.cpp'),str(p/'astro.o'),'-lm','-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
