"""Compile and exercise the actual WLAN control functions with a fake radio/clock."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
s=(root/'WetterHimmel/Network.cpp').read_text()
functions=s[s.index('void scanStart()'):s.index('bool saveWifi(')]
tick=s[s.index('void netTick()'):s.index('  Result *receivedResult=',s.index('void netTick()'))]+'}\n'
pre=r'''
#include <cassert>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <iostream>
class String: public std::string {public:using std::string::string;String()=default;String(const std::string&s):std::string(s){} String(int n):std::string(std::to_string(n)){} bool isEmpty()const{return empty();}};
constexpr int WL_CONNECTED=3,WIFI_SCAN_FAILED=-2;
uint32_t clockMs=0;uint32_t millis(){return clockMs;}
struct WifiProfile{char ssid[33],pass[65];};
struct{int wifiCount=2;WifiProfile wifi[6]={{"Home","password1"},{"Hotspot","password2"}};}cfg;
struct FakeWifi{
 int state=0,scans=0,disconnects=0,scanResult=-1;String name;std::vector<String> attempts;
 void disconnect(bool,bool){++disconnects;state=0;}
 void begin(const char*s,const char*){attempts.emplace_back(s);name=s;}
 int status(){return state;}String SSID(){return name;}String SSID(int){return "Found network";}
 void scanDelete(){}int scanNetworks(bool,bool){++scans;return -1;}int scanComplete(){return scanResult;}
}WiFi;
void esp_wifi_scan_stop(){}void saveSettings(){}
String message,nearby[20];int nearbyCount=0,attempt=-1;
uint32_t scanAt=0,attemptAt=0,nextAircraft=0;
bool starlinkImportBusy(){return false;}
bool dirty=false,scanRunning=false,scanRequested=false,beginPending=false,disconnectPending=false,wasConnected=false,busy=false;
'''
checks=r'''
void at(uint32_t t){clockMs=t;netTick();}
int main(){
 connectProfile(0);assert(WiFi.disconnects==0);at(499);assert(WiFi.disconnects==0);
 at(500);assert(WiFi.disconnects==1);at(649);assert(WiFi.attempts.empty());at(650);assert(WiFi.attempts.back()=="Home");
 // Failure rotates to second profile after 30s, not after 20s+30s.
 at(30649);assert(WiFi.attempts.size()==1);at(30650);assert(beginPending);at(31150);at(31300);assert(WiFi.attempts.back()=="Hotspot");
 WiFi.state=WL_CONNECTED;at(32000);assert(std::string(cfg.wifi[0].ssid)=="Hotspot");
 auto calls=WiFi.attempts.size();at(100000);at(200000);assert(WiFi.attempts.size()==calls);assert(WiFi.scans==0);
 // Lost connection: retry last working profile, never interrupt an HTTPS job.
 WiFi.state=0;at(201000);busy=true;at(231000);assert(!beginPending);busy=false;at(231001);assert(beginPending);at(231501);at(231651);assert(WiFi.attempts.back()=="Hotspot");
 // An explicit scan waits for data worker; does not automatically choose a network.
 WiFi.state=WL_CONNECTED;at(232000);busy=true;scanStart();at(232500);assert(WiFi.scans==0);busy=false;at(232501);assert(WiFi.scans==1&&scanRunning);WiFi.scanResult=1;at(232502);assert(!scanRunning&&nearbyCount==1);
 calls=WiFi.attempts.size();at(500000);assert(WiFi.scans==1&&WiFi.attempts.size()==calls);
 // Idle setup mode remains quiet. No periodic channel scans without saved networks.
 cfg.wifiCount=0;WiFi.state=0;at(500001);at(700000);assert(WiFi.scans==1&&WiFi.attempts.size()==calls);
 // Unsigned elapsed calculation survives millis rollover.
 cfg.wifiCount=1;clockMs=UINT32_MAX-100;attemptAt=clockMs;attempt=-1;wasConnected=false;
 at(29898);assert(!beginPending);at(29899);assert(beginPending);
 std::cout<<"PASS: Praha round-robin, saved preferred network, 30s retry, HTTPS/scan exclusion, no periodic scans, delayed web acknowledgement, timer wrap.\n";
}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'test.cpp').write_text(pre+functions+tick+checks)
 subprocess.run(['g++','-std=c++17',str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
