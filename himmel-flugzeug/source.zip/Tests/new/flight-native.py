from pathlib import Path
import subprocess,os
r=Path(__file__).resolve().parents[2]/'WetterHimmel'
s=(r/'Modern.cpp').read_text();part=s[s.index('static double directionTo'):s.index('bool priorityActive()')]
h=(r/'Modern.h').read_text();types=h[h.index('struct Flight'):h.index('extern ModernSettings')]
cpp='''#include <ArduinoJson.h>
#include "../../WetterHimmel/Airframe.h"
#include <cmath>
#include <cstring>
#include <cassert>
#include <iostream>
using namespace std;
#define DEG_TO_RAD (M_PI/180)
#define RAD_TO_DEG (180/M_PI)
#define sq(x) ((x)*(x))
template<class T>T constrain(T x,T a,T b){return min(b,max(a,x));}
struct Place{double lat,lon;};
'''+types+part+'''
int main(){Place p{0,0};Flight f;JsonDocument d;
assert(!parseFlight(d,f,p,50,false,1800000000));
d["now"]=1800000000;auto ac=d["ac"].to<JsonArray>();
auto a=ac.add<JsonObject>();a["lat"]=.1;a["lon"]=.1;a["seen_pos"]=5;a["alt_baro"]=30000;a["track"]=225;a["gs"]=400;a["flight"]="TEST1 ";
assert(parseFlight(d,f,p,50,true,1800000000));assert(f.found&&f.approaching&&f.positionAt==1799999995);assert(abs(f.altitude-9144)<.01);assert(abs(f.speed-740.8)<.1);assert(string(f.callsign)=="TEST1");
a["track"]=45;assert(parseFlight(d,f,p,50,true,1800000000)&&!f.found);assert(parseFlight(d,f,p,50,false,1800000000)&&f.found);
a["seen_pos"]=100;assert(parseFlight(d,f,p,50,false,1800000000)&&!f.found);
a["seen_pos"]=1;a["alt_baro"]="ground";assert(parseFlight(d,f,p,50,false,1800000000)&&!f.found);
a["alt_baro"]=1000;a["lat"]=30;assert(parseFlight(d,f,p,50,false,1800000000)&&!f.found);
d["now"]=1799990000;assert(!parseFlight(d,f,p,50,false,1800000000));
d["now"]=1800000000;a["lat"]=.1;a["track"]=225;a["category"]="A7";a["desc"]="HELICOPTER";assert(parseFlight(d,f,p,50,false,1800000000)&&f.rotorcraft);assert(string(f.description)=="HELICOPTER");
a["category"]="A3";assert(parseFlight(d,f,p,50,false,1800000000)&&!f.rotorcraft);assert(airframeCategory(f.category)==Airframe::FixedWing);
a["category"]="A77";assert(parseFlight(d,f,p,50,false,1800000000)&&!f.rotorcraft&&airframeCategory(f.category)==Airframe::Unknown);
a.remove("category");assert(parseFlight(d,f,p,50,false,1800000000)&&!f.rotorcraft);assert(airframeCategory(f.category)==Airframe::Unknown);
for(const char *c:{"","A0","B1","A77","C1"})assert(airframeCategory(c)==Airframe::Unknown);
a["category"]="A7";auto b=ac.add<JsonObject>();b["lat"]=.01;b["lon"]=.01;b["seen_pos"]=2;b["alt_baro"]=1000;b["category"]="A3";assert(parseFlight(d,f,p,50,false,1800000000)&&!f.rotorcraft&&f.description[0]==0);
cout<<"PASS flight selection, approach geometry, age, units, radius, ground filtering, source clock, rotorcraft classification, unknown categories, no metadata leakage\\n";
}
'''
out=Path(__file__).parent; (out/'flight-native.cpp').write_text(cpp)
subprocess.run(['g++','-std=c++17','-I'+os.environ.get('ARDUINOJSON_INCLUDE','/home/agent/Arduino/libraries/ArduinoJson/src'),str(out/'flight-native.cpp'),'-o',str(out/'flight-native')],check=True)
subprocess.run([str(out/'flight-native')],check=True)
