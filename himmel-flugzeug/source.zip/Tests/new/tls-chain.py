from pathlib import Path
import subprocess,re,struct,hashlib,tempfile
from cryptography import x509
from cryptography.hazmat.primitives import serialization
r=Path(__file__).resolve().parents[2]
ca=x509.load_pem_x509_certificate((r/'Tests/fixtures/gtsr4.pem').read_bytes())
assert hashlib.sha256(ca.public_bytes(serialization.Encoding.DER)).hexdigest()=='349dfa4058c5e263123b398ae795573c4e1313c83fe68f93556cd5e8031b3c7d'
chain=re.findall(b'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----',(r/'Tests/fixtures/adsb-chain.pem').read_bytes(),re.S)
certs=[x509.load_pem_x509_certificate(c) for c in chain]
b=bytes(map(int,re.search(r'\{(.*?)\}',(r/'WetterHimmel/Certificates.h').read_text()).group(1).split(',')))
names=[]
for i in range(struct.unpack_from('<I',b)[0]//4):
 o=struct.unpack_from('<I',b,i*4)[0];l,k=struct.unpack_from('<HH',b,o);assert o+4+l+k<=len(b);names.append(b[o+4:o+4+l])
assert names==sorted(names)
assert certs[1].issuer.public_bytes() in names
assert certs[-1].issuer.public_bytes() not in names
# Legacy bundle callback reaches untrusted GlobalSign above trusted GTS R4.
# Normal chain building can terminate at the explicit trusted GTS R4.
with tempfile.TemporaryDirectory() as td:
 p=Path(td);(p/'leaf.pem').write_bytes(chain[0]);(p/'chain.pem').write_bytes(b'\n'.join(chain[1:]));(p/'root.pem').write_bytes((r/'Tests/fixtures/gtsr4.pem').read_bytes())
 def verify(host,t):return subprocess.run(['openssl','verify','-no-CAfile','-no-CApath','-no-CAstore','-attime',str(t),'-verify_hostname',host,'-trusted',str(p/'root.pem'),'-untrusted',str(p/'chain.pem'),str(p/'leaf.pem')],capture_output=True,text=True).returncode
 assert verify('opendata.adsb.fi',1795031061)==0
 assert verify('wrong.example',1795031061)!=0
 assert verify('opendata.adsb.fi',2200000000)!=0
src=(r/'WetterHimmel/Network.cpp').read_text();assert 'setInsecure(' not in src and 'useAircraftRoot()' in src
print('PASS actual captured cross-signed chain, official root fingerprint, strict hostname/date rejection; legacy terminal issuer absent from bundle')
