from pathlib import Path
import os,subprocess
from PIL import Image
r=Path(__file__).resolve().parents[2];p=r/'WetterHimmel';out=Path(__file__).parent
host=(r/'Tests/render/host.h').read_text().replace('x<320&&y>=0&&y<480','x<480&&y>=0&&y<320').replace('y*320+x','y*480+x').replace('0,0,320,480','0,0,480,320').replace('320 480','480 320').replace('int(yy/zy)*320','int(yy/zy)*480').replace('pixels[yy*320+xx]','pixels[yy*480+xx]')
host=host.replace('quantized=bits==8;', 'depth=bits;quantized=bits==8;').replace('uint16_t palette[16]', 'int depth=4;uint16_t palette[16]').replace('if(fakeAllocationFailure)return nullptr;', 'if(fakeAllocationFailure || (fakeLargeFailure && w*h*depth/8>12544))return nullptr;').replace('static bool fakeAllocationFailure=false;', 'static bool fakeAllocationFailure=false,fakeLargeFailure=false;')
host=host.replace('void drawEllipse(','''void fillTriangle(int x,int y,int u,int v,int a,int b,uint16_t c){
 auto edge=[](int ax,int ay,int bx,int by,int px,int py){return (px-ax)*(by-ay)-(py-ay)*(bx-ax);};
 for(int yy=min(y,min(v,b));yy<=max(y,max(v,b));yy++)for(int xx=min(x,min(u,a));xx<=max(x,max(u,a));xx++){
 int e1=edge(x,y,u,v,xx,yy),e2=edge(u,v,a,b,xx,yy),e3=edge(a,b,x,y,xx,yy);if((e1>=0&&e2>=0&&e3>=0)||(e1<=0&&e2<=0&&e3<=0))drawPixel(xx,yy,c);}}
void drawEllipse(''')
host=host.replace('public:int writes=0;', 'public:int maxFillArea=0;int writes=0;').replace('int h,uint16_t c){for(int i=0;i<h;i++)drawFastHLine', 'int h,uint16_t c){maxFillArea=max(maxFillArea,w*h);for(int i=0;i<h;i++)drawFastHLine')
host=host.replace('public:int maxFillArea=0;', 'public:int clipW=480,clipH=320;int maxFillArea=0;').replace('x<480&&y>=0&&y<320','x<clipW&&y>=0&&y<clipH')
host=host.replace('void *createSprite(int,int)', 'void *createSprite(int w,int h)').replace('allocated=true;spriteAllocations++;', 'clipW=w;clipH=h;allocated=true;spriteAllocations++;')
host=host.replace('int edge=lround(224*zx);', 'int edge=lround(clipW*zx),height=lround(clipH*zy);').replace('yy<edge;yy++', 'yy<height;yy++').replace('cy-edge/2+yy', 'cy-height/2+yy')
(out/'render-host.h').write_text(host)
s=(p/'Screen.cpp').read_text();parts=[s[:s.index('void keyboard(')],s[s.index('static void back()'):s.index('static const char *letters[]')],s[s.index('struct UiButton'):s.index('static void detailScreen')]]
s='\n'.join(parts)
ext=(p/'Extras.cpp').read_text();s+='\n'+ext[ext.index('bool objectCoordinates('):ext.index('static bool extraFromJson')]
for h in ['App.h','Modern.h','Starlink.h']:s=s.replace('#include "'+h+'"','')
# actual shared structures and drawing functions; only device/clock/network simulated
mh=(p/'Modern.h').read_text();flight=mh[mh.index('struct Flight'):mh.index('extern ModernSettings')]
app=(p/'App.cpp').read_text();helpers=app[app.index('String stamp('):app.index('void saveSettings()')]
a=(p/'Astronomy.cpp').read_text().replace('#include "App.h"','').replace('#include "Starlink.h"','')
pre='#include \"RadarDisplay.h\"\nRadarDisplay radarDisplay;\n#include "render-host.h"\n#include "Airframe.h"\n#include "FlightRoute.h"\n'+flight+'''\nFlight flight;FlightRoute flightRoute;struct ModernPreview{bool aircraft=true,approaching=false;int radius=50;}modern;bool freshFlight=true;bool flightFresh(){return freshFlight;}
'''
# Render the actual TFT hangar functions with a simulated asynchronous data source.
s += '\n#include "HangarModel.h"\n#include "HangarRoute.h"\n' + r"""
static uint32_t surfaceRevision=0;
static unsigned fakeHangarState=3,fakeHangarRevision=1;static String fakeHangarError;
static Hangar::Record fakeRows[12];static HangarRoute::Record fakeRoute;
uint32_t hangarRevision(){return fakeHangarRevision;}
unsigned hangarDisplayState(){return fakeHangarState;}
bool hangarRequest(JsonVariantConst,String&){++fakeHangarRevision;fakeHangarState=3;return true;}
bool hangarDisplayRow(unsigned i,Hangar::Record&r,unsigned&size,unsigned&total,bool&more,String&error){if(fakeHangarState!=3)return false;size=12;total=107;more=true;error=fakeHangarError;if(i<12)r=fakeRows[i];return true;}
bool hangarDisplayRouteResult(HangarRoute::Record&r,String&e){if(fakeHangarState!=6)return false;r=fakeRoute;e=fakeHangarError;return true;}
"""
whole=(p/'Screen.cpp').read_text()
s+=whole[whole.index('static uint32_t hangarScreenRevision'):whole.index('static void menuScreen()')]
body='''
int main(){setenv("TZ","CET-1CEST,M3.5.0,M10.5.0/3",1);tzset();
strcpy(cfg.places[0].name,"Bern");cfg.places[0].lat=46.948;cfg.places[0].lon=7.4474;cfg.places[0].height=540;
const char*names[]={"ISS","Tiangong","Hubble","Starlink"};for(int i=0;i<4;i++)strcpy(satellites[i].name,names[i]);cfg.view=1;skyUpdate();
lcd.fillScreen(0);header();skyScreen(true);nav();lcd.save("himmel.ppm");
lcd.writes=0;skyScreen(false);assert(lcd.writes==0);
auto before=lcd.pixels;uiNetworkMemory(true);generation++;lcd.writes=0;skyScreen(false);assert(lcd.writes==0&&before==lcd.pixels);uiNetworkMemory(false);skyScreen(false);assert(skyPixelsReady);
for(int i=0;i<hitCount;i++)assert(hitScreenX(i)>=128&&hitScreenX(i)<352&&hitScreenY(i)>=34&&hitScreenY(i)<258);
extra.largeMap=true;skyScreen(false);lcd.save("himmel_gross.ppm");for(int i=0;i<hitCount;i++)assert(hitScreenX(i)>=118&&hitScreenX(i)<362&&hitScreenY(i)>=34&&hitScreenY(i)<278);extra.largeMap=false;skyScreen(false);
auto fullColors=lcd.pixels;auto fullHits=hitCount;
uiNetworkMemory(true);uiNetworkMemory(false);fakeLargeFailure=true;skyScreen(false);assert(skyPixelsReady&&uiDiag.bits==4&&uiDiag.fallbacks>=1&&uiDiag.pixelBytes==12544);assert(lcd.pixels==fullColors&&hitCount==fullHits);lcd.save("himmel_fallback.ppm");
extra.largeMap=true;skyScreen(false);auto largeStrips=lcd.pixels;uiNetworkMemory(true);uiNetworkMemory(false);fakeLargeFailure=false;skyScreen(false);assert(lcd.pixels==largeStrips&&uiDiag.pixelBytes==12544);extra.largeMap=false;skyScreen(false);
// Synthetic colored objects on both halves, satellites above horizon and visible.
objectCount=4;for(int i=0;i<4;i++){objects[i].az=i*90;objects[i].alt=45;objects[i].color=i%2?0xF800:0xFFE0;objects[i].kind=i+2;strcpy(objects[i].name,"Color");}
for(int i=0;i<4;i++){satellites[i].valid=true;satellites[i].epoch=time(nullptr);satellites[i].visibilityAt=time(nullptr);satellites[i].visibility=i%2?5:4;satellites[i].az=i*90+45;satellites[i].alt=40;}
generation++;skyScreen(false);auto coloredFull=lcd.pixels;uiNetworkMemory(true);uiNetworkMemory(false);fakeLargeFailure=true;skyScreen(false);assert(lcd.pixels==coloredFull);puts("PASS: 16-color strips are stable across releases pixel-for-pixel at normal and large scale; colored objects on both halves; identical hit targets; 12544 pixel bytes");
uiNetworkMemory(true);uiNetworkMemory(false);fakeAllocationFailure=true;auto retained=lcd.pixels;skyScreen(false);assert(!skyPixelsReady&&mapDeferred&&retained==lcd.pixels);fakeAllocationFailure=fakeLargeFailure=false;skyScreen(false);assert(skyPixelsReady&&uiDiag.bits==4);
puts("PASS: fixed map workspace, chart retained during TLS, unchanged map zero pixel writes, landscape hit bounds");
cfg.view=2;flight.checked=flight.found=true;flight.received=time(nullptr);flight.positionAt=time(nullptr);strcpy(flight.callsign,"SWR123");strcpy(flight.hex,"abc123");JsonDocument routeDoc;std::ifstream routeFile("../fixtures/route-ryr39kv.json");assert(!deserializeJson(routeDoc,routeFile));routeDoc["callsign"]="SWR123";assert(parseRoute(routeDoc,flightRoute,flight.callsign,flight.hex,time(nullptr)));strcpy(flightRoute.originName,"Zürich");strcpy(flightRoute.destinationName,"Praha");strcpy(flightRoute.origin,"ZRH");strcpy(flightRoute.destination,"PRG");strcpy(flight.type,"A320");strcpy(flight.category,"A3");flight.distance=12.4;flight.azimuth=45;flight.track=225;flight.altitude=3240;flight.speed=420;
lcd.fillScreen(0);header();flightScreen(true);nav();lcd.save("flugzeug.ppm");
strcpy(flight.type,"B744");flightScreen(false);lcd.save("boeing747.ppm");lcd.writes=0;flightScreen(false);assert(lcd.writes==0);strcpy(flight.type,"A320");flightScreen(false);
lcd.writes=0;flightScreen(false);assert(lcd.writes==0);
// Changing only speed must not erase the illustration, route, or compass.
auto previous=lcd.pixels;flight.speed=430;lcd.writes=0;flightScreen(false);assert(lcd.writes>0&&lcd.writes<12000);for(int y=34;y<216;y++)for(int x=0;x<480;x++)assert(lcd.pixels[y*480+x]==previous[y*480+x]);
strcpy(flight.callsign,"HELI DEMO");strcpy(flight.type,"EC35");strcpy(flight.category,"A7");flight.rotorcraft=true;flight.received++;flight.altitude=1450;flight.speed=185;lcd.fillScreen(0);header();flightScreen(true);nav();lcd.save("helikopter.ppm");puts("PASS: fixed-wing and rotorcraft drawn from production functions; unchanged flight zero writes");
for(unsigned i=0;i<12;i++){auto&r=fakeRows[i];strcpy(r.hex,"abcdef");strcpy(r.registration,"HB-TEST");snprintf(r.callsign,sizeof r.callsign,"TEST%u",i+1);strcpy(r.type,"A320");r.passes=i+1;r.first=time(nullptr)-86400;r.last=time(nullptr)-i*30;}
RadarDisplay bounded;for(int i=40;i>0;--i){RadarDot d;d.distance=i;bounded.add(d);}assert(bounded.count==16&&bounded.total==40&&bounded.dots[0].distance==1&&bounded.dots[15].distance==16);static_assert(sizeof(RadarDisplay)<1400,"Bounded radar budget");
page=15;radarDisplay.radius=50;radarDisplay.generation=generation;radarSelectionGeneration=generation;radarDisplay.revision=1;radarDisplay.received=time(nullptr);for(int i=0;i<4;i++){RadarDot d;strcpy(d.hex,i==0?"abcdef":"123456");strcpy(d.callsign,"TEST123");d.distance=10+i*8;d.azimuth=i*90;d.track=45+i*60;d.positionAt=time(nullptr)-12;d.rotorcraft=i==2;radarDisplay.add(d);}strcpy(radarSelected,"abcdef");lcd.fillScreen(0);header();radarScreen();assert(radarLastSelected.positionAt!=0);assert(radarX(radarDisplay.dots[0])==136&&radarY(radarDisplay.dots[0])<169);lcd.save("radar_display.ppm");
lcd.writes=0;radarScreen(false);assert(lcd.writes==0);
radarDisplay.received-=5;auto radarPixels=lcd.pixels;lcd.writes=0;radarScreen(false);assert(lcd.writes>0&&lcd.writes<8000);for(int y=34;y<294;y++)for(int x=0;x<265;x++)assert(lcd.pixels[y*480+x]==radarPixels[y*480+x]);
radarDisplay.revision++;radarDisplay.dots[0].azimuth=20;lcd.writes=0;lcd.maxFillArea=0;radarScreen(false);assert(lcd.writes>0&&lcd.maxFillArea<5000);
for(int v=5;v<=200;v++){assert(radarNextRadius(v,1)>=v&&radarNextRadius(v,1)<=200);assert(radarNextRadius(v,-1)<=v&&radarNextRadius(v,-1)>=5);}assert(radarNextRadius(50,1)==75&&radarNextRadius(50,-1)==25);
modern.radius=100;generation++;radarScreen(false);radarDisplay.radius=100;radarDisplay.generation=generation;radarDisplay.revision++;radarScreen(false);lcd.save("radar_range.ppm");
puts("PASS: unchanged radar zero writes; age update leaves chart pixels intact; frame update bounded; range steps bounded 5..200 and pending/new frame rendered");

requestHangarScreen();buttonCount=0;lcd.fillScreen(0);header();hangarScreen();lcd.save("hangar_display.ppm");assert(buttonCount==7);for(int i=0;i<buttonCount;i++)assert(buttons[i].y+buttons[i].h<=266);
hangarScreenOffset=9;buttonCount=0;lcd.fillScreen(0);hangarScreen();assert(buttonCount==7);
hangarSelectedRow=fakeRows[0];page=14;fakeHangarState=6;strcpy(fakeRoute.origin,"ZRH");strcpy(fakeRoute.destination,"LHR");strcpy(fakeRoute.originName,"Zürich");strcpy(fakeRoute.destinationName,"London");strcpy(fakeRoute.airline,"SWISS");buttonCount=0;lcd.fillScreen(0);header();hangarScreen();lcd.save("hangar_detail.ppm");assert(buttonCount==2);
fakeHangarError="SD nicht bereit";page=13;fakeHangarState=3;buttonCount=0;lcd.fillScreen(0);hangarScreen();assert(buttonCount==2);fakeHangarError="";fakeHangarRevision++;buttonCount=0;hangarScreen();assert(buttonCount==2);
puts("PASS: production TFT hangar list/detail rendering, three-row pagination, SD error and superseded query show no stale row controls");
}
'''
(out/'render-preview.cpp').write_text(pre+helpers+'\n'+a+'\n'+s+body)
subprocess.run(['gcc','-O2','-c',str(p/'src/astro/astronomy.c'),'-o',str(out/'astro.o')],check=True)
subprocess.run(['g++','-std=c++17','-O2','-I'+str(p),'-I'+os.environ.get('ARDUINOJSON_INCLUDE',str(Path.home()/'Arduino/libraries/ArduinoJson/src')),str(out/'render-preview.cpp'),str(p/'AircraftImages.cpp'),str(out/'astro.o'),'-lm','-o',str(out/'render-preview')],check=True)
subprocess.run([str(out/'render-preview')],cwd=out,check=True)
for name in ['himmel','himmel_gross','himmel_fallback','flugzeug','helikopter','hangar_display','hangar_detail','radar_display','radar_range','boeing747']:Image.open(out/(name+'.ppm')).save(out/(name+'.png'))
