from pathlib import Path
import subprocess
from PIL import Image
r=Path(__file__).resolve().parents[2];p=r/'WetterHimmel';out=Path(__file__).parent
host=(r/'Tests/render/host.h').read_text().replace('x<320&&y>=0&&y<480','x<480&&y>=0&&y<320').replace('y*320+x','y*480+x').replace('0,0,320,480','0,0,480,320').replace('320 480','480 320').replace('int(yy/zy)*320','int(yy/zy)*480').replace('pixels[yy*320+xx]','pixels[yy*480+xx]')
host=host.replace('void drawEllipse(','''void fillTriangle(int x,int y,int u,int v,int a,int b,uint16_t c){
 auto edge=[](int ax,int ay,int bx,int by,int px,int py){return (px-ax)*(by-ay)-(py-ay)*(bx-ax);};
 for(int yy=min(y,min(v,b));yy<=max(y,max(v,b));yy++)for(int xx=min(x,min(u,a));xx<=max(x,max(u,a));xx++){
 int e1=edge(x,y,u,v,xx,yy),e2=edge(u,v,a,b,xx,yy),e3=edge(a,b,x,y,xx,yy);if((e1>=0&&e2>=0&&e3>=0)||(e1<=0&&e2<=0&&e3<=0))drawPixel(xx,yy,c);}}
void drawEllipse(''')
(out/'render-host.h').write_text(host)
s=(p/'Screen.cpp').read_text();parts=[s[:s.index('void keyboard(')],s[s.index('static void back()'):s.index('static const char *letters[]')],s[s.index('struct UiButton'):s.index('static void detailScreen')]]
s='\n'.join(parts)
ext=(p/'Extras.cpp').read_text();s+='\n'+ext[ext.index('bool objectCoordinates('):ext.index('static bool extraFromJson')]
for h in ['App.h','Modern.h','Starlink.h']:s=s.replace('#include "'+h+'"','')
# actual shared structures and drawing functions; only device/clock/network simulated
mh=(p/'Modern.h').read_text();flight=mh[mh.index('struct Flight'):mh.index('extern ModernSettings')]
app=(p/'App.cpp').read_text();helpers=app[app.index('String stamp('):app.index('void saveSettings()')]
a=(p/'Astronomy.cpp').read_text().replace('#include "App.h"','').replace('#include "Starlink.h"','')
pre='#include "render-host.h"\n#include "Airframe.h"\n'+flight+'''\nFlight flight;struct ModernPreview{bool aircraft=true,approaching=false;int radius=50;}modern;bool freshFlight=true;bool flightFresh(){return freshFlight;}
'''
body='''
int main(){setenv("TZ","CET-1CEST,M3.5.0,M10.5.0/3",1);tzset();
strcpy(cfg.places[0].name,"Bern");cfg.places[0].lat=46.948;cfg.places[0].lon=7.4474;cfg.places[0].height=540;
const char*names[]={"ISS","Tiangong","Hubble","Starlink"};for(int i=0;i<4;i++)strcpy(satellites[i].name,names[i]);cfg.view=1;skyUpdate();
lcd.fillScreen(0);header();skyScreen(true);nav();lcd.save("himmel.ppm");
lcd.writes=0;skyScreen(false);assert(lcd.writes==0);
auto before=lcd.pixels;uiNetworkMemory(true);generation++;lcd.writes=0;skyScreen(false);assert(lcd.writes==0&&before==lcd.pixels);uiNetworkMemory(false);skyScreen(false);assert(skyPixelsReady);
for(int i=0;i<hitCount;i++)assert(hitX[i]>=128&&hitX[i]<352&&hitY[i]>=34&&hitY[i]<258);
extra.largeMap=true;skyScreen(false);lcd.save("himmel_gross.ppm");for(int i=0;i<hitCount;i++)assert(hitX[i]>=118&&hitX[i]<362&&hitY[i]>=34&&hitY[i]<278);extra.largeMap=false;skyScreen(false);
puts("PASS: fixed map workspace, chart retained during TLS, unchanged map zero pixel writes, landscape hit bounds");
cfg.view=2;flight.checked=flight.found=true;flight.received=time(nullptr);flight.positionAt=time(nullptr);strcpy(flight.callsign,"SWR123");strcpy(flight.type,"A320");strcpy(flight.category,"A3");flight.distance=12.4;flight.azimuth=45;flight.track=225;flight.altitude=3240;flight.speed=420;
lcd.fillScreen(0);header();flightScreen(true);nav();lcd.save("flugzeug.ppm");lcd.writes=0;flightScreen(false);assert(lcd.writes==0);
// Changing only speed must not erase the illustration, route, or compass.
auto previous=lcd.pixels;flight.speed=430;lcd.writes=0;flightScreen(false);assert(lcd.writes>0&&lcd.writes<12000);for(int y=34;y<216;y++)for(int x=0;x<480;x++)assert(lcd.pixels[y*480+x]==previous[y*480+x]);
strcpy(flight.callsign,"HELI DEMO");strcpy(flight.type,"EC35");strcpy(flight.category,"A7");flight.rotorcraft=true;flight.received++;flight.altitude=1450;flight.speed=185;lcd.fillScreen(0);header();flightScreen(true);nav();lcd.save("helikopter.ppm");puts("PASS: fixed-wing and rotorcraft drawn from production functions; unchanged flight zero writes");
}
'''
(out/'render-preview.cpp').write_text(pre+helpers+'\n'+a+'\n'+s+body)
subprocess.run(['gcc','-O2','-c',str(p/'src/astro/astronomy.c'),'-o',str(out/'astro.o')],check=True)
subprocess.run(['g++','-std=c++17','-O2','-I'+str(p),str(out/'render-preview.cpp'),str(out/'astro.o'),'-lm','-o',str(out/'render-preview')],check=True)
subprocess.run([str(out/'render-preview')],cwd=out,check=True)
for name in ['himmel','himmel_gross','flugzeug','helikopter']:Image.open(out/(name+'.ppm')).save(out/(name+'.png'))
