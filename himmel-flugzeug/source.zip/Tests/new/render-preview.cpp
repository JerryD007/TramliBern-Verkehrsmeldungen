#include "RadarDisplay.h"
RadarDisplay radarDisplay;
#include "render-host.h"
#include "Airframe.h"
#include "FlightRoute.h"
struct Flight {
 bool checked=false,found=false,approaching=false;
 char category[3]={},description[65]={};
 bool rotorcraft=false;
 char callsign[17]={},type[17]={},hex[9]={},error[96]={};
 float distance=NAN,altitude=NAN,speed=NAN,track=NAN,azimuth=NAN;
 time_t received=0,positionAt=0;
};

Flight flight;FlightRoute flightRoute;struct ModernPreview{bool aircraft=true,approaching=false;int radius=50;}modern;bool freshFlight=true;bool flightFresh(){return freshFlight;}
String stamp(time_t t, bool date) {
  if (t < 1)
    return "--:--";
  struct tm tm;
  localtime_r(&t, &tm);
  char b[40];
  strftime(b, sizeof b, date ? "%d.%m.%Y %H:%M" : "%H:%M", &tm);
  return b;
}
String eventStamp(time_t t) {
  if (!clockReady() || t < 1) return "—";
  struct tm a{}, b{}; time_t now=time(nullptr);
  localtime_r(&now,&a);localtime_r(&t,&b);
  if(a.tm_year==b.tm_year && a.tm_yday==b.tm_yday) return "heute "+stamp(t);
  char date[12];strftime(date,sizeof date,"%d.%m.",&b);
  return String(date)+" "+stamp(t);
}
String bearing(double a) {
  if(!isfinite(a))return "—";
  a=fmod(a+360,360);
  const char *n[] = {"N", "NO", "O", "SO", "S", "SW", "W", "NW"};
  return n[(int)floor((a + 22.5) / 45) % 8];
}


static astro_time_t at;
static astro_rotation_t horizon;
static astro_observer_t observer() {
  auto &p = cfg.places[cfg.place];
  return Astronomy_MakeObserver(p.lat, p.lon, p.height);
}
static astro_time_t astroTime(time_t t) {
  return Astronomy_TimeFromDays((double)t / 86400.0 - 10957.5);
}
bool project(double az, double alt, int &x, int &y) {
  if (!isfinite(az) || !isfinite(alt) || alt < 0 || alt > 90)
    return false;
  double r = (90 - alt) / 90 * 108;
  x = 160 - lround(r * sin(az * DEG_TO_RAD));
  y = 174 - lround(r * cos(az * DEG_TO_RAD));
  return true;
}
void starHorizontal(double ra, double dec, double &az, double &alt) {
  astro_spherical_t s{ASTRO_SUCCESS, dec, ra * 15, 1};
  auto v = Astronomy_RotateVector(horizon, Astronomy_VectorFromSphere(s, at));
  auto h = Astronomy_HorizonFromVector(v, REFRACTION_NORMAL);
  az = h.lon;
  alt = h.lat;
}
void skyUpdate() {
  if (!clockReady())
    return;
  at = astroTime(viewTime());
  horizon = Astronomy_Rotation_EQJ_HOR(&at, observer());
  objectCount = 0;
  const astro_body_t bodies[] = {BODY_SUN,     BODY_MOON,   BODY_MERCURY, BODY_VENUS,  BODY_MARS,
                                 BODY_JUPITER, BODY_SATURN, BODY_URANUS,  BODY_NEPTUNE};
  const char *names[] = {"Sonne",   "Mond",   "Merkur", "Venus", "Mars",
                         "Jupiter", "Saturn", "Uranus", "Neptun"};
  const uint16_t colors[] = {0xFFE0, 0xFFFF, 0xBDF7, 0xFFBB, 0xFA60,
                             0xFD20, 0xEED0, 0x07FF, 0x441F};
  for (int i = 0; i < 9; i++) {
#ifndef UI_HOST_PREVIEW
    uiPollTouch();
#endif
    auto eq = Astronomy_Equator(bodies[i], &at, observer(), EQUATOR_OF_DATE, ABERRATION);
    if (eq.status != ASTRO_SUCCESS)
      continue;
    auto h = Astronomy_Horizon(&at, observer(), eq.ra, eq.dec, REFRACTION_NORMAL);
    auto &o = objects[objectCount++];
    strlcpy(o.name, names[i], 36);
    o.az = h.azimuth;
    o.alt = h.altitude;
    o.color = colors[i];
    o.kind = i;
    auto illum = Astronomy_Illumination(bodies[i], at);
    o.mag = illum.mag;
    if (i == 0) {
      sunAlt = o.alt;
      o.x = o.y = 0;
    } else if (i > 1) {
      auto e = Astronomy_Ecliptic(Astronomy_HelioVector(bodies[i], at));
      o.x = e.elon;
      o.y = 0;
    }
  }
  auto m = Astronomy_MoonPhase(at);
  moonPhase = m.angle;
  auto rise = Astronomy_SearchRiseSet(BODY_SUN, observer(), DIRECTION_RISE, at, 2);
#ifndef UI_HOST_PREVIEW
  uiPollTouch();
#endif
  auto set = Astronomy_SearchRiseSet(BODY_SUN, observer(), DIRECTION_SET, at, 2);
  sunrise = rise.status == ASTRO_SUCCESS ? (time_t)((rise.time.ut + 10957.5) * 86400) : 0;
  sunset = set.status == ASTRO_SUCCESS ? (time_t)((set.time.ut + 10957.5) * 86400) : 0;
}



#ifndef UI_HOST_PREVIEW
#include "Extras.h"
#endif

#include "Catalog.h"
#include "UiFonts.h"
#include "Paint.h"
#include "AircraftArt.h"
#include "AircraftImages.h"
#include "UiDiagnostics.h"
UiDiagnostics uiDiag;
#ifndef UI_HOST_PREVIEW
#include <esp_heap_caps.h>
#include <esp_memory_utils.h>
#endif
#include "Gesture.h"
#include "Visibility.h"
#include "StarNames.h"
static Paint paint(lcd);
#ifndef UI_DIRECT_PREVIEW
static LGFX_Sprite skyBuffer(&lcd);
// Two 224x112 strips reuse 12544 pixel bytes; allocated only when needed.
static bool skyPixelsReady=false;
static int skyBufferHeight=224;
static uint32_t mapRetryAt=0;
static bool skyBufferReady=false;
static bool networkOwnsMemory=false;
static bool mapDeferred=false;
#endif
// Called exclusively by the main loop, before publishing a network job.
void uiNetworkMemory(bool active) {
#ifndef UI_DIRECT_PREVIEW
  networkOwnsMemory=active;
  if(active && skyPixelsReady) {
    // Main-loop ownership: no render can be in progress when the job is queued.
    // The LCD retains its pixels; only the off-screen workspace is released.
    skyBuffer.deleteSprite();
    ++uiDiag.releases;
    skyPixelsReady=false;
    mapDeferred=true;
  }
  if(!active && mapDeferred) {mapRetryAt=millis();dirty=true;}
#endif
}
static const uint16_t bg = 0x0000, blue = 0x0248, white = 0xFFFF, muted = 0xBDF7, cyan = 0x07FF;
static String input, title, wifiName;
static int purpose = 0, keyLayout = 0, networkPage = 0, profile = 0;
static bool shifted = false, held = false, showPassword = false;
static Place draft{};
static int editPlace = -1;
// Map lies inside x=118..361, y=34..277, including the large-map mode.
// Packed, aligned 32-bit accesses allow IRAM storage on classic ESP32.
// Volatile enforces full-word loads/stores even when extracting one byte.
// Do not access this allocation through byte/halfword pointers.
#ifdef UI_HOST_PREVIEW
static uint32_t hitStore[1100];static volatile uint32_t *hitData=hitStore;
#else
static volatile uint32_t *hitData=nullptr;
#endif
static int hitScreenX(int i){return int(hitData[i]&255)+112;}
static int hitScreenY(int i){return int((hitData[i]>>8)&255)+24;}
static int hitObject(int i){return int(hitData[i]>>16);}
static int hitCount=0;
static String objectQuery;static int objectOffset=0,objectChoices[6],objectMatches=0;
static float mapScale(){return extra.largeMap?244.0f/224.0f:1.0f;}
static int mapCenterY(){return extra.largeMap?156:146;}
static int labelBackground=-1;
static uint16_t textBackground(int,int){return labelBackground>=0?uint16_t(labelBackground):bg;}
// Embedded UTF-8 font subset: independent of the limited built-in fonts.
static uint16_t nextCode(const String &s, unsigned &i) {
  uint8_t c = s[i++];
  if (c < 128) return c;
  uint16_t v = c & (c < 224 ? 31 : 15);
  int n = c < 224 ? 1 : 2;
  while (n-- && i < s.length()) v = (v << 6) | (s[i++] & 63);
  return v;
}
static const UiGlyph *glyph(const UiFont &f, uint16_t c) {
  for (unsigned j = 0; j < f.count; j++) if (f.glyphs[j].code == c) return &f.glyphs[j];
  for (unsigned j = 0; j < f.count; j++) if (f.glyphs[j].code == '?') return &f.glyphs[j];
  return &f.glyphs[0];
}
static int width(String s, const UiFont &f = uiFont14) {
  int w = 0; unsigned i = 0;
  while (i < s.length()) w += glyph(f, nextCode(s, i))->advance;
  return w;
}
static void label(String s, int x, int y, const UiFont &f, uint16_t col) {
  unsigned i = 0;
  while (i < s.length()) {
    auto g = glyph(f, nextCode(s, i));
    for(int yy=0;yy<f.height;yy++) for(int xx=0;xx<g->width;xx++) {
      int b=yy*g->width+xx; uint8_t packed=f.bits[g->offset+b/2];
      int alpha=b%2?packed&15:packed>>4;if(!alpha)continue;
      uint16_t back=textBackground(x+xx,y+yy);
      int rr=(((col>>11)&31)*alpha+((back>>11)&31)*(15-alpha))/15;
      int gg=(((col>>5)&63)*alpha+((back>>5)&63)*(15-alpha))/15;
      int bb=((col&31)*alpha+(back&31)*(15-alpha))/15;
      paint.drawPixel(x+xx,y+yy,(rr<<11)|(gg<<5)|bb);
    }
    x += g->advance;
  }
}
static void label(String s,int x,int y,const UiFont &f,uint16_t col,int limit){
 while(s.length()&&width(s,f)>limit){unsigned i=s.length()-1;while(i&&((uint8_t)s[i]&0xc0)==0x80)--i;s.remove(i);}
 label(s,x,y,f,col);
}
static void text(String s, int x, int y, int size = 1, uint16_t col = white) {
  label(s, x, y, size == 2 ? uiFont20 : uiFont14, col);
}
static uint16_t rgb(int r, int g, int b) { return ((r & 248) << 8) | ((g & 252) << 3) | (b >> 3); }
static void gradient(int y, int h, int r, int g, int b, int rr, int gg, int bb) {
  for (int i=0;i<h;i++) paint.drawFastHLine(0,y+i,320,rgb(r+(rr-r)*i/h,g+(gg-g)*i/h,b+(bb-b)*i/h));
}
static void button(String s, int x, int y, int w, int h, uint16_t col = 0x0124) {
  paint.fillRoundRect(x,y,w,h,7,col);
  paint.drawRoundRect(x,y,w,h,7,col == blue ? cyan : 0x4A69);
  const UiFont &f = width(s) <= w-10 ? uiFont14 : uiFont11;
  int previous=labelBackground;labelBackground=col;
  label(s,x+(w-width(s,f))/2,y+(h-f.height)/2,f,white);labelBackground=previous;
}
// Shaded RGB565 spheres. No large framebuffer or PSRAM required.
static void sphere(int cx,int cy,int r,int kind) {
  const int colors[][3]={{255,213,50},{196,202,218},{146,146,158},{236,196,126},{220,101,65},{216,171,121},{217,197,147},{113,216,225},{66,121,228},{40,148,225}};
  kind=constrain(kind,0,9);
  for (int y=-r;y<=r;y++) for (int x=-r;x<=r;x++) {
    float d=float(x*x+y*y)/(r*r); if(d>1) continue;
    float z=sqrtf(1-d), light=0.27f+0.73f*max(0.0f,(-0.4f*x-0.55f*y)/r+0.75f*z);
    if(kind==0) light=0.82f+0.18f*z;
    float band=1;
    if(kind==5 || kind==6) band=0.82f+0.18f*sinf(y*1.1f);
    int red=colors[kind][0], green=colors[kind][1], blueC=colors[kind][2];
    if(kind==9 && sinf(x*0.9f+y*0.5f)+cosf(y*1.2f-x*0.3f)>0.9f) {red=68;green=181;blueC=117;}
    if(kind==1) band=0.83f+0.17f*sinf(x*1.8f+y)*sinf(y*1.6f);
    paint.drawPixel(cx+x,cy+y,rgb(red*light*band,green*light*band,blueC*light*band));
  }
}
static void glowSun(int x,int y,int r) {
  for(int k=r+9;k>r;k--) paint.drawCircle(x,y,k,rgb(35+(r+9-k)*8,25+(r+9-k)*5,20));
  sphere(x,y,r,0);
}

static void back(){button("ZURÜCK",8,280,464,36,0x2104);}
static void header(){
 paint.fillRect(0,0,480,34,bg);labelBackground=bg;
 label((page==13||page==14)?"Mein Hangar":page==15?"Radar":page?"Menü":cfg.view==1?"Himmel":"Flugzeug",8,6,uiFont20,white,205);
 label(String(cfg.places[cfg.place].name),225,6,uiFont20,white,112);
 label(stamp(time(nullptr)),350,6,uiFont20,white,85);
 for(int yy=9;yy<=23;yy+=7)paint.drawFastHLine(445,yy,24,cyan);
 paint.drawFastHLine(8,33,464,cyan);labelBackground=-1;
}
static void nav(){} // Main views use swipe or the menu; space belongs to satellite data.
static bool projectMap(double az,double alt,int &x,int &y){
  if(!project(az,alt,x,y))return false;
  skyCamera.transform(x,y);return true;
}
static void addHit(int x, int y, int type) {
  if (hitData && hitCount < 1100 && skyCamera.contains(x,y)) {
    uint32_t x8=uint8_t(lround(240+(x-160)*mapScale())-112);
    uint32_t y8=uint8_t(lround(mapCenterY()+(y-174)*mapScale())-24);
    hitData[hitCount++]=(uint32_t(type)<<16)|(y8<<8)|x8;
  }
}
// Prefer nearby planets/satellites to the dense background star field.
static int skyHitTarget(int x,int y) {
  int best=-1,bestDistance=0,bestPriority=-1;
  for(int i=0;i<hitCount;i++) {
    bool primary=(hitObject(i)>=0&&hitObject(i)<objectCount)||hitObject(i)>=3000;
    int radius=primary?26:15,dx=x-hitScreenX(i),dy=y-hitScreenY(i),distance=dx*dx+dy*dy;
    int priority=primary?1:0;
    if(distance<=radius*radius && (priority>bestPriority || (priority==bestPriority&&distance<bestDistance))) {
      best=hitObject(i);bestDistance=distance;bestPriority=priority;
    }
  }
  return best;
}
struct LabelBox {int x,y,w,h;};
static LabelBox labelBoxes[24];
static int labelCount=0;
static bool mapLabel(String name,int x,int y,uint16_t color) {
  int w=width(name,uiFont11), h=14;
  const int dx[]={14,14,-14,-14,0,0},dy[]={-19,10,-19,10,-29,18};
  for(int k=0;k<6;k++) {
    int xx=k==4||k==5?x-w/2:k>=2?x-w+dx[k]:x+dx[k], yy=y+dy[k];
    if(xx<48||xx+w>272||yy<78||yy+h>272) continue;
    bool free=true;
    for(int j=0;j<labelCount;j++) {auto b=labelBoxes[j]; if(xx<b.x+b.w+3&&xx+w+3>b.x&&yy<b.y+b.h+3&&yy+h+3>b.y) free=false;}
    // Keep labels away from every solar-system marker, even those drawn later.
    for(int j=0;j<objectCount;j++) {int u,v; if(projectMap(objects[j].az,objects[j].alt,u,v)&&u>xx-13&&u<xx+w+13&&v>yy-10&&v<yy+h+10) free=false;}
    if(free && labelCount<24) {labelBoxes[labelCount++]={xx,yy,w,h};paint.fillRoundRect(xx-2,yy-1,w+4,h+2,2,0x0843);label(name,xx,yy,uiFont11,color);return true;}
  }
  return false;
}
static void moonIcon(int cx,int cy,int r) {
  double a=moonPhase*DEG_TO_RAD;
  for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++) {
    double xx=(double)x/r,yy=(double)y/r,z2=1-xx*xx-yy*yy;
    if(z2<0)continue;
    double light=xx*sin(a)-sqrt(z2)*cos(a);
    int v=light>0?190+int(50*sqrt(z2)):46;
    paint.drawPixel(cx+x,cy+y,rgb(v,v,v+min(9,255-v)));
  }
}
static void satelliteIcon(int x,int y,int kind) {
  paint.drawLine(x-18,y,x+18,y,0xBDF7);
  if(kind==2) {
    paint.fillRoundRect(x-10,y-5,22,10,3,0xBDF7);
    paint.fillCircle(x-10,y,5,0x4208);paint.drawCircle(x-10,y,5,white);
    paint.fillRect(x-3,y-15,10,8,0x2C9B);paint.fillRect(x-3,y+7,10,8,0x2C9B);
  } else {
    paint.fillRoundRect(x-4,y-7,8,14,2,0xD6BA);
    for(int side=-1;side<=1;side+=2) {
      int xx=x+(side<0?-21:8);paint.fillRect(xx,y-11,13,22,0x1B57);
      paint.drawRect(xx,y-11,13,22,0x75DF);
      for(int k=1;k<4;k++)paint.drawFastHLine(xx,y-11+k*5,13,0x4C9D);
      paint.drawFastVLine(xx+6,y-11,22,0x4C9D);
    }
  }
}
static void satelliteCards(){
 const char *names[]={"ISS","Tiangong","Hubble","Starlink"};
 const time_t now=time(nullptr);
 for(int i=0;i<4;i++){
  auto &sat=satellites[i];bool fresh=satellitePositionCurrent(sat,clockReady(),now);
  bool visible=satelliteCandidateSeconds(sat,clockReady(),now)>0;
  int x=i*120;uint16_t c=fresh?(visible?0xFFE0:sat.alt>=0?0x97F2:cyan):muted;
  paint.fillRect(x,258,120,62,bg);paint.drawFastVLine(x,260,58,muted);
  label(names[i],x+7,260,uiFont14,c);
  String line="Daten veraltet",position="Keine Position";
  if(fresh){
   position=bearing(sat.az)+" "+String(sat.alt,0)+"°";
   if(sat.alt>=0)line=visible?"Sichtchance*":"Über Horizont";
   else if(sat.rise>now&&sat.set>now){long m=(sat.rise-now+59)/60;line=m<60?"In "+String(m)+" min":"In "+String(m/60)+"h "+String(m%60)+"m";}
   else line="Berechnung ...";
  }
  label(line,x+7,282,uiFont11,c);label(position,x+7,300,uiFont11,muted);
 }
}
static void sampleChartTouch() {
#ifndef UI_HOST_PREVIEW
  lcd.endWrite();uiPollTouch();lcd.startWrite();
#endif
}
static void skyScreen(bool full=true) {
  static uint64_t lastMap=0;
  static String lastCards;static bool wasLarge=false;
  if(extra.largeMap!=wasLarge){full=true;wasLarge=extra.largeMap;}
  if(full) {paint.fillRect(0,34,480,246,bg);button("+",420,65,52,42);button("-",420,113,52,42);button("1×",420,161,52,42);button("Objekte",4,75,114,36);button("Favoriten",4,119,114,36);}
  uint64_t mapKey=(uint64_t)(clockReady()?time(nullptr)/30:0);
  mapKey=mapKey*31+skyCamera.revision;mapKey=mapKey*31+displayNight;
  mapKey=mapKey*31+generation;mapKey=mapKey*31+objectCount;
  mapKey=mapKey*31+(cfg.labels|cfg.lines<<1|cfg.milky<<2|cfg.satellites<<3|cfg.starlink<<4);
  String cards=String(clockReady())+":"+String((long)(time(nullptr)/60));
  for(int i=0;i<SAT_COUNT;i++) {
    auto &sat=satellites[i];bool fresh=satellitePositionCurrent(sat,clockReady(),time(nullptr));
    int x=0,y=0;
    if(fresh && cfg.satellites && (i<3 || cfg.starlink) && projectMap(sat.az,sat.alt,x,y)) {mapKey=mapKey*31+x;mapKey=mapKey*31+y;}
    bool sight=satelliteCandidateSeconds(sat,clockReady(),time(nullptr))>0;
    mapKey=mapKey*31+sight;cards+=String(sight);
    cards+=String(fresh)+":"+bearing(sat.az)+":"+String(sat.alt,0)+":"+String(sat.alt>=0)+":"+stamp(sat.rise)+":"+String(sat.valid);
  }
  if(!extra.largeMap && (full || cards!=lastCards)) {satelliteCards();lastCards=cards;}
#ifndef UI_DIRECT_PREVIEW
  // Preserve the displayed chart while HTTPS owns the temporary workspace.
  bool deferred=mapDeferred;
#else
  bool deferred=false;
#endif
  mapKey=mapKey*31+(highlightedObject+1);mapKey=mapKey*31+extra.trails;mapKey=mapKey*31+extra.largeMap;
  if(!full && !deferred && mapKey==lastMap)return;
  lastMap=mapKey;
  if (!clockReady()) {
    label("Warte auf Uhrzeit",136,125,uiFont11,muted);label("über WLAN / NTP",136,145,uiFont11,muted);
    return;
  }
#ifndef UI_DIRECT_PREVIEW
  if(!networkOwnsMemory) {
#ifndef UI_HOST_PREVIEW
    if(!hitData)hitData=(uint32_t*)heap_caps_malloc(1100*sizeof(uint32_t),MALLOC_CAP_EXEC|MALLOC_CAP_32BIT);
    if(!hitData)hitData=(uint32_t*)heap_caps_malloc(1100*sizeof(uint32_t),MALLOC_CAP_32BIT);
    uiDiag.hitBytes=hitData?4400:0;uiDiag.hitIram=hitData&&esp_ptr_in_iram((const void*)hitData);
#endif
    if(!skyBufferReady)skyBufferReady=skyBuffer.createPalette(skyPalette,16);
    if(skyBufferReady && !skyPixelsReady) {
      ++uiDiag.attempts;uiDiag.bits=4;skyBufferHeight=112;skyBuffer.setColorDepth(4);
      skyPixelsReady=skyBuffer.createSprite(224,skyBufferHeight)!=nullptr;
      if(skyPixelsReady)++uiDiag.fallbacks;
      else {++uiDiag.failures;uiDiag.lastFailureMs=millis();}

    }
  }
  if(networkOwnsMemory || !skyBufferReady || !skyPixelsReady) {
    mapDeferred=true;
    mapRetryAt=millis()+1000;
    // Do not destroy an existing chart on a temporary allocation failure.
    if(full) {hitCount=0;label(networkOwnsMemory?"Karte nach Datenabruf":"Warte auf Speicher",136,140,uiFont11,muted);}
    return;
  }
  mapDeferred=false;uiDiag.pixelBytes=224*skyBufferHeight/2;
  for(unsigned i=0;i<16;i++)skyBuffer.setPaletteColor(i,nightInk(skyPalette[i],displayNight));
  for(int stripY=0;stripY<224;stripY+=skyBufferHeight) {
  paint.targetAt(skyBuffer,48,62+stripY,true);
#endif
  labelCount=0; hitCount=0;
  // Prepare the complete map off-screen. Never clear the displayed map first.
  for(int y=62;y<286;y++)paint.drawFastHLine(48,y,224,textBackground(48,y));
  int cx=160,cy=174;skyCamera.transform(cx,cy);
  paint.drawCircle(cx,cy,lround(108*skyCamera.zoom),0x8CFA);
  int compassX[]={155,155,54,252},compassY[]={68,265,167,167};const char* compass[]={"N","S","O","W"};
  for(int i=0;i<4;i++){skyCamera.transform(compassX[i],compassY[i]);if(skyCamera.contains(compassX[i],compassY[i]))text(compass[i],compassX[i],compassY[i]);}
  hitCount = 0;
  if (cfg.milky) {
    int px = -1, py = -1;
    for (int latitude = -10; latitude <= 10; latitude += 2) {
    sampleChartTouch();
    px=-1;py=-1;
    for (int i = 0; i <= 360; i += 3) {
      astro_spherical_t s{ASTRO_SUCCESS, (double)latitude, (double)i, 1};
      auto t = Astronomy_TimeFromDays((double)viewTime() / 86400 - 10957.5);
      auto eq = Astronomy_EquatorFromVector(
          Astronomy_RotateVector(Astronomy_Rotation_GAL_EQJ(), Astronomy_VectorFromSphere(s, t)));
      double a, h;
      starHorizontal(eq.ra, eq.dec, a, h);
      int x, y;
      if (projectMap(a, h, x, y)) {
        if (px >= 0)
          for(int band=-2;band<=2;band++)paint.drawLine(px, py+band, x, y+band, rgb(10+(10-abs(latitude))/2,17+(10-abs(latitude)),28+(10-abs(latitude))*2));
        px = x;
        py = y;
      } else
        px = -1;
    }
  }
  }
  if (cfg.lines)
    for (auto &s : constellationLines) {
      double a, h, b, k;
      int x, y, u, v;
      starHorizontal(s.ra1, s.dec1, a, h);
      starHorizontal(s.ra2, s.dec2, b, k);
      if (projectMap(a, h, x, y) && projectMap(b, k, u, v))
        paint.drawLine(x, y, u, v, 0x212D);
    }
  int i = 0;
  for (auto &s : stars) {
    if((i%16)==0)sampleChartTouch();
    double a, h;
    int x, y;
    starHorizontal(s.ra, s.dec, a, h);
    if (projectMap(a, h, x, y)) {
      if(s.mag < 1.5) { paint.drawPixel(x-2,y,0x6B73);paint.drawPixel(x+2,y,0x6B73);paint.drawPixel(x,y-2,0x6B73);paint.drawPixel(x,y+2,0x6B73); paint.fillCircle(x,y,1,white); }
      else paint.drawPixel(x,y,s.mag < 3.5 ? white : 0x6B73);
      addHit(x, y, 100 + i);
    }
    i++;
  }
  i = 0;
  for (auto &s : deepSky) {
    double a, h;
    int x, y;
    starHorizontal(s.ra, s.dec, a, h);
    if (projectMap(a, h, x, y)) {
      paint.drawCircle(x, y, 2, 0x6B73);
      // Deep-sky names appear on tap; keep the chart uncluttered.
      addHit(x, y, 2000 + i);
    }
    i++;
  }
  if(extra.trails&&cfg.satellites&&clockReady())for(int n=0;n<SAT_COUNT;n++){
    sampleChartTouch();
    if((n==3&&!cfg.starlink)||!satellitePositionCurrent(satellites[n],clockReady(),time(nullptr))||satellites[n].alt<0)continue;
    int px=0,py=0,oldx=0,oldy=0;bool previous=false,segment=false;
    for(int dt=0;dt<=120;dt+=20){double az,alt;int x,y;
      if(!satelliteFuture(n,time(nullptr)+dt,az,alt)||!projectMap(az,alt,x,y))break;
      if(previous){paint.drawLine(px,py,x,y,cyan);oldx=px;oldy=py;segment=true;}px=x;py=y;previous=true;
    }
    if(segment){double a=atan2(py-oldy,px-oldx);for(int sign:{-1,1})paint.drawLine(px,py,px-lround(6*cos(a+sign*.5)),py-lround(6*sin(a+sign*.5)),cyan);}
  }
  for (i = 0; i < objectCount; i++) {
    auto &o = objects[i];
    int x, y;
    if (projectMap(o.az, o.alt, x, y)) {
      if(o.kind==0) glowSun(x,y,5); else if(o.kind==1) moonIcon(x,y,7); else {
        if(o.kind==6){
          for(int band=0;band<2;band++)for(int a=0;a<180;a++){
            double t=a*pi/90;double u=(12+band)*cos(t),v=4*sin(t);
            paint.drawPixel(x+lround(u*.94+v*.342),y+lround(-u*.342+v*.94),0xEED0);
          }
        }
        sphere(x,y,7,o.kind);
        if(o.kind==6)for(int a=0;a<90;a++){
          double t=a*pi/90,u=13*cos(t),v=4*sin(t);
          paint.drawPixel(x+lround(u*.94+v*.342),y+lround(-u*.342+v*.94),0xEED0);
        }
      }
      if (cfg.labels) mapLabel(o.name,x,y,o.color);
      addHit(x, y, i);
    }
  }
  if (cfg.satellites && cfg.view == 1)
    for (i = 0; i < SAT_COUNT; i++) {
      if (i >= 3 && !cfg.starlink)
        continue;
      auto &s = satellites[i];
      int x, y;
      if (satellitePositionCurrent(s,clockReady(),time(nullptr)) && projectMap(s.az, s.alt, x, y)) {
        if(satelliteCandidateSeconds(s,clockReady(),time(nullptr)))paint.drawCircle(x,y,16,0xFFE0);
        paint.fillRect(x-3,y-5,7,11,white);
        paint.fillRect(x-13,y-4,8,9,i==3?uint16_t(0xFFE0):cyan);paint.fillRect(x+6,y-4,8,9,i==3?uint16_t(0xFFE0):cyan);
        if (cfg.labels) mapLabel(i==3?String("Starlink"):String(s.name),x,y,i==3?uint16_t(0xFFE0):cyan);
        addHit(x, y, 3000 + i);
      }
    }
  if(cfg.labels) {
    int count=0;
    for(auto &s:constellationLabels) {
      double a,h;int x,y;starHorizontal(s.ra,s.dec,a,h);
      if(h>15 && projectMap(a,h,x,y) && count<3 && mapLabel(s.name,x,y,0x7CBA)) count++;
    }
  }
#ifndef UI_DIRECT_PREVIEW
  if(highlightedObject>=0){double az,alt;String name;int x,y;
    if(objectCoordinates(highlightedObject,az,alt,name)&&projectMap(az,alt,x,y)){paint.drawCircle(x,y,11,0xFFE0);paint.drawCircle(x,y,13,0xFFE0);}}
  paint.targetAt(lcd);
  skyBuffer.setPivot(112,skyBufferHeight/2);
  skyBuffer.pushRotateZoom(240,mapCenterY()+(stripY+skyBufferHeight/2-112)*mapScale(),0,mapScale(),mapScale());
  // Wait for any pending DMA before releasing the image memory.
  lcd.waitDMA();
  }
  ++uiDiag.draws;uiDiag.lastDrawMs=millis();
  // Keep the fixed pixel buffer and tiny palette for the next frame.
#endif
}

struct UiButton {int x,y,w,h,action;};
static UiButton buttons[40];static int buttonCount=0;
static void control(String name,int x,int y,int w,int h,int action,uint16_t color=0x2104){if(buttonCount<40)buttons[buttonCount++]={x,y,w,h,action};button(name,x,y,w,h,color);}
static void cell(String name,int index,int action){control(name,8+(index%2)*236,74+(index/2)*48,228,42,action);}
static String metric(float n,const char*unit,int decimals=0){return isfinite(n)?String(n,decimals)+unit:String("—");}
static void flightScreen(bool full){
 static int lastMode=-1;static String old[13];static uint16_t oldColor[13]={};
 int mode=!modern.aircraft?0:!flight.found?1:2;
 full=full||mode!=lastMode;lastMode=mode;
 if(full){paint.fillRect(0,34,480,246,bg);for(auto &v:old)v="";}
 auto row=[&](int i,String value,int x,int y,const UiFont &font,uint16_t color,int w){
  if(full||old[i]!=value||oldColor[i]!=color){paint.fillRect(x,y,w,((i==0||i==11)?uiFont20.height:font.height)+2,bg);label(value,x,y,font,color,w);old[i]=value;oldColor[i]=color;}
 };
 if(mode==0){row(0,"Flugzeugansicht ausgeschaltet",12,72,uiFont20,white,456);return;}
 if(mode==1){row(0,flight.error[0]?"Datenquelle nicht erreichbar":flight.checked?"Kein Flugzeug im Umkreis":"Flugdaten werden geladen",12,72,uiFont20,white,456);row(1,"Flugzeuge und Hubschrauber · "+String(modern.radius)+" km",12,115,uiFont14,muted,456);return;}
 String call=flight.callsign[0]?flight.callsign:flight.hex;
 row(0,call,12,42,width(call,uiFont20)>174?uiFont14:uiFont20,white,174);
 row(1,flight.type[0]?flight.type:"Typ unbekannt",190,47,uiFont14,muted,170);
 row(2,modern.approaching?"Im Anflug":"Nächstes",365,47,uiFont14,0xFFE0,108);
 unsigned profile=AircraftArt::resolve(flight.type,flight.rotorcraft,airframeCategory(flight.category)==Airframe::FixedWing);
 bool routeOk=clockReady()&&routeMatches(flightRoute,flight.callsign,flight.hex,time(nullptr));
 unsigned livery=AircraftArt::scheme(flight.callsign,routeOk?flightRoute.airline:"");
 if((profile>=21&&!(profile==22&&livery==7))||(profile<21&&livery==7))livery=0;
 String pictureKey=String(profile)+":"+String(livery);
 if(full||old[3]!=pictureKey){paint.fillRect(8,77,212,89,bg);
  if(!AircraftImages::draw(paint,profile,livery,8,80)) AircraftArt::draw(paint,profile,8,80,210,livery);
  label(livery?String(AircraftArt::liveries[livery].name)+" · Schema":String("Typbild · Schema"),12,151,uiFont11,muted,205);old[3]=pictureKey;
 }

 String from=routeOk?(flightRoute.originName[0]?String(flightRoute.originName)+" ("+flightRoute.origin+")":String(flightRoute.origin)):String("Route nicht verfügbar");
 String to=routeOk?(flightRoute.destinationName[0]?String(flightRoute.destinationName)+" ("+flightRoute.destination+")":String(flightRoute.destination)):String("Start / Ziel nicht bestätigt");
 row(11,routeOk?"Von: "+from:from,12,174,uiFont14,routeOk?white:muted,322);
 row(12,routeOk?"Nach: "+to:to,12,197,uiFont14,routeOk?cyan:muted,322);
 row(4,metric(flight.distance," km",1),224,88,uiFont14,cyan,112);
 row(5,bearing(flight.azimuth)+" vom Ort",224,120,uiFont11,white,112);
 const int cx=406,cy=148,rad=43;int px=cx,py=cy,ex=cx,ey=cy;bool point=isfinite(flight.azimuth)&&isfinite(flight.distance),arrow=point&&isfinite(flight.track);
 if(point){double a=flight.azimuth*DEG_TO_RAD,dist=constrain(flight.distance/modern.radius,0.0f,1.0f)*rad;px=cx+lround(sin(a)*dist);py=cy-lround(cos(a)*dist);}
 if(arrow){double t=flight.track*DEG_TO_RAD;ex=px+lround(sin(t)*10);ey=py-lround(cos(t)*10);}
 String compass=String(px)+":"+String(py)+":"+String(ex)+":"+String(ey)+":"+String(point)+String(arrow)+String(flightFresh());
 if(full||old[6]!=compass){paint.fillRect(342,78,130,133,bg);paint.drawCircle(cx,cy,rad,cyan);
  label("N",cx-5,cy-rad-15,uiFont11,white);label("O",cx+rad+4,cy-5,uiFont11,white);label("W",cx-rad-15,cy-5,uiFont11,white);label("S",cx-4,cy+rad+2,uiFont11,white);paint.fillCircle(cx,cy,3,white);
  if(point){uint16_t col=flightFresh()?cyan:0xf800;paint.fillCircle(px,py,3,col);if(arrow){double t=flight.track*DEG_TO_RAD;paint.drawLine(px,py,ex,ey,col);for(int side:{-1,1})paint.drawLine(ex,ey,ex-lround(sin(t+side*.55)*5),ey+lround(cos(t+side*.55)*5),col);}}old[6]=compass;
 }
 if(full){paint.drawFastHLine(8,216,464,cyan);const char*names[]={"Höhe barom.","Geschwindigkeit","Flugrichtung"};for(int i=0;i<3;i++)label(names[i],12+i*158,221,uiFont11,muted);}
 String vals[]={metric(flight.altitude," m"),metric(flight.speed," km/h"),metric(flight.track,"°")};
 for(int i=0;i<3;i++)row(7+i,vals[i],12+i*158,237,uiFont20,white,150);
 int age=clockReady()&&flight.positionAt>0?max(0,int(time(nullptr)-flight.positionAt)):-1;
 String ageText=age<0?String("Alter unbekannt"):age<60?String(age)+" s":String(age/60)+" min";
 row(10,String(flightFresh()?"Aktuell · ":"Veraltet · ")+ageText+(routeOk?" · Route: Katalog":""),12,263,uiFont11,flightFresh()?cyan:0xf800,456);
}

bool objectCoordinates(int id,double &az,double &alt,String &name){
 if(!clockReady())return false;
 if(id>=0&&id<objectCount){az=objects[id].az;alt=objects[id].alt;name=objects[id].name;return true;}
 if(id>=100&&id<100+(int)(sizeof stars/sizeof stars[0])){auto &s=stars[id-100];starHorizontal(s.ra,s.dec,az,alt);name=starName(id-100);return true;}
 return false;
}

#include "HangarModel.h"
#include "HangarRoute.h"

static uint32_t surfaceRevision=0;
static unsigned fakeHangarState=3,fakeHangarRevision=1;static String fakeHangarError;
static Hangar::Record fakeRows[12];static HangarRoute::Record fakeRoute;
uint32_t hangarRevision(){return fakeHangarRevision;}
unsigned hangarDisplayState(){return fakeHangarState;}
bool hangarRequest(JsonVariantConst,String&){++fakeHangarRevision;fakeHangarState=3;return true;}
bool hangarDisplayRow(unsigned i,Hangar::Record&r,unsigned&size,unsigned&total,bool&more,String&error){if(fakeHangarState!=3)return false;size=12;total=107;more=true;error=fakeHangarError;if(i<12)r=fakeRows[i];return true;}
bool hangarDisplayRouteResult(HangarRoute::Record&r,String&e){if(fakeHangarState!=6)return false;r=fakeRoute;e=fakeHangarError;return true;}
static uint32_t hangarScreenRevision=0;
static unsigned hangarScreenOffset=0;
static Hangar::Record hangarSelectedRow;
static String hangarScreenError;
static void requestHangarScreen(bool next=false,bool refresh=false){
 JsonDocument d;d["sort"]="last";d["search"]="";d["force"]=refresh;
 if(next){unsigned size,total;bool more;String error;Hangar::Record cursor;
  if(!hangarDisplayRow(11,cursor,size,total,more,error)||!more)return;
  d["cursorHex"]=cursor.hex;d["cursorLast"]=cursor.last;d["cursorPasses"]=cursor.passes;
 }
 if(hangarRequest(d,hangarScreenError)){hangarScreenRevision=hangarRevision();hangarScreenOffset=0;}
 page=13;surfaceRevision++;
}
static void hangarScreen(){
 control("Mein Hangar",8,40,300,32,820);control("Aktualisieren",316,40,156,32,820);
 if(hangarScreenRevision!=hangarRevision()){label("Ansicht geändert · Aktualisieren",12,95,uiFont14,muted);return;}
 if(page==14){
  auto&r=hangarSelectedRow;
  label(String(r.registration[0]?r.registration:r.hex)+" · "+r.callsign,12,82,uiFont14,cyan,450);
  label("ICAO "+String(r.hex)+" · "+r.type+" · "+String(r.passes)+" Überflüge",12,106,uiFont11,white,450);
  label("Erstmals: "+stamp(r.first,true),12,130,uiFont11,white,450);
  label("Zuletzt: "+stamp(r.last,true),12,150,uiFont11,white,450);
  HangarRoute::Record route;String error;
  if(hangarDisplayRouteResult(route,error)){
   if(error.length())label(error,12,178,uiFont14,muted,450);
   else {label(String(route.origin)+" → "+route.destination,12,176,uiFont14,cyan,450);
    label(String(route.originName)+" → "+route.destinationName,12,198,uiFont11,white,450);
    label(route.airline,12,219,uiFont11,white,450);
    label("Katalogroute · nicht live bestätigt",12,243,uiFont11,muted,450);}
  }else label("Route wird geladen …",12,178,uiFont14,muted,450);
  return;
 }
 unsigned size=0,total=0;bool more=false;String error;Hangar::Record row;
 if(!hangarDisplayRow(0,row,size,total,more,error)){label(hangarScreenError.length()?hangarScreenError:"Hangar wird geladen …",12,95,uiFont14,muted,450);return;}
 if(error.length()){label("Hangar nicht verfügbar",12,92,uiFont14,0xF800,450);label(error,12,122,uiFont11,white,450);return;}
 if(!size){label("Noch keine gespeicherten Flugzeuge",12,95,uiFont14,muted,450);return;}
 for(unsigned i=0;i<3&&hangarScreenOffset+i<size;i++){
  hangarDisplayRow(hangarScreenOffset+i,row,size,total,more,error);
  int y=80+i*48;control("",8,y,464,43,830+i);
  int previousBackground=labelBackground;labelBackground=0x2104;
  label(String(row.registration[0]?row.registration:row.hex)+" · "+row.callsign,18,y+3,uiFont14,white,440);
  label(String(row.passes)+" Überflüge · "+stamp(row.last,true),18,y+25,uiFont11,muted,440);labelBackground=previousBackground;
 }
 control("<",8,230,70,36,821);label(String(total)+" Flugzeuge",94,241,uiFont11,white,230);control(">",392,230,80,36,822);
}
static int radarNextRadius(int radius,int delta){
 const int steps[]={5,10,25,50,75,100,150,200};
 if(delta>0){for(int v:steps)if(v>radius)return v;}else if(delta<0){for(int i=7;i>=0;i--)if(steps[i]<radius)return steps[i];}
 return radius;
}
static String radarRangeError;
static char radarSelected[9]={};
static RadarDot radarLastSelected;
static uint32_t radarSelectionGeneration=0;
static int radarX(const RadarDot &d){return 136+lround(104*d.distance/max(1,radarDisplay.radius)*sin(d.azimuth*DEG_TO_RAD));}
static int radarY(const RadarDot &d){return 169-lround(104*d.distance/max(1,radarDisplay.radius)*cos(d.azimuth*DEG_TO_RAD));}
static void radarScreen(bool full=false){
 static String old[13];static uint16_t oldColor[13];static int oldX[16],oldY[16];static unsigned oldCount=0;static uint32_t oldRevision=0;static String oldSelection;static bool oldValid=false,oldStale=false;static int oldRadius=-1;
 auto row=[&](int i,String value,int x,int y,const UiFont &f,uint16_t c,int w=195){if(full||old[i]!=value||oldColor[i]!=c){paint.fillRect(x,y,w,f.height+2,bg);label(value,x,y,f,c,w);old[i]=value;oldColor[i]=c;}};

 const auto&r=radarDisplay;if(radarSelectionGeneration!=generation){radarSelected[0]=0;radarSelectionGeneration=generation;}bool valid=modern.aircraft&&r.revision&&r.generation==generation;
 if(valid!=oldValid||modern.radius!=oldRadius){full=true;paint.fillRect(0,34,480,286,bg);}oldValid=valid;oldRadius=modern.radius;
 if(full){oldCount=0;oldRevision=0;for(auto &v:old)v="";button("-",275,294,42,26);button("+",430,294,42,26);}
 row(12,String(modern.radius)+" km",326,299,uiFont11,white,100);
 if(!valid){if(full){label("Radar wartet auf Flugdaten",12,75,uiFont14,white);label("Himmel / Flugzeug: wischen",12,110,uiFont11,muted);}return;}
 bool stale=!clockReady()||time(nullptr)<r.received||time(nullptr)-r.received>90;
 uint16_t color=stale?0xF800:cyan;
 bool plot=full||oldRevision!=r.revision||oldSelection!=String(radarSelected)||oldStale!=stale;
 if(plot){for(unsigned i=0;i<oldCount;i++)paint.fillRect(oldX[i]-11,oldY[i]-11,23,23,bg);oldCount=0;

 for(int i=1;i<=4;i++){paint.drawCircle(136,169,26*i,0x2945);label(String(r.radius*i/4.0,1),140,169-26*i+2,uiFont11,muted);}
 label("N",130,43,uiFont14,white);label("S",130,278,uiFont14,white);label("W",10,160,uiFont14,white);label("O",246,160,uiFont14,white);paint.fillCircle(136,169,3,white);}
 row(0,String(r.count)+" / "+String(r.total)+" · "+String(r.radius)+" km",275,45,uiFont11,white,195);
 row(1,stale?"Veraltet":"Aufnahme vor "+String((uint32_t)(time(nullptr)-r.received))+" s",275,64,uiFont11,stale?0xF800:muted,195);
 row(2,radarRangeError.length()?radarRangeError:r.limited?"Ohne SD: Einzelziel":r.total>16?"16 nächste Ziele":"",275,83,uiFont11,radarRangeError.length()?0xF800:muted,195);
 const RadarDot *selectedDot=nullptr;
 for(unsigned i=0;i<r.count;i++){
  const auto&d=r.dots[i];int x=radarX(d),y=radarY(d);bool chosen=radarSelected[0]&&!strcmp(d.hex,radarSelected);uint16_t c=chosen?0xFFE0:((time(nullptr)-(time_t)d.positionAt>90)?0xF800:color);
  if(chosen){radarLastSelected=d;selectedDot=&d;if(plot)paint.drawCircle(x,y,10,c);}
  if(plot){oldX[oldCount]=x;oldY[oldCount++]=y;
  if(d.rotorcraft){paint.drawCircle(x,y,5,c);paint.drawFastHLine(x-7,y,14,c);paint.drawLine(x,y-7,x,y+7,c);}
  else if(isfinite(d.track)){double a=d.track*DEG_TO_RAD;paint.fillTriangle(x+7*sin(a),y-7*cos(a),x+5*sin(a+2.5),y-5*cos(a+2.5),x+5*sin(a-2.5),y-5*cos(a-2.5),c);}
  else paint.fillCircle(x,y,4,c);}
 }
 oldRevision=r.revision;oldSelection=radarSelected;oldStale=stale;
 bool lost=!selectedDot&&radarSelected[0];if(lost)selectedDot=&radarLastSelected;
 if(selectedDot){const auto&d=*selectedDot;
  row(3,d.callsign[0]?d.callsign:d.hex,275,107,uiFont14,0xFFE0,195);
  row(4,lost?"Letzte Position":"Hier suchen",275,132,uiFont11,muted);row(5,String(d.azimuth,0)+"° · "+String(d.distance,1)+" km",275,148,uiFont14,white,195);
  row(6,"Bewegt sich nach",275,173,uiFont11,muted);row(7,isfinite(d.track)?String(d.track,0)+"°":"Unbekannt",275,189,uiFont14,white,195);
  row(8,isfinite(d.altitude)?String(d.altitude,0)+" m barom.":"Höhe unbekannt",275,216,uiFont11,white,195);
  row(9,isfinite(d.speed)?String(d.speed,0)+" km/h":"Tempo unbekannt",275,235,uiFont11,white,195);
  row(10,String(d.type)+" · "+d.hex,275,254,uiFont11,muted,195);
  row(11,"Position vor "+String((uint32_t)max((time_t)0,time(nullptr)-(time_t)d.positionAt))+" s",275,275,uiFont11,(stale||lost||time(nullptr)-(time_t)d.positionAt>90)?0xF800:muted,195);
 }else {row(3,"Ziel antippen",275,107,uiFont14,white,195);}
}

int main(){setenv("TZ","CET-1CEST,M3.5.0,M10.5.0/3",1);tzset();
strcpy(cfg.places[0].name,"Bern");cfg.places[0].lat=46.948;cfg.places[0].lon=7.4474;cfg.places[0].height=540;
const char*names[]={"ISS","Tiangong","Hubble","Starlink"};for(int i=0;i<4;i++)strcpy(satellites[i].name,names[i]);cfg.view=1;skyUpdate();
lcd.fillScreen(0);header();skyScreen(true);nav();lcd.save("himmel.ppm");
lcd.writes=0;skyScreen(false);assert(lcd.writes==0);
auto before=lcd.pixels;uiNetworkMemory(true);generation++;lcd.writes=0;skyScreen(false);assert(lcd.writes==0&&before==lcd.pixels);uiNetworkMemory(false);skyScreen(false);assert(skyPixelsReady);
for(int i=0;i<hitCount;i++)assert(hitScreenX(i)>=128&&hitScreenX(i)<352&&hitScreenY(i)>=34&&hitScreenY(i)<258);
extra.largeMap=true;skyScreen(false);lcd.save("himmel_gross.ppm");for(int i=0;i<hitCount;i++)assert(hitScreenX(i)>=118&&hitScreenX(i)<362&&hitScreenY(i)>=34&&hitScreenY(i)<278);extra.largeMap=false;skyScreen(false);
auto fullColors=lcd.pixels;auto fullHits=hitCount;
uiNetworkMemory(true);uiNetworkMemory(false);fakeLargeFailure=true;skyScreen(false);assert(skyPixelsReady&&uiDiag.bits==4&&uiDiag.fallbacks>=1&&uiDiag.pixelBytes==12544);assert(lcd.pixels==fullColors&&hitCount==fullHits);lcd.save("himmel_fallback.ppm");
extra.largeMap=true;skyScreen(false);auto largeStrips=lcd.pixels;uiNetworkMemory(true);uiNetworkMemory(false);fakeLargeFailure=false;skyScreen(false);assert(lcd.pixels==largeStrips&&uiDiag.pixelBytes==12544);extra.largeMap=false;skyScreen(false);
// Synthetic colored objects on both halves, satellites above horizon and visible.
objectCount=4;for(int i=0;i<4;i++){objects[i].az=i*90;objects[i].alt=45;objects[i].color=i%2?0xF800:0xFFE0;objects[i].kind=i+2;strcpy(objects[i].name,"Color");}
for(int i=0;i<4;i++){satellites[i].valid=true;satellites[i].epoch=time(nullptr);satellites[i].visibilityAt=time(nullptr);satellites[i].visibility=i%2?5:4;satellites[i].az=i*90+45;satellites[i].alt=40;}
generation++;skyScreen(false);auto coloredFull=lcd.pixels;uiNetworkMemory(true);uiNetworkMemory(false);fakeLargeFailure=true;skyScreen(false);assert(lcd.pixels==coloredFull);puts("PASS: 16-color strips are stable across releases pixel-for-pixel at normal and large scale; colored objects on both halves; identical hit targets; 12544 pixel bytes");
uiNetworkMemory(true);uiNetworkMemory(false);fakeAllocationFailure=true;auto retained=lcd.pixels;skyScreen(false);assert(!skyPixelsReady&&mapDeferred&&retained==lcd.pixels);fakeAllocationFailure=fakeLargeFailure=false;skyScreen(false);assert(skyPixelsReady&&uiDiag.bits==4);
puts("PASS: fixed map workspace, chart retained during TLS, unchanged map zero pixel writes, landscape hit bounds");
cfg.view=2;flight.checked=flight.found=true;flight.received=time(nullptr);flight.positionAt=time(nullptr);strcpy(flight.callsign,"SWR123");strcpy(flight.hex,"abc123");JsonDocument routeDoc;std::ifstream routeFile("../fixtures/route-ryr39kv.json");assert(!deserializeJson(routeDoc,routeFile));routeDoc["callsign"]="SWR123";assert(parseRoute(routeDoc,flightRoute,flight.callsign,flight.hex,time(nullptr)));strcpy(flightRoute.originName,"Zürich");strcpy(flightRoute.destinationName,"Praha");strcpy(flightRoute.origin,"ZRH");strcpy(flightRoute.destination,"PRG");strcpy(flight.type,"A320");strcpy(flight.category,"A3");flight.distance=12.4;flight.azimuth=45;flight.track=225;flight.altitude=3240;flight.speed=420;
lcd.fillScreen(0);header();flightScreen(true);nav();lcd.save("flugzeug.ppm");
strcpy(flight.type,"B744");flightScreen(false);lcd.save("boeing747.ppm");lcd.writes=0;flightScreen(false);assert(lcd.writes==0);strcpy(flight.type,"A320");flightScreen(false);
lcd.writes=0;flightScreen(false);assert(lcd.writes==0);
// Changing only speed must not erase the illustration, route, or compass.
auto previous=lcd.pixels;flight.speed=430;lcd.writes=0;flightScreen(false);assert(lcd.writes>0&&lcd.writes<12000);for(int y=34;y<216;y++)for(int x=0;x<480;x++)assert(lcd.pixels[y*480+x]==previous[y*480+x]);
strcpy(flight.callsign,"HELI DEMO");strcpy(flight.type,"EC35");strcpy(flight.category,"A7");flight.rotorcraft=true;flight.received++;flight.altitude=1450;flight.speed=185;lcd.fillScreen(0);header();flightScreen(true);nav();lcd.save("helikopter.ppm");puts("PASS: fixed-wing and rotorcraft drawn from production functions; unchanged flight zero writes");
for(unsigned i=0;i<12;i++){auto&r=fakeRows[i];strcpy(r.hex,"abcdef");strcpy(r.registration,"HB-TEST");snprintf(r.callsign,sizeof r.callsign,"TEST%u",i+1);strcpy(r.type,"A320");r.passes=i+1;r.first=time(nullptr)-86400;r.last=time(nullptr)-i*30;}
RadarDisplay bounded;for(int i=40;i>0;--i){RadarDot d;d.distance=i;bounded.add(d);}assert(bounded.count==16&&bounded.total==40&&bounded.dots[0].distance==1&&bounded.dots[15].distance==16);static_assert(sizeof(RadarDisplay)<1400,"Bounded radar budget");
page=15;radarDisplay.radius=50;radarDisplay.generation=generation;radarSelectionGeneration=generation;radarDisplay.revision=1;radarDisplay.received=time(nullptr);for(int i=0;i<4;i++){RadarDot d;strcpy(d.hex,i==0?"abcdef":"123456");strcpy(d.callsign,"TEST123");d.distance=10+i*8;d.azimuth=i*90;d.track=45+i*60;d.positionAt=time(nullptr)-12;d.rotorcraft=i==2;radarDisplay.add(d);}strcpy(radarSelected,"abcdef");lcd.fillScreen(0);header();radarScreen();assert(radarLastSelected.positionAt!=0);assert(radarX(radarDisplay.dots[0])==136&&radarY(radarDisplay.dots[0])<169);lcd.save("radar_display.ppm");
lcd.writes=0;radarScreen(false);assert(lcd.writes==0);
radarDisplay.received-=5;auto radarPixels=lcd.pixels;lcd.writes=0;radarScreen(false);assert(lcd.writes>0&&lcd.writes<8000);for(int y=34;y<294;y++)for(int x=0;x<265;x++)assert(lcd.pixels[y*480+x]==radarPixels[y*480+x]);
radarDisplay.revision++;radarDisplay.dots[0].azimuth=20;lcd.writes=0;lcd.maxFillArea=0;radarScreen(false);assert(lcd.writes>0&&lcd.maxFillArea<5000);
for(int v=5;v<=200;v++){assert(radarNextRadius(v,1)>=v&&radarNextRadius(v,1)<=200);assert(radarNextRadius(v,-1)<=v&&radarNextRadius(v,-1)>=5);}assert(radarNextRadius(50,1)==75&&radarNextRadius(50,-1)==25);
modern.radius=100;generation++;radarScreen(false);radarDisplay.radius=100;radarDisplay.generation=generation;radarDisplay.revision++;radarScreen(false);lcd.save("radar_range.ppm");
puts("PASS: unchanged radar zero writes; age update leaves chart pixels intact; frame update bounded; range steps bounded 5..200 and pending/new frame rendered");

requestHangarScreen();buttonCount=0;lcd.fillScreen(0);header();hangarScreen();lcd.save("hangar_display.ppm");assert(buttonCount==7);for(int i=0;i<buttonCount;i++)assert(buttons[i].y+buttons[i].h<=266);
hangarScreenOffset=9;buttonCount=0;lcd.fillScreen(0);hangarScreen();assert(buttonCount==7);
hangarSelectedRow=fakeRows[0];page=14;fakeHangarState=6;strcpy(fakeRoute.origin,"ZRH");strcpy(fakeRoute.destination,"LHR");strcpy(fakeRoute.originName,"Zürich");strcpy(fakeRoute.destinationName,"London");strcpy(fakeRoute.airline,"SWISS");buttonCount=0;lcd.fillScreen(0);header();hangarScreen();lcd.save("hangar_detail.ppm");assert(buttonCount==2);
fakeHangarError="SD nicht bereit";page=13;fakeHangarState=3;buttonCount=0;lcd.fillScreen(0);hangarScreen();assert(buttonCount==2);fakeHangarError="";fakeHangarRevision++;buttonCount=0;hangarScreen();assert(buttonCount==2);
puts("PASS: production TFT hangar list/detail rendering, three-row pagination, SD error and superseded query show no stale row controls");
}
