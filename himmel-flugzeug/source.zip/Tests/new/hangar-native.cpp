
#include "HangarModel.h"
#include <cassert>
#include <vector>
#include <map>
#include <string>
#include <algorithm>
#include <iostream>
using Hangar::Record;
static int cut=-1;static std::map<std::string,std::vector<uint8_t>> disk;
struct File{std::string path;size_t pos=0;bool okay=false;operator bool()const{return okay;}size_t size(){return disk[path].size();}bool seek(size_t p){pos=p;return okay;}size_t read(uint8_t*out,size_t n){auto&v=disk[path];if(pos>=v.size())return 0;n=std::min(n,v.size()-pos);memcpy(out,v.data()+pos,n);pos+=n;return n;}size_t write(const uint8_t*p,size_t n){if(cut>=0)n=std::min(n,size_t(cut));auto&v=disk[path];v.resize(std::max(v.size(),pos+n));memcpy(v.data()+pos,p,n);pos+=n;return n;}void close(){}void flush(){}};
struct FakeSD{bool exists(const char*p){return disk.count(p);}File open(const char*p,const char*mode){if(!exists(p)&&mode[0]=='r')return {};if(mode[0]=='w')disk[p].clear();return {p,0,true};}}SD;
#define FILE_READ "r"
constexpr unsigned slotSize=128;
int readRecord(const char*path,Record &out,bool *recovered=nullptr){
 File f=SD.open(path,FILE_READ);if(!f)return SD.exists(path)?-1:0;
 Record a{},b{};bool va=f.read((uint8_t*)&a,sizeof a)==sizeof a&&Hangar::valid(a);
 bool vb=f.seek(slotSize)&&f.read((uint8_t*)&b,sizeof b)==sizeof b&&Hangar::valid(b);size_t size=f.size();f.close();
 if(!va&&!vb)return -1;
 out=va&&(!vb||int32_t(a.sequence-b.sequence)>0)?a:b;
 if(recovered)*recovered=size>slotSize&&(!va||!vb);
 return 1;
}
bool writeRecord(const char*path,Record&r){
 ++r.sequence;r.crc=Hangar::checksum(r);const unsigned slot=(r.sequence-1)&1;
 File f=SD.open(path,SD.exists(path)?"r+":"w+");if(!f)return false;
 bool ok=f.seek(slot*slotSize)&&f.write((const uint8_t*)&r,sizeof r)==sizeof r;f.flush();f.close();
 Record check{};return ok&&readRecord(path,check)==1&&check.sequence==r.sequence&&check.crc==r.crc;
}

int main(){
 const int64_t t=1800000000;Hangar::Coverage c;Record a;
 for(int i=0;i<10;i++){c.begin(t+i*30,46.9,7.4,50);bool added=Hangar::observe(a,"abcdef",t+i*30,t+i*30,c);assert(added==(i==0));}assert(a.passes==1);
 assert(writeRecord("a",a));Record restored;assert(readRecord("a",restored)==1&&restored.passes==1);
 c=Hangar::Coverage{};c.begin(t+300,46.9,7.4,50);Hangar::observe(restored,"abcdef",t+300,t+300,c);assert(restored.passes==1);
 c.interrupt();c.begin(t+7200,46.9,7.4,50);Hangar::observe(restored,"abcdef",t+7200,t+7200,c);assert(restored.passes==1);
 for(int i=1;i<=35;i++)c.begin(t+7200+i*30,46.9,7.4,50);
 assert(Hangar::observe(restored,"abcdef",t+8250,t+8250,c));assert(restored.passes==2);
 // Duplicate receptions, a changed radius/place and stale or future positions cannot increment.
 Hangar::observe(restored,"abcdef",t+8250,t+8250,c);assert(restored.passes==2);
 c.begin(t+10000,47,8,100);Hangar::observe(restored,"abcdef",t+10000,t+10000,c);assert(restored.passes==2);
 auto before=restored;Hangar::observe(restored,"abcdef",t,t+10000,c);assert(!memcmp(&before,&restored,sizeof before));
 assert(!Hangar::observe(restored,"abcdef",t+10002,t+10001,c));
 // A truncated new slot never destroys the previous valid record.
 auto clean=disk;for(int n=0;n<int(sizeof(Record));n++){disk=clean;Record update=a;update.last++;update.frame++;cut=n;assert(!writeRecord("a",update));Record good;assert(readRecord("a",good)==1&&good.sequence==a.sequence&&good.passes==1);}
 disk=clean;cut=-1;Record update=a;update.last++;update.frame++;assert(writeRecord("a",update));Record good;assert(readRecord("a",good)==1&&good.sequence==update.sequence);
 disk["a"][128+10]^=1;assert(readRecord("a",good)==1&&good.sequence==a.sequence);disk["a"][10]^=1;assert(readRecord("a",good)==-1);
 Record b=restored;b.passes=3;assert(Hangar::before(b,restored,true));
 std::cout<<"PASS 10 observations=1, reboot=1, outage=1, covered return=2, context/stale/future handling; every partial-slot length retains previous record; CRC corruption and sorting\n";
}
