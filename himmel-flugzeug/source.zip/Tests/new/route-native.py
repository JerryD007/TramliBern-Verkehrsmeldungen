from pathlib import Path
import subprocess,os
r=Path(__file__).resolve().parents[2];out=Path(__file__).parent
code=r'''
#include "FlightRoute.h"
#include <fstream>
#include <cassert>
#include <iostream>
int main(int argc,char**argv){JsonDocument d;std::ifstream file(argv[1]);assert(!deserializeJson(d,file));FlightRoute route;
assert(parseRoute(d,route,"RYR39KV","abc123",1800000000));assert(std::string(route.origin)=="WRO"&&std::string(route.destination)=="MAD");
assert(routeMatches(route,"RYR39KV","abc123",1800000001));assert(!routeMatches(route,"RYR39KV","abc123",1800021600));assert(!routeMatches(route,"RYR39KV","abc123",1799999999));assert(!routeMatches(route,"RYR39KV","def456",1800000001));assert(!routeMatches(route,"SWR123","abc123",1800000001));
assert(!parseRoute(d,route,"SWR123","abc123",1800000000));
for(const char*s:{"../a","a123","A B","","AB","ABCDEFGHI"})assert(!routeCallsign(s));
d["_airports"][0]["iata"]="<script>";assert(parseRoute(d,route,"RYR39KV","abc123",1800000000));assert(std::string(route.origin)=="EPWR");
d["_airports"][1]["icao"]="EPWR";assert(!parseRoute(d,route,"RYR39KV","abc123",1800000000));
d["_airports"][1]["icao"]="<script>";assert(!parseRoute(d,route,"RYR39KV","abc123",1800000000));
d.clear();d["callsign"]="RYR39KV";d["airport_codes"]="unknown";assert(!parseRoute(d,route,"RYR39KV","abc123",1800000000));
d.clear();auto ar=d["response"]["flightroute"].to<JsonObject>();ar["callsign_icao"]="SWR123";ar["origin"]["iata_code"]="ZRH";ar["origin"]["municipality"]="Zürich";ar["airline"]["name"]="Swiss";ar["destination"]["icao_code"]="EGLL";
assert(parseAdsbRoute(d,route,"SWR123","abc123",1800000000));assert(std::string(route.origin)=="ZRH"&&std::string(route.destination)=="EGLL");
assert(std::string(route.originName)=="Zürich"&&std::string(route.airline)=="Swiss");
assert(!parseAdsbRoute(d,route,"SWR124","abc123",1800000000));ar["destination"]["icao_code"]="<bad>";assert(!parseAdsbRoute(d,route,"SWR123","abc123",1800000000));
ar["destination"]["iata_code"]="ZRH";assert(!parseAdsbRoute(d,route,"SWR123","abc123",1800000000));
d.clear();d["response"]="unknown callsign";assert(!parseAdsbRoute(d,route,"SWR123","abc123",1800000000));
std::cout<<"PASS real catalogue response, callsign/aircraft association, expiry, unknown routes, path validation, airport-code validation\n";
}
'''
(out/'route-native.cpp').write_text(code)
subprocess.run(['g++','-std=c++17','-I'+str(r/'WetterHimmel'),'-I'+os.environ.get('ARDUINOJSON_INCLUDE',str(Path.home()/'Arduino/libraries/ArduinoJson/src')),str(out/'route-native.cpp'),'-o',str(out/'route-native')],check=True)
subprocess.run([str(out/'route-native'),str(r/'Tests/fixtures/route-ryr39kv.json')],check=True)
