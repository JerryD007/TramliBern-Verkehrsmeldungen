from pathlib import Path
import subprocess,tempfile,os
r=Path(__file__).resolve().parents[2]
# Compile the real Result and its production member types, then alternate all variants.
app=(r/'WetterHimmel/App.h').read_text(); modern=(r/'WetterHimmel/Modern.h').read_text(); radar=(r/'WetterHimmel/Radar.h').read_text(); display=(r/'WetterHimmel/RadarDisplay.h').read_text(); net=(r/'WetterHimmel/Network.cpp').read_text()
def struct(src,name):
 start=src.index('struct '+name+' {');level=0
 for i in range(src.index('{',start),len(src)):
  if src[i]=='{':level+=1
  elif src[i]=='}':
   level-=1
   if level==0:return src[start:i+2]
parts=[]
for name in ['Flight','FlightRoute','RadarSnapshot','RadarDot','RadarDisplay']:
 src=next(x for x in [app,modern,radar,display,(r/'WetterHimmel/FlightRoute.h').read_text()] if 'struct '+name+' {' in x)
 parts.append(struct(src,name))
code='#include <cstdint>\n#include <ctime>\n#include <cstring>\n#include <cmath>\n#include <algorithm>\n#include <cassert>\n#include <new>\n#include <cstdio>\nusing std::min;using std::max;\n'+'\n'.join(parts)+'\n'+struct(net,'Result')+r"""
int main(){Result r;for(int n=0;n<1000;n++){
 new (&r) Result{};r.kind=1;strcpy(r.payload.omm,"satellite");assert(!strcmp(r.payload.omm,"satellite"));
 new (&r) Result{};r.kind=9;new (&r.payload.aircraft) Result::Payload::Aircraft{};
 assert(!r.payload.aircraft.flight.found && !r.payload.aircraft.radar.bytes);
 strcpy(r.payload.aircraft.flight.hex,"abcdef");r.payload.aircraft.radar.bytes=100;
 assert(!strcmp(r.payload.aircraft.flight.hex,"abcdef") && r.payload.aircraft.radar.bytes==100);
 new (&r) Result{};r.kind=10;new (&r.payload.route) FlightRoute{};assert(!r.payload.route.found);strcpy(r.payload.route.callsign,"SWR123");assert(!strcmp(r.payload.route.callsign,"SWR123"));
}printf("PASS 1000 alternating payload lifetimes; host Result bytes %zu\n",sizeof r);}
"""
with tempfile.TemporaryDirectory() as t:
 p=Path(t);(p/'test.cpp').write_text(code)
 subprocess.run(['g++','-std=c++17','-fsanitize=undefined,address','-g',str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'))
