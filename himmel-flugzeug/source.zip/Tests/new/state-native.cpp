
#include <ArduinoJson.h>
#include <string>
#include <cstring>
#include <cmath>
#include <cassert>
#include <iostream>
using namespace std;
using String=std::string;
size_t strlcpy(char*d,const char*s,size_t n){size_t z=strlen(s);if(n){memmove(d,s,min(z,n-1));d[min(z,n-1)]=0;}return z;}
static unsigned tick=1000000;static time_t nowTime=1800000000;
unsigned millis(){return tick;}time_t fakeTime(time_t*){return nowTime;}
#define time fakeTime
bool clockReady(){return true;}
bool objectCoordinates(int id,double&,double&,String&){return id<20;}
struct ModernSettings {
 uint32_t version=1;char name[33]="HimmelFlugzeug";
 bool aircraft=true,approaching=false,priority=false,wakeOnFlight=false;
 int radius=50,showSeconds=0,cooldownSeconds=300,sleepMinutes=0;
 int skySeconds=0,flightSeconds=0; // 0 inherits the existing auto interval.
 int favorites[16];int favoriteCount=0;
};
struct Flight {
 bool checked=false,found=false,approaching=false;
 char category[3]={},description[65]={};
 bool rotorcraft=false;
 char callsign[17]={},type[17]={},hex[9]={},error[96]={};
 float distance=NAN,altitude=NAN,speed=NAN,track=NAN,azimuth=NAN;
 time_t received=0,positionAt=0;
};

ModernSettings modern;Flight flight;bool displayAsleep=false,dirty=false;
uint32_t activityAt=0,priorityAt=0,priorityEnded=0,touchMaxGapMs=0;
bool priorityWasAsleep=false,automaticFlight=false,manualFlight=false;int previousView=-1,page=0;char priorityHex[9]={};struct{int view=1;}cfg;
int backlightCalls=0,timerResets=0;void uiDisplayBrightness(){backlightCalls++;}void resetViewTimer(){timerResets++;}
bool priorityActive(){return previousView>=0;}
// Keep a priority view through a transient fetch error only while its last
// position is still recent and inside the current configured radius.
static bool priorityPositionValid(){time_t n=time(nullptr);return clockReady()&&flight.found&&flight.hex[0]&&isfinite(flight.distance)&&flight.distance<=modern.radius&&flight.positionAt>0&&flight.received>0&&flight.positionAt<=n+30&&flight.received<=n+30&&n-flight.positionAt<=90&&n-flight.received<=90&&(!modern.approaching||flight.approaching);}
bool flightFresh(){time_t n=time(nullptr);return clockReady()&&flight.found&&!flight.error[0]&&flight.positionAt<=n+30&&n-flight.positionAt<=90&&n-flight.received<=90;}
void selectManualView(int view){manualFlight=view==2;}
int automaticNextView(){manualFlight=false;automaticFlight=cfg.view==1&&modern.aircraft&&flightFresh();return automaticFlight?2:1;}
void manualInteraction(){automaticFlight=false;activityAt=millis();if(previousView>=0){previousView=-1;priorityWasAsleep=false;priorityEnded=millis();}}
void wakeDisplay(){displayAsleep=false;manualInteraction();uiDisplayBrightness();dirty=true;}
bool touchSleepGate(bool down){static bool swallow=false;static uint32_t releaseAt=0,lastPoll=0;uint32_t n=millis();if(lastPoll)touchMaxGapMs=max(touchMaxGapMs,n-lastPoll);lastPoll=n;
 if(displayAsleep&&down){wakeDisplay();swallow=true;releaseAt=n;}
 if(swallow){if(down)releaseAt=n;else if(n-releaseAt>=100)swallow=false;return true;}
 if(down)activityAt=n;return displayAsleep;
}
void modernJson(JsonObject d,const ModernSettings &m){d["name"]=m.name;d["aircraft"]=m.aircraft;d["approaching"]=m.approaching;d["priority"]=m.priority;d["wakeOnFlight"]=m.wakeOnFlight;d["radius"]=m.radius;d["showSeconds"]=m.showSeconds;d["cooldownSeconds"]=m.cooldownSeconds;d["sleepMinutes"]=m.sleepMinutes;d["skySeconds"]=m.skySeconds;d["flightSeconds"]=m.flightSeconds;auto a=d["favorites"].to<JsonArray>();for(int i=0;i<m.favoriteCount;i++)a.add(m.favorites[i]);}
bool modernRead(JsonVariantConst d,ModernSettings &m){
 if(!d["name"].is<const char*>()||!strlen(d["name"])||strlen(d["name"])>32)return false;
 for(const char*k:{"aircraft","approaching","priority"})if(!d[k].is<bool>())return false;
 if(!d["wakeOnFlight"].isNull()&&!d["wakeOnFlight"].is<bool>())return false;
 m.wakeOnFlight=d["wakeOnFlight"]|false;
 const char*keys[]={"radius","showSeconds","cooldownSeconds","sleepMinutes"};int lo[]={5,0,30,0},hi[]={200,240,3600,240};
 for(int i=0;i<4;i++)if(!d[keys[i]].is<int>()||d[keys[i]].as<int>()<lo[i]||d[keys[i]].as<int>()>hi[i])return false;
 for(const char *key:{"skySeconds","flightSeconds"})if(!d[key].isNull()&&(!d[key].is<int>()||d[key].as<int>()<0||d[key].as<int>()>600||(d[key].as<int>()>0&&d[key].as<int>()<5)))return false;
 m.skySeconds=d["skySeconds"]|0;m.flightSeconds=d["flightSeconds"]|0;
 if(!d["favorites"].is<JsonArrayConst>()||d["favorites"].size()>16)return false;
 m.favoriteCount=0;for(JsonVariantConst v:d["favorites"].as<JsonArrayConst>()){if(!v.is<int>())return false;int id=v;double az,alt;String name;if(id<0||(clockReady()&&!objectCoordinates(id,az,alt,name))||id>10000)return false;for(int i=0;i<m.favoriteCount;i++)if(m.favorites[i]==id)return false;m.favorites[m.favoriteCount++]=id;}
 strlcpy(m.name,d["name"],sizeof m.name);m.aircraft=d["aircraft"];m.approaching=d["approaching"];m.priority=d["priority"];m.radius=d["radius"];m.showSeconds=d["showSeconds"];m.cooldownSeconds=d["cooldownSeconds"];m.sleepMinutes=d["sleepMinutes"];return true;
}
void modernTick(){
 uint32_t n=millis();
 if(automaticFlight&&page==0&&!displayAsleep&&(!modern.aircraft||!flightFresh())){automaticFlight=false;cfg.view=1;resetViewTimer();dirty=true;}
 // A priority temporarily owns the display; inactivity cannot end it early.
 if(previousView>=0){
  if(page!=0||displayAsleep){previousView=-1;priorityWasAsleep=false;priorityEnded=n;return;}
  bool timedOut=modern.showSeconds>0&&n-priorityAt>=uint32_t(modern.showSeconds)*1000;
  if(!modern.aircraft||!modern.priority||!priorityPositionValid()||timedOut){
   cfg.view=1;resetViewTimer();previousView=-1;priorityEnded=timedOut?n:0;dirty=true;
   if(priorityWasAsleep){displayAsleep=true;uiDisplayBrightness();}else activityAt=n;
   priorityWasAsleep=false;
  }
  return;
 }
 // A touch/settings command can end priority ownership without changing the
 // flight screen. In sky-home mode an empty/stale flight must still go home.
 if(!manualFlight&&modern.priority&&page==0&&!displayAsleep&&cfg.view==2&&(!modern.aircraft||!priorityPositionValid())){
  automaticFlight=false;cfg.view=1;resetViewTimer();dirty=true;activityAt=n;
 }
 if(modern.sleepMinutes&&page==0&&!displayAsleep&&n-activityAt>uint32_t(modern.sleepMinutes)*60000){displayAsleep=true;uiDisplayBrightness();}
 bool cooldown=priorityEnded==0||n-priorityEnded>=uint32_t(modern.cooldownSeconds)*1000;
 if(modern.aircraft&&modern.priority&&page==0&&(!displayAsleep||modern.wakeOnFlight)&&(cfg.view!=2||displayAsleep)&&flightFresh()&&priorityPositionValid()&&cooldown){
  manualFlight=false;priorityWasAsleep=displayAsleep;previousView=1;cfg.view=2;priorityAt=n;resetViewTimer();
  displayAsleep=false;uiDisplayBrightness();dirty=true;
 }
}

int main(){JsonDocument d;ModernSettings m;modernJson(d.to<JsonObject>(),m);ModernSettings restored;assert(modernRead(d.as<JsonVariantConst>(),restored));
d.remove("skySeconds");d.remove("flightSeconds");assert(modernRead(d.as<JsonVariantConst>(),restored));assert(restored.skySeconds==0&&restored.flightSeconds==0);
for(int n:{-1,1,4,601}){d["skySeconds"]=n;assert(!modernRead(d.as<JsonVariantConst>(),restored));}d["skySeconds"]=45;d["flightSeconds"]=20;assert(modernRead(d.as<JsonVariantConst>(),restored)&&restored.skySeconds==45&&restored.flightSeconds==20);
modernJson(d.to<JsonObject>(),restored);ModernSettings again;assert(modernRead(d.as<JsonVariantConst>(),again)&&again.skySeconds==45);
// First touch wakes only, short release/recontact stays swallowed.
displayAsleep=true;assert(touchSleepGate(true)&&!displayAsleep);tick+=20;assert(touchSleepGate(false));tick+=20;assert(touchSleepGate(true));tick+=110;assert(touchSleepGate(false));tick++;assert(!touchSleepGate(false));
modern.sleepMinutes=1;activityAt=tick-60001;modernTick();assert(displayAsleep);wakeDisplay();assert(!displayAsleep);
modern.showSeconds=0;
// Continuous priority: menus/sleep guarded, old duration no longer ends a flight.
modern.priority=true;modern.aircraft=true;flight.found=true;flight.distance=12;flight.positionAt=flight.received=nowTime;flight.approaching=true;strcpy(flight.hex,"abc123");
page=1;modernTick();assert(!priorityActive()&&cfg.view==1);page=0;displayAsleep=true;modernTick();assert(!priorityActive()&&cfg.view==1);displayAsleep=false;activityAt=tick;
modernTick();assert(priorityActive()&&cfg.view==2);
for(int i=0;i<40;i++){tick+=30000;nowTime+=30;flight.positionAt=flight.received=nowTime;modernTick();assert(priorityActive()&&cfg.view==2&&!displayAsleep);}
// Receding aircraft and a different nearest aircraft remain displayed.
flight.approaching=false;strcpy(flight.hex,"def123");modernTick();assert(priorityActive()&&cfg.view==2);
// One failed request does not immediately close an existing recent flight.
strcpy(flight.error,"TLS error");modernTick();assert(priorityActive());nowTime+=91;tick+=91000;modernTick();assert(!priorityActive()&&cfg.view==1);
flight.error[0]=0;flight.positionAt=flight.received=nowTime;modernTick();assert(priorityActive());
// Confirmed empty snapshot returns home; same aircraft can return immediately.
flight.found=false;modernTick();assert(!priorityActive()&&cfg.view==1);flight.found=true;modernTick();assert(priorityActive());
flight.distance=modern.radius+1;modernTick();assert(!priorityActive()&&cfg.view==1);flight.distance=12;modernTick();assert(priorityActive());
// Manual intervention suppresses automatic interruption for configured pause.
modern.sleepMinutes=0;manualInteraction();cfg.view=1;modernTick();assert(!priorityActive());tick+=modern.cooldownSeconds*1000;nowTime+=modern.cooldownSeconds;flight.positionAt=flight.received=nowTime;modernTick();assert(priorityActive());
flight.found=false;modernTick();modern.wakeOnFlight=true;flight.found=true;displayAsleep=true;modernTick();assert(priorityActive()&&!displayAsleep);
tick+=20000;modernTick();assert(priorityActive()&&!displayAsleep);flight.found=false;modernTick();assert(!priorityActive()&&displayAsleep&&cfg.view==1);
flight.found=true;modernTick();assert(priorityActive()&&!displayAsleep);manualInteraction();cfg.view=1;flight.found=false;modernTick();assert(!displayAsleep);
page=1;displayAsleep=true;flight.found=true;tick+=modern.cooldownSeconds*1000;modernTick();assert(displayAsleep&&!priorityActive());page=0;
// Timed mode: exact boundary, same-aircraft repeat after pause, max 240 seconds.
page=0;displayAsleep=false;modern.sleepMinutes=0;previousView=-1;priorityEnded=0;cfg.view=1;modern.wakeOnFlight=false;flight.found=true;flight.error[0]=0;flight.positionAt=flight.received=nowTime;
for(int seconds:{1,20,240}){modern.showSeconds=seconds;priorityEnded=0;cfg.view=1;modernTick();assert(priorityActive());tick+=seconds*1000-1;flight.positionAt=flight.received=nowTime;modernTick();assert(priorityActive());tick++;modernTick();assert(!priorityActive()&&cfg.view==1);modernTick();assert(!priorityActive());tick+=modern.cooldownSeconds*1000;flight.positionAt=flight.received=nowTime;modernTick();assert(priorityActive());flight.found=false;modernTick();flight.found=true;}
for(int seconds:{0,1,240}){d["showSeconds"]=seconds;assert(modernRead(d.as<JsonVariantConst>(),restored));}for(int seconds:{-1,241}){d["showSeconds"]=seconds;assert(!modernRead(d.as<JsonVariantConst>(),restored));}d["showSeconds"]=0;
// Regression: ownership canceled by touch/settings, still on flight view.
modern.priority=true;modern.aircraft=true;modern.showSeconds=0;modern.sleepMinutes=0;page=0;displayAsleep=false;cfg.view=1;priorityEnded=0;flight.found=true;flight.distance=12;flight.positionAt=flight.received=nowTime;modernTick();assert(priorityActive());
manualInteraction();assert(!priorityActive()&&cfg.view==2);modernTick();assert(cfg.view==2);flight.found=false;modernTick();assert(cfg.view==1&&!priorityActive());
// Empty screen reached through menu also returns, but menus/radar stay intact.
cfg.view=2;page=1;modernTick();assert(cfg.view==2);page=0;modernTick();assert(cfg.view==1);
cfg.view=3;modernTick();assert(cfg.view==3);cfg.view=2;displayAsleep=true;modernTick();assert(cfg.view==2&&displayAsleep);displayAsleep=false;modernTick();assert(cfg.view==1);
// Manual-only mode keeps manual flight screen. Priority mode clears stale/range.
modern.priority=false;cfg.view=2;modernTick();assert(cfg.view==2);modern.priority=true;flight.found=true;flight.positionAt=nowTime-91;modernTick();assert(cfg.view==1);cfg.view=2;flight.positionAt=nowTime;flight.distance=modern.radius+1;modernTick();assert(cfg.view==1);flight.distance=12;
// Explicit menu/swipe/web selection is kept even with priority enabled and empty data.
selectManualView(2);cfg.view=2;flight.found=false;modernTick();assert(cfg.view==2);
flight.found=true;flight.positionAt=nowTime-91;modernTick();assert(cfg.view==2);
flight.positionAt=nowTime;flight.distance=modern.radius+1;modernTick();assert(cfg.view==2);
selectManualView(1);cfg.view=1;flight.distance=12;
// Older settings do not opt in to wake. Wrong types rejected.
d.remove("wakeOnFlight");assert(modernRead(d.as<JsonVariantConst>(),restored)&&!restored.wakeOnFlight);d["wakeOnFlight"]="true";assert(!modernRead(d.as<JsonVariantConst>(),restored));d["wakeOnFlight"]=true;assert(modernRead(d.as<JsonVariantConst>(),restored)&&restored.wakeOnFlight);
// Automatic cycle only admits fresh, positive aircraft and returns on data loss.
modern.priority=false;modern.sleepMinutes=0;page=0;displayAsleep=false;cfg.view=1;flight.error[0]=0;flight.found=false;assert(automaticNextView()==1);
flight.found=true;flight.positionAt=nowTime-91;assert(automaticNextView()==1);flight.positionAt=flight.received=nowTime;cfg.view=automaticNextView();assert(cfg.view==2);flight.found=false;modernTick();assert(cfg.view==1&&!automaticFlight);
flight.found=true;cfg.view=automaticNextView();assert(cfg.view==2);manualInteraction();flight.found=false;modernTick();assert(cfg.view==2);cfg.view=1;modern.aircraft=false;assert(automaticNextView()==1);
cout<<"PASS optional flight wake/restore/touch/menu/migration; settings migration/validation/roundtrip, wake gesture, inactivity sleep, menu/sleep priority guards, continuous 20-minute in-range priority, same-aircraft reentry, manual pause, bounded fetch failure, stale/out-of-range return\n";
}
