from pathlib import Path
import subprocess,os
r=Path(__file__).resolve().parents[2];s=(r/'WetterHimmel/Modern.cpp').read_text();h=(r/'WetterHimmel/Modern.h').read_text();types=h[h.index('struct ModernSettings'):h.index('extern ModernSettings')]
parts=s[s.index('bool priorityActive()'):s.index('void modernJson')]+s[s.index('void modernJson'):s.index('void modernBegin')]+s[s.index('void modernTick()'):s.index('void modernState')]
pre=r'''
#include <ArduinoJson.h>
#include <string>
#include <cstring>
#include <cmath>
#include <cassert>
#include <iostream>
using namespace std;
using String=std::string;
size_t strlcpy(char*d,const char*s,size_t n){size_t z=strlen(s);if(n){memmove(d,s,min(z,n-1));d[min(z,n-1)]=0;}return z;}
static unsigned tick=1000000;static time_t nowTime=1800000000;
unsigned millis(){return tick;}time_t fakeTime(time_t*){return nowTime;}
#define time fakeTime
bool clockReady(){return true;}
bool objectCoordinates(int id,double&,double&,String&){return id<20;}
'''
post=r'''
ModernSettings modern;Flight flight;bool displayAsleep=false,dirty=false;
uint32_t activityAt=0,priorityAt=0,priorityEnded=0,touchMaxGapMs=0;
bool priorityWasAsleep=false;int previousView=-1,page=0;char priorityHex[9]={};struct{int view=1;}cfg;
int backlightCalls=0,timerResets=0;void uiDisplayBrightness(){backlightCalls++;}void resetViewTimer(){timerResets++;}
'''
main=r'''
int main(){JsonDocument d;ModernSettings m;modernJson(d.to<JsonObject>(),m);ModernSettings restored;assert(modernRead(d.as<JsonVariantConst>(),restored));
d.remove("skySeconds");d.remove("flightSeconds");assert(modernRead(d.as<JsonVariantConst>(),restored));assert(restored.skySeconds==0&&restored.flightSeconds==0);
for(int n:{-1,1,4,601}){d["skySeconds"]=n;assert(!modernRead(d.as<JsonVariantConst>(),restored));}d["skySeconds"]=45;d["flightSeconds"]=20;assert(modernRead(d.as<JsonVariantConst>(),restored)&&restored.skySeconds==45&&restored.flightSeconds==20);
modernJson(d.to<JsonObject>(),restored);ModernSettings again;assert(modernRead(d.as<JsonVariantConst>(),again)&&again.skySeconds==45);
// First touch wakes only, short release/recontact stays swallowed.
displayAsleep=true;assert(touchSleepGate(true)&&!displayAsleep);tick+=20;assert(touchSleepGate(false));tick+=20;assert(touchSleepGate(true));tick+=110;assert(touchSleepGate(false));tick++;assert(!touchSleepGate(false));
modern.sleepMinutes=1;activityAt=tick-60001;modernTick();assert(displayAsleep);wakeDisplay();assert(!displayAsleep);
// Default: menus and sleeping screen stay undisturbed.
modern.priority=true;modern.aircraft=true;flight.found=true;flight.positionAt=flight.received=nowTime;flight.approaching=true;strcpy(flight.hex,"abc123");
page=1;modernTick();assert(!priorityActive()&&cfg.view==1);page=0;displayAsleep=true;modernTick();assert(!priorityActive()&&cfg.view==1);displayAsleep=false;activityAt=tick;
modernTick();assert(priorityActive()&&cfg.view==2);tick+=modern.showSeconds*1000;modernTick();assert(!priorityActive()&&cfg.view==1&&timerResets==1);
// Same aircraft does not repeatedly interrupt; stale positions never trigger priority.
tick+=modern.cooldownSeconds*1000;activityAt=tick;modernTick();assert(!priorityActive());strcpy(flight.hex,"def123");flight.positionAt=nowTime-91;modernTick();assert(!priorityActive());
// Wake is explicit, accepts receding aircraft when approaching-only is off.
modern.wakeOnFlight=true;flight.positionAt=flight.received=nowTime;flight.approaching=false;strcpy(flight.hex,"wake01");displayAsleep=true;
modernTick();assert(priorityActive()&&!displayAsleep&&cfg.view==2);
tick+=modern.showSeconds*1000;modernTick();assert(!priorityActive()&&displayAsleep&&cfg.view==1);
// Touch during temporary wake cancels restoration to sleep.
tick+=modern.cooldownSeconds*1000;strcpy(flight.hex,"wake02");modernTick();assert(priorityActive()&&!displayAsleep);manualInteraction();tick+=modern.showSeconds*1000;modernTick();assert(!displayAsleep);
// Menu still blocks wake even with permission enabled.
page=1;displayAsleep=true;strcpy(flight.hex,"wake03");tick+=modern.cooldownSeconds*1000;modernTick();assert(displayAsleep&&!priorityActive());page=0;
// Older settings do not opt in to wake. Wrong types rejected.
d.remove("wakeOnFlight");assert(modernRead(d.as<JsonVariantConst>(),restored)&&!restored.wakeOnFlight);d["wakeOnFlight"]="true";assert(!modernRead(d.as<JsonVariantConst>(),restored));d["wakeOnFlight"]=true;assert(modernRead(d.as<JsonVariantConst>(),restored)&&restored.wakeOnFlight);
cout<<"PASS optional flight wake/restore/touch/menu/migration; settings migration/validation/roundtrip, wake gesture, inactivity sleep, menu/sleep priority guards, return timer, duplicate/stale priority suppression\n";
}
'''
out=Path(__file__).parent;(out/'state-native.cpp').write_text(pre+types+post+parts+main)
subprocess.run(['g++','-std=c++17','-I'+os.environ.get('ARDUINOJSON_INCLUDE','/home/agent/Arduino/libraries/ArduinoJson/src'),str(out/'state-native.cpp'),'-o',str(out/'state-native')],check=True)
subprocess.run([str(out/'state-native')],check=True)
