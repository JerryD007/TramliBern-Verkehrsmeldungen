#include <sstream>
#include <ArduinoJson.h>
#include "../../WetterHimmel/Airframe.h"
#include <cmath>
#include <cstring>
#include <cassert>
#include <iostream>
using namespace std;
#define DEG_TO_RAD (M_PI/180)
#define RAD_TO_DEG (180/M_PI)
#define sq(x) ((x)*(x))
template<class T>T constrain(T x,T a,T b){return min(b,max(a,x));}
struct Place{double lat,lon;};
struct Flight {
 bool checked=false,found=false,approaching=false;
 char category[3]={},description[65]={};
 bool rotorcraft=false;
 char callsign[17]={},type[17]={},hex[9]={},error[96]={};
 float distance=NAN,altitude=NAN,speed=NAN,track=NAN,azimuth=NAN;
 time_t received=0,positionAt=0;
};
static double directionTo(double lat,double lon,double lat2,double lon2){double a=lat*DEG_TO_RAD,b=lat2*DEG_TO_RAD,d=(lon2-lon)*DEG_TO_RAD;return fmod(atan2(sin(d)*cos(b),cos(a)*sin(b)-sin(a)*cos(b)*cos(d))*RAD_TO_DEG+360,360);}
static bool numeric(JsonVariantConst v){return v.is<double>()&&isfinite(v.as<double>());}
static void cleanText(char *out,size_t n,JsonVariantConst v){const char *s=v.is<const char*>()?v.as<const char*>():"";size_t i=0;for(;*s&&i+1<n;s++)if((uint8_t)*s>=32&&(uint8_t)*s<127)out[i++]=*s;while(i&&out[i-1]==' ')i--;out[i]=0;}
bool parseFlight(JsonDocument &d,Flight &out,const Place &p,int radius,bool approaching,time_t now){
 if(!d["ac"].is<JsonArray>()||!numeric(d["now"]))return false;
 double source=d["now"];if(source>1e12)source/=1000;
 if(source<now-120||source>now+30||(!d["msg"].isNull()&&strcmp(d["msg"]|"","No error")))return false;
 Flight next;next.checked=true;next.received=now;double best=radius+.001;
 for(JsonObjectConst a:d["ac"].as<JsonArrayConst>()){
  if(!numeric(a["lat"])||!numeric(a["lon"])||!numeric(a["seen_pos"]))continue;
  double lat=a["lat"],lon=a["lon"],age=a["seen_pos"];
  if(lat < -90||lat>90||lon < -180||lon>180||age<0||age>60||now-(source-age)>60)continue;
  if(a["alt_baro"].is<const char*>()&&!strcmp(a["alt_baro"],"ground"))continue;
  double dl=(lat-p.lat)*DEG_TO_RAD,dn=(lon-p.lon)*DEG_TO_RAD;
  double h=sq(sin(dl/2))+cos(lat*DEG_TO_RAD)*cos(p.lat*DEG_TO_RAD)*sq(sin(dn/2));
  double dist=12742.0176*asin(sqrt(constrain(h,0.,1.)));
  bool closes=numeric(a["track"])&&a["track"].as<double>()>=0&&a["track"].as<double>()<360&&numeric(a["gs"])&&a["gs"].as<double>()>=10&&cos((a["track"].as<double>()-directionTo(lat,lon,p.lat,p.lon))*DEG_TO_RAD)>.15;
  if(dist>radius||dist>=best||(approaching&&!closes))continue;
  best=dist;next.found=true;next.distance=dist;next.approaching=closes;next.positionAt=(time_t)(source-age);
  next.azimuth=directionTo(p.lat,p.lon,lat,lon);
  cleanText(next.callsign,sizeof next.callsign,a["flight"]);cleanText(next.hex,sizeof next.hex,a["hex"]);cleanText(next.type,sizeof next.type,a["t"]);
  next.category[0]=0;const char *category=a["category"]|"";if(strlen(category)==2)cleanText(next.category,sizeof next.category,a["category"]);cleanText(next.description,sizeof next.description,a["desc"]);
  next.rotorcraft=airframeCategory(next.category)==Airframe::Rotorcraft;
  next.altitude=numeric(a["alt_baro"])&&a["alt_baro"].as<double>()>=-2000&&a["alt_baro"].as<double>()<=100000?a["alt_baro"].as<double>()*.3048:NAN;
  next.speed=numeric(a["gs"])&&a["gs"].as<double>()>=0&&a["gs"].as<double>()<=2000?a["gs"].as<double>()*1.852:NAN;
  next.track=numeric(a["track"])&&a["track"].as<double>()>=0&&a["track"].as<double>()<360?a["track"].as<float>():NAN;
 }
 out=next;return true;
}

#define ARDUINO_ARCH_ESP32 1
unsigned cooperativeYields=0;void vTaskDelay(int){++cooperativeYields;}
#include "../../WetterHimmel/AircraftFile.h"
struct FileMock {std::string text;size_t pos=0;int read(){return pos<text.size()?(unsigned char)text[pos++]:-1;}size_t readBytes(char*b,size_t n){size_t i=0;for(;i<n&&pos<text.size();i++)b[i]=text[pos++];return i;}bool seek(size_t n){if(n>text.size())return false;pos=n;return true;}size_t position(){return pos;}};

int main(){Place p{0,0};Flight f;JsonDocument d;
assert(!parseFlight(d,f,p,50,false,1800000000));
d["now"]=1800000000;auto ac=d["ac"].to<JsonArray>();
auto a=ac.add<JsonObject>();a["lat"]=.1;a["lon"]=.1;a["seen_pos"]=5;a["alt_baro"]=30000;a["track"]=225;a["gs"]=400;a["flight"]="TEST1 ";
assert(parseFlight(d,f,p,50,true,1800000000));assert(f.found&&f.approaching&&f.positionAt==1799999995);assert(abs(f.altitude-9144)<.01);assert(abs(f.speed-740.8)<.1);assert(string(f.callsign)=="TEST1");
a["track"]=45;assert(parseFlight(d,f,p,50,true,1800000000)&&!f.found);assert(parseFlight(d,f,p,50,false,1800000000)&&f.found);
a["seen_pos"]=100;assert(parseFlight(d,f,p,50,false,1800000000)&&!f.found);
a["seen_pos"]=1;a["alt_baro"]="ground";assert(parseFlight(d,f,p,50,false,1800000000)&&!f.found);
a["alt_baro"]=1000;a["lat"]=30;assert(parseFlight(d,f,p,50,false,1800000000)&&!f.found);
d["now"]=1799990000;assert(!parseFlight(d,f,p,50,false,1800000000));
d["now"]=1800000000;a["lat"]=.1;a["track"]=225;a["category"]="A7";a["desc"]="HELICOPTER";assert(parseFlight(d,f,p,50,false,1800000000)&&f.rotorcraft);assert(string(f.description)=="HELICOPTER");
a["category"]="A3";assert(parseFlight(d,f,p,50,false,1800000000)&&!f.rotorcraft);assert(airframeCategory(f.category)==Airframe::FixedWing);
a["category"]="A77";assert(parseFlight(d,f,p,50,false,1800000000)&&!f.rotorcraft&&airframeCategory(f.category)==Airframe::Unknown);
a.remove("category");assert(parseFlight(d,f,p,50,false,1800000000)&&!f.rotorcraft);assert(airframeCategory(f.category)==Airframe::Unknown);
for(const char *c:{"","A0","B1","A77","C1"})assert(airframeCategory(c)==Airframe::Unknown);
a["category"]="A7";auto b=ac.add<JsonObject>();b["lat"]=.01;b["lon"]=.01;b["seen_pos"]=2;b["alt_baro"]=1000;b["category"]="A3";assert(parseFlight(d,f,p,50,false,1800000000)&&!f.rotorcraft&&f.description[0]==0);
// SD parser must agree with the full-response parser, even when metadata follows ac.
std::string raw;serializeJson(d,raw);FileMock file{raw};Flight streamed;const char *why;
assert(readAircraftFile(file,streamed,p,50,false,1800000000,why));assert(streamed.found&&streamed.distance==f.distance);
std::string aircraft;serializeJson(d["ac"],aircraft);
file={"{\"ac\":"+aircraft+",\"extra\":{\"nested\":[1,2,3]},\"now\":1800000000}"};
assert(readAircraftFile(file,streamed,p,50,false,1800000000,why)&&streamed.distance==f.distance);
file={"{\"now\":1800000000,\"ac\":[]}"};assert(readAircraftFile(file,streamed,p,50,false,1800000000,why)&&streamed.checked&&!streamed.found);
for(std::string bad:{raw.substr(0,raw.size()-1),raw+"trailing",std::string("{}"),std::string("{\"now\":1,\"ac\":[]}")}){file={bad};assert(!readAircraftFile(file,streamed,p,50,false,1800000000,why));}
// Many records are read with the same fixed per-document RAM cap.
file={"{\"now\":1800000000,\"ac\":["};std::string record;serializeJson(d["ac"][1],record);
for(int i=0;i<1000;i++){if(i)file.text+=",";file.text+=record;}file.text+="]}";
cooperativeYields=0;assert(file.text.size()>24000);assert(readAircraftFile(file,streamed,p,50,false,1800000000,why)&&streamed.found);assert(cooperativeYields>50);
file={"{\"now\":1800000000,\"msg\":\""+std::string(20000,'x')+"\",\"ac\":[]}"};assert(!readAircraftFile(file,streamed,p,50,false,1800000000,why));
cout<<"PASS bounded SD parser: 1000 aircraft, root order, empty result, truncation, oversized string, stale source, reference equivalence\n";
cout<<"PASS flight selection, approach geometry, age, units, radius, ground filtering, source clock, rotorcraft classification, unknown categories, no metadata leakage\n";
}
