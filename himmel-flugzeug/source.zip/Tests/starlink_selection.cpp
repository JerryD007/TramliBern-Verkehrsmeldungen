#include "../WetterHimmel/StarlinkSelection.h"
#include <cassert>
#include <cstdio>
int main(){
  StarlinkSelection s;int selected=-1;
  double alt[]={-30,12,72,28,-2,NAN};
  for(int i=0;i<6;i++)if(s.consider(alt[i]))selected=i;
  assert(selected==2 && s.highest==72);
  assert(!s.consider(72));
  StarlinkSelection next;selected=-1;
  double moved[]={-10,65,-1,80,-40,NAN};
  for(int i=0;i<6;i++)if(next.consider(moved[i]))selected=i;
  assert(selected==3);
  StarlinkSelection below;assert(!below.consider(-0.01));assert(!below.consider(NAN));assert(below.highest==-90);
  puts("PASS: highest above horizon; replacement after motion; ties; all below horizon; nonfinite exclusion.");
}
