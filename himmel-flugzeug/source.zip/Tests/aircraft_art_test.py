from pathlib import Path
import json,subprocess,tempfile
r=Path(__file__).resolve().parents[1];data=json.loads((r/'Web/aircraft-art.json').read_text());models=data['models']
# Distinct narrow/wide/4-engine/prop/rotor profiles and bounded immutable primitives.
assert len(models)==26
assert len({json.dumps(x['ops']) for x in models[:23]})>=20
codes={}
for i,m in enumerate(models):
 for c in m['codes']:
  assert c not in codes;codes[c]=i
 for k,col,x,y,u,v,a,b in m['ops']:
  assert 0<=col<7 and 0<=x<320 and 0<=y<100
  if k==1:assert u>0 and v>0 and x+u<=320 and y+v<=100
  if k in (0,2):assert 0<=u<320 and 0<=v<100
  if k==0:assert 0<=a<320 and 0<=b<100
cases=[(c,False,False,i) for c,i in codes.items()]+[(' a320 ',False,False,2),('A320X',False,False,25),('A320 BAD',False,True,24),('',True,False,23),('',False,True,24),('',False,False,25),('<svg onload=alert(1)>',False,False,25)]
with tempfile.TemporaryDirectory() as t:
 p=Path(t)
 source='''#include <cassert>
#include "AircraftArt.h"
struct Painter{unsigned writes=0;void point(int x,int y){assert(x>=8&&x<218&&y>=80&&y<146);++writes;}
void fillRect(int x,int y,int w,int h,uint16_t){point(x,y);point(x+w-1,y+h-1);}
void fillTriangle(int x,int y,int u,int v,int a,int b,uint16_t){point(x,y);point(u,v);point(a,b);}
void drawLine(int x,int y,int u,int v,uint16_t){point(x,y);point(u,v);}
void fillCircle(int x,int y,int r,uint16_t){point(x-r,y-r);point(x+r,y+r);}};
int main(){
'''
 for code,rotor,fixed,expected in cases:source+='assert(AircraftArt::resolve(%s,%s,%s)==%d);\n'%(json.dumps(code),str(rotor).lower(),str(fixed).lower(),expected)
 source+='assert(AircraftArt::scheme("SWR123")==1);assert(AircraftArt::scheme("EZS94TH")==2);assert(AircraftArt::scheme("DLH123")==3);assert(AircraftArt::scheme("SWRABC")==0);assert(AircraftArt::scheme("SWR12","Lufthansa")==0);'
 source+='for(unsigned l=0;l<7;l++)for(unsigned i=0;i<26;i++){Painter p;AircraftArt::draw(p,i,8,80,210,l);assert(p.writes>0);}\n}'
 (p/'art.cpp').write_text(source);subprocess.run(['g++','-std=c++17','-I'+str(r/'WetterHimmel'),str(p/'art.cpp'),'-o',str(p/'art')],check=True);subprocess.run([str(p/'art')],check=True)
 js=(r/'Web/aircraft-art.js').read_text()+'\nconst assert=require("node:assert/strict");\n'
 for code,rotor,fixed,expected in cases:js+='assert.equal(AircraftArt.resolve(%s,%s,%s),%d);\n'%(json.dumps(code),str(rotor).lower(),str(fixed).lower(),expected)
 js+='assert.equal(AircraftArt.scheme("SWR123"),1);assert.equal(AircraftArt.scheme("EZS94TH"),2);assert.equal(AircraftArt.scheme("DLH123"),3);assert.equal(AircraftArt.scheme("SWRABC"),0);assert.equal(AircraftArt.scheme("SWR12","Lufthansa"),0);assert.equal(AircraftArt.scheme("HBJRH"),0);'
 js+='assert(!AircraftArt.svg({type:"<img src=x onerror=alert(1)>"}).includes("onerror"));assert(AircraftArt.svg({type:"B744"}).includes("B747"));'
 (p/'art.js').write_text(js);subprocess.run(['node',str(p/'art.js')],check=True)
# No external image fetches and no heap allocations in renderer.
h=(r/'WetterHimmel/AircraftArt.h').read_text();assert all(x not in h for x in ['malloc(','new ','String '])
web=(r/'WetterHimmel/WebPage.h').read_text();assert (r/'Web/aircraft-art.js').read_text() in web
assert "setHtmlIfChanged('flightProfile',f.found?AircraftImages.html(f):'')" in web
print('PASS: 94 exact codes + unknown/malformed input; C++/JS parity; all 26 drawings bounded; fixed flash geometry, no framebuffer; no untrusted SVG injection')
