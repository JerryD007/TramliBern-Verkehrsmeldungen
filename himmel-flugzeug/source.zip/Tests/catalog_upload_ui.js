const {JSDOM,VirtualConsole}=require('jsdom'),fs=require('fs'),path=require('path'),assert=require('assert');
const server=structuredClone(require('./fixtures/state.cjs'));server.starlinkCatalog={canImport:true,canRefresh:false,busy:false,stored:0,bytes:0,accepted:0,rejected:0,sdReady:true,phase:'Bereit',lastHttp:-1,lastTls:-32512,lastTlsText:'SSL allocation failed',lastError:'TLS Fehler',attemptAt:'11.11.2026 05:00',restored:true,next:'heute 08:00'};
const ctx=new Proxy({measureText:()=>({width:30})},{get:(o,k)=>o[k]||(()=>{}),set:(o,k,v)=>(o[k]=v,true)});
let received=0,calls=[],mode='ok',errors=[],windowRef;
const response=(status,data)=>({status,ok:status===200,text:async()=>typeof data==='string'?data:JSON.stringify(data)});
const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
const dom=new JSDOM(fs.readFileSync(path.join(__dirname,'../WetterHimmel/WebPage.h'),'utf8').split('R"WWHTML(')[1].split(')WWHTML"')[0],{url:'http://device.test',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
 windowRef=w;w.HTMLCanvasElement.prototype.getContext=()=>ctx;w.HTMLDialogElement.prototype.showModal=function(){this.open=true};w.HTMLDialogElement.prototype.close=function(){this.open=false};
 w.fetch=async(url,opt={})=>{
  if(url==='/api/state')return response(200,server);
  if(url==='/api/sky')return response(200,{stars:[],lines:[],deep:[]});
  assert(url.startsWith('/api/starlink/import?'),'unexpected endpoint '+url);
  assert.equal(opt.headers['X-WW-Token'],server.token);
  const q=new URL(url,'http://device.test').searchParams,op=q.get('op');calls.push(op);
  if(op==='start'){received=0;return response(200,{session:123,ok:true,received});}
  assert.equal(q.get('id'),'123');
  if(op==='chunk'){
   assert.equal(+q.get('offset'),received);assert(opt.body.byteLength<=4096);received+=opt.body.byteLength;
   if(mode==='cancel')windowRef.cancelCatalogImport();
   if(mode==='drop')throw Error('Verbindung abgebrochen');
   return response(200,{ok:true,received});
  }
  if(op==='finish'){if(mode==='reject')return response(400,'CSV ungültig');server.starlinkCatalog.stored=11199;return response(200,{ok:true,received});}
  if(op==='cancel')return response(200,{ok:true,received});
  throw Error(op);
 };
}});
(async()=>{
 const w=dom.window,d=w.document;await new Promise(r=>setTimeout(r,30));
 assert(d.getElementById('cataloginfo').textContent.includes('SSL allocation failed'));
 assert(d.getElementById('cataloginfo').textContent.includes('vorherigem Start'));
 const bytes=new Uint8Array(9000),file={size:bytes.length,slice:(a,b)=>({arrayBuffer:async()=>bytes.slice(a,b).buffer})};
 Object.defineProperty(d.getElementById('catalogfile'),'files',{configurable:true,value:[file]});
 await w.importCatalog();assert.deepEqual(calls,['start','chunk','chunk','chunk','finish']);assert.equal(received,9000);assert(d.getElementById('cataloguploadstatus').textContent.includes('gespeichert'));
 for(const failure of ['cancel','drop','reject']){mode=failure;calls=[];await w.importCatalog();assert(calls.includes('cancel'));assert(d.getElementById('cataloguploadstatus').textContent.includes('nicht bestätigt'));assert(!d.getElementById('catalogfile').disabled);}
 assert.deepEqual(errors,[]);console.log('PASS: authenticated local upload, 4096-byte chunks/order, import despite HTTPS cooldown, progress, confirmation, cancel/drop/rejection cleanup, persistent TLS history display.');w.close();
})().catch(e=>{console.error(e);dom.window.close();process.exitCode=1});
