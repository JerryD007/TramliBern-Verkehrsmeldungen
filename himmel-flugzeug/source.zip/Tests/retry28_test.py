from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1]
s='''#include "RetryPolicy.h"
#include "RouteSchedule.h"
#include <cassert>
int main(){uint32_t n=0;
assert(RetryPolicy::delta("120",n)&&n==120);assert(RetryPolicy::wait(n,5)==120);
assert(RetryPolicy::delta("0",n)&&n==1);
assert(!RetryPolicy::delta("",n));assert(!RetryPolicy::delta("-1",n));assert(!RetryPolicy::delta("12oops",n));
assert(RetryPolicy::delta("9999999999999999999999999",n)&&n==UINT32_MAX);
assert(RetryPolicy::wait(0,0)==60);assert(RetryPolicy::wait(0,1)==120);assert(RetryPolicy::wait(0,20)==3600);
assert(satelliteDelay(true,0)==7200);assert(satelliteDelay(false,0)==21600);
RouteSchedule s;s.begin("SWR1","123456",1000);s.finish(false,2000,true);
assert(!s.ready("SWR1","123456",2000));assert(s.ready("SWR1","123456",61000));
s.begin("SWR1","123456",61000);s.finish(false,62000);assert(!s.ready("SWR1","123456",180000));
}'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'t.cpp').write_text(s);subprocess.run(['g++','-std=c++17','-I'+str(r/'WetterHimmel'),str(p/'t.cpp'),'-o',str(p/'test')],check=True);subprocess.run([str(p/'test')],check=True)
net=(r/'WetterHimmel/Network.cpp').read_text()
assert 'nextAircraft=0;' in net and 'prefs.getLong64("airHold",0)' in net
assert 'RetryPolicy::wait(r.retrySeconds,aircraftLimited)' in net
assert 'time(nullptr)>=aircraftHoldUntil' in net
assert 'routeSchedule.finish(!r.error[0],now,r.httpStatus==429)' in net
print('PASS: explicit Retry-After, saturation, fallback escalation, no five-minute route floor for 429, retained satellite policy, persistent hold wiring')
# Execute the production HTTP-date conversion with the real astronomy library.
start=net.index('struct tm tm{};char *end=strptime')
end=net.index('\n    }}',start)
body=net[start:end]+'\n}'
body=body.replace('time(nullptr)','now')
source='''#include <ctime>
#include <string>
#include <cstdint>
#include <algorithm>
#include <cassert>
#include "src/astro/astronomy.h"
using std::min;using std::max;
uint32_t parse(std::string retry,time_t now,bool flightSource){uint32_t seconds=0,retrySeconds=flightSource?0:7200;
'''+body+'''
return retrySeconds;}
int main(){time_t now=1795417200; // 2026-11-23 07:00:00 UTC
assert(parse("Mon, 23 Nov 2026 07:02:00 GMT",now,true)==120);
assert(parse("Mon, 23 Nov 2026 06:59:00 GMT",now,true)==1);
assert(parse("Mon, 23 Nov 2026 07:02:00 GMT junk",now,true)==0);
assert(parse("bad date",now,true)==0);
assert(parse("Mon, 23 Nov 2026 07:02:00 GMT",now,false)==7200);
}'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'d.cpp').write_text(source)
 subprocess.run(['gcc','-O2','-c',str(r/'WetterHimmel/src/astro/astronomy.c'),'-o',str(p/'astro.o')],check=True)
 subprocess.run(['g++','-std=c++17','-I'+str(r/'WetterHimmel'),str(p/'d.cpp'),str(p/'astro.o'),'-lm','-o',str(p/'dates')],check=True)
 subprocess.run([str(p/'dates')],check=True)
print('PASS: production HTTP-date conversion, future/past/invalid/trailing data, satellite minimum')
