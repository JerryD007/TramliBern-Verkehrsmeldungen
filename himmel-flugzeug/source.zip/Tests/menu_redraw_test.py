from pathlib import Path
import subprocess,tempfile
p=Path(__file__).resolve().parents[1]/'WetterHimmel'
s=(p/'Screen.cpp').read_text();a=s.index('void uiDraw() {');b=s.index('  bool same=',a);gate=s[a:b]
code=r'''
#include <string>
#include <ctime>
#include <cstdint>
#include <cassert>
#include <cstdio>
#include <algorithm>
using std::max;uint32_t renderMaxUs=0;uint32_t micros(){return 0;}
class String:public std::string{public:using std::string::string;String(const std::string&s):std::string(s){}String(long n):std::string(std::to_string(n)){}String(int n):std::string(std::to_string(n)){}String(bool b):std::string(b?"1":"0"){} };
String objectQuery;int objectOffset=0;struct {bool largeMap=false;}extra;
static time_t now=1000;time_t testTime(time_t*){return now;}
#define time testTime
bool keptPlanet=false;int selected=-1,objectCount=9;uint32_t generation=0;int page=1,headers=0,redraws=0;uint32_t surfaceRevision=0;bool displayNight=false,satPaused=false;
struct {void startWrite(){}void endWrite(){}}lcd;
struct {int status(){return 3;}}WiFi;
struct {bool valid=false;long fetched=0;String error;}weather;
struct Place{String name="Bern";};struct Wifi{String ssid="WiFi";};
struct {int brightness=180,autoSeconds=0,place=0,placeCount=1,wifiCount=1;bool labels=true,lines=true,milky=true,satellites=true;Place places[2];Wifi wifi[2];}cfg;
struct {bool valid=false;long rise=0;char error[80]{};}satellites[3];
String message="Verbunden",nearby[2]={"A","B"};int nearbyCount=1;
bool clockReady(){return true;}String stamp(long t){return std::to_string(t);}void header(){headers++;}
'''+gate+r'''
 keptPlanet=samePlanet;lastPlace=cfg.place;lastPage=page;lastNight=displayNight;lastMinute=time(nullptr)/60;lastWifi=WiFi.status();redraws++;
}
int main(){uiDraw();assert(redraws==1);for(int i=0;i<25;i++){now++;uiDraw();}assert(redraws==1);
 page=6;uiDraw();int baseline=redraws;for(int i=0;i<25;i++){now++;uiDraw();}assert(redraws==baseline);
 cfg.labels=false;uiDraw();assert(redraws==baseline+1);surfaceRevision++;uiDraw();assert(redraws==baseline+2);
 page=2;uiDraw();baseline=redraws;uiDraw();assert(redraws==baseline);nearby[0]="changed";uiDraw();assert(redraws==baseline+1);
 page=3;uiDraw();baseline=redraws;cfg.wifi[0].ssid="new";uiDraw();assert(redraws==baseline+1);
 displayNight=true;uiDraw();assert(redraws==baseline+2);
 page=8;selected=7;uiDraw();assert(!keptPlanet);uiDraw();assert(keptPlanet);
 now+=60;uiDraw();assert(keptPlanet);selected=6;uiDraw();assert(!keptPlanet);
 uiDraw();assert(keptPlanet);generation++;uiDraw();assert(!keptPlanet);
 puts("PASS: production menu gate ignores repeated background dirty updates; page, touch, visible settings, scan results, saved WLAN and night changes redraw.");}
'''
with tempfile.TemporaryDirectory() as tmp:
 f=Path(tmp)/'test.cpp';f.write_text(code);out=Path(tmp)/'test';subprocess.run(['g++','-std=c++17',str(f),'-o',str(out)],check=True);subprocess.run([str(out)],check=True)
