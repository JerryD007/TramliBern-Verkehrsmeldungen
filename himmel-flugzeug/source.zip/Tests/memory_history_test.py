from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[1]/'WetterHimmel'
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);(p/'freertos').mkdir()
 (p/'freertos/FreeRTOS.h').write_text('''#pragma once
#include <cstdint>
using portMUX_TYPE=int;
#define portMUX_INITIALIZER_UNLOCKED 0
#define portENTER_CRITICAL_SAFE(x) ((void)0)
#define portEXIT_CRITICAL_SAFE(x) ((void)0)
#define portTICK_PERIOD_MS 1
''')
 (p/'freertos/task.h').write_text('''#pragma once
using TaskHandle_t=void*;
extern TaskHandle_t currentTask;
inline TaskHandle_t xTaskGetCurrentTaskHandle(){return currentTask;}
inline const char* pcTaskGetName(TaskHandle_t t){return t==(void*)1?"network":"otherTaskNameLongerThan20Characters";}
inline unsigned xTaskGetTickCount(){return 1234;}
''')
 (p/'esp_heap_caps.h').write_text('''#pragma once
#include <cstddef>
#include <cstdint>
#define ESP_OK 0
using esp_alloc_failed_hook_t=void(*)(size_t,uint32_t,const char*);
extern esp_alloc_failed_hook_t hook;
inline int heap_caps_register_failed_alloc_callback(esp_alloc_failed_hook_t h){hook=h;return 0;}
''')
 (p/'test.cpp').write_text('''#include <cassert>
#include <cstring>
#include "esp_heap_caps.h"
#include "freertos/task.h"
#include "MemoryProbe.h"
TaskHandle_t currentTask=(void*)1;esp_alloc_failed_hook_t hook=nullptr;
int main(){memoryProbeInit();MemoryFailureEvent events[4];assert(memoryFailureHistory(events,4)==0);
 hook(10,4,"initial");memoryProbeBegin();memoryProbePhase(2);hook(1492,0x1800,"heap_caps_malloc");currentTask=(void*)2;hook(2308,0x1800,"other_allocator_name_longer_than_buffer");auto p=memoryProbeEnd();assert(p.worker.count==1&&p.other.count==1);
 assert(memoryFailureHistory(events,4)==3);assert(events[0].phase==0&&!events[0].worker);assert(events[1].bytes==1492&&events[1].worker&&events[1].phase==2);assert(events[2].uptimeMs==1234&&!events[2].worker);assert(strlen(events[2].task)==19);assert(strlen(events[2].allocator)==23);
 hook(3,1,"a");hook(4,1,"b");hook(5,1,"c");assert(memoryFailureHistory(events,4)==4);assert(events[0].bytes==2308&&events[3].bytes==5);assert(memoryFailureTotal()==6);assert(memoryFailureHistory(events,2)==2&&events[0].bytes==4&&events[1].bytes==5);memoryProbeBegin();memoryProbeEnd();assert(memoryFailureHistory(events,4)==4);}
''')
 subprocess.run(['g++','-std=c++17','-I'+str(p),'-I'+str(root),str(p/'test.cpp'),str(root/'MemoryProbe.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
 print('PASS bounded allocation history: chronology, last 4, request phases, other task, bounded names, survives next request, total count')
