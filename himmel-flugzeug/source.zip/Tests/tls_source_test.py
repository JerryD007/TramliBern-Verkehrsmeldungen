from pathlib import Path
import json,hashlib,re
root=Path(__file__).resolve().parents[1];tls=root/'WetterHimmel/src/tls';meta=json.loads((tls/'UPSTREAM.json').read_text())
assert len(meta['source_sha256'])==18
for name,digest in meta['source_sha256'].items():
 raw=(tls/name).read_bytes();prefix=b'#include "HimmelTlsConfig.h"\n';assert raw.startswith(prefix);assert hashlib.sha256(raw[len(prefix):]).hexdigest()==digest,name
config=(tls/'HimmelTlsConfig.h').read_text()
assert '#define CONFIG_MBEDTLS_SSL_OUT_CONTENT_LEN 4096' in config
assert '#define CONFIG_MBEDTLS_SSL_IN_CONTENT_LEN 16384' in config
assert 'ESP_ARDUINO_VERSION_VAL(3,3,0)' in config
assert 'MBEDTLS_SSL_VERIFY_NONE' not in config
assert 'setInsecure(' not in (root/'WetterHimmel/TlsDiagnostic.h').read_text()
print('PASS: all 18 TLS units are pinned upstream + configuration include only; RX 16384 / TX 4096; core guard; certificate verification retained')
