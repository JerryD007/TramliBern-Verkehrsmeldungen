let hangarPending=false,hangarCursor=null,hangarRows=[];
function hangarDate(t){return Number.isFinite(t)&&t>0?new Date(t*1000).toLocaleString('de-CH'):'Unbekannt';}
async function openHangar(){if($('settings').open)$('settings').close();$('hangarDialog').showModal();await loadHangar(false,false);}
async function loadHangar(next,force=true){if(hangarPending)return;++hangarRouteGeneration;hangarSelected=null;const request={action:'hangar',force,search:$('hangarSearch').value.trim(),sort:$('hangarSort').value};if(next&&hangarCursor)Object.assign(request,{cursorHex:hangarCursor.hex,cursorLast:hangarCursor.last,cursorPasses:hangarCursor.passes});if(!await act(request))return;hangarPending=true;$('hangarStatus').textContent='Hangar wird von SD geladen …';$('hangarNext').disabled=true;await pollHangar();}
async function pollHangar(){if(!hangarPending)return;try{const r=await fetchTimed('/api/hangar',{cache:'no-store'});if(!r.ok)return;const data=await r.json();if(!data.ready){$('hangarStatus').textContent=`Hangar wird von SD geladen … ${data.scanned||0} geprüft`;return;}hangarPending=false;const list=$('hangarRows');list.replaceChildren();$('hangarDetail').replaceChildren();hangarRows=Array.isArray(data.rows)?data.rows:[];
 $('hangarStatus').textContent=data.error?'Hangar nicht verfügbar · '+data.error:`${data.total||0} passende Flugzeuge${data.damaged?' · '+data.damaged+' beschädigte Datensätze übersprungen':''}`;
 $('hangarStatus').classList.toggle('stale',!!data.error||!!data.damaged);
 for(const f of hangarRows){const b=radarNode('button',null,'radarRow');b.type='button';b.append(radarNode('strong',f.registration||f.hex),radarNode('span',`${f.callsign||'Kein Rufzeichen'} · ${f.type||'Typ unbekannt'}`),radarNode('span',`${f.passes} Überflüge · zuletzt ${hangarDate(f.last)}`));f.routeNode=radarNode('span','Gespeicherte Route wird geladen …');b.append(f.routeNode);b.onclick=()=>showHangarDetail(f);list.append(b);}
 if(!hangarRows.length&&!data.error)list.append(radarNode('p','Noch keine passenden gespeicherten Flugzeuge.'));
 void loadHangarRoutes(hangarRows);hangarCursor=hangarRows.at(-1)||null;$('hangarNext').disabled=!data.more||!!data.error;
 }catch(e){$('hangarStatus').textContent='Hangarabruf unterbrochen · erneuter Versuch folgt';}}
function showHangarDetail(f){hangarSelected=f;const d=$('hangarDetail');d.replaceChildren();d.append(radarNode('h3',f.registration||f.hex));for(const[k,v]of[['ICAO',f.hex],['Registrierung',f.registration||'Nicht verfügbar'],['Letztes Rufzeichen',f.callsign||'Nicht verfügbar'],['Typ',f.type||'Nicht verfügbar'],['Erste Erfassung',hangarDate(f.first)],['Letzte Erfassung',hangarDate(f.last)],['Überflüge',String(f.passes)]])d.append(radarNode('p',k+': '+v));d.append(radarNode('p',hangarRouteText(f)));if(f.savedRoute){const r=f.savedRoute;d.append(radarNode('p',`Rufzeichen ${r.callsign} · Überflug ${r.pass} · abgerufen ${hangarDate(r.received)} · nicht live bestätigt`));if(r.airline)d.append(radarNode('p','Fluggesellschaft laut Routenkatalog: '+r.airline));}}
setInterval(()=>{if($('hangarDialog').open)pollHangar();},2000);
// Routes come from the device's SD history, not from a new external lookup.
let hangarRouteGeneration=0,hangarSelected=null;
function hangarRouteText(f){const r=f.savedRoute;return r?`${r.originName? r.originName+' ':''}(${r.origin}) → ${r.destinationName? r.destinationName+' ':''}(${r.destination}) · gespeicherte Katalogroute`:f.routeError||'Keine gespeicherte Route für diesen Überflug';}
function renderHangarRoute(f){if(f.routeNode)f.routeNode.textContent=hangarRouteText(f);if(hangarSelected===f)showHangarDetail(f);}
async function loadHangarRoutes(rows){const generation=++hangarRouteGeneration;
 for(const f of rows){
  for(let attempt=0;attempt<3;attempt++){
   if(generation!==hangarRouteGeneration||!$('hangarDialog').open)return;
   try{const response=await fetchTimed('/api/hangar-route?hex='+encodeURIComponent(f.hex),{cache:'no-store'});
    if(!response.ok)throw new Error('SD-Abruf nicht verfügbar');
    const r=await response.json();if(generation!==hangarRouteGeneration)return;
    f.savedRoute=r.found&&r.hex===f.hex&&r.callsign===f.callsign&&r.pass===f.passes?r:null;
    f.routeError=r.error?'Route nicht lesbar · '+r.error:'';renderHangarRoute(f);break;
   }catch(e){if(attempt===2){f.routeError='Route derzeit nicht abrufbar · Aktualisieren';renderHangarRoute(f);}else await new Promise(resolve=>setTimeout(resolve,2000));}
  }
 }
}
