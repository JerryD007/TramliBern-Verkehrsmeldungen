let hangarPending=false,hangarCursor=null,hangarRows=[];
function hangarDate(t){return Number.isFinite(t)&&t>0?new Date(t*1000).toLocaleString('de-CH'):'Unbekannt';}
async function openHangar(){if($('settings').open)$('settings').close();$('hangarDialog').showModal();await loadHangar(false);}
async function loadHangar(next){if(hangarPending)return;const request={action:'hangar',search:$('hangarSearch').value.trim(),sort:$('hangarSort').value};if(next&&hangarCursor)Object.assign(request,{cursorHex:hangarCursor.hex,cursorLast:hangarCursor.last,cursorPasses:hangarCursor.passes});if(!await act(request))return;hangarPending=true;$('hangarStatus').textContent='Hangar wird von SD geladen …';$('hangarNext').disabled=true;await pollHangar();}
async function pollHangar(){if(!hangarPending)return;try{const r=await fetchTimed('/api/hangar',{cache:'no-store'});if(!r.ok)return;const data=await r.json();if(!data.ready)return;hangarPending=false;const list=$('hangarRows');list.replaceChildren();$('hangarDetail').replaceChildren();hangarRows=Array.isArray(data.rows)?data.rows:[];
 $('hangarStatus').textContent=data.error?'Hangar nicht verfügbar · '+data.error:`${data.total||0} passende Flugzeuge${data.damaged?' · '+data.damaged+' beschädigte Datensätze übersprungen':''}`;
 $('hangarStatus').classList.toggle('stale',!!data.error||!!data.damaged);
 for(const f of hangarRows){const b=radarNode('button',null,'radarRow');b.type='button';b.append(radarNode('strong',f.registration||f.hex),radarNode('span',`${f.callsign||'Kein Rufzeichen'} · ${f.type||'Typ unbekannt'}`),radarNode('span',`${f.passes} Überflüge · zuletzt ${hangarDate(f.last)}`));b.onclick=()=>showHangarDetail(f);list.append(b);}
 if(!hangarRows.length&&!data.error)list.append(radarNode('p','Noch keine passenden gespeicherten Flugzeuge.'));
 hangarCursor=hangarRows.at(-1)||null;$('hangarNext').disabled=!data.more||!!data.error;
 }catch(e){$('hangarStatus').textContent='Hangarabruf unterbrochen · erneuter Versuch folgt';}}
function showHangarDetail(f){const d=$('hangarDetail');d.replaceChildren();d.append(radarNode('h3',f.registration||f.hex));for(const[k,v]of[['ICAO',f.hex],['Registrierung',f.registration||'Nicht verfügbar'],['Letztes Rufzeichen',f.callsign||'Nicht verfügbar'],['Typ',f.type||'Nicht verfügbar'],['Erste Erfassung',hangarDate(f.first)],['Letzte Erfassung',hangarDate(f.last)],['Überflüge',String(f.passes)]])d.append(radarNode('p',k+': '+v));}
setInterval(()=>{if($('hangarDialog').open)pollHangar();},2000);
