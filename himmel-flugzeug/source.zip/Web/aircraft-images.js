const AircraftImages=(()=>{const sprites=[{"name":"SWISS","profile":2,"livery":1},{"name":"easyJet","profile":2,"livery":2},{"name":"Lufthansa","profile":2,"livery":3},{"name":"KLM","profile":13,"livery":4},{"name":"British Airways","profile":13,"livery":5},{"name":"Emirates","profile":7,"livery":6},{"name":"REGA","profile":22,"livery":7}];
const cache=new Map(),retryAfter=new Map();
function select(profile,livery){return sprites.findIndex(s=>s.profile===profile&&s.livery===livery);}
function decode(bytes){
 if(bytes.length<33||bytes.length>32+210*66)throw Error('Bildformat');
 const pixels=new Uint8ClampedArray(210*66*4);let x=0,y=0,pos=0;
 for(let i=32;i<bytes.length;i++){const n=(bytes[i]>>4)+1,idx=(bytes[i]&15)*2,c=bytes[idx]|(bytes[idx+1]<<8);
  if(y>=66||x+n>210)throw Error('Bildgrenze');
  for(let k=0;k<n;k++){pixels[pos++]=(c>>11)*255/31;pixels[pos++]=((c>>5)&63)*255/63;pixels[pos++]=(c&31)*255/31;pixels[pos++]=255;}
  x+=n;if(x===210){x=0;y++;}
 }if(y!==66||x!==0)throw Error('Bild unvollständig');return pixels;
}
function html(f){const profile=AircraftArt.resolve(f.type,f.rotorcraft,/^A[1-6]$/.test(f.category||''));
 const livery=AircraftArt.scheme(f.callsign,f.airline||f.operator||'');const i=select(profile,livery);
 if(i<0)return AircraftArt.svg(f);
 return '<span class="aircraftAsset"><canvas data-aircraft-image="'+i+'" width="210" height="66" style="width:100%;height:auto" hidden role="img" aria-label="'+sprites[i].name+' · Illustration"></canvas><span data-aircraft-fallback>'+AircraftArt.svg(f)+'</span><small hidden data-aircraft-caption>'+sprites[i].name+' · Illustration, Lackierung nicht bestätigt</small></span>';
}
async function paint(canvas){const id=Number(canvas.dataset.aircraftImage);if(!Number.isInteger(id)||id<0||id>=sprites.length||canvas.dataset.loading||canvas.dataset.ready||Date.now()<(retryAfter.get(id)||0))return;
 canvas.dataset.loading='1';
 try{
  if(!cache.has(id))cache.set(id,(async()=>{const r=await fetch('/api/aircraft-image?id='+id);if(!r.ok)throw Error('Bild nicht bereit');return decode(new Uint8Array(await r.arrayBuffer()));})());
  const pixels=await cache.get(id);if(!canvas.isConnected)return;
  const ctx=canvas.getContext('2d'),data=ctx.createImageData(210,66);data.data.set(pixels);ctx.putImageData(data,0,0);
  canvas.hidden=false;canvas.dataset.ready='1';const parent=canvas.parentElement;parent.querySelector('[data-aircraft-fallback]').hidden=true;parent.querySelector('[data-aircraft-caption]').hidden=false;
 }catch(e){cache.delete(id);retryAfter.set(id,Date.now()+5000);}finally{delete canvas.dataset.loading;}
}
function scan(){if(typeof document==='undefined'||!document)return;document.querySelectorAll('canvas[data-aircraft-image]').forEach(paint);}
if(typeof document!=='undefined'){
 const start=()=>{new MutationObserver(scan).observe(document.body,{childList:true,subtree:true});setInterval(scan,5000);scan();};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
}
return {html,select,decode};})();
