/* Pure geometry/selection model, shared by browser and host tests. */
(function(root){
 'use strict';
 const num=v=>typeof v==='number'&&Number.isFinite(v), rad=Math.PI/180;
 const text=v=>typeof v==='string'?v.replace(/[\x00-\x1f\x7f]/g,'').trim().slice(0,80):'';
 function geometry(a,b,c,d){const x=a*rad,y=c*rad,z=(d-b)*rad,h=Math.sin((y-x)/2)**2+Math.cos(x)*Math.cos(y)*Math.sin(z/2)**2;return {distance:12742.0176*Math.asin(Math.sqrt(Math.max(0,Math.min(1,h)))),bearing:(Math.atan2(Math.sin(z)*Math.cos(y),Math.cos(x)*Math.sin(y)-Math.sin(x)*Math.cos(y)*Math.cos(z))/rad+360)%360};}
 function normalize(data,meta){
  if(!data||!Array.isArray(data.ac)||!num(data.now)||!num(meta.lat)||!num(meta.lon)||Math.abs(meta.lat)>90||Math.abs(meta.lon)>180||!num(meta.received)||!num(meta.radius)||meta.radius<5||meta.radius>200)throw Error('Radarformat ungültig');
  const source=data.now>1e12?data.now/1000:data.now;
  if(source<meta.received-120||source>meta.received+30||(data.msg!=null&&data.msg!=='No error'))throw Error('Radarquellzeit ungültig');
  const unique=new Map();
  for(const a of data.ac){
   if(!a||!num(a.lat)||!num(a.lon)||Math.abs(a.lat)>90||Math.abs(a.lon)>180||!num(a.seen_pos)||a.seen_pos<0||a.seen_pos>60||meta.received-(source-a.seen_pos)>60||a.alt_baro==='ground')continue;
   const hex=text(a.hex).toLowerCase();if(!/^[0-9a-f]{6}$/.test(hex))continue;
   const g=geometry(meta.lat,meta.lon,a.lat,a.lon);if(g.distance>meta.radius)continue;
   const f={hex,callsign:text(a.flight),type:text(a.t),registration:text(a.r),operator:text(a.ownOp),description:text(a.desc),category:text(a.category),lat:a.lat,lon:a.lon,...g,positionAt:source-a.seen_pos,received:meta.received,track:num(a.track)&&a.track>=0&&a.track<360?a.track:null,speed:num(a.gs)&&a.gs>=0&&a.gs<=2000?a.gs*1.852:null,altitude:num(a.alt_baro)&&a.alt_baro>=-2000&&a.alt_baro<=100000?a.alt_baro*.3048:null};
   if(!unique.has(hex)||f.positionAt>unique.get(hex).positionAt)unique.set(hex,f);
  }
  return [...unique.values()].sort((a,b)=>a.distance-b.distance||a.hex.localeCompare(b.hex));
 }
 const direction=b=>!num(b)?'unbekannt':['N','NO','O','SO','S','SW','W','NW'][Math.round(b/45)%8];
 const point=(f,r)=>({x:250+210*f.distance/r*Math.sin(f.bearing*rad),y:250-210*f.distance/r*Math.cos(f.bearing*rad)});
 const fresh=(f,now)=>!!f&&now-f.positionAt<=90&&now-f.received<=90&&f.positionAt<=now+30;
 const api={normalize,geometry,direction,point,fresh};root.RadarModel=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window==='undefined'?globalThis:window);
