let radarRows=[],radarMeta=null,radarKey='',radarBusy=false,radarSelected='',radarPinned='',radarLast=null,radarFailure='',radarFetchedAt=0,radarClock=0,radarClockAt=performance.now();
try{const p=localStorage.getItem('hf-pinned-flight');if(/^[0-9a-f]{6}$/.test(p||''))radarPinned=radarSelected=p;}catch(e){}
const radarNow=()=>radarClock+(performance.now()-radarClockAt)/1000;
function radarSelect(hex){if(radarPinned&&radarPinned!==hex){radarPinned='';try{localStorage.removeItem('hf-pinned-flight');}catch(e){}}radarSelected=hex;radarLast=radarRows.find(f=>f.hex===hex)||radarLast;renderRadar();$('radarDetails').scrollIntoView({block:'nearest',behavior:'smooth'});}
function radarPin(){if(!radarSelected)return;radarPinned=radarPinned===radarSelected?'':radarSelected;try{if(radarPinned)localStorage.setItem('hf-pinned-flight',radarPinned);else localStorage.removeItem('hf-pinned-flight');}catch(e){}renderRadar();}
function radarNode(tag,txt,cls){const n=document.createElement(tag);if(txt!=null)n.textContent=txt;if(cls)n.className=cls;return n;}
function renderRadar(){
 rememberRadarRoute(state?.flight);
 const now=radarNow(),radius=radarMeta?.radius||state?.modern?.radius||50;
 const selected=radarRows.find(f=>f.hex===(radarPinned||radarSelected));
 if(selected){radarSelected=selected.hex;radarLast=selected;}
 else if(!radarPinned&&!radarSelected&&radarRows.length){radarSelected=radarRows[0].hex;radarLast=radarRows[0];}
 const svg=$('radarSvg');svg.replaceChildren();const ns='http://www.w3.org/2000/svg';
 function el(tag,attrs,txt){const n=document.createElementNS(ns,tag);Object.entries(attrs).forEach(([k,v])=>n.setAttribute(k,v));if(txt)n.textContent=txt;svg.append(n);return n;}
 for(let i=1;i<=4;i++){el('circle',{cx:250,cy:250,r:210*i/4,fill:'none',stroke:'#36575b'});el('text',{x:255,y:250-210*i/4+15,fill:'#aaa','font-size':13},formatMetric(radius*i/4,'km',1));}
 el('path',{d:'M250 40V460M40 250H460',stroke:'#36575b','stroke-dasharray':'4 5'});
 for(const [t,x,y] of [['N',250,22],['O',482,255],['S',250,488],['W',18,255]])el('text',{x,y,fill:'#fff','text-anchor':'middle','font-size':20},t);
 el('circle',{cx:250,cy:250,r:5,fill:'#fff'});
 for(const f of radarRows){const p=RadarModel.point(f,radius),active=f.hex===radarSelected,color=!RadarModel.fresh(f,now)?'#ff5159':active?'#ffe12d':'#00e5dc';
  el('circle',{cx:p.x,cy:p.y,r:active?15:9,fill:'#000',stroke:color,'stroke-width':active?3:1});
  const transform=`translate(${p.x} ${p.y}) rotate(${f.track??0})`;
  if(f.category==='A7'){
   el('path',{d:'M-3 -7Q0 -11 3 -7L3 3L1 5L1 11H-1V5L-3 3Z',transform,fill:'#f23845',stroke:'#fff','stroke-width':1});
   el('path',{d:'M-9 -4L9 2M-7 6L7 -8M-4 10H4',transform,fill:'none',stroke:'#fff','stroke-width':1.6});
  }else{
   const d=f.track==null?'M0 -6L6 0L0 6L-6 0Z':'M0 -10L-7 7L0 3L7 7Z';
   el('path',{d,transform,fill:color,stroke:color,'stroke-width':2});
  }
 }
 $('radarStatus').textContent=radarFailure||(!radarMeta?'Warte auf SD-Flugdaten':`${radarRows.length} Luftfahrzeuge · Aufnahme vor ${Math.max(0,Math.floor(now-radarMeta.received))} s · Norden oben`);
 $('radarStatus').classList.toggle('stale',!!radarFailure||!!radarMeta&&now-radarMeta.received>90);
 const list=$('radarList');const listKey=radarRows.map(f=>f.hex).join(',');if(list.dataset.key!==listKey){list.replaceChildren();list.dataset.key=listKey;}
 if(!radarRows.length){list.replaceChildren();list.append(radarNode('p',radarMeta?'Keine geeigneten Positionen in dieser Aufnahme. Empfangslücken sind möglich.':'Noch keine Radaraufnahme. Für die vollständige Flugtafel ist die SD-Karte erforderlich.'));}
 for(const f of radarRows){let b=document.getElementById('radar-'+f.hex);if(!b){b=radarNode('button',null,'radarRow');b.id='radar-'+f.hex;list.append(b);}b.replaceChildren();b.type='button';b.setAttribute('aria-pressed',String(f.hex===radarSelected));b.onclick=()=>radarSelect(f.hex);b.append(radarNode('strong',(f.category==='A7'?'Helikopter · ':'')+(f.callsign||f.registration||f.hex)),radarNode('span',`${formatMetric(f.distance,'km',1)} · ${RadarModel.direction(f.bearing)} ${Math.round(f.bearing)}°`),radarNode('span',`${formatMetric(f.altitude,'m')} barom. · vor ${Math.max(0,Math.floor(now-f.positionAt))} s${RadarModel.fresh(f,now)?'':' · VERALTET'}`));}
 const f=radarLast?.hex===(radarPinned||radarSelected)?radarLast:null;
 $('radarDetailName').textContent=f?(f.callsign||f.registration||f.hex):radarPinned?'Verfolgter Flug: '+radarPinned:'Flug auf Radar oder Flugtafel auswählen';
 $('radarPin').disabled=!radarSelected;$('radarPin').textContent=radarPinned?'Verfolgung beenden':'Flug verfolgen';
 const detail=$('radarDetailBody');detail.replaceChildren();
 if(!f){detail.append(radarNode('p',radarPinned?'Noch keine Position dieses Fluges in der aktuellen Sitzung.':''));return;}
 const cached=radarRoutes.get(f.hex+'|'+f.callsign),nearest=state?.flight;
 const route=cached&&now>=cached.received&&now-cached.received<21600?cached:null;
 const profile=radarNode('div',null,'aircraftProfile');profile.innerHTML=AircraftImages.html({...f,airline:route?.airline||''});detail.append(profile);
 const lost=!radarRows.some(x=>x.hex===f.hex)||!RadarModel.fresh(f,now);
 detail.append(radarNode('p',lost?`Kontakt verloren / veraltet · letzte Position ${new Date(f.positionAt*1000).toLocaleString('de-CH')} · vor ${Math.max(0,Math.floor(now-f.positionAt))} s`:`Position vor ${Math.max(0,Math.floor(now-f.positionAt))} s`,lost?'stale':''));
 const grid=radarNode('div',null,'radarMetrics');
 for(const [k,v] of [['Hier suchen',`${RadarModel.direction(f.bearing)} · ${formatMetric(f.bearing,'°')} · ${formatMetric(f.distance,'km',1)}`],['Bewegt sich nach',`${RadarModel.direction(f.track)} · ${formatMetric(f.track,'°')}`],['Barometrische Höhe',formatMetric(f.altitude,'m')],['Geschwindigkeit über Grund',formatMetric(f.speed,'km/h')],['Typ',[f.type,f.description].filter(Boolean).join(' · ')||'Nicht verfügbar'],['Registrierung',f.registration||'Nicht verfügbar'],['Betreiber (Quelldaten)',f.operator||'Nicht verfügbar'],['ICAO-Kennung',f.hex]]){const cell=radarNode('div');cell.append(radarNode('span',k),radarNode('strong',v));grid.append(cell);}detail.append(grid);

 detail.append(radarNode('p',route?`${route.originName?route.originName+" ("+route.origin+")":route.origin} → ${route.destinationName?route.destinationName+" ("+route.destination+")":route.destination} · Katalogroute, nicht live bestätigt`:'Route nicht verfügbar · Start und Ziel nicht bestätigt.','flightRoute'));
 if(route?.airline)detail.append(radarNode('p','Fluggesellschaft laut Routenkatalog: '+route.airline));
 const btn=radarNode('button','Route dieses Fluges abfragen');btn.type='button';btn.disabled=lost||!/^[A-Z0-9]{3,8}$/.test(f.callsign)||!!radarRoutePending;btn.onclick=()=>radarRequestRoute(f);detail.append(btn);
 detail.append(radarNode('p','Richtung und Position sind ADS-B-Daten, keine Sichtbarkeitsgarantie. Die barometrische Höhe ist keine Höhe über deinem Standort.','small'));
}
$('radarSvg').onclick=e=>{if(!radarMeta)return;const b=e.currentTarget.getBoundingClientRect(),scale=b.width/500,x=(e.clientX-b.left)/scale,y=(e.clientY-b.top)/scale;let best=null,d=24/scale;for(const f of radarRows){const p=RadarModel.point(f,radarMeta.radius),n=Math.hypot(p.x-x,p.y-y);if(n<d){d=n;best=f;}}if(best)radarSelect(best.hex);};
$('radarPin').onclick=radarPin;
const radarRoutes=new Map();let radarRoutePending=null;
function rememberRadarRoute(f){
 if(!f||f.routeStatus!=='catalogue'||!f.origin||!f.destination||!/^[0-9a-f]{6}$/.test(f.hex||'')||!/^[A-Z0-9]{3,8}$/.test(f.callsign||''))return;
 if(!Number.isFinite(f.routeReceived)||f.routeReceived<=0)return;
 const key=f.hex+'|'+f.callsign,old=radarRoutes.get(key);
 if(old&&old.received>=f.routeReceived)return;
 radarRoutes.set(key,{hex:f.hex,callsign:f.callsign,origin:f.origin,destination:f.destination,originName:f.originName,destinationName:f.destinationName,airline:f.airline,received:f.routeReceived});
 if(radarRoutes.size>32)radarRoutes.delete(radarRoutes.keys().next().value);
}

async function radarRequestRoute(f){if(radarRoutePending)return;const wanted={hex:f.hex,callsign:f.callsign,until:performance.now()+180000};if(await act({action:'webRoute',callsign:f.callsign,hex:f.hex})){radarRoutePending=wanted;$('radarRouteStatus').textContent='Routenabfrage vorgemerkt …';renderRadar();}}
async function radarPollRoute(){if(!radarRoutePending)return;if(performance.now()>radarRoutePending.until){radarRoutePending=null;$('radarRouteStatus').textContent='Routenabfrage: Zeitlimit erreicht · bitte erneut versuchen';renderRadar();return;}try{const r=await fetchTimed('/api/flight-route',{cache:'no-store'});if(!r.ok)return;const d=await r.json(),w=radarRoutePending;if(!w)return;if(d.found&&d.hex===w.hex&&d.callsign===w.callsign){radarRoutes.set(d.hex+'|'+d.callsign,d);if(radarRoutes.size>32)radarRoutes.delete(radarRoutes.keys().next().value);radarRoutePending=null;$('radarRouteStatus').textContent='Katalogroute geladen.';}else if(d.error&&d.error!=='Routenabfrage vorgemerkt'||performance.now()>w.until){radarRoutePending=null;$('radarRouteStatus').textContent=d.error||'Routenabfrage nicht bestätigt';}renderRadar();}catch(e){}}
const radarTransferClient={attempts:0,retries:0,completed:0,bytes:0,stage:'idle',lastError:'',revisionRestarts:0};
async function radarRequest(url,kind,deadline){
 while(performance.now()<deadline){
  const c=new AbortController(),timer=setTimeout(()=>c.abort(),Math.min(12000,Math.max(1,deadline-performance.now())));
  try{
   radarTransferClient.attempts++;radarTransferClient.stage=kind;
   const r=await fetch(url,{cache:'no-store',signal:c.signal});
   if(r.status===503){radarTransferClient.retries++;radarTransferClient.stage='waiting';await new Promise(resolve=>setTimeout(resolve,1000));continue;}
   if(r.status===409){const e=Error('Neue Radaraufnahme wird geladen …');e.revisionConflict=true;throw e;}
   if(!r.ok)throw Error(r.status===404?'Radar wartet auf erfolgreiche SD-Flugdaten':'Radarübertragung: HTTP '+r.status);
   return kind==='metadata'?await r.json():new Uint8Array(await r.arrayBuffer());
  }finally{clearTimeout(timer);}
 }
 throw Error('Datenabruf länger beschäftigt · Radar versucht es automatisch erneut');
}
async function refreshRadar(){
 if(radarBusy||document.hidden||!state?.modern?.aircraft||$('aircraft').classList.contains('hidden'))return;
 radarBusy=true;const deadline=performance.now()+60000;radarTransferClient.bytes=0;try{
  for(let restart=0;;restart++){try{
  const meta=await radarRequest('/api/radar','metadata',deadline);if(!Number.isInteger(meta.bytes)||meta.bytes<=0||meta.bytes>262144||!Number.isFinite(meta.now))throw Error('Radargröße ungültig');
  radarClock=meta.now;radarClockAt=performance.now();const key=meta.boot+':'+meta.revision;
  if(key!==radarKey){const bytes=new Uint8Array(meta.bytes);for(let off=0;off<meta.bytes;){const part=await radarRequest(`/api/radar?revision=${meta.revision}&offset=${off}`,'chunk',deadline);if(part.length!==Math.min(1024,meta.bytes-off))throw Error('Radarübertragung unvollständig');bytes.set(part,off);off+=part.length;radarTransferClient.bytes=off;}
   const data=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));const rows=RadarModel.normalize(data,meta);
   if(radarMeta&&(radarMeta.lat!==meta.lat||radarMeta.lon!==meta.lon)){radarLast=null;radarSelected=radarPinned;}
   radarRows=rows;radarMeta=meta;radarKey=key;radarFetchedAt=performance.now();
  }
  radarFailure='';radarTransferClient.completed++;radarTransferClient.lastError='';radarTransferClient.stage='ready';break;
  }catch(e){if(!e.revisionConflict)throw e;radarTransferClient.revisionRestarts++;if(restart>=3||performance.now()>=deadline)throw Error('Aufnahmewechsel · automatische Wiederholung läuft');radarTransferClient.bytes=0;radarTransferClient.stage='restarting';}}
 }catch(e){radarFailure=e.message;radarTransferClient.lastError=e.message;radarTransferClient.stage='failed';}finally{radarBusy=false;renderRadar();}
 await radarPollRoute();
}
setInterval(refreshRadar,10000);
setInterval(()=>{if(!$('aircraft').classList.contains('hidden'))renderRadar();},1000);
