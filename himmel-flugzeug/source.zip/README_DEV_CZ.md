# HimmelFlugzeug 2.0.0-dev26

Úspora paměti během síťových přenosů. Český návod je v přiloženém PDF. Výsledky: TEST_REPORT_CZ.md. Zdroj: WetterHimmel/WetterHimmel.ino. Záloha předchozí verze: Backup/HimmelFlugzeug_2_0_0_dev25.zip.
