# Himmel & Flugzeug 2.0.0-dev6

Český návod: Navod_CZ.pdf. Výsledky: Testy_a_nahledy/TEST_REPORT_CZ.md.

Safari: radar a seznam letadel ze stejné odpovědi uložené na SD, detail, připnutí letu a poslední známá poloha. JSON se přenáší po 1024 bytech s kontrolou revize. Při přerušeném přenosu zůstane předchozí snímek. SD radar používá dva dočasné soubory; satelitní katalog se nemění.

Trasy: ADSBDB, stejný zdroj jako RundeUhr 3.2.0-rc29; kontrola volacího znaku, přiřazení k ICAO identitě a časové omezení. Ověření TLS zůstává zapnuté. Jména měst a dopravce pouze z dostupné odpovědi. Katalogová trasa není potvrzením dnešního letového plánu. Pouze místní zobrazení, bez exportu databáze tras.

Displej: čtyři informační pole družic místo velkých spodních tlačítek; přepínání přes menu a gesto. Stav mapy nepřekrývá Favoriten. Stávající letecká obrazovka zachována.

Testy se provádějí na počítači a v GitHub Actions. Nejde o potvrzení funkce na fyzickém ESP32. Testovací větev, žádné automatické přehrání zařízení.

Mein Hangar: historie podle ICAO na SD, první/poslední zachycení, registrace, volací znak, typ a průlety. Každý záznam má dvě 128B pozice s kontrolním součtem. Při restartu a chybách se pokrytí absence začíná měřit znovu. Nový průlet vyžaduje nejméně 15 minut nepřítomnosti v řadě úspěšných aktualizací; pro neznámý přesný začátek absence se přidává bezpečnostní rezerva až 120 sekund. Stránkování po 12 položkách, hledání a řazení provádí pracovní úloha po malých dávkách; celá historie se nenačítá do RAM. Při plné SD se živá nejbližší poloha pokusí o omezený RAM režim (odpověď do 12 kB).
