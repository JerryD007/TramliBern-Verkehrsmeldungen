# HimmelFlugzeug 2.0.0-dev29

Horní lišta: název pohledu, místo (Bern), hodiny posunuté doleva, napravo od nich barevná ikona baterie a napětí. Bez procent. E32R40T používá vestavěný dělič 1:2 na GPIO34. Přidáno také zobrazení napětí v Safari a diagnostice. Hodnota 4,19 V je pouze testovací vzorek, nikoli pevná hodnota firmware.

Obrázky letadel včetně SWISS beze změny. Bezeztrátová komprese bitmap písma uvolňuje Flash pro ADC a OTA; všechny alfy a metriky znaků zachovány. Síťové opravy, NVS nastavení, Wi-Fi, SD katalogy a hangár z dev28 zůstávají.

Použijte přesně Arduino-ESP32 3.3.0, ArduinoJson 7.4.2, LovyanGFX 1.2.7. Zachovejte celý adresář WetterHimmel včetně src a partitions.csv. Návod je přiložen výhradně jako české PDF; podrobné výsledky jsou v TEST_REPORT_CZ.md. Bez automatického flashování. Měření a barvy na fyzickém zařízení je nutné porovnat s multimetrem; stav nabíjení ani procenta kapacity se neodhadují.
