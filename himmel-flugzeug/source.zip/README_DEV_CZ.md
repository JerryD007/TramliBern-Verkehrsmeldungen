# HimmelFlugzeug 2.0.0-dev28

Oprava zbývající paměťové špičky TLS, odezvy navigace a čekání po HTTP 429. TLS RX 16 KiB / TX 4 KiB zachováno; ECP window 2; dynamické Wi-Fi RX/TX buffery omezeny na 8/8. Použijte přesně esp32 core 3.3.0, ArduinoJson 7.4.2 a LovyanGFX 1.2.7. Celý adresář WetterHimmel/src musí zůstat zachován.

HTTP Retry-After se pro letadla a trasy respektuje jako počet sekund nebo datum. Bez platného záhlaví následuje čekání 60, 120, 240, 480, 960, 1920 a nejvýše 3600 sekund. Čekání přežije restart; ruční obnovení je neobchází. Satelitní zdroje zachovávají svůj dosavadní limit nejméně 2 hodin po chybě. Zpoždění běžné neúspěšné žádosti zůstává 5 minut.

Návod je v přiloženém českém PDF, výsledky v TEST_REPORT_CZ.md. Předchozí úplná verze dev27 je v Backup. Nikdy neformátujte SD ani nemažte Flash kvůli této aktualizaci. Tato verze nebyla testována na fyzickém ESP32.
