# Himmel & Flugzeug 2.0.0-dev4

Podrobný český návod je výhradně v Navod_CZ.pdf. Výsledky testů a omezení jsou v Testy_a_nahledy/TEST_REPORT_CZ.md.

Tato verze snižuje trvalé rezervace RAM: společná úloha pro síť a hledání Starlinku místo dvou zásobníků; menší souřadnice dotykových objektů. Letecká odpověď se při dostupné SD zpracuje po jednotlivých objektech až po uzavření TLS. Katalog zůstává beze změny. Menu nahrazuje duplicitní tlačítko Einstellungen.

Nejde o potvrzení stability na skutečném zařízení. Automatické testy a kompilace nikdy samy nenahrávají firmware. Hlavní větev ani přístroje nebyly změněny.
