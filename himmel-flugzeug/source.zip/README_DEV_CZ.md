# HimmelFlugzeug 2.0.0-dev30

Plný zdrojový kód je ve WetterHimmel. Český uživatelský návod je přiložen výhradně jako PDF. TEST_REPORT_CZ.md a CI_STATUS.txt obsahují technické výsledky a omezení. Záloha dev29 je v Backup.

Kompilace: esp32 Arduino 3.3.0, LovyanGFX 1.2.7, ArduinoJson 7.4.2; arduino-cli compile --jobs 2 --fqbn esp32:esp32:esp32:FlashMode=dio,FlashFreq=40,PartitionScheme=huge_app,PSRAM=disabled WetterHimmel

Přiložený partitions.csv je závazný; dva OTA oddíly po 1966080 bajtech. Žádná změna hlavní větve ani automatické nahrávání na zařízení.

Regrese: Tools/run_tests.py; kontrola skutečných oddílů a TLS ABI: Tools/check_tls_build.py. Nejde o fyzické testy ESP32. Poslední známé okolnosti pádu nenahrazují stack trace.
