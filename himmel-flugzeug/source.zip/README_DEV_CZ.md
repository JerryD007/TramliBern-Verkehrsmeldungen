# HimmelFlugzeug 2.0.0-dev24

Oprava ručního přepnutí na Flugzeug, dělení katalogové úlohy na osm záznamů, průběžná obsluha hangáru, krátké zamykání SD při stahování katalogu, menší trvalá diagnostická paměť a rychlejší transformace hvězd. Displej i web uvádějí názvy měst dodané ADSBDB. Stávající NVS, SD formát a OTA rozdělení zůstávají zachované.

Fyzické testy na ESP32 nebyly provedeny. Podrobnosti: TEST_REPORT_CZ.md a Navod_CZ.pdf.
