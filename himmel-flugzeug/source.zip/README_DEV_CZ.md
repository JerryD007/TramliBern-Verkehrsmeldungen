# HimmelFlugzeug 2.0.0-dev25
Rychlé opakované otevření první stránky hangáru pomocí průběžně aktualizovaného indexu SD; původní jednotlivé záznamy a jejich formát se nemění. První otevření bez indexu, hledání, jiné řazení a ruční Aktualisieren mohou nadále číst historii. Dotykové body oblohy využívají pouze zarovnané 32bitové přístupy a přednostně IRAM, aby zůstalo více DRAM pro TLS a Wi-Fi. Nová diagnostika: cacheHits, cacheBuilds, cacheErrors, queryMs a hitIram.

Fyzický test této verze nebyl proveden. Podrobnosti jsou v TEST_REPORT_CZ.md a českém PDF návodu.
