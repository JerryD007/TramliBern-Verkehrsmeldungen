# Aktualizace 2.0.0-dev2 - 18. 11. 2026

Tato část nahrazuje odlišné chování popsané níže v původním dev1 zadání.
Himmel se otevře po restartu. Volitelná priorita zobrazuje nejbližší aktuální letadlo/vrtulník podle výběru a dosahu; filtr přibližování platí jen při jeho zapnutí. Při prioritě se pozastaví běžné automatické střídání.
Nová volba wakeOnFlight je standardně vypnutá, starší uložená nastavení ji nezapnou. Po jejím povolení lze probudit i ručně zhasnutý displej; po skončení se vrátí Himmel a původní spánek. Práce v menu má přednost. Dotyk či ruční zásah přebírá řízení.

Letecký HTTPS přenos používá standardní X509 řetězec s oficiálním Google GTS Root R4 (AircraftCA.h) místo starého bundle callbacku. Název hostitele, podpisy a platnost se ověřují; setInsecure není použito. Při změně autority zdroje může být nutná aktualizace CA.
Při nezávislém testu 18. 11. zdroj vracel křížově podepsaný GTS R4 → GlobalSign; konečný issuer chybí ve starém bundle. Ověření zachyceného řetězce pomocí nativního GTS R4 prošlo v OpenSSL i hostitelském mbedTLS 3.6.6. To není důkaz úspěchu na ESP32; po OTA je nutná diagnostika.
Diagnostika obsahuje X509 flags před/po ověření, hloubku, vydavatele, počet callbacků, použitý CA režim, stav letadla, dosah, filtry a stav probouzení. Pole jsou omezená a neobsahují hesla ani přístupové klíče.

Počítačové testy a kompilace se nacházejí v Testy_a_nahledy. Fyzické testy dotyku, TLS/RAM, spánku, probuzení a dlouhodobého provozu zbývají. Firmware se do zařízení neinstaluje automaticky.

---
Původní dokumentace dev1 pro další nezměněné funkce:

# Himmel & Flugzeug 2.0.0-dev1 — vývojový kontrolní bod

Tato větev nahrazuje počasí dvěma obrazovkami Himmel a Flugzeug. Nejde o finální schválenou verzi. Předchozí funkční RC5 a data zařízení se nesmějí přepsat při vývoji ani testech.

## Implementováno
- Německé rozhraní 480 × 320 na ležato, rotace 1/3; fyzickou polohu USB-C vpravo musí ověřit majitel zařízení. Nabídka obsahuje otočení o 180°.
- Nové rozložení mapy, nabídky, klávesnice, planetárních detailů a letadel. Zvětšená mapa skrývá spodní řadu družic. Veškeré počasí a jeho pravidelné síťové požadavky odstraněny.
- ISS, Tiangong, Hubble a Starlink; vyhledávání objektů, oblíbené, možné pozorovací okno, věk dat. Katalog zůstává na SD.
- Oddělené symboly pevného křídla a kategorie A7 (rotorové letadlo); neznámé kategorie se nevydávají za vrtulník. Malé detailnější vektorové symboly. Kategorie A7 sama nepotvrzuje konkrétní model vrtulníku.
- Změny leteckých údajů překreslují jen příslušná pole; nabídky nejsou periodicky mazány.
- Volitelná priorita blízkého přibližujícího se letadla; nezasahuje do menu ani neprobouzí displej. Po návratu začíná nový interval automatického střídání.
- Samostatné časy obou obrazovek, zachování starého společného intervalu, spánek a první dotyk pouze pro probuzení.
- Safari OTA, správa uložených Wi-Fi, diagnostika a sbalený přehled zařízení. Skupinová aktualizace postupně ověřuje identitu, nový start a verzi.

## Otevřené body — neoznačovat za dokončené
- Trasa odkud–kam se doplňuje z katalogu VRS Standing Data přes adsb.lol. Živá katalogová odpověď HTTP 200 byla ověřena; parser ověřuje shodu volacího znaku, vazbu na konkrétní letadlo a kódy letišť. Displej i web ji označují „Katalog · nicht live bestätigt“: historická katalogová trasa nepotvrzuje dnešní letový plán. Neznámé trasy zůstávají nedostupné. Fyzický HTTPS přenos na ESP32 ještě není ověřen.
- Skutečná poloha USB-C, kalibrace a kvalita dotyku musí být ověřeny na fyzickém ESP32.
- Prohlížečové testy jsou jsdom, nikoli skutečný Safari; skupinové OTA potřebuje dvě fyzická zařízení.
- Starlink má měření času čtení/výpočtů, nikoli prokázané zrychlení na SD uživatele.
- Stabilita TLS, volný heap při souběhu a dlouhodobý provoz nebyly změřeny na zařízení.
- Náhledy vznikají skutečnými funkcemi kreslení ve simulovaném grafickém prostředí; nejsou fotografiemi displeje.

## Zachování dat
Namespace NVS „wetterwelt“, binární struktura Settings a klíče kalibrace zůstávají. Staré ID obrazovky počasí se převede na Himmel. Původní kalibrační rohy lze znovu použít: LovyanGFX aplikuje rotaci až při převodu raw souřadnic. Výsledek přesto vyžaduje fyzickou zkoušku. Staré položky počasí z NVS ani SD se při aktualizaci nemažou.

## Sestavení
Arduino CLI 1.6.0, esp32 by Espressif Systems 3.3.0, LovyanGFX 1.2.7, ArduinoJson 7.4.2. ESP32 Dev Module, DIO, 40 MHz Flash, 4 MB, PSRAM Disabled, CPU 240 MHz. V kořeni sketche musí zůstat přiložený partitions.csv: oba OTA oddíly 0x1e0000 = 1 966 080 B. Volba Huge APP v nástrojích CLI je přepsána tímto souborem; údaj o maximu ve standardním souhrnu Arduino není skutečná kapacita OTA.

Automatické testy: `python Tools/run_tests.py` (C/C++, Python + Pillow, Node + jsdom, ArduinoJson include cesta). V CI se testují stejné zdroje. Zařízení se neflashuje.

## Zdroje a omezení
- https://github.com/adsbfi/adsbfi-api — polohy, soukromé nekomerční použití; chybějící příjem není důkaz nepřítomnosti letadla. Poziční požadavek běžně 30 s, chyby mají prodlevu; HTTP 429 respektuje Retry-After.
- https://github.com/vradarserver/standing-data/ — katalogové údaje CC0; https://www.adsb.lol/docs/acknowledgements/open-source — hostování/formát tras. Katalogový požadavek nejvýše jednou za 120 s, po chybě 5 min, HTTP 429 podle Retry-After. Jedna odpověď maximálně 4096 B; cache je navázaná na callsign + hex a platí nejvýše 6 h.
- https://github.com/wiedehopf/readsb/blob/dev/README-json.md — pole ADS-B a kategorie.
- Astronomy Engine, CelesTrak, SGP4 a d3-celestial: zachované knihovny a původní licence ve zdrojích.
