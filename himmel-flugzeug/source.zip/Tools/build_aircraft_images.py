"""Compile the approved illustrative atlas into shared compact flash RLE.
TFT uses no image decoder, heap or framebuffer. Safari reads the same data via local HTTP.
Artwork is illustrative; exact aircraft registration livery is not inferred.
"""
from pathlib import Path
import base64,io,json,hashlib
from PIL import Image,ImageChops

root=Path(__file__).resolve().parents[1]
atlas=Image.open(root/'Assets/aircraft-atlas.png').convert('RGB')
# Visually checked strip boundaries in the generated 1024 x 1536 atlas.
assert atlas.size==(1024,1536)
bounds=[(0,300),(300,540),(540,780),(780,1000),(1000,1225),(1225,1536)]
names=['SWISS','easyJet','Lufthansa','KLM','British Airways','Emirates','REGA']
# Exact family matching: A320/A20N; B787 family; A380. No cross-type guessing.
profiles=[2,2,2,13,13,7,22]
sprites=[];web=[];metrics=[]
strips=[atlas.crop((0,top,1024,bottom)) for top,bottom in bounds]+[Image.open(root/'Assets/rega-h145.png').convert('RGB')]
for index,(strip,name) in enumerate(zip(strips,names)):
    mask=strip.convert('L').point(lambda x:255 if x>20 else 0)
    box=mask.getbbox();assert box
    image=strip.crop(box)
    # Technical asset conversion. Keep aspect ratio and center in a fixed viewport.
    def viewport(w,h):
        im=image.copy();im.thumbnail((w-4,h-4),Image.Resampling.LANCZOS)
        canvas=Image.new('RGB',(w,h));canvas.paste(im,((w-im.width)//2,(h-im.height)//2))
        return canvas
    browser=viewport(420,132)
    quant=viewport(210,66).quantize(colors=16)
    pal=quant.getpalette();palette=[]
    for i in range(16):
        red,green,blue=pal[i*3:i*3+3]
        palette.append(((red>>3)<<11)|((green>>2)<<5)|(blue>>3))
    pixels=list(quant.getdata());runs=[]
    for y in range(66):
        row=pixels[y*210:(y+1)*210];x=0
        while x<210:
            n=1
            while n<16 and x+n<210 and row[x+n]==row[x]:n+=1
            runs.append(((n-1)<<4)|row[x]);x+=n
    packet=[]
    for c in palette:packet.extend([c&255,c>>8])
    packet+=runs;sprites.append(packet)
    web.append({'name':name,'profile':profiles[index],'livery':index+1})
    metrics.append({'name':name,'profile':profiles[index],'livery':index+1,'rle_bytes':len(runs),'palette_bytes':32,'draw_calls':len(runs)})
    # Exact decoded TFT pixels for documentation and browser/host parity tests.
    rgb=Image.new('RGB',(210,66));rgb.putdata([((palette[v]>>11)*255//31,((palette[v]>>5)&63)*255//63,(palette[v]&31)*255//31) for v in pixels])
    rgb.save(root/'Assets'/('preview-'+str(index)+'.png'))
    (root/'Assets'/('sprite-'+str(index)+'.bin')).write_bytes(bytes(packet))
cpp=['#include "AircraftImages.h"','namespace AircraftImages {']
for i,packet in enumerate(sprites):cpp.append('static const uint8_t data%d[]={%s};'%(i,','.join(map(str,packet))))
cpp.append('const Sprite sprites[]={'+','.join('{data%d,sizeof(data%d)}'%(i,i) for i in range(7))+'};')
cpp.append('}')
(root/'WetterHimmel/AircraftImages.cpp').write_text('\n'.join(cpp)+'\n')
h=['#pragma once','#include <stdint.h>','namespace AircraftImages {','struct Sprite {const uint8_t* data;unsigned size;};','extern const Sprite sprites[7];']
h.append('inline int select(unsigned profile,unsigned livery){'+''.join('if(profile==%d&&livery==%d)return %d;'%(p,i+1,i) for i,p in enumerate(profiles))+'return -1;}')
h.append("""template<class P> bool draw(P &paint,unsigned profile,unsigned livery,int x,int y){
 int id=select(profile,livery);if(id<0)return false;
 const auto&s=sprites[id];unsigned xx=0,yy=0;
 for(unsigned at=32;at<s.size;++at){unsigned code=s.data[at],n=(code>>4)+1,index=(code&15)*2;
  uint16_t color=s.data[index]|(uint16_t(s.data[index+1])<<8);
  paint.drawFastHLine(x+xx,y+yy,n,color);
  xx+=n;if(xx==210){xx=0;++yy;}
 }return true;
}
}""")
(root/'WetterHimmel/AircraftImages.h').write_text('\n'.join(h)+'\n')
js='const AircraftImages=(()=>{const sprites='+json.dumps(web,separators=(',',':'))+""";
const cache=new Map(),retryAfter=new Map();
function select(profile,livery){return sprites.findIndex(s=>s.profile===profile&&s.livery===livery);}
function decode(bytes){
 if(bytes.length<33||bytes.length>32+210*66)throw Error('Bildformat');
 const pixels=new Uint8ClampedArray(210*66*4);let x=0,y=0,pos=0;
 for(let i=32;i<bytes.length;i++){const n=(bytes[i]>>4)+1,idx=(bytes[i]&15)*2,c=bytes[idx]|(bytes[idx+1]<<8);
  if(y>=66||x+n>210)throw Error('Bildgrenze');
  for(let k=0;k<n;k++){pixels[pos++]=(c>>11)*255/31;pixels[pos++]=((c>>5)&63)*255/63;pixels[pos++]=(c&31)*255/31;pixels[pos++]=255;}
  x+=n;if(x===210){x=0;y++;}
 }if(y!==66||x!==0)throw Error('Bild unvollständig');return pixels;
}
function html(f){const profile=AircraftArt.resolve(f.type,f.rotorcraft,/^A[1-6]$/.test(f.category||''));
 const livery=AircraftArt.scheme(f.callsign,f.airline||f.operator||'');const i=select(profile,livery);
 if(i<0)return AircraftArt.svg(f);
 return '<span class="aircraftAsset"><canvas data-aircraft-image="'+i+'" width="210" height="66" style="width:100%;height:auto" hidden role="img" aria-label="'+sprites[i].name+' · Illustration"></canvas><span data-aircraft-fallback>'+AircraftArt.svg(f)+'</span><small hidden data-aircraft-caption>'+sprites[i].name+' · Illustration, Lackierung nicht bestätigt</small></span>';
}
async function paint(canvas){const id=Number(canvas.dataset.aircraftImage);if(!Number.isInteger(id)||id<0||id>=sprites.length||canvas.dataset.loading||canvas.dataset.ready||Date.now()<(retryAfter.get(id)||0))return;
 canvas.dataset.loading='1';
 try{
  if(!cache.has(id))cache.set(id,(async()=>{const r=await fetch('/api/aircraft-image?id='+id);if(!r.ok)throw Error('Bild nicht bereit');return decode(new Uint8Array(await r.arrayBuffer()));})());
  const pixels=await cache.get(id);if(!canvas.isConnected)return;
  const ctx=canvas.getContext('2d'),data=ctx.createImageData(210,66);data.data.set(pixels);ctx.putImageData(data,0,0);
  canvas.hidden=false;canvas.dataset.ready='1';const parent=canvas.parentElement;parent.querySelector('[data-aircraft-fallback]').hidden=true;parent.querySelector('[data-aircraft-caption]').hidden=false;
 }catch(e){cache.delete(id);retryAfter.set(id,Date.now()+5000);}finally{delete canvas.dataset.loading;}
}
function scan(){if(typeof document==='undefined'||!document)return;document.querySelectorAll('canvas[data-aircraft-image]').forEach(paint);}
if(typeof document!=='undefined'){
 const start=()=>{new MutationObserver(scan).observe(document.body,{childList:true,subtree:true});setInterval(scan,5000);scan();};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
}
return {html,select,decode};})();
"""
(root/'Web/aircraft-images.js').write_text(js)
(root/'Assets/asset-metrics.json').write_text(json.dumps(metrics,indent=2))
print(json.dumps(metrics,indent=2))
