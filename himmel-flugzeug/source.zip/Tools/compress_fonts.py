from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
s=(root/'Tests/fixtures/ui-fonts-original.h').read_text();saved=0
for size,height in [(11,14),(14,17),(20,23),(46,49),(56,59)]:
 bp=r'(static const uint8_t uiBits'+str(size)+r'\[\] PROGMEM = \{)(.*?)(\};)'
 gp=r'(static const UiGlyph uiGlyphs'+str(size)+r'\[\] PROGMEM = \{)(.*?)(\};)'
 bm=re.search(bp,s);gm=re.search(gp,s)
 raw=list(map(int,bm[2].split(',')));rows=[list(map(int,x.split(','))) for x in re.findall(r'\{([^}]+)\}',gm[2])]
 packed=[];newrows=[]
 for code,offset,width,advance in rows:
  values=[(raw[offset+i//2]>>(0 if i%2 else 4))&15 for i in range(width*height)]
  newrows.append([code,len(packed),width,advance]);i=0
  while i<len(values):
   n=1
   while n<16 and i+n<len(values) and values[i+n]==values[i]:n+=1
   packed.append(((n-1)<<4)|values[i]);i+=n
 saved+=len(raw)-len(packed)
 s=re.sub(bp,lambda m:m[1]+','.join(map(str,packed))+m[3],s)
 s=re.sub(gp,lambda m:m[1]+','.join('{'+','.join(map(str,row))+'}' for row in newrows)+m[3],s)
s=s.replace('// DejaVu Sans raster subset;', '// Lossless 4-bit alpha RLE: high nibble run length minus one, low nibble alpha.\n// DejaVu Sans raster subset;')
(root/'WetterHimmel/UiFonts.h').write_text(s)
print('Lossless font bytes saved (all arrays):',saved)
