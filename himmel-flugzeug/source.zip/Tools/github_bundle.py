from pathlib import Path
import zipfile,base64
r=Path(__file__).resolve().parents[1]
with zipfile.ZipFile(r/'Tests/new/github-source.zip','w',zipfile.ZIP_DEFLATED,9) as z:
 for folder in ['WetterHimmel','Web','Tools']:
  for p in (r/folder).rglob('*'):
   if p.is_file() and p.suffix not in ['.bin','.elf','.zip']: z.write(p,p.relative_to(r))
 for p in (r/'Tests').glob('*'):
  if p.is_file() and p.suffix in ['.py','.js','.cjs','.sh','.h','.cpp','.json']:z.write(p,p.relative_to(r))
 for p in (r/'Tests/new').glob('*'):
  if p.suffix in ['.py','.cjs']:z.write(p,p.relative_to(r))
 for p in [r/'ZADANI_CZ.md',r/'README_DEV_CZ.md']:
  if p.exists():z.write(p,p.name)
 for p in (r/'Tests/render').glob('*.h'):z.write(p,p.relative_to(r))
 for p in (r/'Tests/fixtures').rglob('*'):
  if p.is_file():z.write(p,p.relative_to(r))
(r/'Tests/new/github-source.b64').write_text(base64.b64encode((r/'Tests/new/github-source.zip').read_bytes()).decode())
print('bundle bytes', (r/'Tests/new/github-source.zip').stat().st_size)
