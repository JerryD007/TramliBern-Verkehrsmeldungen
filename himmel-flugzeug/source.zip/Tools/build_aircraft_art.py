"""Original schematic side profiles. Single source for TFT primitives and inline SVG.
Schematic airline colour schemes, not proof of the actual aircraft livery.
"""
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
# Explicit ICAO codes only. No prefix guessing for unknown types.
models=[
 ('A318','A318',220,20,'jet'),('A319','A319 A19N',235,20,'jet'),('A320','A320 A20N',250,20,'jet'),('A321','A321 A21N',280,20,'jet'),
 ('A330','A332 A333 A338 A339',290,25,'jet'),('A340','A342 A343 A345 A346',300,25,'four'),('A350','A359 A35K',300,25,'jet'),('A380','A388',300,35,'double'),
 ('B737','B731 B732 B733 B734 B735 B736 B737 B738 B739 B37M B38M B39M B3XM',250,19,'boeing'),('B747','B741 B742 B743 B744 B748 B74S',305,27,'jumbo'),('B757','B752 B753',275,20,'boeing'),('B767','B762 B763 B764',275,24,'boeing'),('B777','B772 B773 B77L B77W B778 B779',305,27,'boeing'),('B787','B788 B789 B78X',295,24,'dream'),
 ('E-Jet','E170 E75L E75S E190 E195 E290 E295',240,18,'jet'),('CRJ','CRJ1 CRJ2 CRJ7 CRJ9 CRJX',245,16,'rear'),('ATR','AT43 AT45 AT46 AT72 AT73 AT75 AT76',230,22,'prop'),('Dash 8','DH8A DH8B DH8C DH8D',250,20,'prop'),('Businessjet','GL5T GL7T GLEX GLF4 GLF5 GLF6 FA7X FA8X C25A C25B C25C C56X C680 C68A C700 C750',245,18,'rear'),('Cessna 172','C172',190,24,'light'),('PC-12','PC12',215,22,'light'),('EC135','EC35',210,30,'heli'),('EC145','EC45',230,32,'heli'),('Helikopter','',215,30,'heli'),('Flugzeug','',250,20,'jet'),('Unbekannt','',180,20,'unknown')]
# Primitive [kind,colour,x,y,u,v,a,b], coordinates in a 320x100 viewport.
# kind: triangle 0, rectangle 1, line 2, circle 3.
palette=['#ffffff','#00dacf','#879aa5','#152d3a','#f23845']
art=[]
def make(length,height,kind):
 q=[];left=(320-length)//2;right=left+length;top=49-height//2;bottom=top+height
 def tri(c,x,y,u,v,a,b):q.append([0,c,x,y,u,v,a,b])
 def rect(c,x,y,w,h):q.append([1,c,x,y,w,h,0,0])
 def line(c,x,y,u,v):q.append([2,c,x,y,u,v,0,0])
 def circle(c,x,y,r):q.append([3,c,x,y,r,0,0,0])
 def poly(c,points):
  for i in range(1,len(points)-1):tri(c,*points[0],*points[i],*points[i+1])
 if kind=='unknown':
  line(0,132,50,160,22);line(0,160,22,188,50);line(0,188,50,160,78);line(0,160,78,132,50)
  rect(1,158,35,4,22);circle(1,160,65,2);return q
 if kind=='heli':
  rect(0,left+10,43,83,27);tri(0,left,61,left+14,44,left+20,70)
  tri(4,left+85,49,right-12,42,left+85,66);tri(4,right-20,43,right-7,20,right-4,49)
  rect(4,left+17,60,75,10);tri(3,left+8,59,left+21,44,left+38,59);rect(3,left+24,45,23,13);rect(3,left+52,45,26,13)
  rect(0,left+50,34,7,10);line(0,left-4,33,left+132,33);line(0,left+20,29,left+111,37)
  circle(0,right-11,45,9);line(0,right-19,38,right-3,52);line(0,right-19,52,right-3,38)
  line(0,left+20,70,left+26,82);line(0,left+73,70,left+79,82);line(0,left+9,83,left+96,83)
  return q
 # Tail fin, far wing, fuselage; stepped nose and tapered rear.
 poly(5,[(right-61,top+3),(right-30,10),(right-18,10),(right-24,top+6)]);poly(5,[(right-51,top+2),(right-29,15),(right-23,15),(right-28,top+3)])
 rect(6,right-34,23,5,13);rect(6,right-38,27,13,5)
 tri(2,left+length//2,top+5,left+length//2+46,23,left+length//2+27,top+8)
 poly(0,[(left,49),(left+4,45),(left+13,top+3),(left+25,top),(right-57,top),(right-20,46),(right,49),(right-21,52),(right-57,bottom),(left+24,bottom),(left+8,54)])
 rect(2,left+25,bottom-3,length-82,3)
 if kind in ('jumbo','double'):
  upper=length-85 if kind=='double' else 80
  rect(0,left+28,top-8,upper,9);tri(0,left+10,top+3,left+28,top-8,left+28,top+3)
  for x in range(left+36,left+24+upper,8):rect(3,x,top-5,3,3)
 # Cockpit and windows.
 tri(3,left+9,top+height//2-2,left+21,top+3,left+21,top+height//2-2)
 rect(3,left+22,top+3,7,5)
 for x in range(left+40,min(right-62,left+85) if kind=="light" else right-62,8):rect(3,x,top+5,3,4)
 line(2,left+34,top+2,left+34,bottom-2);line(2,right-65,top+2,right-65,bottom-2)
 wing=left+length*46//100
 if kind=='light':
  rect(1,left+30,top-3,110,5);line(2,left+66,top,left+105,bottom+3)
  line(0,left+3,top-13,left+3,bottom+12);circle(3,left+45,bottom+9,4);circle(3,left+122,bottom+9,4)
 elif kind=='prop':
  rect(2,wing-32,top-3,92,6);rect(2,wing-15,top-3,18,25);line(0,wing-17,top-13,wing-17,bottom+15)
  tri(2,right-51,top+5,right-12,top-4,right-2,top+5)
 else:
  poly(2,[(wing,49),(wing+26,50),(wing+86,73),(wing+70,74)])
  tri(2,right-56,49,right-13,39,right-7,44)
  positions=[wing+6] if kind not in ('four','double','jumbo','rear') else ([right-82] if kind=='rear' else [wing+5,wing+45])
  for x in positions:
   y=top+2 if kind=='rear' else bottom+4
   poly(0,[(x,y+2),(x+4,y),(x+24,y+1),(x+29,y+4),(x+27,y+10),(x+4,y+12),(x,y+9)]);rect(2,x+4,y+9,22,2);rect(3,x,y+3,3,6);line(1,x+7,y+3,x+23,y+3)
 if kind in ('boeing','dream'):line(1,wing+86,73,wing+87,65)
 return q
for name,codes,length,height,kind in models:art.append(make(length,height,kind))
for ops in art:
 for o in ops:
  k=o[0];o[2]=320-o[2]-(o[4] if k==1 else 0)
  if k in (0,2):o[4]=320-o[4]
  if k==0:o[6]=320-o[6]
palette.extend(['#00dacf','#ffffff'])
liveries=[{'name':'Neutral','hex':'#00dacf','codes':[],'names':[]},
 {'name':'SWISS','hex':'#e60005','codes':['SWR'],'names':['SWISS','SWISS INTERNATIONAL AIR LINES']},
 {'name':'easyJet','hex':'#ff6600','codes':['EZY','EZS','EJU'],'names':['EASYJET','EASYJET SWITZERLAND','EASYJET EUROPE','EASYJET UK']},
 {'name':'Lufthansa','hex':'#05164d','codes':['DLH'],'names':['LUFTHANSA','DEUTSCHE LUFTHANSA']},
 {'name':'KLM','hex':'#00a1de','codes':['KLM'],'names':['KLM','KLM ROYAL DUTCH AIRLINES']},
 {'name':'British Airways','hex':'#15264d','codes':['BAW'],'names':['BRITISH AIRWAYS']},
 {'name':'Emirates','hex':'#c39b37','codes':['UAE'],'names':['EMIRATES']},
 {'name':'REGA','hex':'#e3252b','codes':['RGA'],'names':['REGA','SWISS AIR-RESCUE','SCHWEIZERISCHE RETTUNGSFLUGWACHT']}]
data={'liveries':liveries,'palette':palette,'models':[{'name':m[0],'codes':m[1].split(),'ops':a} for m,a in zip(models,art)]}
(root/'Web/aircraft-art.json').write_text(json.dumps(data,indent=2))
# All arrays are immutable flash constants; the renderer needs only scalar locals.
h=['#pragma once','#include <stdint.h>','#include <stddef.h>','#include <string.h>','#include <ctype.h>','#include <strings.h>','namespace AircraftArt {','struct Op {uint8_t kind,color;int16_t x,y,u,v,a,b;};','struct Model {const char* name;const Op* ops;uint16_t count;};']
for i,ops in enumerate(art):h.append('static const Op ops%d[]={%s};'%(i,','.join('{'+','.join(map(str,o))+'}' for o in ops)))
h.append('static const Model models[]={'+','.join('{"%s",ops%d,%d}'%(m[0],i,len(art[i])) for i,m in enumerate(models))+'};')
h.append('struct Code {const char* code;uint8_t model;};static const Code codes[]={'+','.join('{"%s",%d}'%(c,i) for i,m in enumerate(models) for c in m[1].split())+'};')
h.append('struct Livery {const char* name;uint16_t color;};static const Livery liveries[]={'+','.join('{"%s",%d}'%(v['name'],((int(v['hex'][1:3],16)>>3)<<11)|((int(v['hex'][3:5],16)>>2)<<5)|(int(v['hex'][5:7],16)>>3)) for v in liveries)+'};')
h.append('inline unsigned byName(const char*name){if(!name)return 0;'+''.join('if(!strcasecmp(name,"%s"))return %d;'%(name,i) for i,v in enumerate(liveries) for name in v['names'])+'return 0;}')
h.append('inline unsigned scheme(const char*call,const char*airline=""){unsigned v=0;size_t n=call?strlen(call):0;bool valid=n>=4&&n<=8&&isdigit((unsigned char)call[3]);for(size_t i=0;valid&&i<n;i++)if(!((call[i]>=\'A\'&&call[i]<=\'Z\')||isdigit((unsigned char)call[i])))valid=false;if(valid){'+''.join('if(!strncmp(call,"%s",3))v=%d;'%(code,i) for i,l in enumerate(liveries) for code in l['codes'])+'}if(airline&&*airline){unsigned a=byName(airline);return a&&(!v||a==v)?a:0;}return v;}')
h.append('''inline unsigned resolve(const char *type,bool rotor,bool fixedWing){
 char code[9]={};unsigned n=0;if(type){while(*type==' ')++type;while(*type&&*type!=' '&&n<8)code[n++]=toupper((unsigned char)*type++);while(*type==' ')++type;if(*type)code[0]=0;}
 for(const auto &entry:codes)if(!strcmp(code,entry.code))return entry.model;
 return rotor?23:fixedWing?24:25;
}
static const uint16_t colors[]={0xffff,0x06d9,0x8cd4,0x1167,0xf1c8,0x06d9,0xffff};
template<class P> void draw(P &paint,unsigned model,int x,int y,int width,unsigned livery=0){
 if(livery>6||model>=21)livery=0;
 if(model>=sizeof(models)/sizeof(models[0]))model=25;
 const auto&m=models[model];for(unsigned i=0;i<m.count;i++){const auto&o=m.ops[i];if(o.color==6&&livery!=1)continue;uint16_t c=(o.color==5&&livery)?liveries[livery].color:colors[o.color];
 int xx=x+o.x*width/320,yy=y+o.y*width/320;
 if(o.kind==0)paint.fillTriangle(xx,yy,x+o.u*width/320,y+o.v*width/320,x+o.a*width/320,y+o.b*width/320,c);
 else if(o.kind==1)paint.fillRect(xx,yy,(o.u*width/320)>0?o.u*width/320:1,(o.v*width/320)>0?o.v*width/320:1,c);
 else if(o.kind==2)paint.drawLine(xx,yy,x+o.u*width/320,y+o.v*width/320,c);
 else paint.fillCircle(xx,yy,(o.u*width/320)>0?o.u*width/320:1,c);
 }}
}''')
(root/'WetterHimmel/AircraftArt.h').write_text('\n'.join(h)+'\n')
js='const AircraftArt=(()=>{const data='+json.dumps(data,separators=(',',':'))+''';
function resolve(type,rotor,fixed){const code=String(type||'').trim().toUpperCase();const i=data.models.findIndex(m=>m.codes.includes(code));return i>=0?i:rotor?23:fixed?24:25;}
function scheme(call,airline=''){let v=0;call=String(call||'');if(/^[A-Z]{3}[0-9][A-Z0-9]{0,4}$/.test(call))v=data.liveries.findIndex(l=>l.codes.includes(call.slice(0,3)));v=Math.max(0,v);if(airline){const a=data.liveries.findIndex(l=>l.names.includes(String(airline).toUpperCase()));return a>0&&(!v||a===v)?a:0;}return v;}
function svg(f){const i=resolve(f.type,f.rotorcraft,/^A[1-6]$/.test(f.category||'')),m=data.models[i],l=i<21?scheme(f.callsign,f.airline||f.operator||''):0;let out='<svg viewBox="0 0 320 100" role="img" aria-label="'+m.name+' · schematische Seitenansicht" xmlns="http://www.w3.org/2000/svg">';
for(const [k,c,x,y,u,v,a,b] of m.ops){if(c===6&&l!==1)continue;const col=c===5&&l?data.liveries[l].hex:data.palette[c];out+=k===0?`<polygon fill="${col}" points="${x},${y} ${u},${v} ${a},${b}"/>`:k===1?`<rect fill="${col}" x="${x}" y="${y}" width="${u}" height="${v}"/>`:k===2?`<path stroke="${col}" stroke-width="1.5" d="M${x} ${y}L${u} ${v}"/>`:`<circle fill="${col}" cx="${x}" cy="${y}" r="${u}"/>`;}
return out+'</svg><small>'+m.name+' · '+(l?data.liveries[l].name+' Farbschema · Lackierung nicht bestätigt':'Schema, keine Betreiberlackierung')+'</small>';}
return {resolve,scheme,svg,count:data.models.length};})();
'''
(root/'Web/aircraft-art.js').write_text(js)
print(len(models),'profiles;',sum(len(m[1].split()) for m in models),'explicit codes; generated header', (root/'WetterHimmel/AircraftArt.h').stat().st_size)
