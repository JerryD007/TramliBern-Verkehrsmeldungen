"""Check real ESP32 ABI, source/header alignment and final linker ownership."""
from pathlib import Path
import argparse,subprocess as sp,tempfile,re,json
p=argparse.ArgumentParser();p.add_argument('--packages',required=True);p.add_argument('--build',required=True);a=p.parse_args()
packages=Path(a.packages).resolve();build=Path(a.build).resolve();root=Path(__file__).resolve().parents[1]
sdk=packages/'esp32/tools/esp32-arduino-libs/idf-release_v5.5-b66b5448-v1/esp32';core=packages/'esp32/hardware/esp32/3.3.0/cores/esp32';cc=packages/'esp32/tools/esp-x32/2411/bin/xtensa-esp32-elf-gcc';nm=cc.with_name('xtensa-esp32-elf-nm');vendor=root/'WetterHimmel/src/tls'
for f in vendor.glob('*.h'):
 if f.name=='HimmelTlsConfig.h':continue
 original=sdk/'include/mbedtls/mbedtls/library'/f.name
 if original.exists():assert original.read_bytes()==f.read_bytes(),f'Header mismatch: {f.name}'
probe='''#ifdef CUSTOM
#include "HimmelTlsConfig.h"
#else
#define MBEDTLS_ALLOW_PRIVATE_ACCESS
#include "mbedtls/build_info.h"
#endif
#include "ssl_misc.h"
#include <stddef.h>
unsigned char context[sizeof(mbedtls_ssl_context)];
unsigned char config[sizeof(mbedtls_ssl_config)];
unsigned char session[sizeof(mbedtls_ssl_session)];
unsigned char handshake[sizeof(mbedtls_ssl_handshake_params)];
unsigned char transform[sizeof(mbedtls_ssl_transform)];
unsigned char off_in[offsetof(mbedtls_ssl_context,in_buf)+1];
unsigned char off_out[offsetof(mbedtls_ssl_context,out_buf)+1];
unsigned char rx_buffer[MBEDTLS_SSL_IN_BUFFER_LEN];
unsigned char tx_buffer[MBEDTLS_SSL_OUT_BUFFER_LEN];
'''
results={}
with tempfile.TemporaryDirectory() as tmp:
 tmp=Path(tmp);source=tmp/'probe.c';source.write_text(probe)
 for mode in ['stock','custom']:
  obj=tmp/(mode+'.o');cmd=[str(cc),'@'+str(sdk/'flags/c_flags'),'@'+str(sdk/'flags/defines'),'-iprefix',str(sdk/'include')+'/', '@'+str(sdk/'flags/includes'),'-I'+str(sdk/'dio_qspi/include'),'-I'+str(core),'-I'+str(vendor),'-c',str(source),'-o',str(obj)]
  if mode=='custom':cmd+=['-DCUSTOM=1']
  sp.run(cmd,check=True)
  text=sp.check_output([str(nm),'-S',str(obj)],text=True);results[mode]={name:int(size,16) for _,size,name in re.findall(r'(?m)^([0-9a-f]+) ([0-9a-f]+) [BbDd] (\w+)$',text)}
 assert results['stock']['tx_buffer']-results['custom']['tx_buffer']==12288,results
 for k in results['stock']:
  if k!='tx_buffer':assert results['stock'][k]==results['custom'][k],(k,results)
linkmap=(build/'WetterHimmel.ino.map').read_text()
stock=set(re.findall(r'libmbedtls[^/\s]*\.a\(([^)]+)\)',linkmap))
assert stock <= {'esp_crt_bundle.c.obj','x509_crt_bundle.S.obj','esp_platform_time.c.obj','net_sockets.c.obj'},('Stock TLS object linked: mixed configuration',stock)
for source in ['ssl_tls.c','ssl_msg.c','ssl_tls12_client.c']:
 assert f'src/tls/{source}.o' in linkmap,source
image=build/'WetterHimmel.ino.bin';data=(build/'WetterHimmel.ino.partitions.bin').read_bytes();slots=[]
import struct
for i in range(0,len(data)-31,32):
 magic,typ,sub,offset,size,label,flags=struct.unpack('<HBBII16sI',data[i:i+32])
 if magic==0x50aa and typ==0 and sub in (0x10,0x11):slots.append(size)
assert len(slots)==2 and min(slots)==1966080,slots
assert image.stat().st_size<=min(slots)
results['ota']={'imageBytes':image.stat().st_size,'slotBytes':slots,'remaining':min(slots)-image.stat().st_size}
print(json.dumps(results,indent=2))
(root/'Tests/new/tls-build-check.json').write_text(json.dumps(results,indent=2)+'\n')
