from pathlib import Path
import subprocess,os,json,sys
root=Path(__file__).resolve().parents[1];p=root/'Tests';out=p/'new';out.mkdir(exist_ok=True)
env=dict(os.environ)
env.setdefault("ARDUINOJSON_INCLUDE",str(Path.home()/"Arduino/libraries/ArduinoJson/src"))
env.setdefault("ARDUINOJSON_DIR",env["ARDUINOJSON_INCLUDE"])
commands=[['sh','run_native.sh']]+[['python3',s+'.py'] for s in ['wifi_recovery_test','starlink_scan_test','catalog_download_test','ota_handler_test']]+[['node','new/web-modern.cjs'],['python3','new/flight-native.py'],['python3','new/state-native.py'],['python3','new/route-native.py'],['python3','new/render-preview.py'],['python3','new/tls-chain.py'],['python3','new/hangar-native.py']]
commands += [['node','radar_model.cjs'],['node','radar_web.cjs'],['node','hangar_web.cjs']]
results=[]
for cmd in commands:
 with open(out/(Path(cmd[1]).stem+'.log'),'w') as f:
  try:run=subprocess.run(cmd,cwd=p,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180);code=run.returncode
  except subprocess.TimeoutExpired:code=124
 results.append({'command':' '.join(cmd),'exit':code});print(cmd[1],code,flush=True)
(out/'results.json').write_text(json.dumps(results,indent=2))
sys.exit(any(x['exit'] for x in results))
