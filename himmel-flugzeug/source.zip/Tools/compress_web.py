import gzip,pathlib,hashlib,json
root=pathlib.Path(__file__).resolve().parents[1]
p=root/'WetterHimmel/WebPage.template.h'
s=p.read_text().split('R"WWHTML(',1)[1].split(')WWHTML";',1)[0]
s=s.replace('<!--MODERN_CSS-->',(root/'Web/modern.css').read_text()).replace('<!--MODERN_HTML-->',(root/'Web/modern.html').read_text()).replace('// MODERN_JS',(root/'Web/modern.js').read_text()+'\n'+(root/'Web/radar-model.js').read_text()+'\n'+(root/'Web/radar.js').read_text())
b=gzip.compress(s.encode(),compresslevel=9,mtime=0)
# Normalize gzip OS byte across Python 3.12/3.14 runners.
b=b[:9]+bytes([255])+b[10:]
(root/'Web/preview.html').write_text(s)
(root/'WetterHimmel/WebPage.h').write_text('#pragma once\nstatic const char WEB_PAGE[] PROGMEM=R"WWHTML('+s+')WWHTML";\n')
(root/'WetterHimmel/WebCompressed.h').write_text('#pragma once\nstatic const uint8_t WEB_GZIP[] PROGMEM={'+','.join(map(str,b))+'};\n')
print('HTML',len(s.encode()),'gzip',len(b),'sha256',hashlib.sha256(b).hexdigest())
