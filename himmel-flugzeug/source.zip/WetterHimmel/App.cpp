#include "App.h"
#include "Starlink.h"
#include "Extras.h"
#include "Modern.h"
#include "UiDiagnostics.h"
Display lcd;
Settings cfg{};
Preferences prefs;
WebServer web(80);
SkyObject objects[24];
int objectCount = 0;
Satellite satellites[SAT_COUNT]{};
bool dirty = true;
SkyCamera skyCamera;
bool displayNight=false;
void uiDisplayBrightness(){lcd.setBrightness(displayAsleep?0:displayNight?min(cfg.brightness,extra.autoNight?extra.dim:55):cfg.brightness);}
void setDisplayNight(bool enabled){displayNight=enabled;prefs.putBool("nightDisplay",enabled);uiDisplayBrightness();dirty=true;}

String message, apPassword, csrf;
int page = 0, selected = -1;

uint32_t generation = 0;
static uint32_t lastViewSwitch=0;
void resetViewTimer(){lastViewSwitch=millis();}
double moonPhase = 0, sunAlt = 0;
time_t sunrise = 0, sunset = 0;
Display::Display() {
  auto b = bus.config();
  b.spi_host = SPI2_HOST;
  b.spi_mode = 0;
  b.freq_write = 27000000;
  b.freq_read = 10000000;
  b.spi_3wire = false;
  b.use_lock = true;
  b.dma_channel = SPI_DMA_CH_AUTO;
  b.pin_sclk = 14;
  b.pin_mosi = 13;
  b.pin_miso = 12;
  b.pin_dc = 2;
  bus.config(b);
  panel.setBus(&bus);
  auto p = panel.config();
  p.pin_cs = 15;
  p.pin_rst = -1;
  p.pin_busy = -1;
  p.panel_width = 320;
  p.panel_height = 480;
  p.memory_width = 320;
  p.memory_height = 480;
  p.readable = true;
  p.invert = false; // RC3: photos show inverted colors with true on this panel.
  p.rgb_order = false;
  p.bus_shared = true;
  panel.config(p);
  auto l = light.config();
  l.pin_bl = 27;
  l.invert = false;
  l.freq = 20000;
  l.pwm_channel = 7;
  light.config(l);
  panel.setLight(&light);
  auto t = touch.config();
  t.x_min = 0;
  t.x_max = 4095;
  t.y_min = 0;
  t.y_max = 4095;
  t.pin_int = 36;
  t.bus_shared = true;
  t.offset_rotation = 0;
  t.spi_host = SPI2_HOST;
  t.freq = 1000000;
  t.pin_sclk = 14;
  t.pin_mosi = 13;
  t.pin_miso = 12;
  t.pin_cs = 33;
  touch.config(t);
  panel.setTouch(&touch);
  setPanel(&panel);
}
bool clockReady() { return time(nullptr) > 1700000000; }
time_t viewTime() { return time(nullptr); }
String stamp(time_t t, bool date) {
  if (t < 1)
    return "--:--";
  struct tm tm;
  localtime_r(&t, &tm);
  char b[40];
  strftime(b, sizeof b, date ? "%d.%m.%Y %H:%M" : "%H:%M", &tm);
  return b;
}
String eventStamp(time_t t) {
  if (!clockReady() || t < 1) return "—";
  struct tm a{}, b{}; time_t now=time(nullptr);
  localtime_r(&now,&a);localtime_r(&t,&b);
  if(a.tm_year==b.tm_year && a.tm_yday==b.tm_yday) return "heute "+stamp(t);
  char date[12];strftime(date,sizeof date,"%d.%m.",&b);
  return String(date)+" "+stamp(t);
}
String bearing(double a) {
  if(!isfinite(a))return "—";
  a=fmod(a+360,360);
  const char *n[] = {"N", "NO", "O", "SO", "S", "SW", "W", "NW"};
  return n[(int)floor((a + 22.5) / 45) % 8];
}
void saveSettings() {
  prefs.putBytes("settings", &cfg, sizeof cfg);
  dirty = true;
}
void applyPlace() {
  setenv("TZ", cfg.places[cfg.place].tz, 1);
  tzset();
  generation++;
  satellites[3].valid=false;
  flight=Flight();
  resetSatPrediction();
  fetchSoon();
  skyUpdate();
  dirty = true;
}
void setView(int v) {
  if (v < 1 || v > 2)
    return;
  manualInteraction();
  cfg.view = v;lastViewSwitch=millis();
  page = 0;
  selected = -1;
  saveSettings();
  skyUpdate();
}
void appBegin() {
  Serial.begin(115200);
  prefs.begin("wetterwelt", false);
  if (prefs.getBytesLength("settings") == sizeof cfg)
    prefs.getBytes("settings", &cfg, sizeof cfg);
  if (cfg.version != 2 || cfg.placeCount < 1 || cfg.placeCount > 6 || cfg.wifiCount < 0 ||
      cfg.wifiCount > 6) {
    memset(&cfg, 0, sizeof cfg);
    cfg.version = 2;
    cfg.starlink = true;
    cfg.starlinkIds[0] = 44714;
    cfg.starlinkIds[1] = 44718;
    cfg.starlinkIds[2] = 44723;
    cfg.starlinkIds[3] = 44725;
    cfg.placeCount = 1;
    strcpy(cfg.places[0].name, "Bern");
    cfg.places[0].lat = 46.948;
    cfg.places[0].lon = 7.4474;
    cfg.places[0].height = 540;
    strcpy(cfg.places[0].tz, "CET-1CEST,M3.5.0,M10.5.0/3");
    cfg.brightness = 180;
    cfg.labels = cfg.lines = cfg.milky = cfg.satellites = true;
    saveSettings();
  }
  cfg.place = constrain(cfg.place, 0, cfg.placeCount - 1);
  cfg.rotation = cfg.rotation == 3 ? 3 : 1; // Landscape; physical USB side requires verification on the device.
  if (cfg.view < 1 || cfg.view > 2) { cfg.view = 1; saveSettings(); }
  setenv("TZ", cfg.places[cfg.place].tz, 1);
  tzset();
  csrf = String(esp_random(), HEX) + String(esp_random(), HEX);
  strcpy(satellites[0].name, "ISS");
  satellites[0].catalog = 25544;
  strcpy(satellites[1].name, "Tiangong");
  satellites[1].catalog = 48274;
  strcpy(satellites[2].name, "Hubble");
  satellites[2].catalog = 20580;
  strcpy(satellites[3].name,"Starlink automatisch");
  displayNight=prefs.getBool("nightDisplay",false);
  extrasBegin();
  modernBegin();
  uiBegin();
  starlinkBegin();
  netBegin();
  webBegin();
}
void appTick() {
  uiTick();
  healthTick();
  uint32_t webAt=micros();web.handleClient();uiDiag.webHandlerMaxUs=max(uiDiag.webHandlerMaxUs,micros()-webAt);
  extrasTick();
  modernTick();
  if(firmwareUploading)return;
  netTick();
  uiTick();
  starlinkTick();
  satTick();
  if(!networkBusy())visiblePassTick();
  uiTick();
  static uint32_t lastSky = 0;
  static bool hadClock=false;static time_t minute=-1;
  if(clockReady() && !hadClock){hadClock=true;skyUpdate();dirty=true;}
  if(time(nullptr)/60!=minute){minute=time(nullptr)/60;dirty=true;}
  uint32_t n = millis();
  if (clockReady() && n - lastSky > 30000) {
    lastSky = n;
    skyUpdate();
    dirty = true;
  }
  static uint32_t ageTick=0;if(page==0&&cfg.view==2&&n-ageTick>=5000){ageTick=n;dirty=true;}
  int viewSeconds=cfg.view==1?modern.skySeconds:modern.flightSeconds;
  if(!viewSeconds)viewSeconds=cfg.autoSeconds;
  if (!modern.priority && cfg.autoSeconds && !displayAsleep && !priorityActive() && page == 0 && n - lastViewSwitch > (uint32_t)viewSeconds * 1000) {
    lastViewSwitch = n;
    cfg.view = (modern.aircraft&&cfg.view==1?2:1);
    selected = -1;
    skyUpdate();
    dirty = true;
  }
  uiTick();
  if (dirty) {
    dirty = false;
    uiDraw();
  }
  delay(3);
}
