#pragma once
#include "App.h"
#include "Airframe.h"
#include "FlightRoute.h"
#define WW_VERSION "2.0.0-dev7"
struct ModernSettings {
 uint32_t version=1;char name[33]="HimmelFlugzeug";
 bool aircraft=true,approaching=false,priority=false,wakeOnFlight=false;
 int radius=50,showSeconds=20,cooldownSeconds=300,sleepMinutes=0;
 int skySeconds=0,flightSeconds=0; // 0 inherits the existing auto interval.
 int favorites[16];int favoriteCount=0;
};
struct Flight {
 bool checked=false,found=false,approaching=false;
 char category[3]={},description[65]={};
 bool rotorcraft=false;
 char callsign[17]={},type[17]={},hex[9]={},error[96]={};
 float distance=NAN,altitude=NAN,speed=NAN,track=NAN,azimuth=NAN;
 time_t received=0,positionAt=0;
};
extern ModernSettings modern;
extern Flight flight;
extern FlightRoute flightRoute;
extern bool displayAsleep;
extern String deviceBoot,deviceKey;
extern uint32_t renderMaxUs,touchMaxGapMs;
bool priorityActive();
void modernBegin();void modernTick();void modernState(JsonDocument &d);void modernWeb();
bool modernCommand(JsonDocument &d,String &error);
void modernJson(JsonObject d,const ModernSettings &m);bool modernRead(JsonVariantConst d,ModernSettings &m);
void wakeDisplay();bool touchSleepGate(bool down);
void manualInteraction();bool flightFresh();
bool parseFlight(JsonDocument &d,Flight &out,const Place &p,int radius,bool approaching,time_t now);
void modernDiagnostic(JsonDocument &d);
void visiblePassTick();void visiblePassJson(JsonObject d);
void sourceStarted(int kind);void sourceFinished(int kind,int http,uint32_t duration,const char*error,const char*trace);
void sourceJson(JsonObject d);

int automaticNextView();
