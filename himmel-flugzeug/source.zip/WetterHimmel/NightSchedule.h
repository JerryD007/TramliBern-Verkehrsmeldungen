#pragma once
inline bool nightScheduled(int minute,int start,int end){return start!=end&&(start<end?(minute>=start&&minute<end):(minute>=start||minute<end));}
