#pragma once
// Pinned Arduino-ESP32 3.3.0 / ESP-IDF b66b5448, esp-mbedTLS 98ae8db.
// Compile EVERY TLS translation unit with this configuration. Do not resize
// live buffers or alter a context allocated by the stock TLS library.
#define MBEDTLS_ALLOW_PRIVATE_ACCESS
#include "sdkconfig.h"
#include "esp_arduino_version.h"
#if ESP_ARDUINO_VERSION != ESP_ARDUINO_VERSION_VAL(3,3,0)
#error Use pinned Arduino ESP32 core 3.3.0
#endif
#if !defined(CONFIG_IDF_TARGET_ESP32)
#error This TLS build has only been validated for classic ESP32
#endif
#if defined(CONFIG_MBEDTLS_DYNAMIC_BUFFER) || defined(CONFIG_MBEDTLS_SSL_VARIABLE_BUFFER_LENGTH)
#error Unexpected SDK buffer ABI; use the pinned Arduino core
#endif
#undef CONFIG_MBEDTLS_SSL_MAX_CONTENT_LEN
#define CONFIG_MBEDTLS_ASYMMETRIC_CONTENT_LEN 1
#undef CONFIG_MBEDTLS_SSL_IN_CONTENT_LEN
#define CONFIG_MBEDTLS_SSL_IN_CONTENT_LEN 16384
#undef CONFIG_MBEDTLS_SSL_OUT_CONTENT_LEN
#define CONFIG_MBEDTLS_SSL_OUT_CONTENT_LEN 4096
#include "mbedtls/build_info.h"
#include "mbedtls/ssl.h"
_Static_assert(MBEDTLS_VERSION_NUMBER == 0x03060300, "Unexpected mbedTLS version");
_Static_assert(MBEDTLS_SSL_IN_CONTENT_LEN == 16384, "Full TLS receive capacity required");
_Static_assert(MBEDTLS_SSL_OUT_CONTENT_LEN == 4096, "TLS transmit budget mismatch");
