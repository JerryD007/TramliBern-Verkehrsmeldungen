#include "HimmelTlsConfig.h"
unsigned himmelTlsRxCapacity(void){return MBEDTLS_SSL_IN_CONTENT_LEN;}
unsigned himmelTlsTxCapacity(void){return MBEDTLS_SSL_OUT_CONTENT_LEN;}
