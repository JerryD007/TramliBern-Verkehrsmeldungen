// Adapter for CelesTrak OMM fields; angular input is degrees, mean motion rev/day.
#include "Omm.h"
#include <math.h>
#include <string.h>
int initOmm(TLE *tle, const OmmElements *o) {
  if (!isfinite(o->meanMotion) || o->meanMotion <= 0 || o->meanMotion > 20 || o->eccentricity < 0 ||
      o->eccentricity >= 1)
    return 0;
  memset(tle, 0, sizeof(*tle));
  ElsetRec *r = &tle->rec;
  r->whichconst = wgs72;
  jday(o->year, o->month, o->day, o->hour, o->minute, o->second, &r->jdsatepoch, &r->jdsatepochF);
  r->bstar = o->bstar;
  r->inclo = o->inclination * deg2rad;
  r->nodeo = o->raan * deg2rad;
  r->argpo = o->argPerigee * deg2rad;
  r->mo = o->meanAnomaly * deg2rad;
  r->ecco = o->eccentricity;
  double xp = 1440 / (2 * pi);
  r->no_kozai = o->meanMotion / xp;
  r->ndot = o->ndot / (xp * 1440);
  r->nddot = o->nddot / (xp * 1440 * 1440);
  strcpy(r->satid, "00000");
  tle->epoch = (int64_t)llround(((r->jdsatepoch - 2440587.5) + r->jdsatepochF) * 86400000);
  return sgp4init('a', r) && !r->error;
}
