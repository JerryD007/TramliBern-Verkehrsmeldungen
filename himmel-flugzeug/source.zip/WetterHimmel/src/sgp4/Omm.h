#pragma once
#include "TLE.h"
typedef struct {
  int year, month, day, hour, minute;
  double second, meanMotion, eccentricity, inclination, raan, argPerigee, meanAnomaly, bstar, ndot,
      nddot;
} OmmElements;
int initOmm(TLE *tle, const OmmElements *o);
