#pragma once
#include <stdint.h>
struct UiDiagnostics {
 uint32_t attempts=0,failures=0,fallbacks=0,releases=0,draws=0,lastDrawMs=0,lastFailureMs=0,failedLargest=0;
 uint32_t webCalls=0,webMaxMs=0,webLastMs=0,webBytes=0,webRows=0;
 uint32_t webHandlerMaxUs=0;
 uint32_t pixelBytes=0;
 uint32_t hitBytes=0;bool hitIram=false;
 uint8_t bits=4;
};
extern UiDiagnostics uiDiag;
