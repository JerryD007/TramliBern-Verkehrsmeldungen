#include "App.h"
#include "UiDiagnostics.h"
#include "Extras.h"
#include "Modern.h"
#include "Starlink.h"
#include "Catalog.h"
#include "StarNames.h"
#include "Visibility.h"
#include "WebCompressed.h"
// Called on the main loop, which also publishes network jobs. A handler cannot
// race the start of a TLS job; it finishes before netTick can queue that job.
bool webMemoryAvailable() {
  if(!networkBusy())return true;
  web.sendHeader("Cache-Control","no-store");
  web.sendHeader("Retry-After","2");
  web.send(503,"text/plain","Datenabruf laeuft; bitte kurz warten");
  return false;
}
class JsonWebWriter {
  char buffer[512];size_t used=0;
public:
  void flush(){if(used){web.sendContent(buffer,used);used=0;}}
  size_t write(uint8_t byte){buffer[used++]=(char)byte;if(used==sizeof buffer)flush();return 1;}
  size_t write(const uint8_t *data,size_t len){for(size_t i=0;i<len;i++)write(data[i]);return len;}
};
void webReplyJson(JsonDocument &d) {
  if(d.overflowed()){web.send(503,"text/plain","Speicher fuer Antwort fehlt; bitte erneut versuchen");return;}
  web.sendHeader("Cache-Control", "no-store");
  web.setContentLength(measureJson(d));
  web.send(200, "application/json", "");
  JsonWebWriter writer;serializeJson(d,writer);writer.flush();
}
static void reply(JsonDocument &d){webReplyJson(d);}
void stateJson(JsonDocument &d) {
  extrasState(d);
  modernState(d);
  d["starlinkStatus"]=starlinkStatus;d["starlinkCount"]=starlinkCount;d["starlinkScanMs"]=starlinkScanMs;
  auto cs=starlinkCatalogStatus();
  auto c=d["starlinkCatalog"].to<JsonObject>();
  c["busy"]=cs.busy;c["sdReady"]=cs.sdReady;c["backup"]=cs.backup;
  c["phase"]=cs.phase;c["error"]=cs.error;c["bytes"]=cs.bytes;c["total"]=cs.total;
  c["accepted"]=cs.accepted;c["rejected"]=cs.rejected;c["stored"]=cs.stored;c["usable"]=cs.usable;
  c["fetched"]=cs.fetched?stamp(cs.fetched,true):"Noch kein Katalog";
  c["http"]=cs.http;c["tls"]=cs.tls;c["tlsText"]=cs.tlsText;
  c["attemptAt"]=cs.lastFetch.at?stamp(cs.lastFetch.at,true):"Noch kein gespeicherter HTTPS-Abruf";
  c["lastHttp"]=cs.lastFetch.http;c["lastTls"]=cs.lastFetch.tls;c["lastTlsText"]=cs.lastFetch.tlsText;
  c["lastError"]=cs.lastFetch.error;c["lastBytes"]=cs.lastFetch.bytes;c["interrupted"]=cs.lastFetch.interrupted;
  c["restored"]=cs.restored;c["importing"]=cs.importing;
  c["canImport"]=clockReady()&&!networkBusy()&&!cs.busy;
  c["waitReason"]=cs.lastFetch.at?(cs.lastFetch.interrupted?"Abruf begonnen, Abschluss nicht protokolliert (z.B. Neustart)":cs.lastFetch.error[0]?"Wartezeit nach dem letzten Abruffehler":"Reguläres Aktualisierungsintervall"):
      "Gespeicherter Termin; ältere Firmware hat keinen Abrufgrund protokolliert";
  c["next"]=eventStamp(max(starlinkNext,satHoldUntil));
  c["canRefresh"]=cfg.starlink && WiFi.status()==WL_CONNECTED && clockReady() && !cs.busy && !satPaused && time(nullptr)>=max(starlinkNext,satHoldUntil);
  auto health=d["health"].to<JsonObject>();healthJson(health,false);
  d["satPaused"] = satPaused;
  d["satPauseReason"] = satPauseReason;
  d["satHoldUntil"] = eventStamp(satHoldUntil);
  d["token"] = csrf;
  d["version"] = WW_VERSION;
  d["view"] = cfg.view;
  auto camera=d["skyCamera"].to<JsonObject>();camera["zoom"]=skyCamera.zoom;camera["panX"]=skyCamera.panX;camera["panY"]=skyCamera.panY;camera["revision"]=skyCamera.revision;
  d["clockReady"] = clockReady();
  d["time"] = clockReady() ? stamp(time(nullptr), true) : "Warte auf NTP";
  d["displayTime"] = stamp(viewTime(), true);
  d["connected"] = WiFi.status() == WL_CONNECTED;
  d["ip"] = (WiFi.status() == WL_CONNECTED ? WiFi.localIP() : WiFi.softAPIP()).toString();
  d["ssid"] = WiFi.SSID();
  d["wifiStatus"] = (int)WiFi.status();
  if (WiFi.status() == WL_CONNECTED) d["rssi"] = WiFi.RSSI();
  else d["rssi"] = nullptr;
  d["message"] = message;
  d["scanning"] = scanRunning || scanRequested;
  d["place"] = cfg.place;
  d["brightness"] = cfg.brightness;
  d["nightDisplay"]=displayNight;
  d["autoSeconds"] = cfg.autoSeconds;
  d["labels"] = cfg.labels;
  d["lines"] = cfg.lines;
  d["milky"] = cfg.milky;
  d["satellites"] = cfg.satellites;
  d["starlink"] = cfg.starlink;
  auto places = d["places"].to<JsonArray>();
  for (int i = 0; i < cfg.placeCount; i++) {
    auto p = places.add<JsonObject>();
    p["id"] = i;
    p["name"] = cfg.places[i].name;
    p["lat"] = cfg.places[i].lat;
    p["lon"] = cfg.places[i].lon;
    p["height"] = cfg.places[i].height;
    p["tz"] = cfg.places[i].tz;
  }
  auto wifi = d["wifi"].to<JsonArray>();
  for (int i = 0; i < cfg.wifiCount; i++) {
    auto p = wifi.add<JsonObject>();
    p["id"] = i;
    p["ssid"] = cfg.wifi[i].ssid;
  }
  auto scan = d["networks"].to<JsonArray>();
  for (int i = 0; i < nearbyCount; i++)
    scan.add(nearby[i]);
  d["moon"] = round((1 - cos(moonPhase * DEG_TO_RAD)) * 50);
  d["moonWaxing"] = moonPhase < 180;
  d["sunAlt"] = sunAlt;
  d["heap"] = ESP.getFreeHeap();
  d["minHeap"] = ESP.getMinFreeHeap();
  d["sunrise"] = stamp(sunrise, true);
  d["sunset"] = stamp(sunset, true);
  auto obj = d["objects"].to<JsonArray>();
  for (int i = 0; i < objectCount; i++) {
    auto &o = objects[i];
    auto a = obj.add<JsonObject>();
    a["name"] = o.name;
    a["az"] = o.az;
    a["alt"] = o.alt;
    a["mag"] = o.mag;
    a["lon"] = o.x;
    a["kind"] = o.kind;
  }
  auto sat = d["sats"].to<JsonArray>();
  for (auto &s : satellites) {
    auto a = sat.add<JsonObject>();
    a["catalog"] = s.catalog;
    a["index"] = (int)(&s-satellites);
    a["retry"] = clockReady() ? eventStamp(satelliteRetry(&s-satellites)) : "Warte auf NTP";
    a["passReady"] = s.set > time(nullptr);
    a["countdown"] = satelliteCountdown(s);
    a["riseIn"] = s.set>time(nullptr)?max((int64_t)0,(int64_t)s.rise-time(nullptr)):-1;
    a["duration"] = s.set>time(nullptr)?(s.set-s.rise):0;
    a["ongoing"] = s.passOngoing;
    a["visibility"] = visibilityLabel((s.visibility!=5 || satelliteCandidateSeconds(s,clockReady(),time(nullptr))) && clockReady() && s.valid && llabs((int64_t)time(nullptr)-s.epoch)<=7*86400 && llabs((int64_t)time(nullptr)-s.visibilityAt)<=20?s.visibility:0);
    a["sightSeconds"] = satelliteCandidateSeconds(s,clockReady(),time(nullptr));
    a["bearing"] = bearing(s.az);
    a["starlink"] = &s >= satellites + 3;
    a["slot"] = (int)(&s - satellites) - 3;
    a["name"] = s.name;
    a["orbitValid"] = s.valid && clockReady() && llabs((int64_t)time(nullptr)-s.epoch)<=7*86400;
    a["valid"] = satellitePositionCurrent(s,clockReady(),time(nullptr));
    a["positionAge"] = clockReady()&&s.visibilityAt>0?int64_t(time(nullptr))-s.visibilityAt:-1;
    a["orbitAge"] = clockReady()&&s.epoch>0?int64_t(time(nullptr))-s.epoch:-1;
    a["error"] = s.error;
    a["epoch"] = stamp(s.epoch, true);
    a["az"] = s.az;
    a["alt"] = s.alt;
    a["rise"] = stamp(s.rise, true);
    a["set"] = stamp(s.set, true);
    a["max"] = s.maxAlt;
    a["direction"] = bearing(s.startAz) + " → " + bearing(s.endAz);
  }
}
static bool number(JsonVariant v, double lo, double hi) {
  return v.is<double>() && isfinite(v.as<double>()) && v.as<double>() >= lo && v.as<double>() <= hi;
}
bool applyCommand(JsonDocument &d, String &error) {
  String a = d["action"] | "";
  if(a=="modern"||a=="wake"||a=="sleep"||a=="hangar"||a=="webRoute")return modernCommand(d,error);
  if(a=="extras"||a=="highlight")return extrasCommand(d,error);
  if(starlinkImportBusy()&&(a=="wifiSave"||a=="wifiConnect"||a=="wifiDelete"||a=="scan")){error="Bitte CSV-Import zuerst beenden oder abbrechen";return false;}
  if (a == "starlinkRefresh") return requestStarlinkCatalog(error);
  if(a=="skyCamera"){
    if(!number(d["zoom"],1,4)||!number(d["panX"],-324,324)||!number(d["panY"],-324,324)) {error="Zoomdaten ungültig";return false;}
    skyCamera.set(d["zoom"].as<double>(),d["panX"].as<double>(),d["panY"].as<double>());
    if(cfg.view!=1||page!=0)setView(1);
    dirty=true;return true;
  }
  if (a == "view") {
    int v = d["value"] | -1;
    if (v < 1 || v > 2) {
      error = "Ansicht ungültig";
      return false;
    }
    setView(v);
    return true;
  }
  if (a == "satResume") {
    resumeSatellites();
    return true;
  }
  if (a == "scan") {
    scanStart();
    return true;
  }
  if (a == "wifiSave") {
    if (!saveWifi(d["ssid"] | "", d["password"] | "")) {
      error = message;
      return false;
    }
    return true;
  }
  if (a == "wifiConnect" || a == "wifiDelete") {
    int i = d["id"] | -1;
    if (i < 0 || i >= cfg.wifiCount) {
      error = "WLAN fehlt";
      return false;
    }
    if (a == "wifiConnect")
      connectProfile(i);
    else
      deleteWifi(i);
    return true;
  }
  if (a == "placeSelect" || a == "placeDelete") {
    int i = d["id"] | -1;
    if (i < 0 || i >= cfg.placeCount) {
      error = "Standort fehlt";
      return false;
    }
    if (a == "placeDelete") {
      if (cfg.placeCount == 1) {
        error = "Ein Standort muss bleiben";
        return false;
      }
      for (int k = i; k < cfg.placeCount - 1; k++)
        cfg.places[k] = cfg.places[k + 1];
      cfg.placeCount--;
      cfg.place = 0;
    } else
      cfg.place = i;
    saveSettings();
    applyPlace();
    return true;
  }
  if (a == "placeSave") {
    int i = d["id"] | -1;
    String n = d["name"] | "", tz = d["tz"] | "";
    if (i < -1 || i >= cfg.placeCount || n.isEmpty() || n.length() > 39 || tz.isEmpty() ||
        tz.length() > 79 || !number(d["lat"], -90, 90) || !number(d["lon"], -180, 180) ||
        !number(d["height"], -500, 9000)) {
      error = "Standortdaten prüfen";
      return false;
    }
    if (i == -1) {
      if (cfg.placeCount == 6) {
        error = "Maximal 6 Standorte";
        return false;
      }
      i = cfg.placeCount++;
    }
    auto &p = cfg.places[i];
    strlcpy(p.name, n.c_str(), 40);
    strlcpy(p.tz, tz.c_str(), 80);
    p.lat = d["lat"];
    p.lon = d["lon"];
    p.height = d["height"];
    cfg.place = i;
    saveSettings();
    applyPlace();
    return true;
  }
  if (a == "display") {
    if (d["brightness"].is<int>())
      cfg.brightness = constrain(d["brightness"].as<int>(), 20, 255);
    if (d["autoSeconds"].is<int>())
      cfg.autoSeconds = d["autoSeconds"] == 0 ? 0 : constrain(d["autoSeconds"].as<int>(), 10, 3600);
    if (d["labels"].is<bool>())
      cfg.labels = d["labels"];
    if (d["lines"].is<bool>())
      cfg.lines = d["lines"];
    if (d["milky"].is<bool>())
      cfg.milky = d["milky"];
    if (d["satellites"].is<bool>())
      cfg.satellites = d["satellites"];
    if (d["starlink"].is<bool>())
      cfg.starlink = d["starlink"];
    if(d["nightDisplay"].is<bool>())setDisplayNight(d["nightDisplay"].as<bool>());
    uiDisplayBrightness();
    saveSettings();
    return true;
  }
  error = "Unbekannte Aktion";
  return false;
}
void webBegin() {
  web.on("/", HTTP_GET, [] {
    web.sendHeader("Cache-Control", "no-store");
    web.sendHeader("Content-Encoding","gzip");
    web.send_P(200, "text/html; charset=utf-8", (const char*)WEB_GZIP,sizeof WEB_GZIP);
  });
  web.on("/api/state", HTTP_GET, [] {
    if(!webMemoryAvailable())return;
    JsonDocument d;
    stateJson(d);
    reply(d);
  });
  web.on("/api/health", HTTP_GET, [] {if(!webMemoryAvailable())return;JsonDocument d;auto o=d.to<JsonObject>();healthJson(o,true);reply(d);});
  web.on("/api/sky", HTTP_GET, [] {
    if(!webMemoryAvailable())return;
    uint32_t skyStarted=millis();++uiDiag.webCalls;uiDiag.webBytes=uiDiag.webRows=0;
    // Send small rows instead of retaining hundreds of stars in a heap document.
    web.sendHeader("Cache-Control","no-store");
    web.setContentLength(CONTENT_LENGTH_UNKNOWN);
    web.send(200,"application/json", "");
    String chunk,encoded;chunk.reserve(1536);encoded.reserve(256);JsonDocument row;bool first=true;
    auto flush=[&](){if(chunk.length()){uiDiag.webBytes+=chunk.length();web.sendContent(chunk);chunk="";}yield();};
    auto emit=[&](){++uiDiag.webRows;if(!first)chunk+=',';first=false;serializeJson(row,encoded);chunk+=encoded;row.clear();if(chunk.length()>1024)flush();};
    auto array=[&](const char *key){chunk+=key;first=true;};
    array("{\"stars\":[");
    if(clockReady()) {int id=0;for(auto &s:stars){id++;double a,h;int x,y;starHorizontal(s.ra,s.dec,a,h);
      if(project(a,h,x,y)){auto r=row.to<JsonArray>();r.add(x);r.add(y);r.add(s.mag);r.add(a);r.add(h);r.add(id);r.add(starName(id-1));emit();}}}
    array("],\"lines\":[");
    if(clockReady()&&cfg.lines)for(auto &s:constellationLines){double a,h,b,k;int x,y,u,v;
      starHorizontal(s.ra1,s.dec1,a,h);starHorizontal(s.ra2,s.dec2,b,k);
      if(project(a,h,x,y)&&project(b,k,u,v)){auto r=row.to<JsonArray>();r.add(x);r.add(y);r.add(u);r.add(v);emit();}}
    array("],\"constellations\":[");
    if(clockReady()&&cfg.labels)for(auto &s:constellationLabels){double a,h;int x,y;starHorizontal(s.ra,s.dec,a,h);
      if(h>15&&project(a,h,x,y)){auto r=row.to<JsonArray>();r.add(x);r.add(y);r.add(s.name);emit();}}
    array("],\"mw\":[");
    if(clockReady()&&cfg.milky)for(int i=0;i<=360;i+=3){astro_spherical_t s{ASTRO_SUCCESS,0,(double)i,1};
      auto t=Astronomy_TimeFromDays((double)viewTime()/86400-10957.5);
      auto eq=Astronomy_EquatorFromVector(Astronomy_RotateVector(Astronomy_Rotation_GAL_EQJ(),Astronomy_VectorFromSphere(s,t)));
      double a,h;int x,y;starHorizontal(eq.ra,eq.dec,a,h);
      if(project(a,h,x,y)){auto r=row.to<JsonArray>();r.add(x);r.add(y);}else row.set(nullptr);emit();}
    array("],\"deep\":[");
    if(clockReady())for(auto &s:deepSky){double a,h;int x,y;starHorizontal(s.ra,s.dec,a,h);
      if(project(a,h,x,y)){auto r=row.to<JsonObject>();r["x"]=x;r["y"]=y;r["name"]=s.name;r["az"]=a;r["alt"]=h;r["mag"]=s.mag;emit();}}
    chunk+="]}";flush();web.sendContent("");uiDiag.webLastMs=millis()-skyStarted;uiDiag.webMaxMs=max(uiDiag.webMaxMs,uiDiag.webLastMs);
  });
  web.on("/api/action", HTTP_POST, [] {
    if (web.header("X-WW-Token") != csrf) {
      web.send(403, "text/plain", "Bitte Seite neu laden");
      return;
    }
    if (web.arg("plain").length() > 2048) {
      web.send(413);
      return;
    }
    JsonDocument d;
    auto e = deserializeJson(d, web.arg("plain"));
    String error;
    if (e || !applyCommand(d, error)) {
      web.send(400, "text/plain", e ? "JSON ungueltig" : error);
      return;
    }
    JsonDocument result;result["ok"]=true;result["view"]=cfg.view;
    auto camera=result["skyCamera"].to<JsonObject>();camera["zoom"]=skyCamera.zoom;camera["panX"]=skyCamera.panX;camera["panY"]=skyCamera.panY;
    reply(result);
  });
  web.on("/api/starlink/import",HTTP_POST,[]{
    if(web.header("X-WW-Token")!=csrf){web.send(403,"text/plain","Bitte Seite neu laden");return;}
    auto integer=[](const String &s,uint32_t &value){
      if(s.isEmpty()||s.length()>10)return false;uint64_t n=0;
      for(size_t i=0;i<s.length();i++){if(s[i]<'0'||s[i]>'9')return false;n=n*10+s[i]-'0';if(n>UINT32_MAX)return false;}
      value=(uint32_t)n;return true;
    };
    String op=web.arg("op"),error;uint32_t id=0,size=0,offset=0;bool ok=false;
    if(op=="start"){
      if(integer(web.arg("size"),size))ok=starlinkImportStart(size,id,error);
      else error="Ungültige Dateigröße";
    }else if(!integer(web.arg("id"),id))error="Ungültige Importsitzung";
    else if(op=="chunk"){
      const String body=web.arg("plain");
      if(integer(web.arg("offset"),offset)&&body.length()<=4096)
        ok=starlinkImportChunk(id,offset,(const uint8_t*)body.c_str(),body.length(),error);
      else error="Ungültiger Importabschnitt";
    }else if(op=="finish")ok=starlinkImportFinish(id,error);
    else if(op=="cancel")ok=starlinkImportCancel(id,error);
    else error="Unbekannter Importbefehl";
    if(!ok){web.send(400,"text/plain",error);return;}
    JsonDocument d;d["ok"]=true;d["session"]=id;d["received"]=starlinkCatalogStatus().bytes;reply(d);
  });
  const char *headers[] = {"X-WW-Token","X-WW-Key"};
  web.collectHeaders(headers, 2);
  web.onNotFound([] { web.send(404, "text/plain", "Nicht gefunden"); });
  extrasWeb();
  modernWeb();
  web.begin();
}
