// Wetter & Weltall — E32R40T. Alle Module liegen neben dieser Datei.
#include "App.h"
void setup() { appBegin(); }
void loop() { appTick(); }
