#include "WiFiMemory.h"
#include <esp_wifi.h>
#include <esp_arduino_version.h>
#if ESP_ARDUINO_VERSION != ESP_ARDUINO_VERSION_VAL(3,3,0)
#error Use Arduino ESP32 3.3.0
#endif
#include "RetryPolicy.h"
#include "App.h"
#include "Modern.h"
#include "Starlink.h"
#include "RetryPolicy.h"
#include "Certificates.h"
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <esp_wifi.h>
#include "NetworkTrace.h"
#include "TlsDiagnostic.h"
#include <SD.h>
#include <new>
#include <atomic>
#include "AircraftFile.h"
#include "Radar.h"
#include "RadarDisplay.h"
#include "Hangar.h"

#include "RouteSchedule.h"
bool satPaused = false;
time_t satHoldUntil=0;
String satPauseReason;
static uint32_t satGap=0;
bool scanRunning = false, scanRequested = false;
String nearby[20];
int nearbyCount = 0;
static uint32_t scanAt = 0, attemptAt = 0, nextSat[SAT_COUNT] = {};
static int attempt = -1;
static bool beginPending = false, disconnectPending = false;
static bool wasConnected = false, busy = false;
static std::atomic<bool> catalogStreaming{false};
bool networkBusy(){return busy;}
bool networkSmallReplyAllowed(){return !busy||catalogStreaming.load(std::memory_order_acquire);}
void networkCatalogStreaming(bool value){catalogStreaming.store(value,std::memory_order_release);}
struct Job {
  int kind;
  uint32_t generation;
  Place place;
  int catalog;int radius;bool approaching;uint8_t radarSlot;char callsign[17],hex[9];
};
static bool collectRadar(JsonVariantConst,const Flight &f,void *context){
 RadarDot d;strlcpy(d.hex,f.hex,sizeof d.hex);strlcpy(d.callsign,f.callsign,sizeof d.callsign);strlcpy(d.type,f.type,sizeof d.type);
 d.distance=f.distance;d.azimuth=f.azimuth;d.track=f.track;d.altitude=f.altitude;d.speed=f.speed;d.positionAt=f.positionAt;d.rotorcraft=f.rotorcraft;
 ((RadarDisplay*)context)->add(d);return true;
}
struct Result {
  int kind;
  uint32_t generation;
  union Payload {
    struct Aircraft {Flight flight; RadarSnapshot radar; RadarDisplay displayRadar;} aircraft;
    FlightRoute route;
    char omm[1600];
    Payload():omm{} {}
  } payload;
  int catalog;
  char error[96];
  char diagnostic[1024];
  uint32_t duration;
  int httpStatus;
  uint32_t retrySeconds;
};
// Single producer/consumer slot: main queues the next job only after consuming it.
// Replaces the full Result queue copy and the worker's stack-local Result.
static Result resultSlot;
static_assert(sizeof(Result)<3200,"Network result must not retain unrelated job payloads");
static QueueHandle_t jobs, results;
static RouteSchedule routeSchedule;
static uint32_t nextAircraft=0;static time_t aircraftHoldUntil=0,routeHoldUntil=0;
static unsigned aircraftLimited=0,routeLimited=0;
time_t aircraftNextAttempt(){if(aircraftHoldUntil>time(nullptr))return aircraftHoldUntil;int32_t left=nextAircraft?int32_t(nextAircraft-millis()):0;return time(nullptr)+(left>0?(left+999)/1000:0);}
uint32_t aircraftWaitSeconds(){time_t left=aircraftNextAttempt()-time(nullptr);return left>0?uint32_t(left):0;}

static char requestedCall[17]={},requestedHex[9]={};
static uint32_t webRouteNext=0;
bool requestWebRoute(const char *call,const char *hex,String &error){
 if(!routeCallsign(call)||strlen(hex)!=6){error="Flugkennung ungueltig";return false;}
 for(const char*p=hex;*p;p++)if(!isxdigit((unsigned char)*p)){error="ICAO-Kennung ungueltig";return false;}
 if(requestedCall[0]||(webRouteNext&&(int32_t)(millis()-webRouteNext)<0)){error="Routenabfrage wartet; bitte spaeter erneut versuchen";return false;}
 strlcpy(requestedCall,call,sizeof requestedCall);strlcpy(requestedHex,hex,sizeof requestedHex);
 webFlightRoute=FlightRoute();strlcpy(webRouteError,"Routenabfrage vorgemerkt",sizeof webRouteError);webRouteNext=millis()+60000;return true;
}
static bool getUrl(String url, String &data, String &error, int &httpStatus, uint32_t &retrySeconds, char *diagnostic = nullptr, unsigned maxBytes=24000, File *spool=nullptr) {
  httpStatus=0; const bool flightSource=url.startsWith("https://opendata.adsb.fi/")||url.startsWith("https://api.adsbdb.com/");retrySeconds=flightSource?0:7200;
  NetworkTrace trace(diagnostic, error);
  TlsDiagnostic::Client client; // Destroy TLS before the final memory measurement.
  if (diagnostic) {
    IPAddress resolved;
    uint32_t dnsStart = millis();
    String host=url.substring(8);host=host.substring(0,host.indexOf('/'));
    int dnsResult = WiFi.hostByName(host.c_str(), resolved);
    trace.add("DNS %s: %s (%lu ms)\n",host.c_str(), dnsResult == 1 ? resolved.toString().c_str() : "FEHLGESCHLAGEN", (unsigned long)(millis()-dnsStart));
    if (dnsResult != 1) { error = "DNS-Aufloesung fehlgeschlagen"; return false; }
  }
  if(url.startsWith("https://opendata.adsb.fi/")){
    client.useAircraftRoot();
    if(diagnostic)trace.add("Trust: native X509 GTS Root R4; host/time verification ON\n");
  }else if(url.startsWith("https://api.adsbdb.com/")){
    client.useAircraftRoot(true);
    if(diagnostic)trace.add("Trust: RundeUhr native root set; host/time verification ON\n");
  }else{
    client.setCACertBundle(rootBundle, sizeof rootBundle);
    if(diagnostic){client.enableTrace();trace.add("CA bundle: %u bytes; X509 trace active\n",(unsigned)sizeof rootBundle);}
  }
  client.setTimeout(25000);
  HTTPClient h;
  h.setConnectTimeout(8000);
  h.setTimeout(25000);
  h.useHTTP10(true);
  h.setFollowRedirects(HTTPC_DISABLE_FOLLOW_REDIRECTS);
  if (!h.begin(client, url)) {
    error = "HTTPS Start fehlgeschlagen";
    return false;
  }
  h.addHeader("User-Agent", "HimmelFlugzeug/2.0 private-ESP32");
  const char *wanted[]={"Retry-After"};h.collectHeaders(wanted,1);
  if(diagnostic)memoryProbePhase(2); // Includes TCP/TLS handshake and response headers.
  int status = h.GET();httpStatus=status;
  if(diagnostic)trace.memory("Nach GET, TLS noch offen");
  if(diagnostic)memoryProbePhase(3);
  if (diagnostic) {
    trace.add("HTTPClient: %d; TX calls/short %lu/%lu bytes %u/%u; pre-TX internal/default free/max %lu/%lu DMA %lu\n",status,(unsigned long)client.writes,(unsigned long)client.shortWrites,(unsigned)client.written,(unsigned)client.requested,(unsigned long)client.txFree,(unsigned long)client.txLargest,(unsigned long)client.txDma);
    trace.add("X509 callbacks: %u\n%.160s\n",TlsDiagnostic::callbacks,TlsDiagnostic::detail);
    if(status>0)trace.add("TLS: Verbindung aufgebaut; HTTP-Antwort empfangen\n");
    else {
      char tlsText[192] = {};
      int tlsCode = client.lastError(tlsText, sizeof tlsText);
      if(tlsCode<0)trace.add("TLS-Code: %d\nTLS-Detail: %.160s\n",tlsCode,tlsText);
      else trace.add("TLS: Kein negativer TLS-Fehlercode verfügbar\n");
    }
  }
  String retry=h.header("Retry-After");
  if(retry.length()) {
    uint32_t seconds=0;
    if(RetryPolicy::delta(retry.c_str(),seconds))retrySeconds=flightSource?seconds:max((uint32_t)7200,seconds);
    else {struct tm tm{};char *end=strptime(retry.c_str(),"%a, %d %b %Y %H:%M:%S GMT",&tm);if(end&&!*end) {
      auto t=Astronomy_MakeTime(tm.tm_year+1900,tm.tm_mon+1,tm.tm_mday,tm.tm_hour,tm.tm_min,tm.tm_sec);
      int64_t delay=(int64_t)((t.ut+10957.5)*86400)-time(nullptr);
      seconds=delay<=0?1:(uint32_t)min(delay,(int64_t)UINT32_MAX);
      retrySeconds=flightSource?seconds:max((uint32_t)7200,seconds);
    }}
  }
  if (status != 200) {
    error = status == HTTPC_ERROR_READ_TIMEOUT ? "Zeitlimit beim Datenabruf (-11)" :
            status < 0 ? "Verbindung fehlgeschlagen (" + String(status) + ")" : "HTTP " + String(status);
    h.end();
    return false;
  }
  int length = h.getSize();
  if (length > (int)maxBytes) {
    error = "Antwort zu gross";
    h.end();
    return false;
  }
  data = "";
  if(!spool && !data.reserve(length > 0 ? length : 4096)){error="Antwortpuffer: Speichermangel";h.end();return false;}
  auto stream = h.getStreamPtr();
  uint32_t until = millis(), received=0;
  uint8_t chunk[512];
  while ((h.connected() || stream->available()) && (length < 0 || received < (unsigned)length)) {
    int available=stream->available();
    if(available>0){
      size_t n=min((size_t)available,sizeof chunk);
      if(length>=0)n=min(n,(size_t)(length-received));
      int got=stream->read(chunk,n);
      if(got>0){
        if(received+(unsigned)got>maxBytes){error=spool?"Antwortlimit: SD":"Antwortlimit: RAM-Puffer";h.end();return false;}
        if(spool ? spool->write(chunk,got)!=(size_t)got : !data.concat((const char*)chunk,got)){
          error=spool?"SD: Flugantwort nicht schreibbar":"Antwortpuffer: Speichermangel";h.end();return false;
        }
        received+=got;until=millis();
      }
    }
    if(millis()-until>25000){error="Antwort unvollstaendig";h.end();return false;}
    vTaskDelay(1);
  }
  h.end();
  if(diagnostic)trace.add("Antwort: %lu Byte; Speicher: %s\n",(unsigned long)received,spool?"SD (512-Byte Puffer)":"RAM");
  if(length>=0&&received!=(unsigned)length){error="Antwort unvollstaendig";return false;}
  return true;
}
bool loadOmm(Satellite &s, const String &json) {
  JsonDocument d;
  if (deserializeJson(d, json))
    return false;
  JsonVariant o = d.is<JsonArray>() ? d[0].as<JsonVariant>() : d.as<JsonVariant>();
  if (o["NORAD_CAT_ID"].as<int>() != s.catalog || o["OBJECT_NAME"].isNull())
    return false;
  const char *fields[] = {"MEAN_MOTION",    "ECCENTRICITY",      "INCLINATION",
                          "RA_OF_ASC_NODE", "ARG_OF_PERICENTER", "MEAN_ANOMALY",
                          "BSTAR",          "MEAN_MOTION_DOT",   "MEAN_MOTION_DDOT"};
  for (auto k : fields)
    if (!o[k].is<double>() || !isfinite(o[k].as<double>()))
      return false;
  double mm = o["MEAN_MOTION"], ecc = o["ECCENTRICITY"], inc = o["INCLINATION"];
  if (mm <= 0 || mm > 20 || ecc < 0 || ecc >= 1 || inc < 0 || inc > 180)
    return false;
  int y, m, day, h, min;
  double sec;
  String epoch = o["EPOCH"] | "";
  if (sscanf(epoch.c_str(), "%d-%d-%dT%d:%d:%lf", &y, &m, &day, &h, &min, &sec) != 6 || y < 2000 ||
      y > 2099 || m < 1 || m > 12 || day < 1 || day > 31)
    return false;
  OmmElements elements{y,
                       m,
                       day,
                       h,
                       min,
                       sec,
                       mm,
                       ecc,
                       inc,
                       o["RA_OF_ASC_NODE"],
                       o["ARG_OF_PERICENTER"],
                       o["MEAN_ANOMALY"],
                       o["BSTAR"],
                       o["MEAN_MOTION_DOT"],
                       o["MEAN_MOTION_DDOT"]};
  TLE tle{};
  if (!initOmm(&tle, &elements))
    return false;
  s.tle = tle;
  s.epoch = tle.epoch / 1000;
  strlcpy(s.name, o["OBJECT_NAME"] | "Satellit", sizeof s.name);
  s.valid = true;
  s.alt = -90;
  return true;
}
static void fetchTask(void *) {
  Job j;
  for (;;) {
    if (xQueueReceive(jobs, &j, (hangarBusy()||starlinkScanning())?0:pdMS_TO_TICKS(20)) != pdTRUE) {hangarWork();if(!hangarBusy())starlinkWork();else vTaskDelay(1);continue;}
    uint32_t jobStarted=millis();
    Result &r=resultSlot;
    new (&r) Result{}; // Construct in place; no large temporary on the worker stack.
    r.kind = j.kind;
    r.generation = j.generation;
    r.catalog = j.catalog;
    String data, error;
    if(j.kind==9){
      new (&r.payload.aircraft) Result::Payload::Aircraft{};
      String u="https://opendata.adsb.fi/api/v3/lat/"+String(j.place.lat,5)+"/lon/"+String(j.place.lon,5)+"/dist/"+String((int)ceil(j.radius/1.852));
      bool ramFallback=false;
      if(aircraftSdAcquire()){
        struct Release{~Release(){aircraftSdRelease();}} release;
        const char *path="/wetterhimmel/aircraft.tmp";
        SD.mkdir("/wetterhimmel");SD.remove(path);
        File file=SD.open(path,FILE_WRITE);
        if(!file)error="SD: Flugantwort nicht anlegbar";
        else if(getUrl(u,data,error,r.httpStatus,r.retrySeconds,r.diagnostic,262144,&file)){
          file.close();file=SD.open(path,FILE_READ);
          const char *why=nullptr;
          if(!file||!readAircraftFile(file,r.payload.aircraft.flight,j.place,j.radius,j.approaching,time(nullptr),why,collectRadar,&r.payload.aircraft.displayRadar))error=why?why:"SD: Flugantwort nicht lesbar";
          if(!error.length())hangarObserveFile(file,j.place,j.radius,time(nullptr));
        }
        file.close();
        if(!error.length()){
          const char *target=radarPath(j.radarSlot);SD.remove(target);
          if(SD.rename(path,target)){
            File saved=SD.open(target,FILE_READ);
            if(saved){r.payload.aircraft.radar.bytes=saved.size();r.payload.aircraft.radar.slot=j.radarSlot;r.payload.aircraft.radar.received=time(nullptr);r.payload.aircraft.radar.generation=j.generation;r.payload.aircraft.radar.lat=j.place.lat;r.payload.aircraft.radar.lon=j.place.lon;r.payload.aircraft.radar.radius=j.radius;}saved.close();
          }
        }
        SD.remove(path);
        ramFallback=error.startsWith("SD:");
      }else ramFallback=true;
      if(ramFallback){
        error="";
        hangarInterrupted("SD nicht bereit; keine Hangar-Speicherung");
        // Preserve aircraft support without an SD card; bounded small-response fallback.
        if(getUrl(u,data,error,r.httpStatus,r.retrySeconds,r.diagnostic,12000)){
          JsonDocument filter;aircraftFilter(filter);
          JsonDocument d;auto parsed=deserializeJson(d,data,DeserializationOption::Filter(filter));
          if(parsed)error=String("Flug-JSON: ")+parsed.c_str();
          else if(!parseFlight(d,r.payload.aircraft.flight,j.place,j.radius,j.approaching,time(nullptr)))error="Flugquelle: Zeit / Format ungueltig";
        }
      }
      if(error.length())hangarInterrupted("Flugdatenfehler: Abwesenheit nicht bestaetigt");
      else {if(ramFallback){r.payload.aircraft.displayRadar=RadarDisplay();r.payload.aircraft.displayRadar.limited=true;if(r.payload.aircraft.flight.found)collectRadar(JsonVariantConst(),r.payload.aircraft.flight,&r.payload.aircraft.displayRadar);}
       r.payload.aircraft.displayRadar.received=time(nullptr);r.payload.aircraft.displayRadar.generation=j.generation;r.payload.aircraft.displayRadar.radius=j.radius;}

    } else if(j.kind==10||j.kind==11){
      new (&r.payload.route) FlightRoute{};
      if(!routeCallsign(j.callsign))error="Rufzeichen ungueltig";
      else {String call=j.callsign;String u="https://api.adsbdb.com/v0/callsign/"+call;
       if(getUrl(u,data,error,r.httpStatus,r.retrySeconds,r.diagnostic,6144)){
        JsonDocument d;if(deserializeJson(d,data)||!parseAdsbRoute(d,r.payload.route,j.callsign,j.hex,time(nullptr)))error="Keine passende Katalogroute";
       }
      }
      if(!error.length()&&r.payload.route.found)hangarStoreRoute(r.payload.route);
    } else if(j.kind==8) {starlinkDownload(error,r.httpStatus,r.retrySeconds);networkCatalogStreaming(false);
    } else {
      String u =
          "https://celestrak.org/NORAD/elements/gp.php?CATNR=" + String(j.catalog) + "&FORMAT=JSON";
      if (getUrl(u, data, error, r.httpStatus, r.retrySeconds, r.diagnostic)) {
        if (data.length() >= sizeof r.payload.omm)
          error = "OMM-Antwort zu gross";
        else {
          Satellite test{};
          test.catalog = j.catalog;
          if (!loadOmm(test, data))
            error = "Keine gültigen OMM-Bahndaten";
          else
            strlcpy(r.payload.omm, data.c_str(), sizeof r.payload.omm);
        }
      }
    }
    r.duration=millis()-jobStarted;
    strlcpy(r.error, error.c_str(), sizeof r.error);
    Result *published=&r;
    xQueueSend(results, &published, portMAX_DELAY);
  }
}
void fetchSoon() { nextAircraft = 0; }
// WLAN scheduling ported from TramvajPraha v0.9.11 App.cpp (tickApp).
// Scans are requested by the user, queued until HTTPS is idle, and never periodic.
void scanStart() {
  if (scanRunning || scanRequested) return;
  scanRequested = true;
  scanAt = millis();
  message = "WLAN-Suche vorgemerkt";
  dirty = true;
}
void connectProfile(int i) {
  if (i < 0 || i >= cfg.wifiCount)
    return;
  if (scanRunning) {
    esp_wifi_scan_stop();
    WiFi.scanDelete();
    scanRunning = false;
  }
  scanRequested = false;
  attempt = i;
  attemptAt = millis();
  // Return the web action acknowledgement before changing the radio connection.
  disconnectPending = true;
  wasConnected = false;
  beginPending = true; // Let the disconnect finish without blocking touch or web.
  message = "Verbinde: " + String(cfg.wifi[i].ssid);
  dirty = true;
}
bool saveWifi(String s, String p) {
  if (s.isEmpty() || s.length() > 32 || p.length() > 63 || (!p.isEmpty() && p.length() < 8)) {
    message = "SSID/Passwort prüfen";
    return false;
  }
  int i = 0;
  while (i < cfg.wifiCount && s != cfg.wifi[i].ssid)
    i++;
  if (i == 6) {
    message = "Maximal 6 WLANs";
    return false;
  }
  if (i == cfg.wifiCount)
    cfg.wifiCount++;
  strlcpy(cfg.wifi[i].ssid, s.c_str(), 33);
  strlcpy(cfg.wifi[i].pass, p.c_str(), 65);
  saveSettings();
  connectProfile(i);
  return true;
}
void deleteWifi(int i) {
  if (i < 0 || i >= cfg.wifiCount)
    return;
  bool active = beginPending || WiFi.SSID() == cfg.wifi[i].ssid;
  for (int k = i; k < cfg.wifiCount - 1; k++)
    cfg.wifi[k] = cfg.wifi[k + 1];
  cfg.wifiCount--;
  memset(&cfg.wifi[cfg.wifiCount], 0, sizeof(WifiProfile));
  saveSettings();
  attempt = -1;
  beginPending = disconnectPending = false;
  if (active)
    WiFi.disconnect(false, true);
}
time_t satelliteRetry(int index) {
  if(index==3)return max(starlinkNext,satHoldUntil);
  if(index<0 || index>=SAT_COUNT) return 0;
  String id=String(satellites[index].catalog);
  time_t due=prefs.getLong64(("sr"+id).c_str(),0);
  if(!due) {time_t prev=prefs.getLong64(("sa"+id).c_str(),0);if(prev)due=prev+(satellites[index].valid?21600:7200);}
  return max(due,satHoldUntil);
}
void resumeSatellites() {
  if(!clockReady() || time(nullptr)<satHoldUntil) {
    message="Wartezeit bis "+eventStamp(satHoldUntil);dirty=true;return;
  }
  satPaused = false;
  satPauseReason="";
  prefs.putString("satReason","");
  prefs.putBool("satPause", false);
  dirty = true;
}
bool requestStarlinkCatalog(String &error) {
  if(!cfg.starlink){error="Bitte Starlink automatisch unter Anzeige einschalten";return false;}
  if(WiFi.status()!=WL_CONNECTED||!clockReady()){error="WLAN und Uhrzeit erforderlich";return false;}
  if(starlinkCatalogStatus().busy){error="Katalog wird bereits geladen";return false;}
  if(satPaused){error="Satellitenabrufe pausiert: "+satPauseReason;return false;}
  time_t due=max(starlinkNext,satHoldUntil);
  if(time(nullptr)<due){error="Nächster Katalogabruf ab "+eventStamp(due);return false;}
  starlinkNext=0;
  message="Starlink-Abruf vorgemerkt; Wetter hat Vorrang";dirty=true;return true;
}
void netBegin() {
  memoryProbeInit();
  aircraftHoldUntil=prefs.getLong64("airHold",0);routeHoldUntil=prefs.getLong64("routeHold",0);
  aircraftLimited=prefs.getUInt("airLimited",0);routeLimited=prefs.getUInt("routeLimited",0);
  satPaused = prefs.getBool("satPause", false);
  satHoldUntil=prefs.getLong64("satHold",0);
  satPauseReason=prefs.getString("satReason",satPaused?"Gespeicherte Pause: bitte fortsetzen":"");
  apPassword = prefs.getString("apPass", "");
  if (apPassword.length() < 12) {
    apPassword = String(esp_random(), HEX) + String(esp_random(), HEX) + "Ww";
    prefs.putString("apPass", apPassword);
  }
  // IDF b66b5448 esp_wifi_init is idempotent: Arduino's subsequent init
  // returns ESP_OK without replacing this configuration. No WiFi OFF path.
  wifi_init_config_t wifiConfig=WIFI_INIT_CONFIG_DEFAULT();configureWiFiMemory(wifiConfig);
  if(!Network.begin()||esp_wifi_init(&wifiConfig)!=ESP_OK){message="WLAN-Speicherinitialisierung fehlgeschlagen";busy=true;return;}
  WiFi.useStaticBuffers(false);
  WiFi.persistent(false);
  WiFi.mode(WIFI_AP_STA);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(false); // This state machine owns reconnects.
  WiFi.softAP("WetterWeltall", apPassword.c_str());
  configTzTime(cfg.places[cfg.place].tz, "pool.ntp.org", "time.cloudflare.com", "time.google.com");

  for (int i = 0; i < 3; i++) {
    String key = "omm" + String(i);
    String t = prefs.getString(key.c_str(), "");
    if (t.length())
      loadOmm(satellites[i], t);
  }

  jobs = xQueueCreate(1, sizeof(Job));
  results = xQueueCreate(1, sizeof(Result*));
  if (!jobs || !results || xTaskCreatePinnedToCore(fetchTask, "data+starlink", 14000, nullptr, 1, nullptr, 0) != pdPASS) {
    message = "Daten-Task: Speichermangel";
    busy = true;
  }
  // Try the last successful saved network directly; do not scan all channels first.
  if (cfg.wifiCount) connectProfile(0);
}
void netTick() {
  uint32_t now = millis();
  if (disconnectPending && !busy && !starlinkImportBusy() && now - attemptAt >= 500) {
    WiFi.disconnect(false, false);
    disconnectPending = false;
    attemptAt = now;
  }
  if (beginPending && !disconnectPending && now - attemptAt >= 150) {
    beginPending = false;
    if (attempt >= 0 && attempt < cfg.wifiCount)
      WiFi.begin(cfg.wifi[attempt].ssid, cfg.wifi[attempt].pass);
    attemptAt = now;
  }
  if (scanRequested && !busy && !starlinkImportBusy() && !beginPending) {
    scanRequested = false;
    WiFi.scanDelete();
    nearbyCount = 0;
    scanRunning = WiFi.scanNetworks(true, false) != WIFI_SCAN_FAILED;
    message = scanRunning ? "WLAN-Suche läuft" : "WLAN-Suche fehlgeschlagen";
    dirty = true;
  }
  if (scanRequested && now - scanAt >= 30000) {
    scanRequested = false;
    message = "WLAN-Suche: Datenabruf noch beschäftigt. Bitte erneut versuchen.";
    dirty = true;
  }
  if (scanRunning) {
    int n = WiFi.scanComplete();
    if (n >= 0) {
      nearbyCount = 0;
      for (int i = 0; i < n && nearbyCount < 20; i++) {
        String s = WiFi.SSID(i);
        bool found = s.isEmpty();
        for (int k = 0; k < nearbyCount; k++)
          if (nearby[k] == s)
            found = true;
        if (!found)
          nearby[nearbyCount++] = s;
      }
      WiFi.scanDelete();
      scanRunning = false;
      message = String(nearbyCount) + " WLANs gefunden";
      dirty = true;
    } else if (n == WIFI_SCAN_FAILED || now - scanAt > 30000) {
      esp_wifi_scan_stop();
      WiFi.scanDelete();
      scanRunning = false;
      message = "WLAN-Suche: Zeitlimit";
      dirty = true;
    }
  }
  bool connected = !beginPending && WiFi.status() == WL_CONNECTED;
  if (connected)
    beginPending = disconnectPending = false;
  if (connected && !wasConnected) {
    message = "Verbunden: " + WiFi.SSID();
    nextAircraft = 0;
    for (int i = 1; i < cfg.wifiCount; i++)
      if (WiFi.SSID() == cfg.wifi[i].ssid) {
        WifiProfile p = cfg.wifi[i];
        for (int k = i; k > 0; k--)
          cfg.wifi[k] = cfg.wifi[k - 1];
        cfg.wifi[0] = p;
        saveSettings();
        break;
      }
    attempt = 0;
    dirty = true;
  }
  if (!connected && wasConnected) {
    attemptAt = now;
    attempt = -1; // Successful profile is first: retry it before other saved networks.
    message = "Verbindung unterbrochen";
    dirty = true;
  }
  wasConnected = connected;
  // Same bounded round-robin as Praha: every 30 s, only when scan/fetch are idle.
  // Keep a working connection untouched; after a loss start with last successful profile.
  if (!connected && !beginPending && cfg.wifiCount && now - attemptAt >= 30000 &&
      !scanRunning && !scanRequested && !busy && !starlinkImportBusy())
    connectProfile((attempt + 1) % cfg.wifiCount);
  Result *receivedResult=nullptr;
  if (results && xQueueReceive(results, &receivedResult, 0) == pdTRUE) {
    const Result &r=*receivedResult;
    busy = false;
    healthResult(r.kind==11?10:r.kind,!r.error[0]);
    sourceFinished(r.kind==11?10:r.kind,r.httpStatus,r.duration,r.error,r.diagnostic);
    uiNetworkMemory(false);
    if(r.kind==9){
      if(r.httpStatus==429){aircraftHoldUntil=time(nullptr)+RetryPolicy::wait(r.retrySeconds,aircraftLimited);if(aircraftLimited<6)++aircraftLimited;prefs.putLong64("airHold",aircraftHoldUntil);prefs.putUInt("airLimited",aircraftLimited);nextAircraft=0;}
      else {nextAircraft=now+(r.error[0]?300000:30000);if(!r.error[0]&&(aircraftLimited||aircraftHoldUntil)){aircraftLimited=0;aircraftHoldUntil=0;prefs.remove("airHold");prefs.remove("airLimited");}}
      if(r.generation==generation){if(!r.error[0])flight=r.payload.aircraft.flight;else strlcpy(flight.error,r.error,sizeof flight.error);}
    }
    if(r.kind==10||r.kind==11){
      if(r.httpStatus==429){routeHoldUntil=time(nullptr)+RetryPolicy::wait(r.retrySeconds,routeLimited);if(routeLimited<6)++routeLimited;prefs.putLong64("routeHold",routeHoldUntil);prefs.putUInt("routeLimited",routeLimited);}
      else if(!r.error[0]&&(routeLimited||routeHoldUntil)){routeLimited=0;routeHoldUntil=0;prefs.remove("routeHold");prefs.remove("routeLimited");}
    }
    if(r.kind==9&&r.generation==generation&&!r.error[0]){uint32_t rev=radarDisplay.revision+1;radarDisplay=r.payload.aircraft.displayRadar;radarDisplay.revision=rev?rev:1;dirty=true;}
    if(r.kind==9&&r.generation==generation&&!r.error[0]&&r.payload.aircraft.radar.bytes){uint32_t rev=radarSnapshot.revision+1;radarSnapshot=r.payload.aircraft.radar;radarSnapshot.revision=rev?rev:1;}
    if(r.kind==10||r.kind==11)routeSchedule.finish(!r.error[0],now,r.httpStatus==429);
    if(r.kind==11){
      
      if(r.generation==generation){webFlightRoute=r.payload.route;strlcpy(webRouteError,r.error,sizeof webRouteError);}
    }
    if(r.kind==10||r.kind==11){if(r.generation==generation&&!r.error[0]&&flight.found&&!strcmp(r.payload.route.callsign,flight.callsign)&&!strcmp(r.payload.route.hex,flight.hex))flightRoute=r.payload.route;}
    if((r.kind>0&&r.kind<=3)||r.kind==8) {
      // Negative transport codes are NOT HTTP responses. No permanent pause.
      satGap=now+60000;
      if(pauseForHttp(r.httpStatus)) {
        satPaused=true;satHoldUntil=time(nullptr)+r.retrySeconds;
        satPauseReason="HTTP "+String(r.httpStatus)+" · Datenquelle prüfen";
        prefs.putBool("satPause",true);prefs.putLong64("satHold",satHoldUntil);
        prefs.putString("satReason",satPauseReason);message=satPauseReason;
      }
      time_t due=time(nullptr)+satelliteDelay(r.error[0]!=0,r.retrySeconds);
      prefs.putLong64(("sr"+String(r.catalog)).c_str(),due);
      if(r.kind<=3)nextSat[r.kind-1]=now+(r.error[0]?7200000:21600000);
      if(r.kind==8){
        auto c=starlinkCatalogStatus();
        // Local SD failures did not contact CelesTrak: retry card check in one minute.
        starlinkNext=c.attempted?c.lastFetch.next:time(nullptr)+60;
        prefs.putLong64("slNext",starlinkNext);
        if(r.error[0])starlinkStatus=r.error;
      }
    }
    if (r.kind > 0 && r.kind<=3 && r.catalog == satellites[r.kind - 1].catalog) {
      auto &s = satellites[r.kind - 1];
      strlcpy(s.error, r.error, sizeof s.error);
      if(r.error[0] && !s.valid) nextSat[r.kind-1]=now+7200000;
      if (!r.error[0] && loadOmm(s, r.payload.omm)) {
        s.fetched = time(nullptr);
        prefs.putString(("omm" + String(r.kind - 1)).c_str(), r.payload.omm);
        resetSatPrediction();
      }
    }
    dirty = true;
  }
  if (connected && clockReady() && !busy && !hangarBusy() && !scanRunning && !scanRequested && !starlinkImportBusy()) {
    Job j{};
    j.generation = generation;
    j.place = cfg.places[cfg.place];
    bool send = false;
    if (!satPaused && (satGap==0 || (int32_t)(now-satGap)>=0))
      for (int i = 0; i < 3; i++)
        if (nextSat[i] == 0 || (int32_t)(now - nextSat[i]) >= 0) {
          String key = "sa" + String(satellites[i].catalog);
          time_t due=satelliteRetry(i);
          int64_t remaining=(int64_t)due-time(nullptr);
          if(remaining>0) {nextSat[i]=now+(uint32_t)min(remaining,(int64_t)86400)*1000;continue;}
          prefs.putLong64(key.c_str(), time(nullptr));
          prefs.putLong64(("sr"+String(satellites[i].catalog)).c_str(),time(nullptr)+7200);
          nextSat[i] = now + 21600000;
          j.kind = i + 1;
          j.catalog = satellites[i].catalog;
          send = true;
          break;
        }
    if(!send && !starlinkScanning() && cfg.starlink && !satPaused && time(nullptr)>=starlinkNext && time(nullptr)>=satHoldUntil && (satGap==0 || (int32_t)(now-satGap)>=0)) {
      j.kind=8;send=true;starlinkNext=time(nullptr)+7200;starlinkStatus="Katalog wird geladen";starlinkCatalogQueued();
    }
    if(!send&&modern.aircraft&&time(nullptr)>=aircraftHoldUntil&&(nextAircraft==0||(int32_t)(now-nextAircraft)>=0)){j.kind=9;j.radarSlot=1-radarSnapshot.slot;j.radius=modern.radius;j.approaching=modern.approaching;send=true;nextAircraft=now+30000;}
    if(!send&&modern.aircraft&&requestedCall[0]&&routeSchedule.gapReady(now)&&time(nullptr)>=routeHoldUntil){j.kind=11;strlcpy(j.callsign,requestedCall,sizeof j.callsign);strlcpy(j.hex,requestedHex,sizeof j.hex);send=true;}
    if(!send&&modern.aircraft&&time(nullptr)>=routeHoldUntil&&flightFresh()&&routeCallsign(flight.callsign)&&!routeMatches(flightRoute,flight.callsign,flight.hex,time(nullptr))&&routeSchedule.ready(flight.callsign,flight.hex,now)){
      j.kind=10;strlcpy(j.callsign,flight.callsign,sizeof j.callsign);strlcpy(j.hex,flight.hex,sizeof j.hex);send=true;
    }
    if (send && jobs) {
      uiNetworkMemory(true);
      if (xQueueSend(jobs, &j, 0) == pdTRUE){busy=true;if(j.kind==10||j.kind==11){routeSchedule.begin(j.callsign,j.hex,now);if(j.kind==11)requestedCall[0]=0;}sourceStarted(j.kind==11?10:j.kind);}
      else {
        uiNetworkMemory(false);
        if(j.kind==8){starlinkCatalogCancel();starlinkNext=time(nullptr)+60;prefs.putLong64("slNext",starlinkNext);}
      }
    }
  }
}
