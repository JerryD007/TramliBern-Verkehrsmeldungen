#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
namespace Hangar {
constexpr int64_t absenceSeconds=900, maximumGap=120;
struct Record {
 uint32_t magic=0x48464731,version=1,sequence=0,passes=0;
 int64_t first=0,last=0,frame=0;
 char hex[7]={},registration[17]={},callsign[17]={},type[9]={};
 uint8_t reserved[14]={};uint32_t crc=0;
};
static_assert(sizeof(Record)<=128,"Hangar slot budget");
inline uint32_t checksum(const Record&r){uint32_t c=0xffffffff;auto p=(const uint8_t*)&r;for(size_t i=0;i<offsetof(Record,crc);i++){c^=p[i];for(int b=0;b<8;b++)c=(c>>1)^((0-(c&1))&0xedb88320);}return ~c;}
inline bool hexValid(const char*s){if(strlen(s)!=6)return false;for(int i=0;i<6;i++)if(!((s[i]>='0'&&s[i]<='9')||(s[i]>='a'&&s[i]<='f')))return false;return true;}
inline bool valid(const Record&r){return r.magic==0x48464731&&r.version==1&&r.hex[6]==0&&hexValid(r.hex)&&r.registration[16]==0&&r.callsign[16]==0&&r.type[8]==0&&r.passes>0&&r.first>0&&r.last>=r.first&&r.frame>=r.last&&r.crc==checksum(r);}
struct Coverage {
 int64_t start=0,previous=0;double lat=0,lon=0;int radius=0;
 void interrupt(){start=previous=0;}
 bool begin(int64_t now,double x,double y,int range){
  if(now<=0)return false;
  if(!previous||now<=previous||now-previous>maximumGap||x!=lat||y!=lon||range!=radius)start=now;
  previous=now;lat=x;lon=y;radius=range;return true;
 }
};
// Count only after >=15 minutes of continuously covered absence. The extra
// maximumGap is a conservative upper bound for the first absent observation.
inline bool observe(Record&r,const char*hex,int64_t position,int64_t now,const Coverage&coverage){
 if(!hexValid(hex)||position<=0||position>now||now-position>60)return false;
 if(r.passes&&strcmp(r.hex,hex))return false;
 if(r.passes&&position<r.last)return false;
 bool newPass=!r.passes;
 if(!newPass){int64_t absentFrom=r.frame+maximumGap;if(absentFrom<coverage.start)absentFrom=coverage.start;newPass=coverage.start>0&&now-absentFrom>=absenceSeconds;}
 if(!r.passes){snprintf(r.hex,sizeof r.hex,"%s",hex);r.first=position;}
 if(newPass&&r.passes!=UINT32_MAX)++r.passes;
 r.last=position;r.frame=now;return newPass;
}
inline void label(char*out,size_t cap,const char*s){if(!s||!*s)return;size_t n=0;while(*s&&n+1<cap){unsigned char c=*s++;if(c>=32&&c<127)out[n++]=c;}out[n]=0;}
inline bool before(const Record&a,const Record&b,bool byPasses){if(byPasses&&a.passes!=b.passes)return a.passes>b.passes;if(a.last!=b.last)return a.last>b.last;return strcmp(a.hex,b.hex)<0;}
}
