#pragma once
#include "App.h"
struct ExtraSettings { uint32_t version=1; bool largeMap=false,trails=true,autoNight=false; int start=1320,end=420,dim=35; };
extern ExtraSettings extra;
extern int highlightedObject;
extern bool firmwareUploading;
void extrasBegin();void extrasTick();void extrasWeb();void extrasState(JsonDocument &d);
bool extrasCommand(JsonDocument &d,String &error);
bool objectCoordinates(int id,double &az,double &alt,String &name);
bool satelliteFuture(int index,time_t t,double &az,double &alt);
bool nightScheduled(int minute,int start,int end);
