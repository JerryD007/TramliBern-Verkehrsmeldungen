#include "Radar.h"
#include "RadarDisplay.h"
RadarDisplay radarDisplay;
#include "Starlink.h"
#include <SD.h>
RadarSnapshot radarSnapshot;
RadarTransferStats radarTransfer;
FlightRoute webFlightRoute;
char webRouteError[96]={};
const char *radarPath(unsigned slot){return slot?"/wetterhimmel/radar1.json":"/wetterhimmel/radar0.json";}
static bool unsignedArg(const char *key,uint32_t &out){
 String s=web.arg(key);if(!s.length()||s.length()>9)return false;
 out=0;for(char c:s){if(c<'0'||c>'9')return false;out=out*10+c-'0';}return true;
}
void radarWeb(){
 web.on("/api/radar",HTTP_GET,[]{
  radarTransfer.requests++;
  if(!webMemoryAvailable()){radarTransfer.networkBusy++;return;}
  web.sendHeader("Cache-Control","no-store");
  const auto &s=radarSnapshot;
  if(!modern.aircraft||!s.revision||s.generation!=generation){web.send(404,"text/plain","Radar wartet auf erfolgreiche SD-Flugdaten");return;}
  if(!web.hasArg("offset")){
   JsonDocument d;d["revision"]=s.revision;d["bytes"]=s.bytes;d["received"]=(int64_t)s.received;d["now"]=(int64_t)time(nullptr);d["lat"]=s.lat;d["lon"]=s.lon;d["radius"]=s.radius;d["boot"]=deviceBoot;webReplyJson(d);return;
  }
  uint32_t offset,revision;
  if(!unsignedArg("offset",offset)||!unsignedArg("revision",revision)||offset>=s.bytes){web.send(400,"text/plain","Radarbereich ungueltig");return;}
  if(revision!=s.revision){radarTransfer.conflicts++;web.send(409,"text/plain","Neue Radaraufnahme; erneut laden");return;}
  if(!aircraftSdAcquire()){radarTransfer.sdBusy++;web.send(503,"text/plain","SD beschaeftigt");return;}
  // 1 KiB requests return control to the touch loop between chunks.
  File f=SD.open(radarPath(s.slot),FILE_READ);
  char data[1024];size_t want=min((uint32_t)sizeof data,s.bytes-offset),n=0;
  if(f&&f.size()==s.bytes&&f.seek(offset))n=f.readBytes(data,want);
  f.close();aircraftSdRelease();
  if(n!=want){radarTransfer.readErrors++;web.send(503,"text/plain","Radar-SD-Lesefehler");return;}
  radarTransfer.chunks++;radarTransfer.bytes+=n;
  web.setContentLength(n);web.send(200,"application/octet-stream","");web.sendContent(data,n);
 });
 web.on("/api/flight-route",HTTP_GET,[]{
  if(!webMemoryAvailable())return;
  JsonDocument d;auto&r=webFlightRoute;
  d["found"]=clockReady()&&routeMatches(r,r.callsign,r.hex,time(nullptr));d["callsign"]=r.callsign;d["hex"]=r.hex;d["origin"]=r.origin;d["destination"]=r.destination;d["originName"]=r.originName;d["destinationName"]=r.destinationName;d["airline"]=r.airline;d["stops"]=r.stops;d["received"]=(int64_t)r.received;d["error"]=webRouteError;webReplyJson(d);
 });
}
