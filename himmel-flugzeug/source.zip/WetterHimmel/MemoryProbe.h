#pragma once
#include <stddef.h>
#include <stdint.h>
struct MemoryFailure {
  size_t bytes=0;
  uint32_t caps=0,count=0;
  uint8_t phase=0;
  char allocator[24]={};
};
struct MemoryProbeResult {
  bool registered=false;
  MemoryFailure worker,other;
};
void memoryProbeInit();
void memoryProbeBegin();
void memoryProbePhase(uint8_t phase);
MemoryProbeResult memoryProbeEnd();

uint32_t memoryFailureTotal();

// Fixed-size history survives the end of a request, including recovered failures.
struct MemoryFailureEvent {
 uint32_t uptimeMs=0;size_t bytes=0;uint32_t caps=0;
 uint8_t phase=0;bool worker=false;
 char task[20]={},allocator[24]={};
};
unsigned memoryFailureHistory(MemoryFailureEvent *out,unsigned capacity);
