#pragma once
// Match Arduino 3.3.0 dynamic-buffer mode, limiting only burst pool counts.
template<class Config> void configureWiFiMemory(Config &cfg){
 cfg.static_tx_buf_num=0;cfg.dynamic_tx_buf_num=8;cfg.tx_buf_type=1;
 cfg.cache_tx_buf_num=4;cfg.static_rx_buf_num=4;cfg.dynamic_rx_buf_num=8;
}
