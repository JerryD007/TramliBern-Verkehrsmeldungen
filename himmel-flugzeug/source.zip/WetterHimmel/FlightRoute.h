#pragma once
#include <ArduinoJson.h>
#include <cstring>
#include <ctime>
#include <cmath>
struct FlightRoute {
 bool found=false;char callsign[17]={},hex[9]={},origin[5]={},destination[5]={};
 uint8_t stops=0;time_t received=0;
};
inline bool routeCallsign(const char *s){size_t n=strlen(s);if(n<3||n>8)return false;for(size_t i=0;i<n;i++)if(!((s[i]>='A'&&s[i]<='Z')||(s[i]>='0'&&s[i]<='9')))return false;return true;}
inline bool routeCode(JsonVariantConst v,size_t length){if(!v.is<const char*>())return false;const char*s=v; if(strlen(s)!=length)return false;for(size_t i=0;i<length;i++)if(s[i]<'A'||s[i]>'Z')return false;return true;}
inline bool parseRoute(JsonDocument &d,FlightRoute &out,const char *callsign,const char *hex,time_t now){
 if(!routeCallsign(callsign)||!d["callsign"].is<const char*>()||strcmp(d["callsign"],callsign)||!d["_airports"].is<JsonArray>())return false;
 auto airports=d["_airports"].as<JsonArrayConst>();if(airports.size()<2||airports.size()>8)return false;
 auto first=airports[0],last=airports[airports.size()-1];
 if(!routeCode(first["icao"],4)||!routeCode(last["icao"],4)||!strcmp(first["icao"],last["icao"]))return false;
 const char *a=routeCode(first["iata"],3)?first["iata"].as<const char*>():first["icao"].as<const char*>();
 const char *b=routeCode(last["iata"],3)?last["iata"].as<const char*>():last["icao"].as<const char*>();
 FlightRoute next;next.found=true;next.received=now;next.stops=airports.size()-2;
 snprintf(next.callsign,sizeof next.callsign,"%s",callsign);snprintf(next.hex,sizeof next.hex,"%s",hex);snprintf(next.origin,sizeof next.origin,"%s",a);snprintf(next.destination,sizeof next.destination,"%s",b);out=next;return true;
}
inline bool routeMatches(const FlightRoute &r,const char *callsign,const char *hex,time_t now){return r.found&&r.received>0&&r.received<=now&&now-r.received<21600&&!strcmp(r.callsign,callsign)&&!strcmp(r.hex,hex);}

// ADSBDB: exact ICAO/IATA callsign match; only airport codes enter the TFT.
inline bool parseAdsbRoute(JsonDocument &d,FlightRoute &out,const char *call,const char *hex,time_t now){
 if(!routeCallsign(call))return false;
 auto r=d["response"]["flightroute"].as<JsonObjectConst>();if(r.isNull())return false;
 bool matches=false;for(auto key:{"callsign","callsign_icao","callsign_iata"})if(r[key].is<const char*>()&&!strcmp(call,r[key].as<const char*>()))matches=true;
 if(!matches)return false;
 auto a=r["origin"],b=r["destination"];
 const char *from=routeCode(a["iata_code"],3)?a["iata_code"].as<const char*>():routeCode(a["icao_code"],4)?a["icao_code"].as<const char*>():nullptr;
 const char *to=routeCode(b["iata_code"],3)?b["iata_code"].as<const char*>():routeCode(b["icao_code"],4)?b["icao_code"].as<const char*>():nullptr;
 if(!from||!to||!strcmp(from,to))return false;
 FlightRoute next;next.found=true;next.received=now;next.stops=r["midpoint"].is<JsonObjectConst>()?1:0;
 snprintf(next.callsign,sizeof next.callsign,"%s",call);snprintf(next.hex,sizeof next.hex,"%s",hex);
 snprintf(next.origin,sizeof next.origin,"%s",from);snprintf(next.destination,sizeof next.destination,"%s",to);out=next;return true;
}
