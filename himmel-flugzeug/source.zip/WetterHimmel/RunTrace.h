#pragma once
#include <stdint.h>
// Two-slot committed snapshots survive warm reset; no writes to flash in a loop.
struct RunPoint {uint32_t magic,seq,phase,at,aux,check;};
inline uint32_t runCheck(const RunPoint &r){return 0x9b73ad21u^r.magic^r.seq^r.phase^r.at^r.aux;}
inline bool runValid(const RunPoint &r){return r.magic==0x48523330u&&r.check==runCheck(r);}
inline int runNewest(const RunPoint *r){bool a=runValid(r[0]),b=runValid(r[1]);return !a?(b?1:-1):(!b?0:((int32_t)(r[1].seq-r[0].seq)>0?1:0));}
inline void runStore(volatile RunPoint *slots,uint32_t phase,uint32_t at,uint32_t aux){
 RunPoint old[2];for(int i=0;i<2;i++){old[i].magic=slots[i].magic;old[i].seq=slots[i].seq;old[i].phase=slots[i].phase;old[i].at=slots[i].at;old[i].aux=slots[i].aux;old[i].check=slots[i].check;}
 int n=runNewest(old),i=n<0?0:1-n;RunPoint r{0x48523330u,n<0?1u:old[n].seq+1,phase,at,aux,0};r.check=runCheck(r);
 slots[i].check=0;__sync_synchronize();slots[i].magic=r.magic;slots[i].seq=r.seq;slots[i].phase=r.phase;slots[i].at=r.at;slots[i].aux=r.aux;__sync_synchronize();slots[i].check=r.check;
}
#ifdef UI_HOST_PREVIEW
inline void runPhase(uint32_t,uint32_t=0){} inline void runTouch(uint32_t){}
#else
void runBegin();void runPhase(uint32_t phase,uint32_t aux=0);void runWorker(uint32_t phase,uint32_t aux=0);void runTouch(uint32_t now);
#endif
