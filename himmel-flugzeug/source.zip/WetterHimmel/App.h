#pragma once
#include <Arduino.h>
#include "SkyCamera.h"
extern SkyCamera skyCamera;
extern bool displayNight;
void uiDisplayBrightness();
void setDisplayNight(bool enabled);
#include <ArduinoJson.h>
#include <LovyanGFX.hpp>
#include <Preferences.h>
#include <WebServer.h>
#include <WiFi.h>
extern "C" {
#include "src/astro/astronomy.h"
#include "src/sgp4/Omm.h"
#include "src/sgp4/TLE.h"
}
struct Place {
  char name[40];
  double lat, lon, height;
  char tz[80];
};
struct WifiProfile {
  char ssid[33], pass[65];
};
constexpr int SAT_COUNT = 4;
struct Settings {
  uint32_t version;
  int starlinkIds[4];
  bool starlink;
  Place places[6];
  int placeCount, place, view, brightness, rotation, autoSeconds;
  bool labels, lines, milky, satellites;
  WifiProfile wifi[6];
  int wifiCount;
};
struct SkyObject {
  char name[36];
  double az, alt, mag, x, y;
  uint16_t color;
  int kind;
};
struct Satellite {
  char name[20];
  int catalog;
  TLE tle;
  bool valid;
  time_t fetched, epoch, rise, set, peak;
  double maxAlt, az, alt, startAz, endAz;
  uint8_t visibility;
  time_t visibilityAt;
  bool passOngoing;
  char error[80];
};
class Display : public lgfx::LGFX_Device {
  lgfx::Panel_ST7796 panel;
  lgfx::Bus_SPI bus;
  lgfx::Light_PWM light;
  lgfx::Touch_XPT2046 touch;

public:
  Display();
};
extern Display lcd;
extern Settings cfg;
extern Preferences prefs;
extern WebServer web;
extern SkyObject objects[24];
extern int objectCount;
extern Satellite satellites[SAT_COUNT];
extern bool dirty, scanRunning, scanRequested;
extern String message, apPassword, nearby[20];
extern int nearbyCount;
extern int page, selected;

extern double moonPhase, sunAlt;
extern time_t sunrise, sunset;
extern uint32_t generation;
extern String csrf;
void appBegin();
void appTick();
void saveSettings();
void applyPlace();
bool clockReady();
time_t viewTime();
String stamp(time_t t, bool date = false);
String bearing(double az);
void netBegin();
void netTick();
void scanStart();
void connectProfile(int i);
bool saveWifi(String s, String p);
void deleteWifi(int i);
void fetchSoon();
void skyUpdate();
bool project(double az, double alt, int &x, int &y);
void starHorizontal(double ra, double dec, double &az, double &alt);
void satTick();
void resetSatPrediction();
void resetStarlinkPrediction();
void uiBegin();
void uiTick();
void uiDraw();
void keyboard(String title, String initial, int purpose);
void webBegin();
void stateJson(JsonDocument &d);
void setView(int v);
bool applyCommand(JsonDocument &d, String &error);

bool loadOmm(Satellite &s, const String &json);


extern bool satPaused;
void resumeSatellites();
extern time_t satHoldUntil;
extern String satPauseReason;
time_t satelliteRetry(int index);
String eventStamp(time_t t);



void uiNetworkMemory(bool active);

String satelliteCountdown(const Satellite &s);

void healthTick();
void healthResult(int kind,bool success);
void healthJson(JsonObject d,bool history);

void uiPollTouch();

bool webMemoryAvailable();
void webReplyJson(JsonDocument &d);

void resetViewTimer();

bool networkSmallReplyAllowed();
void networkCatalogStreaming(bool value);
