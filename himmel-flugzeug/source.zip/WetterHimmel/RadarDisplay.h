#pragma once
#include <stdint.h>
#include <string.h>
// Compact, bounded display snapshot; never allocates a framebuffer or starts TLS.
struct RadarDot {
 char hex[9]={},callsign[17]={},type[17]={};
 float distance=0,azimuth=0,track=0,altitude=0,speed=0;
 uint32_t positionAt=0;bool rotorcraft=false;
};
struct RadarDisplay {
 RadarDot dots[16];unsigned count=0,total=0;
 uint32_t revision=0,generation=0,received=0;int radius=0;bool limited=false;
 void add(const RadarDot &dot){
  ++total;unsigned i=0;while(i<count&&dots[i].distance<=dot.distance)++i;
  if(i>=16)return;
  unsigned last=count<16?count++:15;
  for(unsigned j=last;j>i;--j)dots[j]=dots[j-1];dots[i]=dot;
 }
};
extern RadarDisplay radarDisplay;
