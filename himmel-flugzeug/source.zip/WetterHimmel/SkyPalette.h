#pragma once
#include <stdint.h>
// Fixed 16-color chart palette. The 224x224 image needs 25088 bytes.
static const uint16_t skyPalette[16]={0x0000,0x0843,0x212D,0x21AE,0x441F,0x07FF,0x10A6,0x8CFA,0x6B73,0xB67F,0xFFFF,0xFFE0,0xEED0,0xFD20,0xFA60,0x7FEA};
static inline uint8_t skyPaletteIndex(uint16_t color){
 unsigned best=0,dist=~0u;int r=(color>>11)&31,g=((color>>5)&63)/2,b=color&31;
 for(unsigned i=0;i<16;i++){uint16_t c=skyPalette[i];int dr=r-((c>>11)&31),dg=g-(((c>>5)&63)/2),db=b-(c&31);unsigned d=dr*dr+dg*dg+db*db;if(d<dist){dist=d;best=i;if(!d)break;}}
 return best;
}

static const uint16_t skySmallPalette[4]={0x0000,0x6B73,0x07FF,0xFFFF};
static inline uint8_t skySmallIndex(uint16_t color){
 unsigned best=0,dist=~0u;int r=(color>>11)&31,g=((color>>5)&63)/2,b=color&31;
 for(unsigned i=0;i<4;i++){uint16_t c=skySmallPalette[i];int dr=r-((c>>11)&31),dg=g-(((c>>5)&63)/2),db=b-(c&31);unsigned d=dr*dr+dg*dg+db*db;if(d<dist){dist=d;best=i;}}
 return best;
}
