#include "Starlink.h"
#include "Hangar.h"
#include "StarlinkSelection.h"
#include "TransientBuffer.h"
#include "StarlinkCsv.h"
#include "Certificates.h"
#include <SD.h>
#include <atomic>
#include <SPI.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
// Binary cache layout unchanged: existing catalogs and backups remain readable.
struct Record { uint32_t id; char name[20]; OmmElements orbit; };
struct Header {uint32_t magic,count;int64_t fetched;};
static SPIClass sdBus(VSPI);
static SemaphoreHandle_t lock;
// Protected by the SD mutex; imports must not replace the open scan catalog.
static std::atomic<bool> scanReading{false};
static portMUX_TYPE catalogMux=portMUX_INITIALIZER_UNLOCKED;
static StarlinkCatalogStatus catalogStatus;
StarlinkCatalogStatus starlinkCatalogStatus(){portENTER_CRITICAL(&catalogMux);auto copy=catalogStatus;portEXIT_CRITICAL(&catalogMux);return copy;}
static void publishDownload(const StarlinkCatalogStatus &s){portENTER_CRITICAL(&catalogMux);catalogStatus=s;portEXIT_CRITICAL(&catalogMux);}
static void persistTrace(const StarlinkFetchTrace &trace){
 Preferences history;if(history.begin("sl-history",false)){history.putBytes("fetch-v1",&trace,sizeof trace);history.end();}
}
static void restoreTrace(){
 Preferences history;if(history.begin("sl-history",true)){
  StarlinkFetchTrace trace{};
  if(history.getBytesLength("fetch-v1")==sizeof trace&&history.getBytes("fetch-v1",&trace,sizeof trace)==sizeof trace&&trace.magic==0x534C5431){
   trace.error[sizeof trace.error-1]=0;trace.tlsText[sizeof trace.tlsText-1]=0;
   catalogStatus.lastFetch=trace;catalogStatus.restored=true;
  }history.end();
 }
}
void starlinkCatalogQueued(){portENTER_CRITICAL(&catalogMux);catalogStatus.busy=true;strlcpy(catalogStatus.phase,"Warte auf SD / laufende Berechnung",sizeof catalogStatus.phase);portEXIT_CRITICAL(&catalogMux);}
void starlinkCatalogCancel(){portENTER_CRITICAL(&catalogMux);catalogStatus.busy=false;strlcpy(catalogStatus.phase,"Warteschlange belegt; neuer Versuch folgt",sizeof catalogStatus.phase);portEXIT_CRITICAL(&catalogMux);}
static QueueHandle_t requests,answers;
struct Request {Place place;uint32_t generation;};
struct Answer {Satellite selected;uint32_t generation,count,ms,usable,readUs,computeUs,waitMs;time_t at;char message[80];};
String starlinkStatus="SD wird geprüft";
uint32_t starlinkCount=0,starlinkScanMs=0,starlinkReadUs=0,starlinkComputeUs=0,starlinkWaitMs=0;
time_t starlinkNext=0;
static bool mounted=false,pending=false,active=false;
static uint32_t selectedGeneration=UINT32_MAX;
static const uint32_t MAGIC=0x534C3132,MAX_CATALOG_BYTES=30000000;
static bool mountCard(){if(mounted)return true;sdBus.begin(18,19,23,5);mounted=SD.begin(5,sdBus,4000000);return mounted;}
bool aircraftSdAcquire(){if(!lock||xSemaphoreTake(lock,0)!=pdTRUE)return false;if(!mountCard()){xSemaphoreGive(lock);return false;}return true;}
void aircraftSdRelease(){xSemaphoreGive(lock);}
static bool validFile(const char *path,Header &h){File f=SD.open(path);return f && f.read((uint8_t*)&h,sizeof h)==sizeof h && h.magic==MAGIC && h.count>0 && h.count<=50000 && f.size()==sizeof h+h.count*sizeof(Record);}
struct CatalogWriter {
 File out;Header h{};StarlinkCsv csv;uint32_t fresh=0;
 void close(){out.close();}
 bool begin(StarlinkCatalogStatus &s,String &error){
  csv={};fresh=0;h={MAGIC,0,(int64_t)time(nullptr)};s.sdReady=mountCard();
  if(!s.sdReady){error="SD-Karte fehlt / nicht lesbar";return false;}
  if(!SD.exists("/wetterhimmel")&&!SD.mkdir("/wetterhimmel")){error="SD: Ordner nicht anlegbar";return false;}
  if(SD.exists("/wetterhimmel/new.bin")&&!SD.remove("/wetterhimmel/new.bin")){error="SD: temporäre Datei nicht entfernbar";return false;}
  out=SD.open("/wetterhimmel/new.bin",FILE_WRITE);
  if(!out||out.write((uint8_t*)&h,sizeof h)!=sizeof h){error="SD: Datei nicht beschreibbar";return false;}return true;
 }
 bool record(int result,const Record &r,StarlinkCatalogStatus &s,String &error){
  if(result<0){error="CSV ungültig: Kopfzeile, Spaltenzahl, Anführungszeichen oder Zeilenlimit";return false;}
  if(result==2)++s.rejected;
  if(result==1){if(out.write((const uint8_t*)&r,sizeof r)!=sizeof r){error="SD-Schreibfehler beim Katalog";return false;}s.accepted=++h.count;if(llabs((int64_t)time(nullptr)*1000-csv.epochMs)<=7LL*86400*1000)++fresh;}
  if(s.accepted+s.rejected>50000){error="Katalog überschreitet 50.000 Einträge";return false;}return true;
 }
 bool feed(const uint8_t *data,size_t size,StarlinkCatalogStatus &s,String &error){
  for(size_t i=0;i<size;i++){
   if(++s.bytes>MAX_CATALOG_BYTES){error="Katalog überschreitet 30 MB";return false;}
   Record r{};int result=csv.feed((char)data[i],r.id,r.name,sizeof r.name,r.orbit);
   if(!record(result,r,s,error))return false;
  }return true;
 }
 bool finish(StarlinkCatalogStatus &s,String &error){
  if(csv.used){Record r{};if(!record(csv.finish(r.id,r.name,sizeof r.name,r.orbit),r,s,error))return false;}
  if(!csv.header||!h.count){error="CSV enthält keine gültigen Starlink-Bahndaten";return false;}
  if(s.importing&&!fresh){error="CSV-Bahndaten sind vollständig älter als 7 Tage oder Gerätezeit falsch";return false;}
  if(!out.seek(0)||out.write((uint8_t*)&h,sizeof h)!=sizeof h){error="SD: Dateikopf nicht schreibbar";return false;}
  out.flush();out.close();Header check{};
  if(!validFile("/wetterhimmel/new.bin",check)){error="SD: neue Datei unvollständig";return false;}
  // Rotate only after validation. On activation failure scanner can still use backup.bin.
  Header old{};
  if(validFile("/wetterhimmel/catalog.bin",old)){
   if(SD.exists("/wetterhimmel/backup.bin")&&!SD.remove("/wetterhimmel/backup.bin")){error="SD: Sicherung nicht ersetzbar";return false;}
   if(!SD.rename("/wetterhimmel/catalog.bin","/wetterhimmel/backup.bin")){error="SD: bisheriger Katalog nicht sicherbar";return false;}
  }else if(SD.exists("/wetterhimmel/catalog.bin")&&!SD.remove("/wetterhimmel/catalog.bin")){error="SD: defekte Datei nicht entfernbar";return false;}
  if(!SD.rename("/wetterhimmel/new.bin","/wetterhimmel/catalog.bin")){error="SD: Aktivierung fehlgeschlagen; Sicherung bleibt";return false;}
  s.stored=h.count;s.fetched=h.fetched;s.backup=false;
  strlcpy(s.phase,s.importing?"CSV-Import erfolgreich gespeichert":"CSV-Katalog erfolgreich gespeichert",sizeof s.phase);return true;
 }
};
struct CatalogGuard {
 StarlinkCatalogStatus &state;String &error;uint32_t &retry;CatalogWriter &writer;
 ~CatalogGuard(){
  xSemaphoreTake(lock,portMAX_DELAY);writer.close();state.busy=false;strlcpy(state.error,error.c_str(),sizeof state.error);
  if(error.length())strlcpy(state.phase,"Download fehlgeschlagen",sizeof state.phase);
  if(state.attempted){auto &t=state.lastFetch;t.interrupted=false;t.http=state.http;t.tls=state.tls;t.bytes=state.bytes;
   t.next=time(nullptr)+(error.length()?max((uint32_t)7200,retry):21600);
   strlcpy(t.error,error.c_str(),sizeof t.error);strlcpy(t.tlsText,state.tlsText,sizeof t.tlsText);persistTrace(t);
   prefs.putLong64("slNext",t.next);
  }
  publishDownload(state);xSemaphoreGive(lock);
 }
};
bool starlinkDownload(String &error,int &status,uint32_t &retry){
 error="";status=0;retry=7200;
 if(!lock){error="Starlink: Speichermangel";auto s=starlinkCatalogStatus();s.busy=false;s.attempted=false;strlcpy(s.error,error.c_str(),sizeof s.error);publishDownload(s);return false;}
 xSemaphoreTake(lock,portMAX_DELAY);auto state=starlinkCatalogStatus();
 state.busy=true;state.importing=false;state.attempted=false;state.restored=false;
 state.bytes=state.total=state.accepted=state.rejected=0;state.http=state.tls=0;state.error[0]=state.tlsText[0]=0;
 CatalogWriter writer;CatalogGuard guard{state,error,retry,writer};
 strlcpy(state.phase,"SD-Karte prüfen",sizeof state.phase);publishDownload(state);
 bool opened=false;
 if(scanReading)error="Katalogsuche laeuft; Abruf folgt";else opened=writer.begin(state,error);
 xSemaphoreGive(lock);
 if(!opened)return false;
 WiFiClientSecure client;client.setCACertBundle(rootBundle,sizeof rootBundle);client.setTimeout(25000);
 HTTPClient http;http.useHTTP10(true);http.setTimeout(25000);http.setConnectTimeout(8000);http.setFollowRedirects(HTTPC_DISABLE_FOLLOW_REDIRECTS);
 if(!http.begin(client,"https://celestrak.org/NORAD/elements/gp.php?GROUP=starlink&FORMAT=CSV")){error="HTTPS-Start fehlgeschlagen";return false;}
 http.addHeader("User-Agent","WetterHimmel/1.8 private-ESP32");
 const char *headers[]={"Retry-After"};http.collectHeaders(headers,1);
 // Persist at the actual attempt, not merely when queued. Reboots retain the cooldown.
 state.attempted=true;state.attemptAt=time(nullptr);state.lastFetch={};
 state.lastFetch.at=state.attemptAt;state.lastFetch.next=state.attemptAt+7200;state.lastFetch.interrupted=true;
 persistTrace(state.lastFetch);prefs.putLong64("slNext",state.lastFetch.next);
 strlcpy(state.phase,"HTTPS: Starlink-CSV laden",sizeof state.phase);publishDownload(state);
 status=http.GET();state.http=status;state.tls=client.lastError(state.tlsText,sizeof state.tlsText);
 String retryHeader=http.header("Retry-After");
 if(retryHeader.length()){
  char *end;unsigned long seconds=strtoul(retryHeader.c_str(),&end,10);
  if(!*end)retry=max((uint32_t)7200,(uint32_t)min(seconds,2592000UL));
  else{struct tm tm{};if(strptime(retryHeader.c_str(),"%a, %d %b %Y %H:%M:%S GMT",&tm)){
   auto t=Astronomy_MakeTime(tm.tm_year+1900,tm.tm_mon+1,tm.tm_mday,tm.tm_hour,tm.tm_min,tm.tm_sec);
   int64_t delay=(int64_t)((t.ut+10957.5)*86400)-time(nullptr);if(delay>7200)retry=(uint32_t)min(delay,(int64_t)2592000);
  }}
 }
 if(status!=200){error=status<0?"Starlink: "+HTTPClient::errorToString(status)+"; TLS "+String(state.tls):"CelesTrak HTTP "+String(status)+"; Abrufe pausiert";http.end();return false;}
 int length=http.getSize();state.total=length>0?length:0;
 if(length>(int)MAX_CATALOG_BYTES){error="Katalog überschreitet 30 MB";http.end();return false;}
 strlcpy(state.phase,"CSV zeilenweise auf SD schreiben",sizeof state.phase);publishDownload(state);
 networkCatalogStreaming(true);
 auto stream=http.getStreamPtr();uint32_t idle=millis(),start=millis(),lastReport=0;bool ok=true;
 uint8_t buffer[512];
 while(http.connected()||stream->available()){
  if(length>=0&&state.bytes>=(uint32_t)length)break;
  if(millis()-start>300000){error="Katalog: Gesamtzeitlimit 5 Minuten";ok=false;break;}
  int available=stream->available();
  if(!available){hangarWork();if(millis()-idle>25000){error="Katalog: 25 Sekunden ohne Daten";ok=false;break;}vTaskDelay(1);continue;}
  size_t take=min((size_t)available,sizeof buffer);if(length>=0)take=min(take,(size_t)((uint32_t)length-state.bytes));
  int got=stream->read(buffer,take);size_t received=got>0?(size_t)got:0;
  if(received){idle=millis();xSemaphoreTake(lock,portMAX_DELAY);bool wrote=writer.feed(buffer,received,state,error);xSemaphoreGive(lock);if(!wrote){ok=false;break;}}
  hangarWork();
  if(millis()-lastReport>=500){lastReport=millis();publishDownload(state);}vTaskDelay(1);
 }
 http.end();
 if(length>=0&&state.bytes!=(uint32_t)length){if(error.isEmpty())error="CSV-Download unvollständig";ok=false;}
 if(ok){xSemaphoreTake(lock,portMAX_DELAY);ok=writer.finish(state,error);xSemaphoreGive(lock);}return ok;
}
// Local CSV import: ordered 4096-byte chunks, authenticated in Web.cpp.
// SD mutex stays with the main task until commit/cancel/timeout; no blocking lock in HTTP.
static bool importActive=false;static uint32_t importSession=0,importAt=0,importStarted=0;
static CatalogWriter importer;static StarlinkCatalogStatus importState;
bool starlinkImportBusy(){return importActive;}
static void endImport(const String &error){
 importer.close();importState.busy=importState.importing=false;
 strlcpy(importState.error,error.c_str(),sizeof importState.error);
 if(error.length())strlcpy(importState.phase,"CSV-Import abgebrochen",sizeof importState.phase);
 publishDownload(importState);importActive=false;xSemaphoreGive(lock);dirty=true;
}
bool starlinkImportStart(uint32_t size,uint32_t &session,String &error){
 error="";
 if(!size||size>MAX_CATALOG_BYTES){error="CSV-Datei muss 1 Byte bis 30 MB groß sein";return false;}
 if(!clockReady()){error="Für den Import wird eine gültige Gerätezeit benötigt";return false;}
 if(!active||!lock){error="Starlink-Modul nicht bereit";return false;}
 if(importActive||networkBusy()||starlinkCatalogStatus().busy){error="Datenabruf oder Import läuft; bitte danach erneut versuchen";return false;}
 if(xSemaphoreTake(lock,0)!=pdTRUE){error="SD-Berechnung läuft; bitte in wenigen Sekunden erneut versuchen";return false;}
 if(scanReading){xSemaphoreGive(lock);error="Katalogsuche läuft; Import danach erneut versuchen";return false;}
 importState=starlinkCatalogStatus();importState.busy=importState.importing=true;
 importState.bytes=importState.accepted=importState.rejected=0;importState.total=size;importState.error[0]=0;
 importActive=true;importSession=esp_random();if(!importSession)importSession=1;
 importAt=importStarted=millis();session=importSession;
 if(!importer.begin(importState,error)){endImport(error);return false;}
 strlcpy(importState.phase,"CSV-Datei wird importiert",sizeof importState.phase);publishDownload(importState);return true;
}
bool starlinkImportChunk(uint32_t session,uint32_t offset,const uint8_t *data,size_t size,String &error){
 error="";
 if(!importActive||session!=importSession){error="Importsitzung abgelaufen";return false;}
 if(offset!=importState.bytes){error="Import-Reihenfolge stimmt nicht";return false;}
 if(!size||size>4096||size>importState.total-importState.bytes){error="Ungültige Größe des Importabschnitts";return false;}
 importAt=millis();
 if(!importer.feed(data,size,importState,error)){endImport(error);return false;}
 publishDownload(importState);return true;
}
bool starlinkImportFinish(uint32_t session,String &error){
 error="";
 if(!importActive||session!=importSession){error="Importsitzung abgelaufen";return false;}
 bool ok=importState.bytes==importState.total;
 if(!ok)error="CSV-Import unvollständig";else ok=importer.finish(importState,error);
 if(ok){starlinkNext=max(starlinkNext,time(nullptr)+21600);prefs.putLong64("slNext",starlinkNext);}
 endImport(error);return ok;
}
bool starlinkImportCancel(uint32_t session,String &error){
 error="";
 if(!importActive||session!=importSession){error="Importsitzung abgelaufen";return false;}
 endImport("Vom Benutzer abgebrochen; bisheriger Katalog bleibt");return true;
}
static void importTick(){if(importActive&&(millis()-importAt>120000||millis()-importStarted>1200000))endImport("Import-Zeitlimit; bisheriger Katalog bleibt");}
struct HorizonFrame {
 double c,s,sl,cl,so,co,x,y,z;
 HorizonFrame(time_t now,const Place &p){double gm=gstime((double)now/86400+2440587.5);
 c=cos(gm);s=sin(gm);sl=sin(p.lat*DEG_TO_RAD);cl=cos(p.lat*DEG_TO_RAD);
 so=sin(p.lon*DEG_TO_RAD);co=cos(p.lon*DEG_TO_RAD);
 double n=6378.137/sqrt(1-.00669437999014*sl*sl),h=p.height/1000;
 x=(n+h)*cl*co;y=(n+h)*cl*so;z=(n*(1-.00669437999014)+h)*sl;
 }
};
static bool framedPosition(TLE &tle,time_t now,const HorizonFrame &f,double &az,double &alt){
 double r[3],v[3];getRV(&tle,((double)now-tle.epoch/1000.0)/60,r,v);if(tle.sgp4Error)return false;
 double dx=f.c*r[0]+f.s*r[1]-f.x,dy=-f.s*r[0]+f.c*r[1]-f.y,dz=r[2]-f.z;
 double east=-f.so*dx+f.co*dy,north=-f.sl*f.co*dx-f.sl*f.so*dy+f.cl*dz,up=f.cl*f.co*dx+f.cl*f.so*dy+f.sl*dz;
 az=fmod(atan2(east,north)*RAD_TO_DEG+360,360);alt=atan2(up,hypot(east,north))*RAD_TO_DEG;return isfinite(alt)&&isfinite(az);
}
static bool position(TLE &tle,time_t now,const Place &p,double &az,double &alt){return framedPosition(tle,now,HorizonFrame(now,p),az,alt);}
// One slice per worker turn: queued HTTPS and hangar requests run between slices.
// Only a 16-record shortlist survives a slice, no full catalog in RAM.
struct Scan {
 Request req;Header header{};File file;uint32_t started=0,index=0,usable=0,failed=0,readUs=0,computeUs=0;
 time_t at=0;unsigned count=0;uint32_t candidates[16];double ranks[16];
};
static std::unique_ptr<Scan> scan;
bool starlinkScanning(){return scanReading;}
void starlinkWork(){
 if(!active)return;
 if(!scan){
  if(starlinkCatalogStatus().busy)return;
  Request req;if(xQueueReceive(requests,&req,0)!=pdTRUE)return;
  scan.reset(new(std::nothrow) Scan);
  if(!scan){Answer a{};a.generation=req.generation;strlcpy(a.message,"Starlink: Speichermangel",sizeof a.message);xQueueOverwrite(answers,&a);return;}
  scan->req=req;scan->started=millis();scan->at=time(nullptr);
  if(!aircraftSdAcquire()){Answer a{};a.generation=req.generation;strlcpy(a.message,"SD-Karte fehlt",sizeof a.message);xQueueOverwrite(answers,&a);scan.reset();return;}
  const char *path="/wetterhimmel/catalog.bin";
  if(!validFile(path,scan->header))path="/wetterhimmel/backup.bin";
  bool valid=validFile(path,scan->header);
  if(valid){scan->file=SD.open(path);valid=scan->file&&scan->file.seek(sizeof(Header));}
  if(valid){scanReading=true;portENTER_CRITICAL(&catalogMux);catalogStatus.sdReady=true;catalogStatus.stored=scan->header.count;catalogStatus.fetched=scan->header.fetched;catalogStatus.backup=strcmp(path,"/wetterhimmel/backup.bin")==0;portEXIT_CRITICAL(&catalogMux);}
  aircraftSdRelease();
  if(!valid){Answer a{};a.generation=req.generation;strlcpy(a.message,"Bahndaten fehlen",sizeof a.message);xQueueOverwrite(answers,&a);scan.reset();return;}
 }
 auto &s=*scan;
 if(s.index<s.header.count){
  Record block[8];unsigned n=min((uint32_t)8,s.header.count-s.index);
  if(!aircraftSdAcquire())return;
  uint32_t at=micros();bool ok=s.file.read((uint8_t*)block,n*sizeof(Record))==n*sizeof(Record);s.readUs+=micros()-at;aircraftSdRelease();
  if(!ok){++s.failed;s.index=s.header.count;}
  else {
   const HorizonFrame frame(s.at,s.req.place);at=micros();
   for(unsigned i=0;i<n;i++){
    const auto&r=block[i];TLE tle;double az,alt;
    if(!initOmm(&tle,&r.orbit)||llabs((int64_t)s.at-tle.epoch/1000)>7*86400||!framedPosition(tle,s.at,frame,az,alt)){++s.failed;continue;}
    ++s.usable;unsigned slot=s.count;
    if(s.count<16)++s.count;
    else {slot=0;for(unsigned j=1;j<16;j++)if(s.ranks[j]<s.ranks[slot])slot=j;if(alt<=s.ranks[slot])continue;}
    s.candidates[slot]=s.index+i;s.ranks[slot]=alt;
   }
   s.computeUs+=micros()-at;s.index+=n;
  }
  vTaskDelay(1);return;
 }
 if(!aircraftSdAcquire())return;
 aircraftSdRelease();
 Answer answer{};answer.generation=s.req.generation;answer.count=s.header.count;answer.usable=s.usable;answer.at=time(nullptr);answer.ms=millis()-s.started;answer.readUs=s.readUs;answer.computeUs=s.computeUs;
 StarlinkSelection selection;
 for(unsigned j=0;j<s.count;j++){Record r{};TLE tle;double az,alt;
  xSemaphoreTake(lock,portMAX_DELAY);
  bool read=s.file.seek(sizeof(Header)+s.candidates[j]*sizeof(Record))&&s.file.read((uint8_t*)&r,sizeof r)==sizeof r;
  xSemaphoreGive(lock);
  if(!read){++s.failed;continue;}
  if(!initOmm(&tle,&r.orbit)||!position(tle,answer.at,s.req.place,az,alt))continue;
  if(selection.consider(alt)){auto &sat=answer.selected;sat={};sat.catalog=r.id;strlcpy(sat.name,r.name,sizeof sat.name);sat.tle=tle;sat.valid=true;sat.epoch=tle.epoch/1000;sat.az=az;sat.alt=alt;sat.fetched=s.header.fetched;}
 }
 strlcpy(answer.message,!s.usable?"Bahndaten fehlen / veraltet":s.failed?"Automatische Auswahl · Datenlücken":answer.selected.valid?"Automatische Auswahl · Position aktuell":"Keine Auswahl über dem Horizont",sizeof answer.message);
 portENTER_CRITICAL(&catalogMux);catalogStatus.usable=s.usable;portEXIT_CRITICAL(&catalogMux);
 xSemaphoreTake(lock,portMAX_DELAY);s.file.close();scanReading=false;xSemaphoreGive(lock);
 scan.reset();xQueueOverwrite(answers,&answer);
}
void starlinkBegin(){restoreTrace();lock=xSemaphoreCreateMutex();requests=xQueueCreate(1,sizeof(Request));answers=xQueueCreate(1,sizeof(Answer));if(!lock||!requests||!answers){starlinkStatus="Starlink: Speichermangel";return;}active=true;starlinkNext=max((time_t)prefs.getLong64("slNext",0),catalogStatus.lastFetch.next);}
void starlinkTick(){importTick();if(!active||!clockReady())return;static uint32_t last=0;Answer a;
 if(xQueueReceive(answers,&a,0)==pdTRUE){pending=false;if(a.generation==generation){starlinkCount=a.count;starlinkScanMs=a.ms;starlinkReadUs=a.readUs;starlinkComputeUs=a.computeUs;starlinkWaitMs=a.waitMs;starlinkStatus=a.message;
 if(a.selected.valid){double az,alt;time_t now=time(nullptr);
 if(llabs((int64_t)now-a.selected.epoch)>7*86400||!position(a.selected.tle,now,cfg.places[cfg.place],az,alt)||alt<0)a.selected.valid=false;
 else {a.selected.az=az;a.selected.alt=alt;}}
 bool same=satellites[3].valid && a.selected.valid && satellites[3].catalog==a.selected.catalog;
if(same){auto &old=satellites[3];a.selected.rise=old.rise;a.selected.set=old.set;a.selected.peak=old.peak;a.selected.maxAlt=old.maxAlt;a.selected.startAz=old.startAz;a.selected.endAz=old.endAz;a.selected.visibility=old.visibility;a.selected.visibilityAt=old.visibilityAt;a.selected.passOngoing=old.passOngoing;}
satellites[3]=a.selected;selectedGeneration=a.generation;if(!same)resetStarlinkPrediction();dirty=true;}}
 if(selectedGeneration!=generation||!cfg.starlink)satellites[3].valid=false;
 auto progress=starlinkCatalogStatus();
 if(progress.busy && starlinkStatus!=progress.phase){starlinkStatus=progress.phase;dirty=true;}
 // Track the chosen object each second while the next SD scan runs.
 static time_t trackedAt=0;time_t now=time(nullptr);
 if(satellites[3].valid&&trackedAt!=now){trackedAt=now;auto &sat=satellites[3];double az,alt;
 if(llabs((int64_t)now-sat.epoch)>7*86400||!position(sat.tle,now,cfg.places[cfg.place],az,alt)){sat.valid=false;starlinkStatus="Bahnberechnung fehlgeschlagen";}
 else {sat.az=az;sat.alt=alt;if(alt<0){sat.valid=false;starlinkStatus="Auswahl unter Horizont · Suche läuft";}}
 if(cfg.view==1)dirty=true;
 }
 if(cfg.starlink && !starlinkCatalogStatus().busy && !pending && millis()-last>=5000){Request q{cfg.places[cfg.place],generation};if(xQueueSend(requests,&q,0)==pdTRUE){pending=true;last=millis();}}
}
