#pragma once
#include <stdint.h>
static inline uint16_t nightInk(uint16_t c,bool night){
 if(!night)return c;
 unsigned r=(c>>11)&31,g=(c>>5)&63,b=c&31;
 unsigned luminance=(2*r+g+b)/5;
 return (luminance*24/31)<<11;
}
