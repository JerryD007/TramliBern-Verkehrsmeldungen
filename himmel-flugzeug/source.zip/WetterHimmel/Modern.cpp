#include "Modern.h"
#include "Extras.h"
#include "Starlink.h"
#include "UiDiagnostics.h"
#include "MemoryProbe.h"
#include <esp_ota_ops.h>
#include <esp_heap_caps.h>
ModernSettings modern;
Flight flight;
FlightRoute flightRoute;
bool displayAsleep=false;
String deviceBoot,deviceKey;
uint32_t renderMaxUs=0,touchMaxGapMs=0;
static uint32_t activityAt=0,priorityAt=0,priorityEnded=0;static int previousView=-1;static char priorityHex[9]={};
static bool priorityWasAsleep=false;
static uint32_t bootCount=0;
static double directionTo(double lat,double lon,double lat2,double lon2){double a=lat*DEG_TO_RAD,b=lat2*DEG_TO_RAD,d=(lon2-lon)*DEG_TO_RAD;return fmod(atan2(sin(d)*cos(b),cos(a)*sin(b)-sin(a)*cos(b)*cos(d))*RAD_TO_DEG+360,360);}
static bool numeric(JsonVariantConst v){return v.is<double>()&&isfinite(v.as<double>());}
static void cleanText(char *out,size_t n,JsonVariantConst v){const char *s=v.is<const char*>()?v.as<const char*>():"";size_t i=0;for(;*s&&i+1<n;s++)if((uint8_t)*s>=32&&(uint8_t)*s<127)out[i++]=*s;while(i&&out[i-1]==' ')i--;out[i]=0;}
bool parseFlight(JsonDocument &d,Flight &out,const Place &p,int radius,bool approaching,time_t now){
 if(!d["ac"].is<JsonArray>()||!numeric(d["now"]))return false;
 double source=d["now"];if(source>1e12)source/=1000;
 if(source<now-120||source>now+30||(!d["msg"].isNull()&&strcmp(d["msg"]|"","No error")))return false;
 Flight next;next.checked=true;next.received=now;double best=radius+.001;
 for(JsonObjectConst a:d["ac"].as<JsonArrayConst>()){
  if(!numeric(a["lat"])||!numeric(a["lon"])||!numeric(a["seen_pos"]))continue;
  double lat=a["lat"],lon=a["lon"],age=a["seen_pos"];
  if(lat < -90||lat>90||lon < -180||lon>180||age<0||age>60||now-(source-age)>60)continue;
  if(a["alt_baro"].is<const char*>()&&!strcmp(a["alt_baro"],"ground"))continue;
  double dl=(lat-p.lat)*DEG_TO_RAD,dn=(lon-p.lon)*DEG_TO_RAD;
  double h=sq(sin(dl/2))+cos(lat*DEG_TO_RAD)*cos(p.lat*DEG_TO_RAD)*sq(sin(dn/2));
  double dist=12742.0176*asin(sqrt(constrain(h,0.,1.)));
  bool closes=numeric(a["track"])&&a["track"].as<double>()>=0&&a["track"].as<double>()<360&&numeric(a["gs"])&&a["gs"].as<double>()>=10&&cos((a["track"].as<double>()-directionTo(lat,lon,p.lat,p.lon))*DEG_TO_RAD)>.15;
  if(dist>radius||dist>=best||(approaching&&!closes))continue;
  best=dist;next.found=true;next.distance=dist;next.approaching=closes;next.positionAt=(time_t)(source-age);
  next.azimuth=directionTo(p.lat,p.lon,lat,lon);
  cleanText(next.callsign,sizeof next.callsign,a["flight"]);cleanText(next.hex,sizeof next.hex,a["hex"]);cleanText(next.type,sizeof next.type,a["t"]);
  next.category[0]=0;const char *category=a["category"]|"";if(strlen(category)==2)cleanText(next.category,sizeof next.category,a["category"]);cleanText(next.description,sizeof next.description,a["desc"]);
  next.rotorcraft=airframeCategory(next.category)==Airframe::Rotorcraft;
  next.altitude=numeric(a["alt_baro"])&&a["alt_baro"].as<double>()>=-2000&&a["alt_baro"].as<double>()<=100000?a["alt_baro"].as<double>()*.3048:NAN;
  next.speed=numeric(a["gs"])&&a["gs"].as<double>()>=0&&a["gs"].as<double>()<=2000?a["gs"].as<double>()*1.852:NAN;
  next.track=numeric(a["track"])&&a["track"].as<double>()>=0&&a["track"].as<double>()<360?a["track"].as<float>():NAN;
 }
 out=next;return true;
}
bool priorityActive(){return previousView>=0;}
bool flightFresh(){time_t n=time(nullptr);return clockReady()&&flight.found&&!flight.error[0]&&flight.positionAt<=n+30&&n-flight.positionAt<=90&&n-flight.received<=90;}
void manualInteraction(){activityAt=millis();if(previousView>=0){previousView=-1;priorityWasAsleep=false;priorityEnded=millis();}}
void wakeDisplay(){displayAsleep=false;manualInteraction();uiDisplayBrightness();dirty=true;}
bool touchSleepGate(bool down){static bool swallow=false;static uint32_t releaseAt=0,lastPoll=0;uint32_t n=millis();if(lastPoll)touchMaxGapMs=max(touchMaxGapMs,n-lastPoll);lastPoll=n;
 if(displayAsleep&&down){wakeDisplay();swallow=true;releaseAt=n;}
 if(swallow){if(down)releaseAt=n;else if(n-releaseAt>=100)swallow=false;return true;}
 if(down)activityAt=n;return displayAsleep;
}
void modernJson(JsonObject d,const ModernSettings &m){d["name"]=m.name;d["aircraft"]=m.aircraft;d["approaching"]=m.approaching;d["priority"]=m.priority;d["wakeOnFlight"]=m.wakeOnFlight;d["radius"]=m.radius;d["showSeconds"]=m.showSeconds;d["cooldownSeconds"]=m.cooldownSeconds;d["sleepMinutes"]=m.sleepMinutes;d["skySeconds"]=m.skySeconds;d["flightSeconds"]=m.flightSeconds;auto a=d["favorites"].to<JsonArray>();for(int i=0;i<m.favoriteCount;i++)a.add(m.favorites[i]);}
bool modernRead(JsonVariantConst d,ModernSettings &m){
 if(!d["name"].is<const char*>()||!strlen(d["name"])||strlen(d["name"])>32)return false;
 for(const char*k:{"aircraft","approaching","priority"})if(!d[k].is<bool>())return false;
 if(!d["wakeOnFlight"].isNull()&&!d["wakeOnFlight"].is<bool>())return false;
 m.wakeOnFlight=d["wakeOnFlight"]|false;
 const char*keys[]={"radius","showSeconds","cooldownSeconds","sleepMinutes"};int lo[]={5,5,30,0},hi[]={200,120,3600,240};
 for(int i=0;i<4;i++)if(!d[keys[i]].is<int>()||d[keys[i]].as<int>()<lo[i]||d[keys[i]].as<int>()>hi[i])return false;
 for(const char *key:{"skySeconds","flightSeconds"})if(!d[key].isNull()&&(!d[key].is<int>()||d[key].as<int>()<0||d[key].as<int>()>600||(d[key].as<int>()>0&&d[key].as<int>()<5)))return false;
 m.skySeconds=d["skySeconds"]|0;m.flightSeconds=d["flightSeconds"]|0;
 if(!d["favorites"].is<JsonArrayConst>()||d["favorites"].size()>16)return false;
 m.favoriteCount=0;for(JsonVariantConst v:d["favorites"].as<JsonArrayConst>()){if(!v.is<int>())return false;int id=v;double az,alt;String name;if(id<0||(clockReady()&&!objectCoordinates(id,az,alt,name))||id>10000)return false;for(int i=0;i<m.favoriteCount;i++)if(m.favorites[i]==id)return false;m.favorites[m.favoriteCount++]=id;}
 strlcpy(m.name,d["name"],sizeof m.name);m.aircraft=d["aircraft"];m.approaching=d["approaching"];m.priority=d["priority"];m.radius=d["radius"];m.showSeconds=d["showSeconds"];m.cooldownSeconds=d["cooldownSeconds"];m.sleepMinutes=d["sleepMinutes"];return true;
}
void modernBegin(){String saved=prefs.getString("modern","");if(saved.length()){JsonDocument d;if(!deserializeJson(d,saved)){ModernSettings tmp;if(modernRead(d.as<JsonVariantConst>(),tmp))modern=tmp;}}
 deviceBoot=String(esp_random(),HEX)+String(esp_random(),HEX);deviceKey=prefs.getString("fleetKey","");if(deviceKey.length()!=32){char key[33];snprintf(key,sizeof key,"%08lx%08lx%08lx%08lx",(unsigned long)esp_random(),(unsigned long)esp_random(),(unsigned long)esp_random(),(unsigned long)esp_random());deviceKey=key;prefs.putString("fleetKey",deviceKey);}
 bootCount=prefs.getUInt("boots",0)+1;prefs.putUInt("boots",bootCount);activityAt=millis();displayAsleep=false;cfg.view=1;
}
bool modernCommand(JsonDocument &d,String &error){String a=d["action"]|"";
 if(a=="wake"){wakeDisplay();return true;}if(a=="sleep"){manualInteraction();displayAsleep=true;uiDisplayBrightness();return true;}
 if(a=="modern"){ModernSettings tmp=modern;if(!modernRead(d["modern"],tmp)){error="Einstellungen ungültig";return false;}JsonDocument save;modernJson(save.to<JsonObject>(),tmp);String json;serializeJson(save,json);if(prefs.putString("modern",json)!=json.length()){error="Speichern fehlgeschlagen";return false;}bool reset=tmp.radius!=modern.radius||tmp.approaching!=modern.approaching;modern=tmp;if(reset){generation++;flight=Flight();}manualInteraction();if(!modern.aircraft&&cfg.view==2)setView(1);dirty=true;return true;}
 error="Unbekannte Aktion";return false;
}
void modernTick(){
 uint32_t n=millis();
 // A priority temporarily owns the display; inactivity cannot end it early.
 if(previousView>=0){
  if(page!=0||displayAsleep){previousView=-1;priorityWasAsleep=false;priorityEnded=n;return;}
  if(!modern.aircraft||!modern.priority||!flightFresh()||n-priorityAt>=uint32_t(modern.showSeconds)*1000){
   cfg.view=1;resetViewTimer();previousView=-1;priorityEnded=n;dirty=true;
   if(priorityWasAsleep){displayAsleep=true;uiDisplayBrightness();}else activityAt=n;
   priorityWasAsleep=false;
  }
  return;
 }
 if(modern.sleepMinutes&&page==0&&!displayAsleep&&n-activityAt>uint32_t(modern.sleepMinutes)*60000){displayAsleep=true;uiDisplayBrightness();}
 bool cooldown=priorityEnded==0||n-priorityEnded>=uint32_t(modern.cooldownSeconds)*1000;
 if(modern.aircraft&&modern.priority&&page==0&&(!displayAsleep||modern.wakeOnFlight)&&(cfg.view!=2||displayAsleep)&&flightFresh()&&flight.hex[0]&&(!modern.approaching||flight.approaching)&&cooldown&&strcmp(priorityHex,flight.hex)){
  priorityWasAsleep=displayAsleep;previousView=1;cfg.view=2;priorityAt=n;
  strlcpy(priorityHex,flight.hex,sizeof priorityHex);displayAsleep=false;uiDisplayBrightness();dirty=true;
 }
}
void modernState(JsonDocument &d){d["release"]="WW_RELEASE:" WW_VERSION;sourceJson(d["sources"].to<JsonObject>());visiblePassJson(d["possiblePass"].to<JsonObject>());modernJson(d["modern"].to<JsonObject>(),modern);d["displayAsleep"]=displayAsleep;d["boot"]=deviceBoot;
 auto f=d["flight"].to<JsonObject>();f["checked"]=flight.checked;f["found"]=flight.found;f["fresh"]=flightFresh();f["error"]=flight.error;f["callsign"]=flight.callsign;f["type"]=flight.type;f["description"]=flight.description;f["rotorcraft"]=flight.rotorcraft;f["category"]=flight.category;bool routeOk=flight.found&&clockReady()&&routeMatches(flightRoute,flight.callsign,flight.hex,time(nullptr));f["routeStatus"]=routeOk?"catalogue":"unavailable";f["origin"]=routeOk?flightRoute.origin:"";f["destination"]=routeOk?flightRoute.destination:"";f["routeStops"]=routeOk?flightRoute.stops:0;f["routeAge"]=routeOk?time(nullptr)-flightRoute.received:-1;f["hex"]=flight.hex;f["distance"]=flight.distance;f["altitude"]=flight.altitude;f["speed"]=flight.speed;f["track"]=flight.track;f["azimuth"]=flight.azimuth;f["approaching"]=flight.approaching;f["age"]=flight.positionAt&&clockReady()?time(nullptr)-flight.positionAt:-1;
 auto fav=d["favorites"].to<JsonArray>();for(int i=0;i<modern.favoriteCount;i++){double az,alt;String name;if(objectCoordinates(modern.favorites[i],az,alt,name)){auto o=fav.add<JsonObject>();o["id"]=modern.favorites[i];o["name"]=name;o["az"]=az;o["alt"]=alt;}}
}
static void traceExport(JsonDocument &d);
static void detailedDiagnostic(JsonDocument &d){
 auto u=d["skyDisplay"].to<JsonObject>();u["view"]=cfg.view;u["page"]=page;u["attempts"]=uiDiag.attempts;u["allocationFailures"]=uiDiag.failures;u["fallbacks"]=uiDiag.fallbacks;u["paletteBits"]=uiDiag.bits;u["pixelBytes"]=224*224*uiDiag.bits/8;u["releasesForNetwork"]=uiDiag.releases;u["draws"]=uiDiag.draws;u["lastDrawUptimeMs"]=uiDiag.lastDrawMs;u["lastAllocationFailureUptimeMs"]=uiDiag.lastFailureMs;u["largestBlockAtFailure"]=uiDiag.failedLargest;
 auto w=d["skyWeb"].to<JsonObject>();w["handlerMaxUs"]=uiDiag.webHandlerMaxUs;w["requests"]=uiDiag.webCalls;w["lastMs"]=uiDiag.webLastMs;w["maxMs"]=uiDiag.webMaxMs;w["lastBytes"]=uiDiag.webBytes;w["lastRows"]=uiDiag.webRows;
 auto m=d["memoryDetailed"].to<JsonObject>();m["internalFree"]=heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);m["internalMinimum"]=heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);m["dmaFree"]=heap_caps_get_free_size(MALLOC_CAP_DMA);m["dmaLargest"]=heap_caps_get_largest_free_block(MALLOC_CAP_DMA);m["defaultInternalFree"]=heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_DEFAULT);m["defaultInternalLargest"]=heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_DEFAULT);m["allocationFailuresSinceBoot"]=memoryFailureTotal();d["diagnosticSchema"]=3;d["satelliteDownloadsPaused"]=satPaused;d["satellitePauseReason"]=satPauseReason;d["satelliteHoldUntil"]=(int64_t)satHoldUntil;
}

void modernDiagnostic(JsonDocument &d){detailedDiagnostic(d);traceExport(d);sourceJson(d["sources"].to<JsonObject>());d["format"]="WetterHimmel-Diagnose";d["version"]=WW_VERSION;d["time"]=(int64_t)(clockReady()?time(nullptr):0);d["clockReady"]=clockReady();d["boots"]=bootCount;d["renderMaxUs"]=renderMaxUs;d["touchMaxGapMs"]=touchMaxGapMs;healthJson(d["health"].to<JsonObject>(),true);d["heapMinimum"]=ESP.getMinFreeHeap();d["largestBlock"]=heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);d["wifiConnected"]=WiFi.status()==WL_CONNECTED;d["rssi"]=WiFi.RSSI();d["starlinkScanMs"]=starlinkScanMs;d["starlinkReadUs"]=starlinkReadUs;d["starlinkComputeUs"]=starlinkComputeUs;d["starlinkWaitMs"]=starlinkWaitMs;d["starlinkCount"]=starlinkCount;d["flightError"]=flight.error;d["flightChecked"]=flight.checked;d["flightFound"]=flight.found;d["flightFresh"]=flightFresh();d["flightPositionAt"]=(int64_t)flight.positionAt;d["flightReceived"]=(int64_t)flight.received;d["aircraftEnabled"]=modern.aircraft;d["flightRadiusKm"]=modern.radius;d["approachingOnly"]=modern.approaching;d["flightPriority"]=modern.priority;d["wakeOnFlight"]=modern.wakeOnFlight;d["displayAsleep"]=displayAsleep;d["priorityActive"]=priorityActive();auto a=d["satellites"].to<JsonArray>();for(auto&s:satellites){auto o=a.add<JsonObject>();o["name"]=s.name;o["catalog"]=s.catalog;o["orbitEpoch"]=(int64_t)s.epoch;o["positionAt"]=(int64_t)s.visibilityAt;o["nextAllowedFetch"]=(int64_t)satelliteRetry(&s-satellites);}}
void modernWeb(){web.on("/api/diagnostic",HTTP_GET,[]{if(!webMemoryAvailable())return;JsonDocument d;modernDiagnostic(d);web.sendHeader("Content-Disposition","attachment; filename=WetterHimmel_Diagnose.json");webReplyJson(d);});
 web.on("/api/pair",HTTP_POST,[]{if(web.header("X-WW-Token")!=csrf){web.send(403,"text/plain","Nicht autorisiert");return;}JsonDocument d;d["key"]=deviceKey;web.sendHeader("Cache-Control","no-store");webReplyJson(d);});
}
struct SourceTrace {time_t attempt=0,success=0;uint32_t uptime=0,duration=0;int http=0;bool busy=false;char error[96]={};};
static SourceTrace sourceTraces[6];
struct Event {time_t at;uint32_t uptime,duration;int16_t kind,http;bool ok;};
static Event events[24];static uint8_t eventHead=0,eventCount=0;static char flightTrace[2048]={},flightFailureTrace[2048]={};
static int sourceSlot(int kind){return kind==10?5:kind==9?4:kind==8?3:kind==0?0:1;}
void sourceStarted(int kind){auto &s=sourceTraces[sourceSlot(kind)];s.attempt=clockReady()?time(nullptr):0;s.uptime=millis()/1000;s.busy=true;}
void sourceFinished(int kind,int http,uint32_t duration,const char*error,const char*trace){auto &s=sourceTraces[sourceSlot(kind)];s.duration=duration;s.http=http;s.busy=false;strlcpy(s.error,error,sizeof s.error);if(!*error)s.success=clockReady()?time(nullptr):0;if(kind==9){strlcpy(flightTrace,trace,sizeof flightTrace);if(*error)strlcpy(flightFailureTrace,trace,sizeof flightFailureTrace);}events[eventHead]={clockReady()?time(nullptr):0,millis()/1000,duration,(int16_t)kind,(int16_t)http,!*error};eventHead=(eventHead+1)%24;if(eventCount<24)eventCount++;}
void sourceJson(JsonObject d){const char*names[]={"weather","satellites","reserved","starlink","aircraft","routes"};for(int i:{1,3,4,5}){auto&s=sourceTraces[i];auto o=d[names[i]].to<JsonObject>();o["attempt"]=(int64_t)s.attempt;o["success"]=(int64_t)s.success;o["uptime"]=s.uptime;o["durationMs"]=s.duration;o["http"]=s.http;o["busy"]=s.busy;o["error"]=s.error;}}

static void traceExport(JsonDocument &d){d["flightTrace"]=flightTrace;d["lastFailedFlightTrace"]=flightFailureTrace;d["otaLastStage"]=prefs.getString("otaStage","Noch kein Update");auto a=d["events"].to<JsonArray>();for(unsigned i=0;i<eventCount;i++){auto&e=events[(eventHead+24-eventCount+i)%24];auto o=a.add<JsonObject>();o["at"]=(int64_t)e.at;o["uptime"]=e.uptime;o["durationMs"]=e.duration;o["kind"]=e.kind;o["http"]=e.http;o["ok"]=e.ok;}}
