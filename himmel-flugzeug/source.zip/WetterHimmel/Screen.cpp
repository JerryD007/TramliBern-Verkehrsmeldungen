#include "Battery.h"
#include "App.h"
#include "Modern.h"
#ifndef UI_HOST_PREVIEW
#include "Extras.h"
#endif
#include "Starlink.h"
#include "Catalog.h"
#include "UiFonts.h"
#include "Paint.h"
#include "AircraftArt.h"
#include "AircraftImages.h"
#include "UiDiagnostics.h"
UiDiagnostics uiDiag;
#ifndef UI_HOST_PREVIEW
#include <esp_heap_caps.h>
#include <esp_memory_utils.h>
#endif
#include "Gesture.h"
#include "Visibility.h"
#include "StarNames.h"
static Paint paint(lcd);
#ifndef UI_DIRECT_PREVIEW
static LGFX_Sprite skyBuffer(&lcd);
// Two 224x112 strips reuse 12544 pixel bytes; allocated only when needed.
static bool skyPixelsReady=false;
static int skyBufferHeight=224;
static uint32_t mapRetryAt=0;
static bool skyBufferReady=false;
static bool networkOwnsMemory=false;
static bool mapDeferred=false;
#endif
// Called exclusively by the main loop, before publishing a network job.
void uiNetworkMemory(bool active) {
#ifndef UI_DIRECT_PREVIEW
  networkOwnsMemory=active;
  if(active && skyPixelsReady) {
    // Main-loop ownership: no render can be in progress when the job is queued.
    // The LCD retains its pixels; only the off-screen workspace is released.
    skyBuffer.deleteSprite();
    ++uiDiag.releases;
    skyPixelsReady=false;
    mapDeferred=true;
  }
  if(!active && mapDeferred) {mapRetryAt=millis();dirty=true;}
#endif
}
static const uint16_t bg = 0x0000, blue = 0x0248, white = 0xFFFF, muted = 0xBDF7, cyan = 0x07FF;
static String input, title, wifiName;
static int purpose = 0, keyLayout = 0, networkPage = 0, profile = 0;
static bool shifted = false, held = false, showPassword = false;
static Place draft{};
static int editPlace = -1;
// Map lies inside x=118..361, y=34..277, including the large-map mode.
// Packed, aligned 32-bit accesses allow IRAM storage on classic ESP32.
// Volatile enforces full-word loads/stores even when extracting one byte.
// Do not access this allocation through byte/halfword pointers.
#ifdef UI_HOST_PREVIEW
static uint32_t hitStore[1100];static volatile uint32_t *hitData=hitStore;
#else
static volatile uint32_t *hitData=nullptr;
#endif
static int hitScreenX(int i){return int(hitData[i]&255)+112;}
static int hitScreenY(int i){return int((hitData[i]>>8)&255)+24;}
static int hitObject(int i){return int(hitData[i]>>16);}
static int hitCount=0;
static String objectQuery;static int objectOffset=0,objectChoices[6],objectMatches=0;
static float mapScale(){return extra.largeMap?244.0f/224.0f:1.0f;}
static int mapCenterY(){return extra.largeMap?156:146;}
static int labelBackground=-1;
static uint16_t textBackground(int,int){return labelBackground>=0?uint16_t(labelBackground):bg;}
// Embedded UTF-8 font subset: independent of the limited built-in fonts.
static uint16_t nextCode(const String &s, unsigned &i) {
  uint8_t c = s[i++];
  if (c < 128) return c;
  uint16_t v = c & (c < 224 ? 31 : 15);
  int n = c < 224 ? 1 : 2;
  while (n-- && i < s.length()) v = (v << 6) | (s[i++] & 63);
  return v;
}
static const UiGlyph *glyph(const UiFont &f, uint16_t c) {
  for (unsigned j = 0; j < f.count; j++) if (f.glyphs[j].code == c) return &f.glyphs[j];
  for (unsigned j = 0; j < f.count; j++) if (f.glyphs[j].code == '?') return &f.glyphs[j];
  return &f.glyphs[0];
}
static int width(String s, const UiFont &f = uiFont14) {
  int w = 0; unsigned i = 0;
  while (i < s.length()) w += glyph(f, nextCode(s, i))->advance;
  return w;
}
static void label(String s, int x, int y, const UiFont &f, uint16_t col) {
  unsigned i = 0;
  while (i < s.length()) {
    auto g = glyph(f, nextCode(s, i));
    uint32_t offset=g->offset;unsigned run=0;int alpha=0;
    for(int yy=0;yy<f.height;yy++) for(int xx=0;xx<g->width;xx++) {
      if(!run){uint8_t token=f.bits[offset++];run=(token>>4)+1;alpha=token&15;}
      --run;if(!alpha)continue;
      uint16_t back=textBackground(x+xx,y+yy);
      int rr=(((col>>11)&31)*alpha+((back>>11)&31)*(15-alpha))/15;
      int gg=(((col>>5)&63)*alpha+((back>>5)&63)*(15-alpha))/15;
      int bb=((col&31)*alpha+(back&31)*(15-alpha))/15;
      paint.drawPixel(x+xx,y+yy,(rr<<11)|(gg<<5)|bb);
    }
    x += g->advance;
  }
}
static void label(String s,int x,int y,const UiFont &f,uint16_t col,int limit){
 while(s.length()&&width(s,f)>limit){unsigned i=s.length()-1;while(i&&((uint8_t)s[i]&0xc0)==0x80)--i;s.remove(i);}
 label(s,x,y,f,col);
}
static void text(String s, int x, int y, int size = 1, uint16_t col = white) {
  label(s, x, y, size == 2 ? uiFont20 : uiFont14, col);
}
static uint16_t rgb(int r, int g, int b) { return ((r & 248) << 8) | ((g & 252) << 3) | (b >> 3); }
static void gradient(int y, int h, int r, int g, int b, int rr, int gg, int bb) {
  for (int i=0;i<h;i++) paint.drawFastHLine(0,y+i,320,rgb(r+(rr-r)*i/h,g+(gg-g)*i/h,b+(bb-b)*i/h));
}
static void button(String s, int x, int y, int w, int h, uint16_t col = 0x0124) {
  paint.fillRoundRect(x,y,w,h,7,col);
  paint.drawRoundRect(x,y,w,h,7,col == blue ? cyan : 0x4A69);
  const UiFont &f = width(s) <= w-10 ? uiFont14 : uiFont11;
  int previous=labelBackground;labelBackground=col;
  label(s,x+(w-width(s,f))/2,y+(h-f.height)/2,f,white);labelBackground=previous;
}
// Shaded RGB565 spheres. No large framebuffer or PSRAM required.
static void sphere(int cx,int cy,int r,int kind) {
  const int colors[][3]={{255,213,50},{196,202,218},{146,146,158},{236,196,126},{220,101,65},{216,171,121},{217,197,147},{113,216,225},{66,121,228},{40,148,225}};
  kind=constrain(kind,0,9);
  for (int y=-r;y<=r;y++) for (int x=-r;x<=r;x++) {
    float d=float(x*x+y*y)/(r*r); if(d>1) continue;
    float z=sqrtf(1-d), light=0.27f+0.73f*max(0.0f,(-0.4f*x-0.55f*y)/r+0.75f*z);
    if(kind==0) light=0.82f+0.18f*z;
    float band=1;
    if(kind==5 || kind==6) band=0.82f+0.18f*sinf(y*1.1f);
    int red=colors[kind][0], green=colors[kind][1], blueC=colors[kind][2];
    if(kind==9 && sinf(x*0.9f+y*0.5f)+cosf(y*1.2f-x*0.3f)>0.9f) {red=68;green=181;blueC=117;}
    if(kind==1) band=0.83f+0.17f*sinf(x*1.8f+y)*sinf(y*1.6f);
    paint.drawPixel(cx+x,cy+y,rgb(red*light*band,green*light*band,blueC*light*band));
  }
}
static void glowSun(int x,int y,int r) {
  for(int k=r+9;k>r;k--) paint.drawCircle(x,y,k,rgb(35+(r+9-k)*8,25+(r+9-k)*5,20));
  sphere(x,y,r,0);
}
void keyboard(String name, String value, int why) {
  title = name;
  input = value;
  purpose = why;
  showPassword = false;
  keyLayout = 0;
  shifted = false;
  page = 10;
  dirty = true;
}
static uint32_t surfaceRevision=0;
static void calibrate() {
  ++surfaceRevision;
  paint.fillScreen(bg);
  text("Touchkalibrierung", 20, 40, 2);
  text("Bitte die Markierungen antippen.", 12, 80);
  uint16_t c[8];
  lcd.calibrateTouch(c, white, bg, 16);
  prefs.putBytes(("cal" + String(cfg.rotation)).c_str(), c, sizeof c);
  dirty = true;
}
void uiBegin() {
  lcd.init();
  lcd.setRotation(cfg.rotation);
  uiDisplayBrightness();
  lcd.setTextWrap(false);
#ifndef UI_DIRECT_PREVIEW
  skyBuffer.setPsram(false);
  skyBuffer.setColorDepth(4);
  skyBufferReady=skyBuffer.createPalette(skyPalette,16);
  // Do not reserve the pixel buffer at startup or while showing aircraft.
#endif
  uint16_t c[8];
  String key = "cal" + String(cfg.rotation);
  if (prefs.getBytesLength(key.c_str()) == sizeof c) {
    prefs.getBytes(key.c_str(), c, sizeof c);
    lcd.setTouchCalibrate(c);
  } else {
    bool loaded=false;
    for(const char *legacy:{"cal0","cal2"})if(prefs.getBytesLength(legacy)==sizeof c){prefs.getBytes(legacy,c,sizeof c);lcd.setTouchCalibrate(c);loaded=true;break;}
    if(!loaded)calibrate();
  }
}
static void back(){button("ZURÜCK",8,280,464,36,0x2104);}
static void header(){
 paint.fillRect(0,0,480,34,bg);labelBackground=bg;
 String title=(page==13||page==14)?"Mein Hangar":page==15?"Radar":page?"Menü":cfg.view==1?"Himmel":"Flugzeug";
 label(title,8,6,uiFont20,white,155);
 int placeX=8+min(width(title,uiFont20),155)+10;
 label(String(cfg.places[cfg.place].name),placeX,8,uiFont14,white,260-placeX);
 label(stamp(time(nullptr)),270,6,uiFont20,white,64);
 uint16_t color=battery.band==3?0x07e0:battery.band==2?0xffe0:battery.band==1?0xf800:muted;
 paint.drawRect(340,9,22,14,color);paint.fillRect(362,13,3,6,color);
 if(battery.band)paint.fillRect(343,12,battery.band==3?16:battery.band==2?10:4,8,color);
 char value[12];unsigned cv=(battery.millivolts+5)/10;if(battery.millivolts)snprintf(value,sizeof value,"%u,%02u V",cv/100,cv%100);else strcpy(value,"-- V");
 label(value,370,8,uiFont14,color,67);
 for(int yy=9;yy<=23;yy+=7)paint.drawFastHLine(445,yy,24,cyan);
 paint.drawFastHLine(8,33,464,cyan);labelBackground=-1;
}
static void nav(){} // Main views use swipe or the menu; space belongs to satellite data.
static bool projectMap(double az,double alt,int &x,int &y){
  if(!project(az,alt,x,y))return false;
  skyCamera.transform(x,y);return true;
}
static void addHit(int x, int y, int type) {
  if (hitData && hitCount < 1100 && skyCamera.contains(x,y)) {
    uint32_t x8=uint8_t(lround(240+(x-160)*mapScale())-112);
    uint32_t y8=uint8_t(lround(mapCenterY()+(y-174)*mapScale())-24);
    hitData[hitCount++]=(uint32_t(type)<<16)|(y8<<8)|x8;
  }
}
// Prefer nearby planets/satellites to the dense background star field.
static int skyHitTarget(int x,int y) {
  int best=-1,bestDistance=0,bestPriority=-1;
  for(int i=0;i<hitCount;i++) {
    bool primary=(hitObject(i)>=0&&hitObject(i)<objectCount)||hitObject(i)>=3000;
    int radius=primary?26:15,dx=x-hitScreenX(i),dy=y-hitScreenY(i),distance=dx*dx+dy*dy;
    int priority=primary?1:0;
    if(distance<=radius*radius && (priority>bestPriority || (priority==bestPriority&&distance<bestDistance))) {
      best=hitObject(i);bestDistance=distance;bestPriority=priority;
    }
  }
  return best;
}
struct LabelBox {int x,y,w,h;};
static LabelBox labelBoxes[24];
static int labelCount=0;
static bool mapLabel(String name,int x,int y,uint16_t color) {
  int w=width(name,uiFont11), h=14;
  const int dx[]={14,14,-14,-14,0,0},dy[]={-19,10,-19,10,-29,18};
  for(int k=0;k<6;k++) {
    int xx=k==4||k==5?x-w/2:k>=2?x-w+dx[k]:x+dx[k], yy=y+dy[k];
    if(xx<48||xx+w>272||yy<78||yy+h>272) continue;
    bool free=true;
    for(int j=0;j<labelCount;j++) {auto b=labelBoxes[j]; if(xx<b.x+b.w+3&&xx+w+3>b.x&&yy<b.y+b.h+3&&yy+h+3>b.y) free=false;}
    // Keep labels away from every solar-system marker, even those drawn later.
    for(int j=0;j<objectCount;j++) {int u,v; if(projectMap(objects[j].az,objects[j].alt,u,v)&&u>xx-13&&u<xx+w+13&&v>yy-10&&v<yy+h+10) free=false;}
    if(free && labelCount<24) {labelBoxes[labelCount++]={xx,yy,w,h};paint.fillRoundRect(xx-2,yy-1,w+4,h+2,2,0x0843);label(name,xx,yy,uiFont11,color);return true;}
  }
  return false;
}
static void moonIcon(int cx,int cy,int r) {
  double a=moonPhase*DEG_TO_RAD;
  for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++) {
    double xx=(double)x/r,yy=(double)y/r,z2=1-xx*xx-yy*yy;
    if(z2<0)continue;
    double light=xx*sin(a)-sqrt(z2)*cos(a);
    int v=light>0?190+int(50*sqrt(z2)):46;
    paint.drawPixel(cx+x,cy+y,rgb(v,v,v+min(9,255-v)));
  }
}
static void satelliteIcon(int x,int y,int kind) {
  paint.drawLine(x-18,y,x+18,y,0xBDF7);
  if(kind==2) {
    paint.fillRoundRect(x-10,y-5,22,10,3,0xBDF7);
    paint.fillCircle(x-10,y,5,0x4208);paint.drawCircle(x-10,y,5,white);
    paint.fillRect(x-3,y-15,10,8,0x2C9B);paint.fillRect(x-3,y+7,10,8,0x2C9B);
  } else {
    paint.fillRoundRect(x-4,y-7,8,14,2,0xD6BA);
    for(int side=-1;side<=1;side+=2) {
      int xx=x+(side<0?-21:8);paint.fillRect(xx,y-11,13,22,0x1B57);
      paint.drawRect(xx,y-11,13,22,0x75DF);
      for(int k=1;k<4;k++)paint.drawFastHLine(xx,y-11+k*5,13,0x4C9D);
      paint.drawFastVLine(xx+6,y-11,22,0x4C9D);
    }
  }
}
static void satelliteCards(){
 const char *names[]={"ISS","Tiangong","Hubble","Starlink"};
 const time_t now=time(nullptr);
 for(int i=0;i<4;i++){
  auto &sat=satellites[i];bool fresh=satellitePositionCurrent(sat,clockReady(),now);
  bool visible=satelliteCandidateSeconds(sat,clockReady(),now)>0;
  int x=i*120;uint16_t c=fresh?(visible?0xFFE0:sat.alt>=0?0x97F2:cyan):muted;
  paint.fillRect(x,258,120,62,bg);paint.drawFastVLine(x,260,58,muted);
  label(names[i],x+7,260,uiFont14,c);
  String line="Daten veraltet",position="Keine Position";
  if(fresh){
   position=bearing(sat.az)+" "+String(sat.alt,0)+"°";
   if(sat.alt>=0)line=visible?"Sichtchance*":"Über Horizont";
   else if(sat.rise>now&&sat.set>now){long m=(sat.rise-now+59)/60;line=m<60?"In "+String(m)+" min":"In "+String(m/60)+"h "+String(m%60)+"m";}
   else line="Berechnung ...";
  }
  label(line,x+7,282,uiFont11,c);label(position,x+7,300,uiFont11,muted);
 }
}
static bool uiInputPending();
static bool sampleChartTouch() {
#ifndef UI_HOST_PREVIEW
  lcd.endWrite();uiPollTouch();lcd.startWrite();
  if(uiInputPending()){
    paint.targetAt(lcd);hitCount=0;dirty=true;
#ifndef UI_DIRECT_PREVIEW
    mapDeferred=true;mapRetryAt=millis();
#endif
    return true;
  }
#endif
  return false;
}
static void skyScreen(bool full=true) {
  static uint64_t lastMap=0;
  static String lastCards;static bool wasLarge=false;
  const auto mapTime=Astronomy_TimeFromDays((double)viewTime()/86400-10957.5);
  const auto galRotation=Astronomy_Rotation_GAL_EQJ();
  if(extra.largeMap!=wasLarge){full=true;wasLarge=extra.largeMap;}
  if(full) {paint.fillRect(0,34,480,246,bg);button("+",420,65,52,42);button("-",420,113,52,42);button("1×",420,161,52,42);button("Objekte",4,75,114,36);button("Favoriten",4,119,114,36);}
  uint64_t mapKey=(uint64_t)(clockReady()?time(nullptr)/30:0);
  mapKey=mapKey*31+skyCamera.revision;mapKey=mapKey*31+displayNight;
  mapKey=mapKey*31+generation;mapKey=mapKey*31+objectCount;
  mapKey=mapKey*31+(cfg.labels|cfg.lines<<1|cfg.milky<<2|cfg.satellites<<3|cfg.starlink<<4);
  String cards=String(clockReady())+":"+String((long)(time(nullptr)/60));
  for(int i=0;i<SAT_COUNT;i++) {
    auto &sat=satellites[i];bool fresh=satellitePositionCurrent(sat,clockReady(),time(nullptr));
    int x=0,y=0;
    if(fresh && cfg.satellites && (i<3 || cfg.starlink) && projectMap(sat.az,sat.alt,x,y)) {mapKey=mapKey*31+x;mapKey=mapKey*31+y;}
    bool sight=satelliteCandidateSeconds(sat,clockReady(),time(nullptr))>0;
    mapKey=mapKey*31+sight;cards+=String(sight);
    cards+=String(fresh)+":"+bearing(sat.az)+":"+String(sat.alt,0)+":"+String(sat.alt>=0)+":"+stamp(sat.rise)+":"+String(sat.valid);
  }
  if(!extra.largeMap && (full || cards!=lastCards)) {satelliteCards();lastCards=cards;}
#ifndef UI_DIRECT_PREVIEW
  // Preserve the displayed chart while HTTPS owns the temporary workspace.
  bool deferred=mapDeferred;
#else
  bool deferred=false;
#endif
  mapKey=mapKey*31+(highlightedObject+1);mapKey=mapKey*31+extra.trails;mapKey=mapKey*31+extra.largeMap;
  if(!full && !deferred && mapKey==lastMap)return;
  lastMap=mapKey;
  if (!clockReady()) {
    label("Warte auf Uhrzeit",136,125,uiFont11,muted);label("über WLAN / NTP",136,145,uiFont11,muted);
    return;
  }
#ifndef UI_DIRECT_PREVIEW
  if(!networkOwnsMemory) {
#ifndef UI_HOST_PREVIEW
    if(!hitData)hitData=(uint32_t*)heap_caps_malloc(1100*sizeof(uint32_t),MALLOC_CAP_EXEC|MALLOC_CAP_32BIT);
    if(!hitData)hitData=(uint32_t*)heap_caps_malloc(1100*sizeof(uint32_t),MALLOC_CAP_32BIT);
    uiDiag.hitBytes=hitData?4400:0;uiDiag.hitIram=hitData&&esp_ptr_in_iram((const void*)hitData);
#endif
    if(!skyBufferReady)skyBufferReady=skyBuffer.createPalette(skyPalette,16);
    if(skyBufferReady && !skyPixelsReady) {
      ++uiDiag.attempts;uiDiag.bits=4;skyBufferHeight=112;skyBuffer.setColorDepth(4);
      skyPixelsReady=skyBuffer.createSprite(224,skyBufferHeight)!=nullptr;
      if(skyPixelsReady)++uiDiag.fallbacks;
      else {++uiDiag.failures;uiDiag.lastFailureMs=millis();}

    }
  }
  if(networkOwnsMemory || !skyBufferReady || !skyPixelsReady) {
    mapDeferred=true;
    mapRetryAt=millis()+1000;
    // Do not destroy an existing chart on a temporary allocation failure.
    if(full) {hitCount=0;label(networkOwnsMemory?"Karte nach Datenabruf":"Warte auf Speicher",136,140,uiFont11,muted);}
    return;
  }
  mapDeferred=false;uiDiag.pixelBytes=224*skyBufferHeight/2;
  for(unsigned i=0;i<16;i++)skyBuffer.setPaletteColor(i,nightInk(skyPalette[i],displayNight));
  for(int stripY=0;stripY<224;stripY+=skyBufferHeight) {
  paint.targetAt(skyBuffer,48,62+stripY,true);
#endif
  labelCount=0; hitCount=0;
  // Prepare the complete map off-screen. Never clear the displayed map first.
  for(int y=62;y<286;y++)paint.drawFastHLine(48,y,224,textBackground(48,y));
  int cx=160,cy=174;skyCamera.transform(cx,cy);
  paint.drawCircle(cx,cy,lround(108*skyCamera.zoom),0x8CFA);
  int compassX[]={155,155,54,252},compassY[]={68,265,167,167};const char* compass[]={"N","S","O","W"};
  for(int i=0;i<4;i++){skyCamera.transform(compassX[i],compassY[i]);if(skyCamera.contains(compassX[i],compassY[i]))text(compass[i],compassX[i],compassY[i]);}
  hitCount = 0;
  if (cfg.milky) {
    int px = -1, py = -1;
    for (int latitude = -10; latitude <= 10; latitude += 2) {
    if(sampleChartTouch())return;
    px=-1;py=-1;
    for (int i = 0; i <= 360; i += 3) {
      if(i%24==0&&sampleChartTouch())return;
      astro_spherical_t s{ASTRO_SUCCESS, (double)latitude, (double)i, 1};
      auto eq = Astronomy_EquatorFromVector(
          Astronomy_RotateVector(galRotation, Astronomy_VectorFromSphere(s, mapTime)));
      double a, h;
      starHorizontal(eq.ra, eq.dec, a, h);
      int x, y;
      if (projectMap(a, h, x, y)) {
        if (px >= 0)
          for(int band=-2;band<=2;band++)paint.drawLine(px, py+band, x, y+band, rgb(10+(10-abs(latitude))/2,17+(10-abs(latitude)),28+(10-abs(latitude))*2));
        px = x;
        py = y;
      } else
        px = -1;
    }
  }
  }
  if (cfg.lines)
    for (auto &s : constellationLines) {
      if(sampleChartTouch())return;
      double a, h, b, k;
      int x, y, u, v;
      starHorizontal(s.ra1, s.dec1, a, h);
      starHorizontal(s.ra2, s.dec2, b, k);
      if (projectMap(a, h, x, y) && projectMap(b, k, u, v))
        paint.drawLine(x, y, u, v, 0x212D);
    }
  int i = 0;
  for (auto &s : stars) {
    if((i%16)==0&&sampleChartTouch())return;
    double a, h;
    int x, y;
    starHorizontal(s.ra, s.dec, a, h);
    if (projectMap(a, h, x, y)) {
      if(s.mag < 1.5) { paint.drawPixel(x-2,y,0x6B73);paint.drawPixel(x+2,y,0x6B73);paint.drawPixel(x,y-2,0x6B73);paint.drawPixel(x,y+2,0x6B73); paint.fillCircle(x,y,1,white); }
      else paint.drawPixel(x,y,s.mag < 3.5 ? white : 0x6B73);
      addHit(x, y, 100 + i);
    }
    i++;
  }
  i = 0;
  for (auto &s : deepSky) {
    if((i%16)==0&&sampleChartTouch())return;
    double a, h;
    int x, y;
    starHorizontal(s.ra, s.dec, a, h);
    if (projectMap(a, h, x, y)) {
      paint.drawCircle(x, y, 2, 0x6B73);
      // Deep-sky names appear on tap; keep the chart uncluttered.
      addHit(x, y, 2000 + i);
    }
    i++;
  }
  if(extra.trails&&cfg.satellites&&clockReady())for(int n=0;n<SAT_COUNT;n++){
    if(sampleChartTouch())return;
    if((n==3&&!cfg.starlink)||!satellitePositionCurrent(satellites[n],clockReady(),time(nullptr))||satellites[n].alt<0)continue;
    int px=0,py=0,oldx=0,oldy=0;bool previous=false,segment=false;
    for(int dt=0;dt<=120;dt+=20){double az,alt;int x,y;
      if(!satelliteFuture(n,time(nullptr)+dt,az,alt)||!projectMap(az,alt,x,y))break;
      if(previous){paint.drawLine(px,py,x,y,cyan);oldx=px;oldy=py;segment=true;}px=x;py=y;previous=true;
    }
    if(segment){double a=atan2(py-oldy,px-oldx);for(int sign:{-1,1})paint.drawLine(px,py,px-lround(6*cos(a+sign*.5)),py-lround(6*sin(a+sign*.5)),cyan);}
  }
  for (i = 0; i < objectCount; i++) {
    auto &o = objects[i];
    int x, y;
    if (projectMap(o.az, o.alt, x, y)) {
      if(o.kind==0) glowSun(x,y,5); else if(o.kind==1) moonIcon(x,y,7); else {
        if(o.kind==6){
          for(int band=0;band<2;band++)for(int a=0;a<180;a++){
            double t=a*pi/90;double u=(12+band)*cos(t),v=4*sin(t);
            paint.drawPixel(x+lround(u*.94+v*.342),y+lround(-u*.342+v*.94),0xEED0);
          }
        }
        sphere(x,y,7,o.kind);
        if(o.kind==6)for(int a=0;a<90;a++){
          double t=a*pi/90,u=13*cos(t),v=4*sin(t);
          paint.drawPixel(x+lround(u*.94+v*.342),y+lround(-u*.342+v*.94),0xEED0);
        }
      }
      if (cfg.labels) mapLabel(o.name,x,y,o.color);
      addHit(x, y, i);
    }
  }
  if (cfg.satellites && cfg.view == 1)
    for (i = 0; i < SAT_COUNT; i++) {
      if (i >= 3 && !cfg.starlink)
        continue;
      auto &s = satellites[i];
      int x, y;
      if (satellitePositionCurrent(s,clockReady(),time(nullptr)) && projectMap(s.az, s.alt, x, y)) {
        if(satelliteCandidateSeconds(s,clockReady(),time(nullptr)))paint.drawCircle(x,y,16,0xFFE0);
        paint.fillRect(x-3,y-5,7,11,white);
        paint.fillRect(x-13,y-4,8,9,i==3?uint16_t(0xFFE0):cyan);paint.fillRect(x+6,y-4,8,9,i==3?uint16_t(0xFFE0):cyan);
        if (cfg.labels) mapLabel(i==3?String("Starlink"):String(s.name),x,y,i==3?uint16_t(0xFFE0):cyan);
        addHit(x, y, 3000 + i);
      }
    }
  if(cfg.labels) {
    int count=0;
    for(auto &s:constellationLabels) {
      double a,h;int x,y;starHorizontal(s.ra,s.dec,a,h);
      if(h>15 && projectMap(a,h,x,y) && count<3 && mapLabel(s.name,x,y,0x7CBA)) count++;
    }
  }
#ifndef UI_DIRECT_PREVIEW
  if(highlightedObject>=0){double az,alt;String name;int x,y;
    if(objectCoordinates(highlightedObject,az,alt,name)&&projectMap(az,alt,x,y)){paint.drawCircle(x,y,11,0xFFE0);paint.drawCircle(x,y,13,0xFFE0);}}
  paint.targetAt(lcd);
  skyBuffer.setPivot(112,skyBufferHeight/2);
  skyBuffer.pushRotateZoom(240,mapCenterY()+(stripY+skyBufferHeight/2-112)*mapScale(),0,mapScale(),mapScale());
  // Wait for any pending DMA before releasing the image memory.
  lcd.waitDMA();
  }
  ++uiDiag.draws;uiDiag.lastDrawMs=millis();
  // Keep the fixed pixel buffer and tiny palette for the next frame.
#endif
}
static const char *letters[] = {"q", "w", "e", "r", "t", "z", "u", "i", "o", "p",
                                "a", "s", "d", "f", "g", "h", "j", "k", "l", "ü",
                                "y", "x", "c", "v", "b", "n", "m", "ö", "ä", "ß"};
static const char *symbols[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0",
                                "!", "@", "#", "$", "%", "&", "*", "(", ")", "?",
                                "-", "_", ".", ",", ":", ";", "/", "+", "=", "\""};

static bool favoritesOnly=false;
static void submit() {
  if(purpose==19){objectQuery=input;objectOffset=0;page=12;return;}
  String err;
  JsonDocument d;
  if (purpose == 1) {
    wifiName = input;
    keyboard("WLAN-Passwort", "", 2);
    return;
  }
  if (purpose == 2) {
    if (saveWifi(wifiName, input))
      { page = 2; input = ""; showPassword = false; }
    else
      title = message;
  }
  if (purpose == 4) {
    strlcpy(draft.name, input.c_str(), 40);
    keyboard("Breite −90 bis 90", String(draft.lat, 6), 5);
    return;
  }
  if (purpose == 5) {
    char *end;
    double v = strtod(input.c_str(), &end);
    if (*end || !isfinite(v) || v < -90 || v > 90) {
      title = "Ungültige Breite";
      return;
    }
    draft.lat = v;
    keyboard("Länge −180 bis 180", String(draft.lon, 6), 6);
    return;
  }
  if (purpose == 6) {
    char *end;
    double v = strtod(input.c_str(), &end);
    if (*end || !isfinite(v) || v < -180 || v > 180) {
      title = "Ungültige Länge";
      return;
    }
    draft.lon = v;
    keyboard("Höhe über Meer (m)",String(draft.height,0),9);
    return;
  }
  if(purpose==9){char *end;double h=strtod(input.c_str(),&end);if(*end||!isfinite(h)||h< -500||h>9000){title="Höhe −500 bis 9000 m";return;}draft.height=h;keyboard("Zeitzone (POSIX)",draft.tz,7);return;}
  if (purpose == 7) {
    if (input.isEmpty() || input.length() > 79) {
      title = "Zeitzone prüfen";
      return;
    }
    strlcpy(draft.tz, input.c_str(), 80);
    if (editPlace < 0) {
      if (cfg.placeCount == 6) {
        title = "Maximal 6 Standorte";
        return;
      }
      editPlace = cfg.placeCount++;
    }
    cfg.places[editPlace] = draft;
    cfg.place = editPlace;
    saveSettings();
    applyPlace();
    page = 5;
  }
}
struct UiButton {int x,y,w,h,action;};
static UiButton buttons[40];static int buttonCount=0;
static void control(String name,int x,int y,int w,int h,int action,uint16_t color=0x2104){if(buttonCount<40)buttons[buttonCount++]={x,y,w,h,action};button(name,x,y,w,h,color);}
static void cell(String name,int index,int action){control(name,8+(index%2)*236,74+(index/2)*48,228,42,action);}
static String metric(float n,const char*unit,int decimals=0){return isfinite(n)?String(n,decimals)+unit:String("—");}
static void flightScreen(bool full){
 static int lastMode=-1;static String old[13];static uint16_t oldColor[13]={};
 int mode=!modern.aircraft?0:!flight.found?1:2;
 full=full||mode!=lastMode;lastMode=mode;
 if(full){paint.fillRect(0,34,480,246,bg);for(auto &v:old)v="";}
 auto row=[&](int i,String value,int x,int y,const UiFont &font,uint16_t color,int w){
  if(full||old[i]!=value||oldColor[i]!=color){paint.fillRect(x,y,w,((i==0||i==11)?uiFont20.height:font.height)+2,bg);label(value,x,y,font,color,w);old[i]=value;oldColor[i]=color;}
 };
 if(mode==0){row(0,"Flugzeugansicht ausgeschaltet",12,72,uiFont20,white,456);return;}
 if(mode==1){row(0,flight.error[0]?"Datenquelle nicht erreichbar":flight.checked?"Kein Flugzeug im Umkreis":"Flugdaten werden geladen",12,72,uiFont20,white,456);row(1,strstr(flight.error,"429")?String("HTTP 429 · Versuch ")+stamp(aircraftNextAttempt(),true):String("Flugzeuge und Hubschrauber · ")+String(modern.radius)+" km",12,115,uiFont14,muted,456);return;}
 String call=flight.callsign[0]?flight.callsign:flight.hex;
 row(0,call,12,42,width(call,uiFont20)>174?uiFont14:uiFont20,white,174);
 row(1,flight.type[0]?flight.type:"Typ unbekannt",190,47,uiFont14,muted,170);
 row(2,modern.approaching?"Im Anflug":"Nächstes",365,47,uiFont14,0xFFE0,108);
 unsigned profile=AircraftArt::resolve(flight.type,flight.rotorcraft,airframeCategory(flight.category)==Airframe::FixedWing);
 bool routeOk=clockReady()&&routeMatches(flightRoute,flight.callsign,flight.hex,time(nullptr));
 unsigned livery=AircraftArt::scheme(flight.callsign,routeOk?flightRoute.airline:"");
 if((profile>=21&&!(profile==22&&livery==7))||(profile<21&&livery==7))livery=0;
 String pictureKey=String(profile)+":"+String(livery);
 if(full||old[3]!=pictureKey){paint.fillRect(8,77,212,89,bg);
  if(!AircraftImages::draw(paint,profile,livery,8,80)) AircraftArt::draw(paint,profile,8,80,210,livery);
  label(livery?String(AircraftArt::liveries[livery].name)+" · Schema":String("Typbild · Schema"),12,151,uiFont11,muted,205);old[3]=pictureKey;
 }

 String from=routeOk?(flightRoute.originName[0]?String(flightRoute.originName)+" ("+flightRoute.origin+")":String(flightRoute.origin)):String("Route nicht verfügbar");
 String to=routeOk?(flightRoute.destinationName[0]?String(flightRoute.destinationName)+" ("+flightRoute.destination+")":String(flightRoute.destination)):String("Start / Ziel nicht bestätigt");
 row(11,routeOk?"Von: "+from:from,12,174,uiFont14,routeOk?white:muted,322);
 row(12,routeOk?"Nach: "+to:to,12,197,uiFont14,routeOk?cyan:muted,322);
 row(4,metric(flight.distance," km",1),224,88,uiFont14,cyan,112);
 row(5,bearing(flight.azimuth)+" vom Ort",224,120,uiFont11,white,112);
 const int cx=406,cy=148,rad=43;int px=cx,py=cy,ex=cx,ey=cy;bool point=isfinite(flight.azimuth)&&isfinite(flight.distance),arrow=point&&isfinite(flight.track);
 if(point){double a=flight.azimuth*DEG_TO_RAD,dist=constrain(flight.distance/modern.radius,0.0f,1.0f)*rad;px=cx+lround(sin(a)*dist);py=cy-lround(cos(a)*dist);}
 if(arrow){double t=flight.track*DEG_TO_RAD;ex=px+lround(sin(t)*10);ey=py-lround(cos(t)*10);}
 String compass=String(px)+":"+String(py)+":"+String(ex)+":"+String(ey)+":"+String(point)+String(arrow)+String(flightFresh());
 if(full||old[6]!=compass){paint.fillRect(342,78,130,133,bg);paint.drawCircle(cx,cy,rad,cyan);
  label("N",cx-5,cy-rad-15,uiFont11,white);label("O",cx+rad+4,cy-5,uiFont11,white);label("W",cx-rad-15,cy-5,uiFont11,white);label("S",cx-4,cy+rad+2,uiFont11,white);paint.fillCircle(cx,cy,3,white);
  if(point){uint16_t col=flightFresh()?cyan:0xf800;paint.fillCircle(px,py,3,col);if(arrow){double t=flight.track*DEG_TO_RAD;paint.drawLine(px,py,ex,ey,col);for(int side:{-1,1})paint.drawLine(ex,ey,ex-lround(sin(t+side*.55)*5),ey+lround(cos(t+side*.55)*5),col);}}old[6]=compass;
 }
 if(full){paint.drawFastHLine(8,216,464,cyan);const char*names[]={"Höhe barom.","Geschwindigkeit","Flugrichtung"};for(int i=0;i<3;i++)label(names[i],12+i*158,221,uiFont11,muted);}
 String vals[]={metric(flight.altitude," m"),metric(flight.speed," km/h"),metric(flight.track,"°")};
 for(int i=0;i<3;i++)row(7+i,vals[i],12+i*158,237,uiFont20,white,150);
 int age=clockReady()&&flight.positionAt>0?max(0,int(time(nullptr)-flight.positionAt)):-1;
 String ageText=age<0?String("Alter unbekannt"):age<60?String(age)+" s":String(age/60)+" min";
 row(10,String(flightFresh()?"Aktuell · ":"Veraltet · ")+ageText+(routeOk?" · Route: Katalog":""),12,263,uiFont11,flightFresh()?cyan:0xf800,456);
}
static void detailScreen(bool full){
 static String old[12];
 auto row=[&](int i,String value,int x,int y,const UiFont &font,uint16_t color,int w){if(full||old[i]!=value){paint.fillRect(x,y,w,font.height+2,bg);label(value,x,y,font,color);old[i]=value;}};
 double az=0,alt=0,mag=NAN;String name;
 if(selected>=3000&&selected<3004){auto&s=satellites[selected-3000];
  if(full){text(s.name,12,45,2);satelliteIcon(62,118,selected-3000);}
  bool fresh=satellitePositionCurrent(s,clockReady(),time(nullptr));
  row(0,"NORAD "+String(s.catalog),115,84,uiFont14,white,350);
  row(1,fresh?"Richtung "+bearing(s.az)+" · Höhe "+String(s.alt,1)+"°":"Bahndaten fehlen / veraltet",115,112,uiFont14,white,350);
  row(2,fresh?satelliteCountdown(s):String("Keine aktuelle Position"),115,141,uiFont14,fresh?(satelliteCandidateSeconds(s,clockReady(),time(nullptr))?0xFFE0:s.alt>=0?0x97F2:muted):muted,350);
  row(3,fresh?"Beginn "+eventStamp(s.rise):String("Überflug nicht verfügbar"),12,181,uiFont14,white,456);
  row(4,fresh?"Maximum "+String(s.maxAlt,0)+"° · "+bearing(s.startAz)+" → "+bearing(s.endAz):String(""),12,208,uiFont14,white,456);
  row(5,satelliteCandidateSeconds(s,clockReady(),time(nullptr))?"Sichtchance* · nur bei klarem Himmel":"Sichtbarkeit nicht bestätigt",12,240,uiFont14,0xFFE0,456);
  row(6,"*Keine Garantie · Bahndaten "+stamp(s.epoch,true),12,260,uiFont11,muted,456);return;}
 if(!objectCoordinates(selected,az,alt,name)){row(0,"Objektdaten nicht verfügbar",12,65,uiFont14,muted,456);return;}
 if(selected<objectCount){auto&o=objects[selected];mag=o.mag;
  if(full){if(o.kind==1)moonIcon(85,145,48);else{if(o.kind==6)for(int a=0;a<360;a++){double t=a*DEG_TO_RAD;paint.drawPixel(85+lround(70*cos(t)),145+lround(20*sin(t)),0xEED0);}sphere(85,145,45,o.kind);}}
 }else if(selected>=2000&&selected-2000<(int)(sizeof deepSky/sizeof deepSky[0]))mag=deepSky[selected-2000].mag;
 else if(selected>=100&&selected-100<(int)(sizeof stars/sizeof stars[0])){mag=stars[selected-100].mag;if(full)paint.fillCircle(85,145,8,white);}
 if(full)text(name,12,45,2);
 row(0,"Richtung "+bearing(az)+" / "+String(az,1)+"°",175,90,uiFont14,white,295);
 row(1,"Höhe "+String(alt,1)+"°",175,125,uiFont14,white,295);
 row(2,"Helligkeit "+metric(mag," mag",1),175,160,uiFont14,white,295);
 row(3,alt>=0?"Über dem Horizont":"Unter dem Horizont",175,198,uiFont14,alt>=0?cyan:muted,295);
 if(full){bool fav=false;for(int i=0;i<modern.favoriteCount;i++)fav|=modern.favorites[i]==selected;
 control(fav?"Favorit entfernen":"Als Favorit",175,230,285,38,700);}
}
static void keyboardDraw(){
 text(title.substring(0,36),8,42);String shown=input;if(purpose==2&&!showPassword){shown="";for(unsigned i=0;i<input.length();i++)shown+='*';}
 paint.drawRect(8,67,464,35,muted);text(shown.substring(shown.length()>46?shown.length()-46:0),12,76);
 for(int k=0;k<30;k++){String ch=keyLayout?symbols[k]:letters[k];if(shifted&&!keyLayout)ch.toUpperCase();control(ch,k%10*48+2,109+k/10*38,44,34,1000+k);}
 control(shifted?"abc":"ABC",2,226,70,36,1030);control(keyLayout?"abc":"123",76,226,70,36,1031);control("Leer",150,226,100,36,1032);control("DEL",254,226,80,36,1033);control(showPassword?"Verbergen":"Anzeigen",338,226,140,36,1034);
 control("Abbruch",8,280,228,36,1035);control("OK",244,280,228,36,1036,blue);
}
static void objectListScreen(){
 control(favoritesOnly?"Favoriten":objectQuery.length()?objectQuery:"Objekt suchen",8,40,340,34,600);
 control("<",356,40,54,34,601);control(">",416,40,56,34,602);
 objectMatches=0;for(int&v:objectChoices)v=-1;String q=objectQuery;q.toLowerCase();
 if(clockReady())for(int id=0;id<100+(int)(sizeof stars/sizeof stars[0]);id++){
  double az,alt;String name;if(!objectCoordinates(id,az,alt,name))continue;bool fav=false;for(int i=0;i<modern.favoriteCount;i++)fav|=modern.favorites[i]==id;
  String lower=name;lower.toLowerCase();if(favoritesOnly?!fav:q.length()?lower.indexOf(q)<0:(id<2||id>=100||alt<0))continue;
  int row=objectMatches++-objectOffset;if(row<0||row>=4)continue;objectChoices[row]=id;control(name+" · "+bearing(az)+" "+String(alt,0)+"°",8,82+row*46,464,40,610+row);}
 if(!objectMatches)text(clockReady()?"Keine passenden Objekte":"Warte auf Uhrzeit",12,120);
}

#include "Hangar.h"
#include "RadarDisplay.h"
static uint32_t hangarScreenRevision=0;
static unsigned hangarScreenOffset=0;
static Hangar::Record hangarSelectedRow;
static String hangarScreenError;
static void requestHangarScreen(bool next=false,bool refresh=false){
 JsonDocument d;d["sort"]="last";d["search"]="";d["force"]=refresh;
 if(next){unsigned size,total;bool more;String error;Hangar::Record cursor;
  if(!hangarDisplayRow(11,cursor,size,total,more,error)||!more)return;
  d["cursorHex"]=cursor.hex;d["cursorLast"]=cursor.last;d["cursorPasses"]=cursor.passes;
 }
 if(hangarRequest(d,hangarScreenError)){hangarScreenRevision=hangarRevision();hangarScreenOffset=0;}
 page=13;surfaceRevision++;
}
static void hangarScreen(){
 control("Mein Hangar",8,40,300,32,820);control("Aktualisieren",316,40,156,32,820);
 if(hangarScreenRevision!=hangarRevision()){label("Ansicht geändert · Aktualisieren",12,95,uiFont14,muted);return;}
 if(page==14){
  auto&r=hangarSelectedRow;
  label(String(r.registration[0]?r.registration:r.hex)+" · "+r.callsign,12,82,uiFont14,cyan,450);
  label("ICAO "+String(r.hex)+" · "+r.type+" · "+String(r.passes)+" Überflüge",12,106,uiFont11,white,450);
  label("Erstmals: "+stamp(r.first,true),12,130,uiFont11,white,450);
  label("Zuletzt: "+stamp(r.last,true),12,150,uiFont11,white,450);
  HangarRoute::Record route;String error;
  if(hangarDisplayRouteResult(route,error)){
   if(error.length())label(error,12,178,uiFont14,muted,450);
   else {label(String(route.origin)+" → "+route.destination,12,176,uiFont14,cyan,450);
    label(String(route.originName)+" → "+route.destinationName,12,198,uiFont11,white,450);
    label(route.airline,12,219,uiFont11,white,450);
    label("Katalogroute · nicht live bestätigt",12,243,uiFont11,muted,450);}
  }else label("Route wird geladen …",12,178,uiFont14,muted,450);
  return;
 }
 unsigned size=0,total=0;bool more=false;String error;Hangar::Record row;
 if(!hangarDisplayRow(0,row,size,total,more,error)){label(hangarScreenError.length()?hangarScreenError:"Hangar wird geladen …",12,95,uiFont14,muted,450);return;}
 if(error.length()){label("Hangar nicht verfügbar",12,92,uiFont14,0xF800,450);label(error,12,122,uiFont11,white,450);return;}
 if(!size){label("Noch keine gespeicherten Flugzeuge",12,95,uiFont14,muted,450);return;}
 for(unsigned i=0;i<3&&hangarScreenOffset+i<size;i++){
  hangarDisplayRow(hangarScreenOffset+i,row,size,total,more,error);
  int y=80+i*48;control("",8,y,464,43,830+i);
  int previousBackground=labelBackground;labelBackground=0x2104;
  label(String(row.registration[0]?row.registration:row.hex)+" · "+row.callsign,18,y+3,uiFont14,white,440);
  label(String(row.passes)+" Überflüge · "+stamp(row.last,true),18,y+25,uiFont11,muted,440);labelBackground=previousBackground;
 }
 control("<",8,230,70,36,821);label(String(total)+" Flugzeuge",94,241,uiFont11,white,230);control(">",392,230,80,36,822);
}
static int radarNextRadius(int radius,int delta){
 const int steps[]={5,10,25,50,75,100,150,200};
 if(delta>0){for(int v:steps)if(v>radius)return v;}else if(delta<0){for(int i=7;i>=0;i--)if(steps[i]<radius)return steps[i];}
 return radius;
}
static String radarRangeError;
static char radarSelected[9]={};
static RadarDot radarLastSelected;
static uint32_t radarSelectionGeneration=0;
static int radarX(const RadarDot &d){return 136+lround(104*d.distance/max(1,radarDisplay.radius)*sin(d.azimuth*DEG_TO_RAD));}
static int radarY(const RadarDot &d){return 169-lround(104*d.distance/max(1,radarDisplay.radius)*cos(d.azimuth*DEG_TO_RAD));}
static void radarScreen(bool full=false){
 static String old[13];static uint16_t oldColor[13];static int oldX[16],oldY[16];static unsigned oldCount=0;static uint32_t oldRevision=0;static String oldSelection;static bool oldValid=false,oldStale=false;static int oldRadius=-1;
 auto row=[&](int i,String value,int x,int y,const UiFont &f,uint16_t c,int w=195){if(full||old[i]!=value||oldColor[i]!=c){paint.fillRect(x,y,w,f.height+2,bg);label(value,x,y,f,c,w);old[i]=value;oldColor[i]=c;}};

 const auto&r=radarDisplay;if(radarSelectionGeneration!=generation){radarSelected[0]=0;radarSelectionGeneration=generation;}bool valid=modern.aircraft&&r.revision&&r.generation==generation;
 if(valid!=oldValid||modern.radius!=oldRadius){full=true;paint.fillRect(0,34,480,286,bg);}oldValid=valid;oldRadius=modern.radius;
 if(full){oldCount=0;oldRevision=0;for(auto &v:old)v="";button("-",275,294,42,26);button("+",430,294,42,26);}
 row(12,String(modern.radius)+" km",326,299,uiFont11,white,100);
 if(!valid){if(full){label("Radar wartet auf Flugdaten",12,75,uiFont14,white);label("Himmel / Flugzeug: wischen",12,110,uiFont11,muted);}return;}
 bool stale=!clockReady()||time(nullptr)<r.received||time(nullptr)-r.received>90;
 uint16_t color=stale?0xF800:cyan;
 bool plot=full||oldRevision!=r.revision||oldSelection!=String(radarSelected)||oldStale!=stale;
 if(plot){for(unsigned i=0;i<oldCount;i++)paint.fillRect(oldX[i]-11,oldY[i]-11,23,23,bg);oldCount=0;

 for(int i=1;i<=4;i++){paint.drawCircle(136,169,26*i,0x2945);label(String(r.radius*i/4.0,1),140,169-26*i+2,uiFont11,muted);}
 label("N",130,43,uiFont14,white);label("S",130,278,uiFont14,white);label("W",10,160,uiFont14,white);label("O",246,160,uiFont14,white);paint.fillCircle(136,169,3,white);}
 row(0,String(r.count)+" / "+String(r.total)+" · "+String(r.radius)+" km",275,45,uiFont11,white,195);
 row(1,stale?"Veraltet":"Aufnahme vor "+String((uint32_t)(time(nullptr)-r.received))+" s",275,64,uiFont11,stale?0xF800:muted,195);
 row(2,radarRangeError.length()?radarRangeError:r.limited?"Ohne SD: Einzelziel":r.total>16?"16 nächste Ziele":"",275,83,uiFont11,radarRangeError.length()?0xF800:muted,195);
 const RadarDot *selectedDot=nullptr;
 for(unsigned i=0;i<r.count;i++){
  const auto&d=r.dots[i];int x=radarX(d),y=radarY(d);bool chosen=radarSelected[0]&&!strcmp(d.hex,radarSelected);uint16_t c=chosen?0xFFE0:((time(nullptr)-(time_t)d.positionAt>90)?0xF800:color);
  if(chosen){radarLastSelected=d;selectedDot=&d;if(plot)paint.drawCircle(x,y,10,c);}
  if(plot){oldX[oldCount]=x;oldY[oldCount++]=y;
  if(d.rotorcraft){paint.drawCircle(x,y,5,c);paint.drawFastHLine(x-7,y,14,c);paint.drawLine(x,y-7,x,y+7,c);}
  else if(isfinite(d.track)){double a=d.track*DEG_TO_RAD;paint.fillTriangle(x+7*sin(a),y-7*cos(a),x+5*sin(a+2.5),y-5*cos(a+2.5),x+5*sin(a-2.5),y-5*cos(a-2.5),c);}
  else paint.fillCircle(x,y,4,c);}
 }
 oldRevision=r.revision;oldSelection=radarSelected;oldStale=stale;
 bool lost=!selectedDot&&radarSelected[0];if(lost)selectedDot=&radarLastSelected;
 if(selectedDot){const auto&d=*selectedDot;
  row(3,d.callsign[0]?d.callsign:d.hex,275,107,uiFont14,0xFFE0,195);
  row(4,lost?"Letzte Position":"Hier suchen",275,132,uiFont11,muted);row(5,String(d.azimuth,0)+"° · "+String(d.distance,1)+" km",275,148,uiFont14,white,195);
  row(6,"Bewegt sich nach",275,173,uiFont11,muted);row(7,isfinite(d.track)?String(d.track,0)+"°":"Unbekannt",275,189,uiFont14,white,195);
  row(8,isfinite(d.altitude)?String(d.altitude,0)+" m barom.":"Höhe unbekannt",275,216,uiFont11,white,195);
  row(9,isfinite(d.speed)?String(d.speed,0)+" km/h":"Tempo unbekannt",275,235,uiFont11,white,195);
  row(10,String(d.type)+" · "+d.hex,275,254,uiFont11,muted,195);
  row(11,"Position vor "+String((uint32_t)max((time_t)0,time(nullptr)-(time_t)d.positionAt))+" s",275,275,uiFont11,(stale||lost||time(nullptr)-(time_t)d.positionAt>90)?0xF800:muted,195);
 }else {row(3,"Ziel antippen",275,107,uiFont14,white,195);}
}
static void menuScreen(){
 if(page==1){text("Einstellungen",12,43,2);cell("WLAN",0,2);cell("Standorte",1,5);cell("Anzeige",2,6);cell("Satelliten",3,7);cell("Touch kalibrieren",4,50);cell("180° drehen",5,51);control("Himmel",8,226,110,30,800);control("Flugzeug",126,226,110,30,801);control("Radar",244,226,110,30,802);control("Hangar",362,226,110,30,820);label("Safari: "+(WiFi.status()==WL_CONNECTED?WiFi.localIP():WiFi.softAPIP()).toString(),12,261,uiFont11,cyan);}
 else if(page==2){control("WLAN suchen",8,41,150,33,100);control("Gespeicherte",165,41,150,33,3);control("Manuell",322,41,150,33,101);for(int i=0;i<6;i++){int k=networkPage*6+i;if(k<nearbyCount)cell(nearby[k],i,110+i);}control("<",8,226,80,34,102);control(">",392,226,80,34,103);label(message.substring(0,38),96,237,uiFont11,muted);}
 else if(page==3){text("Gespeicherte WLANs",12,43,2);for(int i=0;i<cfg.wifiCount;i++)cell(cfg.wifi[i].ssid,i,130+i);label("AP-Passwort: "+apPassword,12,242,uiFont14,muted);}
 else if(page==4){text(cfg.wifi[profile].ssid,12,43,2);cell("Verbinden",0,140);cell("Passwort ändern",1,141);cell("WLAN löschen",2,142);}
 else if(page==5){text("Standorte · wählen / bearbeiten",12,43,2);for(int i=0;i<cfg.placeCount;i++){int x=8+(i%2)*236,y=74+(i/2)*48;control(cfg.places[i].name,x,y,184,42,200+i,i==cfg.place?blue:0x2104);control("…",x+188,y,40,42,210+i);}control("Neuer Standort",8,230,464,38,220);}
 else if(page==9){text(cfg.places[editPlace].name,12,43,2);cell("Bearbeiten",0,221);cell("Löschen",1,222);}
 else if(page==6){text("Anzeige",12,43,2);label("Helligkeit",12,70,uiFont14,white);paint.fillRect(140,74,310,8,muted);paint.fillCircle(140+(cfg.brightness-20)*310/235,78,10,cyan);cell(String("Namen: ")+(cfg.labels?"Ein":"Aus"),2,302);cell(String("Linien: ")+(cfg.lines?"Ein":"Aus"),3,303);cell(String("Milchstraße: ")+(cfg.milky?"Ein":"Aus"),4,304);cell(String("Satelliten: ")+(cfg.satellites?"Ein":"Aus"),5,305);control("Auto: "+String(cfg.autoSeconds)+" s",8,226,228,40,306);}
 else if(page==7){text("Satelliten",12,43,2);for(int i=0;i<4;i++)cell(i==3?"Starlink":satellites[i].name,i,400+i);cell(satPaused?"API fortsetzen":"API aktiv",4,404);cell("Gesamtkarte",5,405);}
}
void uiDraw(){
 struct Timer{uint32_t at=micros();~Timer(){renderMaxUs=max(renderMaxUs,micros()-at);}} timer;
 static uint32_t batteryRevision=UINT32_MAX;static String lastKey;static int lastPage=-1,lastView=-1,lastSelected=-1;static bool lastNight=false;static uint32_t lastSurface=0;static time_t lastMinute=-1;
 String key=String(page)+":"+String(selected)+":"+String(surfaceRevision)+":"+String(cfg.brightness)+String(cfg.labels)+String(cfg.lines)+String(cfg.milky)+String(cfg.satellites)+String(displayNight)+String(cfg.place)+String(cfg.autoSeconds)+String(modern.favoriteCount);
 if(page==2)key+=message+String(nearbyCount);
 if(page==15)key+=String(radarDisplay.revision)+":"+String(time(nullptr)/5)+":"+radarSelected+":"+radarRangeError;
 if(page==13||page==14)key+=String(hangarRevision())+":"+String(hangarDisplayState());
 bool full=page!=lastPage||cfg.view!=lastView||selected!=lastSelected||lastNight!=displayNight||(page!=15&&lastSurface!=surfaceRevision);
 bool changed=key!=lastKey;bool clockChanged=lastMinute!=time(nullptr)/60||batteryRevision!=battery.revision;batteryRevision=battery.revision;
 if(page>0&&page!=8&&!changed){if(clockChanged){lcd.startWrite();header();lcd.endWrite();lastMinute=time(nullptr)/60;}return;}
 lastKey=key;lastPage=page;lastView=cfg.view;lastSelected=selected;lastNight=displayNight;lastSurface=surfaceRevision;
 lcd.startWrite();
 bool rebuild=full||(page>0&&page!=8&&page!=15&&changed);
 if(rebuild){buttonCount=0;paint.fillScreen(bg);}if(rebuild||clockChanged)header();lastMinute=time(nullptr)/60;
 if(page==0){if(cfg.view==1)skyScreen(full);else flightScreen(full);if(rebuild)nav();}
 else if(page==10)keyboardDraw();
 else {if(page==8)detailScreen(full);else if(page==12)objectListScreen();else if(page==13||page==14)hangarScreen();else if(page==15)radarScreen(rebuild);else menuScreen();if(rebuild&&page!=15)control("ZURÜCK",8,280,464,36,0);}
 lcd.endWrite();
}
struct QueuedTouch{int event,x,y,page,view,dx;};static QueuedTouch queue[8];static uint8_t qr=0,qw=0;
static bool uiInputPending(){
 if(qr==qw)return false;const auto &t=queue[qr];
 // Navigation does not consume the partially rebuilt object hit map.
 // Object taps wait for the completed map, preserving accurate selection.
 return t.event==2||(t.y<40&&t.x>=425)||(t.page==0&&t.view==1&&
   (t.y>=258||(t.x>=420&&t.y>=65&&t.y<203)||(t.x<118&&t.y>=75&&t.y<155)));
}
void uiPollTouch(){static TouchGesture g;static int beganPage=0,beganView=1;int32_t x=0,y=0;bool down=lcd.getTouch(&x,&y);if(touchSleepGate(down)){g=TouchGesture();qr=qw;return;}
 static bool brightnessSliding=false;
 if(down&&page==6&&(brightnessSliding||(x>=120&&y>=58&&y<=100))){brightnessSliding=true;cfg.brightness=constrain(20+(x-140)*235/310,20,255);uiDisplayBrightness();manualInteraction();dirty=true;g=TouchGesture();return;}
 if(brightnessSliding&&!down){brightnessSliding=false;saveSettings();g=TouchGesture();return;}
 int ep=beganPage,ev=beganView;uint32_t seq=g.sequence;int event=g.update(down,x,y,millis(),(beganPage==0||beganPage==15)&&g.sy>=40&&g.sy<280);if(seq!=g.sequence){beganPage=page;beganView=cfg.view;}
 if(!event)return;uint8_t next=(qw+1)%8;if(next==qr)return;queue[qw]={event,g.eventX,g.eventY,ep,ev,g.eventDx};qw=next;
}
static void action(int a){
 if(a==0&&page==14){requestHangarScreen();return;}
 if(a==0){page=(page==1||page==8||page==12)?0:1;selected=-1;return;}
 if(a==802){page=15;return;}
 if(a==820){requestHangarScreen(false,page==13||page==14);return;}
 if(a==821){hangarScreenOffset=hangarScreenOffset>=3?hangarScreenOffset-3:0;return;}
 if(a==822){unsigned size,total;bool more;String error;Hangar::Record row;
  if(hangarScreenRevision==hangarRevision()&&hangarDisplayRow(0,row,size,total,more,error)){
   if(hangarScreenOffset+3<size)hangarScreenOffset+=3;else if(more)requestHangarScreen(true);
  }return;
 }
 if(a>=830&&a<833){unsigned size,total;bool more;String error;Hangar::Record row;
  if(hangarScreenRevision==hangarRevision()&&hangarDisplayRow(hangarScreenOffset+a-830,row,size,total,more,error)&&hangarScreenOffset+a-830<size){
   if(hangarDisplayRouteRequest(row)){hangarSelectedRow=row;hangarScreenRevision=hangarRevision();page=14;}
  }return;
 }
 if(a>=2&&a<=7){page=a;if(a==2)scanStart();return;}
 if(a==800||a==801){setView(a==800?1:2);page=0;return;}
 if(a==50){calibrate();return;}if(a==51){cfg.rotation=cfg.rotation==1?3:1;lcd.setRotation(cfg.rotation);saveSettings();return;}
 if(a==100){scanStart();return;}if(a==101){keyboard("WLAN-Name (SSID)","",1);return;}if(a==102){networkPage=max(0,networkPage-1);return;}if(a==103){networkPage=min(3,networkPage+1);return;}
 if(a>=110&&a<116){int i=networkPage*6+a-110;if(i<nearbyCount){wifiName=nearby[i];keyboard("Passwort: "+wifiName,"",2);}return;}
 if(a>=130&&a<136){profile=a-130;page=4;return;}if(a==140){connectProfile(profile);page=2;return;}if(a==141){wifiName=cfg.wifi[profile].ssid;keyboard("Neues Passwort","",2);return;}if(a==142){deleteWifi(profile);page=3;return;}
 if(a>=200&&a<206){cfg.place=a-200;saveSettings();applyPlace();return;}if(a>=210&&a<216){editPlace=a-210;page=9;return;}
 if(a==220){editPlace=-1;draft=cfg.places[cfg.place];keyboard("Standortname","",4);return;}if(a==221){draft=cfg.places[editPlace];keyboard("Standortname",draft.name,4);return;}
 if(a==222&&cfg.placeCount>1){for(int i=editPlace;i<cfg.placeCount-1;i++)cfg.places[i]=cfg.places[i+1];cfg.placeCount--;cfg.place=0;saveSettings();applyPlace();page=5;return;}
 if(a>=300&&a<=307){if(a<=301){cfg.brightness=constrain(cfg.brightness+(a==300?-20:20),20,255);uiDisplayBrightness();}if(a==302)cfg.labels=!cfg.labels;if(a==303)cfg.lines=!cfg.lines;if(a==304)cfg.milky=!cfg.milky;if(a==305)cfg.satellites=!cfg.satellites;if(a==306)cfg.autoSeconds=cfg.autoSeconds==0?15:cfg.autoSeconds==15?30:cfg.autoSeconds==30?60:0;saveSettings();return;}
 if(a>=400&&a<=403){selected=3000+a-400;page=8;return;}if(a==404){resumeSatellites();return;}if(a==405){skyCamera.set(1,0,0);setView(1);return;}
 if(a==600){favoritesOnly=false;keyboard("Objekt suchen",objectQuery,19);return;}if(a==601||a==602){objectOffset=max(0,objectOffset+(a==601?-4:4));if(objectOffset>=objectMatches)objectOffset=0;return;}
 if(a>=610&&a<614){selected=objectChoices[a-610];if(selected>=0){highlightedObject=selected;page=8;}return;}
 if(a==700){ModernSettings m=modern;int found=-1;for(int i=0;i<m.favoriteCount;i++)if(m.favorites[i]==selected)found=i;if(found>=0){for(int i=found;i<m.favoriteCount-1;i++)m.favorites[i]=m.favorites[i+1];m.favoriteCount--;}else if(m.favoriteCount<16)m.favorites[m.favoriteCount++]=selected;JsonDocument d;d["action"]="modern";modernJson(d["modern"].to<JsonObject>(),m);String error;modernCommand(d,error);return;}
 if(a>=1000&&a<1030&&input.length()<79){String c=keyLayout?symbols[a-1000]:letters[a-1000];if(shifted&&!keyLayout)c.toUpperCase();input+=c;return;}
 if(a==1030)shifted=!shifted;if(a==1031)keyLayout=!keyLayout;if(a==1032&&input.length()<79)input+=' ';if(a==1033&&input.length()){int n=input.length()-1;while(n>0&&((uint8_t)input[n]&0xc0)==0x80)n--;input.remove(n);}if(a==1034)showPassword=!showPassword;if(a==1035){input="";showPassword=false;page=1;}if(a==1036)submit();
}
void uiTick(){static uint32_t seenBattery=UINT32_MAX;if(seenBattery!=battery.revision){seenBattery=battery.revision;dirty=true;}
 if(mapDeferred&&!networkOwnsMemory&&page==0&&cfg.view==1&&(int32_t)(millis()-mapRetryAt)>=0){mapRetryAt=millis()+1000;dirty=true;}
 static unsigned lastHangarState=0;unsigned hs=(page==13||page==14)?hangarDisplayState():0;if(hs!=lastHangarState){lastHangarState=hs;dirty=true;}
 static uint32_t radarAge=0;if(page==15&&millis()-radarAge>=5000){radarAge=millis();dirty=true;}
 uiPollTouch();if(qr==qw)return;auto t=queue[qr];qr=(qr+1)%8;if(t.page!=page||t.view!=cfg.view)return;manualInteraction();dirty=true;
 if(t.event==2&&(page==0||page==15)){
  int current=page==15?2:(cfg.view==2?1:0);
  int next=modern.aircraft?(current+(t.dx<0?1:2))%3:0;
  if(next==2){page=15;surfaceRevision++;}else setView(next==0?1:2);
  return;
 }
 int x=t.x,y=t.y;
 if(page==6&&y>=58&&y<=100&&x>=120){cfg.brightness=constrain(20+(x-140)*235/310,20,255);uiDisplayBrightness();saveSettings();surfaceRevision++;return;}
 if(y<40&&x>=425){page=1;surfaceRevision++;return;}
 if(page==15&&y>=292){
  int delta=x>=430?1:(x>=275&&x<=317?-1:0);
  if(delta){int radius=radarNextRadius(modern.radius,delta);
   if(radius!=modern.radius){ModernSettings m=modern;m.radius=radius;JsonDocument d;d["action"]="modern";modernJson(d["modern"].to<JsonObject>(),m);String error;if(modernCommand(d,error)){radarRangeError="";fetchSoon();surfaceRevision++;}else radarRangeError=error;}
  }return;
 }
 if(page==15){if(!modern.aircraft||radarDisplay.generation!=generation)return;int best=225;int hit=-1;for(unsigned i=0;i<radarDisplay.count;i++){int dx=x-radarX(radarDisplay.dots[i]),dy=y-radarY(radarDisplay.dots[i]);int d=dx*dx+dy*dy;if(d<best){best=d;hit=i;}}if(hit>=0){radarLastSelected=radarDisplay.dots[hit];radarSelectionGeneration=generation;strlcpy(radarSelected,radarDisplay.dots[hit].hex,sizeof radarSelected);surfaceRevision++;}return;}
 if(page==0){if(cfg.view!=1)return;
  if(!extra.largeMap&&y>=258){selected=3000+constrain(x/120,0,3);page=8;return;}
  if(x>=420&&y>=65&&y<203){if(y<107)skyCamera.set(min(4.0f,skyCamera.zoom+.5f),skyCamera.panX,skyCamera.panY);else if(y<155)skyCamera.set(max(1.0f,skyCamera.zoom-.5f),skyCamera.panX,skyCamera.panY);else skyCamera.set(1,0,0);return;}
  if(x<118&&y>=75&&y<155){favoritesOnly=y>=119;objectOffset=0;objectQuery="";page=12;return;}
  int hit=skyHitTarget(x,y);if(hit>=0){selected=hit;page=8;}return;
 }
 for(int i=0;i<buttonCount;i++){auto b=buttons[i];if(x>=b.x&&x<b.x+b.w&&y>=b.y&&y<b.y+b.h){action(b.action);surfaceRevision++;return;}}
}

// Only called from a web handler on the main loop, never from a renderer.
void webServiceUi(){uiTick();if(dirty&&(page!=0||cfg.view!=1)){dirty=false;uiDraw();}}
