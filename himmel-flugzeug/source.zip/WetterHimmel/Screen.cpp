#include "App.h"
#include "Modern.h"
#ifndef UI_HOST_PREVIEW
#include "Extras.h"
#endif
#include "Starlink.h"
#include "Catalog.h"
#include "UiFonts.h"
#include "Paint.h"
#include "Gesture.h"
#include "Visibility.h"
#include "StarNames.h"
static Paint paint(lcd);
#ifndef UI_DIRECT_PREVIEW
static LGFX_Sprite skyBuffer(&lcd);
// One 224x224, 4-bit sprite (25088 pixel bytes), allocated only when needed.
static bool skyPixelsReady=false;
static uint32_t mapRetryAt=0;
static bool skyBufferReady=false;
static bool networkOwnsMemory=false;
static bool mapDeferred=false;
#endif
// Called exclusively by the main loop, before publishing a network job.
void uiNetworkMemory(bool active) {
#ifndef UI_DIRECT_PREVIEW
  networkOwnsMemory=active;
  if(active && skyPixelsReady) {
    // Main-loop ownership: no render can be in progress when the job is queued.
    // The LCD retains its pixels; only the off-screen workspace is released.
    skyBuffer.deleteSprite();
    skyPixelsReady=false;
    mapDeferred=true;
  }
  if(!active && mapDeferred) {mapRetryAt=millis();dirty=true;}
#endif
}
static const uint16_t bg = 0x0000, blue = 0x0248, white = 0xFFFF, muted = 0xBDF7, cyan = 0x07FF;
static String input, title, wifiName;
static int purpose = 0, keyLayout = 0, networkPage = 0, profile = 0;
static bool shifted = false, held = false, showPassword = false;
static Place draft{};
static int editPlace = -1;
static int16_t hitX[1100], hitY[1100], hitType[1100];
static int hitCount=0;
static String objectQuery;static int objectOffset=0,objectChoices[6],objectMatches=0;
static float mapScale(){return extra.largeMap?244.0f/224.0f:1.0f;}
static int mapCenterY(){return extra.largeMap?156:146;}
static int labelBackground=-1;
static uint16_t textBackground(int,int){return labelBackground>=0?uint16_t(labelBackground):bg;}
// Embedded UTF-8 font subset: independent of the limited built-in fonts.
static uint16_t nextCode(const String &s, unsigned &i) {
  uint8_t c = s[i++];
  if (c < 128) return c;
  uint16_t v = c & (c < 224 ? 31 : 15);
  int n = c < 224 ? 1 : 2;
  while (n-- && i < s.length()) v = (v << 6) | (s[i++] & 63);
  return v;
}
static const UiGlyph *glyph(const UiFont &f, uint16_t c) {
  for (unsigned j = 0; j < f.count; j++) if (f.glyphs[j].code == c) return &f.glyphs[j];
  for (unsigned j = 0; j < f.count; j++) if (f.glyphs[j].code == '?') return &f.glyphs[j];
  return &f.glyphs[0];
}
static int width(String s, const UiFont &f = uiFont14) {
  int w = 0; unsigned i = 0;
  while (i < s.length()) w += glyph(f, nextCode(s, i))->advance;
  return w;
}
static void label(String s, int x, int y, const UiFont &f, uint16_t col) {
  unsigned i = 0;
  while (i < s.length()) {
    auto g = glyph(f, nextCode(s, i));
    for(int yy=0;yy<f.height;yy++) for(int xx=0;xx<g->width;xx++) {
      int b=yy*g->width+xx; uint8_t packed=f.bits[g->offset+b/2];
      int alpha=b%2?packed&15:packed>>4;if(!alpha)continue;
      uint16_t back=textBackground(x+xx,y+yy);
      int rr=(((col>>11)&31)*alpha+((back>>11)&31)*(15-alpha))/15;
      int gg=(((col>>5)&63)*alpha+((back>>5)&63)*(15-alpha))/15;
      int bb=((col&31)*alpha+(back&31)*(15-alpha))/15;
      paint.drawPixel(x+xx,y+yy,(rr<<11)|(gg<<5)|bb);
    }
    x += g->advance;
  }
}
static void text(String s, int x, int y, int size = 1, uint16_t col = white) {
  label(s, x, y, size == 2 ? uiFont20 : uiFont14, col);
}
static uint16_t rgb(int r, int g, int b) { return ((r & 248) << 8) | ((g & 252) << 3) | (b >> 3); }
static void gradient(int y, int h, int r, int g, int b, int rr, int gg, int bb) {
  for (int i=0;i<h;i++) paint.drawFastHLine(0,y+i,320,rgb(r+(rr-r)*i/h,g+(gg-g)*i/h,b+(bb-b)*i/h));
}
static void button(String s, int x, int y, int w, int h, uint16_t col = 0x0124) {
  paint.fillRoundRect(x,y,w,h,7,col);
  paint.drawRoundRect(x,y,w,h,7,col == blue ? cyan : 0x4A69);
  const UiFont &f = width(s) <= w-10 ? uiFont14 : uiFont11;
  int previous=labelBackground;labelBackground=col;
  label(s,x+(w-width(s,f))/2,y+(h-f.height)/2,f,white);labelBackground=previous;
}
// Shaded RGB565 spheres. No large framebuffer or PSRAM required.
static void sphere(int cx,int cy,int r,int kind) {
  const int colors[][3]={{255,213,50},{196,202,218},{146,146,158},{236,196,126},{220,101,65},{216,171,121},{217,197,147},{113,216,225},{66,121,228},{40,148,225}};
  kind=constrain(kind,0,9);
  for (int y=-r;y<=r;y++) for (int x=-r;x<=r;x++) {
    float d=float(x*x+y*y)/(r*r); if(d>1) continue;
    float z=sqrtf(1-d), light=0.27f+0.73f*max(0.0f,(-0.4f*x-0.55f*y)/r+0.75f*z);
    if(kind==0) light=0.82f+0.18f*z;
    float band=1;
    if(kind==5 || kind==6) band=0.82f+0.18f*sinf(y*1.1f);
    int red=colors[kind][0], green=colors[kind][1], blueC=colors[kind][2];
    if(kind==9 && sinf(x*0.9f+y*0.5f)+cosf(y*1.2f-x*0.3f)>0.9f) {red=68;green=181;blueC=117;}
    if(kind==1) band=0.83f+0.17f*sinf(x*1.8f+y)*sinf(y*1.6f);
    paint.drawPixel(cx+x,cy+y,rgb(red*light*band,green*light*band,blueC*light*band));
  }
}
static void glowSun(int x,int y,int r) {
  for(int k=r+9;k>r;k--) paint.drawCircle(x,y,k,rgb(35+(r+9-k)*8,25+(r+9-k)*5,20));
  sphere(x,y,r,0);
}
void keyboard(String name, String value, int why) {
  title = name;
  input = value;
  purpose = why;
  showPassword = false;
  keyLayout = 0;
  shifted = false;
  page = 10;
  dirty = true;
}
static uint32_t surfaceRevision=0;
static void calibrate() {
  ++surfaceRevision;
  paint.fillScreen(bg);
  text("Touchkalibrierung", 20, 40, 2);
  text("Bitte die Markierungen antippen.", 12, 80);
  uint16_t c[8];
  lcd.calibrateTouch(c, white, bg, 16);
  prefs.putBytes(("cal" + String(cfg.rotation)).c_str(), c, sizeof c);
  dirty = true;
}
void uiBegin() {
  lcd.init();
  lcd.setRotation(cfg.rotation);
  uiDisplayBrightness();
  lcd.setTextWrap(false);
#ifndef UI_DIRECT_PREVIEW
  skyBuffer.setPsram(false);
  skyBuffer.setColorDepth(4);
  skyBufferReady=skyBuffer.createPalette(skyPalette,16);
  // Do not reserve the pixel buffer at startup or while showing aircraft.
#endif
  uint16_t c[8];
  String key = "cal" + String(cfg.rotation);
  if (prefs.getBytesLength(key.c_str()) == sizeof c) {
    prefs.getBytes(key.c_str(), c, sizeof c);
    lcd.setTouchCalibrate(c);
  } else {
    bool loaded=false;
    for(const char *legacy:{"cal0","cal2"})if(prefs.getBytesLength(legacy)==sizeof c){prefs.getBytes(legacy,c,sizeof c);lcd.setTouchCalibrate(c);loaded=true;break;}
    if(!loaded)calibrate();
  }
}
static void back(){button("ZURÜCK",8,280,464,36,0x2104);}
static void header(){
 paint.fillRect(0,0,480,34,bg);labelBackground=bg;
 label(page?"Himmel & Flugzeug":cfg.view==1?"Himmel":"Flugzeug",8,6,uiFont20,white);
 label(String(cfg.places[cfg.place].name).substring(0,14)+" · "+stamp(time(nullptr)),225,10,uiFont11,muted);
 for(int yy=9;yy<=23;yy+=7)paint.drawFastHLine(445,yy,24,cyan);
 paint.drawFastHLine(8,33,464,cyan);labelBackground=-1;
}
static void nav(){
 paint.fillRect(0,280,480,40,bg);
 button("Himmel",8,282,228,34,cfg.view==1?blue:0x2104);
 button("Flugzeug",244,282,228,34,cfg.view==2?blue:0x2104);
}
static bool projectMap(double az,double alt,int &x,int &y){
  if(!project(az,alt,x,y))return false;
  skyCamera.transform(x,y);return true;
}
static void addHit(int x, int y, int type) {
  if (hitCount < 1100 && skyCamera.contains(x,y)) {
    hitX[hitCount] = lround(240+(x-160)*mapScale());
    hitY[hitCount] = lround(mapCenterY()+(y-174)*mapScale());
    hitType[hitCount++] = type;
  }
}
// Prefer nearby planets/satellites to the dense background star field.
static int skyHitTarget(int x,int y) {
  int best=-1,bestDistance=0,bestPriority=-1;
  for(int i=0;i<hitCount;i++) {
    bool primary=(hitType[i]>=0&&hitType[i]<objectCount)||hitType[i]>=3000;
    int radius=primary?26:15,dx=x-hitX[i],dy=y-hitY[i],distance=dx*dx+dy*dy;
    int priority=primary?1:0;
    if(distance<=radius*radius && (priority>bestPriority || (priority==bestPriority&&distance<bestDistance))) {
      best=hitType[i];bestDistance=distance;bestPriority=priority;
    }
  }
  return best;
}
struct LabelBox {int x,y,w,h;};
static LabelBox labelBoxes[24];
static int labelCount=0;
static bool mapLabel(String name,int x,int y,uint16_t color) {
  int w=width(name,uiFont11), h=14;
  const int dx[]={14,14,-14,-14,0,0},dy[]={-19,10,-19,10,-29,18};
  for(int k=0;k<6;k++) {
    int xx=k==4||k==5?x-w/2:k>=2?x-w+dx[k]:x+dx[k], yy=y+dy[k];
    if(xx<48||xx+w>272||yy<78||yy+h>272) continue;
    bool free=true;
    for(int j=0;j<labelCount;j++) {auto b=labelBoxes[j]; if(xx<b.x+b.w+3&&xx+w+3>b.x&&yy<b.y+b.h+3&&yy+h+3>b.y) free=false;}
    // Keep labels away from every solar-system marker, even those drawn later.
    for(int j=0;j<objectCount;j++) {int u,v; if(projectMap(objects[j].az,objects[j].alt,u,v)&&u>xx-13&&u<xx+w+13&&v>yy-10&&v<yy+h+10) free=false;}
    if(free && labelCount<24) {labelBoxes[labelCount++]={xx,yy,w,h};paint.fillRoundRect(xx-2,yy-1,w+4,h+2,2,0x0843);label(name,xx,yy,uiFont11,color);return true;}
  }
  return false;
}
static void moonIcon(int cx,int cy,int r) {
  double a=moonPhase*DEG_TO_RAD;
  for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++) {
    double xx=(double)x/r,yy=(double)y/r,z2=1-xx*xx-yy*yy;
    if(z2<0)continue;
    double light=xx*sin(a)-sqrt(z2)*cos(a);
    int v=light>0?190+int(50*sqrt(z2)):46;
    paint.drawPixel(cx+x,cy+y,rgb(v,v,v+min(9,255-v)));
  }
}
static void satelliteIcon(int x,int y,int kind) {
  paint.drawLine(x-18,y,x+18,y,0xBDF7);
  if(kind==2) {
    paint.fillRoundRect(x-10,y-5,22,10,3,0xBDF7);
    paint.fillCircle(x-10,y,5,0x4208);paint.drawCircle(x-10,y,5,white);
    paint.fillRect(x-3,y-15,10,8,0x2C9B);paint.fillRect(x-3,y+7,10,8,0x2C9B);
  } else {
    paint.fillRoundRect(x-4,y-7,8,14,2,0xD6BA);
    for(int side=-1;side<=1;side+=2) {
      int xx=x+(side<0?-21:8);paint.fillRect(xx,y-11,13,22,0x1B57);
      paint.drawRect(xx,y-11,13,22,0x75DF);
      for(int k=1;k<4;k++)paint.drawFastHLine(xx,y-11+k*5,13,0x4C9D);
      paint.drawFastVLine(xx+6,y-11,22,0x4C9D);
    }
  }
}
static void satelliteCards(){
 const char *names[]={"ISS","Tiangong","Hubble","Starlink"};
 for(int i=0;i<4;i++){uint16_t c=satelliteCandidateSeconds(satellites[i],clockReady(),time(nullptr))?0xFFE0:muted;
  paint.fillRect(i*120,258,120,22,bg);label(names[i],i*120+8,261,uiFont14,c);}
}
static void sampleChartTouch() {
#ifndef UI_HOST_PREVIEW
  lcd.endWrite();uiPollTouch();lcd.startWrite();
#endif
}
static void skyScreen(bool full=true) {
  static uint64_t lastMap=0;
  static String lastCards;static bool wasLarge=false;
  if(extra.largeMap!=wasLarge){full=true;wasLarge=extra.largeMap;}
  if(full) {paint.fillRect(0,34,480,246,bg);button("+",420,65,52,42);button("−",420,113,52,42);button("1×",420,161,52,42);button("Objekte",4,75,114,36);button("Favoriten",4,119,114,36);}
  uint64_t mapKey=(uint64_t)(clockReady()?time(nullptr)/30:0);
  mapKey=mapKey*31+skyCamera.revision;mapKey=mapKey*31+displayNight;
  mapKey=mapKey*31+generation;mapKey=mapKey*31+objectCount;
  mapKey=mapKey*31+(cfg.labels|cfg.lines<<1|cfg.milky<<2|cfg.satellites<<3|cfg.starlink<<4);
  String cards=String(clockReady())+":"+String((long)(time(nullptr)/60));
  for(int i=0;i<SAT_COUNT;i++) {
    auto &sat=satellites[i];bool fresh=satellitePositionCurrent(sat,clockReady(),time(nullptr));
    int x=0,y=0;
    if(fresh && cfg.satellites && (i<3 || cfg.starlink) && projectMap(sat.az,sat.alt,x,y)) {mapKey=mapKey*31+x;mapKey=mapKey*31+y;}
    bool sight=satelliteCandidateSeconds(sat,clockReady(),time(nullptr))>0;
    mapKey=mapKey*31+sight;cards+=String(sight);
    cards+=String(fresh)+":"+String(sat.alt>=0)+":"+stamp(sat.rise)+":"+String(sat.valid);
  }
  if(!extra.largeMap && (full || cards!=lastCards)) {satelliteCards();lastCards=cards;}
#ifndef UI_DIRECT_PREVIEW
  // Preserve the displayed chart while HTTPS owns the temporary workspace.
  bool deferred=mapDeferred;
#else
  bool deferred=false;
#endif
  mapKey=mapKey*31+(highlightedObject+1);mapKey=mapKey*31+extra.trails;mapKey=mapKey*31+extra.largeMap;
  if(!full && !deferred && mapKey==lastMap)return;
  lastMap=mapKey;
  if (!clockReady()) {
    text("Warte auf Uhrzeit",60,120);text("über WLAN / NTP",60,145);
    return;
  }
#ifndef UI_DIRECT_PREVIEW
  if(!networkOwnsMemory) {
    if(!skyBufferReady)skyBufferReady=skyBuffer.createPalette(skyPalette,16);
    if(skyBufferReady && !skyPixelsReady)
      skyPixelsReady=skyBuffer.createSprite(224,224)!=nullptr;
  }
  if(networkOwnsMemory || !skyBufferReady || !skyPixelsReady) {
    mapDeferred=true;
    mapRetryAt=millis()+1000;
    // Do not destroy an existing chart on a temporary allocation failure.
    if(full) {hitCount=0;text(networkOwnsMemory?"Karte nach Datenabruf":"Karte wartet auf Speicher",40,120);}
    return;
  }
  mapDeferred=false;
  for(unsigned i=0;i<16;i++)skyBuffer.setPaletteColor(i,nightInk(skyPalette[i],displayNight));
  paint.targetAt(skyBuffer,48,62,true);
#endif
  labelCount=0; hitCount=0;
  // Prepare the complete map off-screen. Never clear the displayed map first.
  for(int y=62;y<286;y++)paint.drawFastHLine(48,y,224,textBackground(48,y));
  int cx=160,cy=174;skyCamera.transform(cx,cy);
  paint.drawCircle(cx,cy,lround(108*skyCamera.zoom),0x8CFA);
  int compassX[]={155,155,54,252},compassY[]={68,265,167,167};const char* compass[]={"N","S","O","W"};
  for(int i=0;i<4;i++){skyCamera.transform(compassX[i],compassY[i]);if(skyCamera.contains(compassX[i],compassY[i]))text(compass[i],compassX[i],compassY[i]);}
  hitCount = 0;
  if (cfg.milky) {
    int px = -1, py = -1;
    for (int latitude = -10; latitude <= 10; latitude += 2) {
    sampleChartTouch();
    px=-1;py=-1;
    for (int i = 0; i <= 360; i += 3) {
      astro_spherical_t s{ASTRO_SUCCESS, (double)latitude, (double)i, 1};
      auto t = Astronomy_TimeFromDays((double)viewTime() / 86400 - 10957.5);
      auto eq = Astronomy_EquatorFromVector(
          Astronomy_RotateVector(Astronomy_Rotation_GAL_EQJ(), Astronomy_VectorFromSphere(s, t)));
      double a, h;
      starHorizontal(eq.ra, eq.dec, a, h);
      int x, y;
      if (projectMap(a, h, x, y)) {
        if (px >= 0)
          for(int band=-2;band<=2;band++)paint.drawLine(px, py+band, x, y+band, rgb(10+(10-abs(latitude))/2,17+(10-abs(latitude)),28+(10-abs(latitude))*2));
        px = x;
        py = y;
      } else
        px = -1;
    }
  }
  }
  if (cfg.lines)
    for (auto &s : constellationLines) {
      double a, h, b, k;
      int x, y, u, v;
      starHorizontal(s.ra1, s.dec1, a, h);
      starHorizontal(s.ra2, s.dec2, b, k);
      if (projectMap(a, h, x, y) && projectMap(b, k, u, v))
        paint.drawLine(x, y, u, v, 0x212D);
    }
  int i = 0;
  for (auto &s : stars) {
    if((i%16)==0)sampleChartTouch();
    double a, h;
    int x, y;
    starHorizontal(s.ra, s.dec, a, h);
    if (projectMap(a, h, x, y)) {
      if(s.mag < 1.5) { paint.drawPixel(x-2,y,0x6B73);paint.drawPixel(x+2,y,0x6B73);paint.drawPixel(x,y-2,0x6B73);paint.drawPixel(x,y+2,0x6B73); paint.fillCircle(x,y,1,white); }
      else paint.drawPixel(x,y,s.mag < 3.5 ? white : 0x6B73);
      addHit(x, y, 100 + i);
    }
    i++;
  }
  i = 0;
  for (auto &s : deepSky) {
    double a, h;
    int x, y;
    starHorizontal(s.ra, s.dec, a, h);
    if (projectMap(a, h, x, y)) {
      paint.drawCircle(x, y, 2, 0x6B73);
      // Deep-sky names appear on tap; keep the chart uncluttered.
      addHit(x, y, 2000 + i);
    }
    i++;
  }
  if(extra.trails&&cfg.satellites&&clockReady())for(int n=0;n<SAT_COUNT;n++){
    sampleChartTouch();
    if((n==3&&!cfg.starlink)||!satellitePositionCurrent(satellites[n],clockReady(),time(nullptr))||satellites[n].alt<0)continue;
    int px=0,py=0,oldx=0,oldy=0;bool previous=false,segment=false;
    for(int dt=0;dt<=120;dt+=20){double az,alt;int x,y;
      if(!satelliteFuture(n,time(nullptr)+dt,az,alt)||!projectMap(az,alt,x,y))break;
      if(previous){paint.drawLine(px,py,x,y,cyan);oldx=px;oldy=py;segment=true;}px=x;py=y;previous=true;
    }
    if(segment){double a=atan2(py-oldy,px-oldx);for(int sign:{-1,1})paint.drawLine(px,py,px-lround(6*cos(a+sign*.5)),py-lround(6*sin(a+sign*.5)),cyan);}
  }
  for (i = 0; i < objectCount; i++) {
    auto &o = objects[i];
    int x, y;
    if (projectMap(o.az, o.alt, x, y)) {
      if(o.kind==0) glowSun(x,y,5); else if(o.kind==1) moonIcon(x,y,7); else {
        if(o.kind==6){
          for(int band=0;band<2;band++)for(int a=0;a<180;a++){
            double t=a*pi/90;double u=(12+band)*cos(t),v=4*sin(t);
            paint.drawPixel(x+lround(u*.94+v*.342),y+lround(-u*.342+v*.94),0xEED0);
          }
        }
        sphere(x,y,7,o.kind);
        if(o.kind==6)for(int a=0;a<90;a++){
          double t=a*pi/90,u=13*cos(t),v=4*sin(t);
          paint.drawPixel(x+lround(u*.94+v*.342),y+lround(-u*.342+v*.94),0xEED0);
        }
      }
      if (cfg.labels) mapLabel(o.name,x,y,o.color);
      addHit(x, y, i);
    }
  }
  if (cfg.satellites && cfg.view == 1)
    for (i = 0; i < SAT_COUNT; i++) {
      if (i >= 3 && !cfg.starlink)
        continue;
      auto &s = satellites[i];
      int x, y;
      if (satellitePositionCurrent(s,clockReady(),time(nullptr)) && projectMap(s.az, s.alt, x, y)) {
        if(satelliteCandidateSeconds(s,clockReady(),time(nullptr)))paint.drawCircle(x,y,16,0xFFE0);
        paint.fillRect(x-3,y-5,7,11,white);
        paint.fillRect(x-13,y-4,8,9,i==3?uint16_t(0xFFE0):cyan);paint.fillRect(x+6,y-4,8,9,i==3?uint16_t(0xFFE0):cyan);
        if (cfg.labels) mapLabel(i==3?String("Starlink"):String(s.name),x,y,i==3?uint16_t(0xFFE0):cyan);
        addHit(x, y, 3000 + i);
      }
    }
  if(cfg.labels) {
    int count=0;
    for(auto &s:constellationLabels) {
      double a,h;int x,y;starHorizontal(s.ra,s.dec,a,h);
      if(h>15 && projectMap(a,h,x,y) && count<3 && mapLabel(s.name,x,y,0x7CBA)) count++;
    }
  }
#ifndef UI_DIRECT_PREVIEW
  if(highlightedObject>=0){double az,alt;String name;int x,y;
    if(objectCoordinates(highlightedObject,az,alt,name)&&projectMap(az,alt,x,y)){paint.drawCircle(x,y,11,0xFFE0);paint.drawCircle(x,y,13,0xFFE0);}}
  paint.targetAt(lcd);
  skyBuffer.setPivot(112,112);
  skyBuffer.pushRotateZoom(240,mapCenterY(),0,mapScale(),mapScale());
  // Wait for any pending DMA before releasing the image memory.
  lcd.waitDMA();
  // Keep the fixed pixel buffer and tiny palette for the next frame.
#endif
}
static const char *letters[] = {"q", "w", "e", "r", "t", "z", "u", "i", "o", "p",
                                "a", "s", "d", "f", "g", "h", "j", "k", "l", "ü",
                                "y", "x", "c", "v", "b", "n", "m", "ö", "ä", "ß"};
static const char *symbols[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0",
                                "!", "@", "#", "$", "%", "&", "*", "(", ")", "?",
                                "-", "_", ".", ",", ":", ";", "/", "+", "=", "\""};

static bool favoritesOnly=false;
static void submit() {
  if(purpose==19){objectQuery=input;objectOffset=0;page=12;return;}
  String err;
  JsonDocument d;
  if (purpose == 1) {
    wifiName = input;
    keyboard("WLAN-Passwort", "", 2);
    return;
  }
  if (purpose == 2) {
    if (saveWifi(wifiName, input))
      { page = 2; input = ""; showPassword = false; }
    else
      title = message;
  }
  if (purpose == 4) {
    strlcpy(draft.name, input.c_str(), 40);
    keyboard("Breite −90 bis 90", String(draft.lat, 6), 5);
    return;
  }
  if (purpose == 5) {
    char *end;
    double v = strtod(input.c_str(), &end);
    if (*end || !isfinite(v) || v < -90 || v > 90) {
      title = "Ungültige Breite";
      return;
    }
    draft.lat = v;
    keyboard("Länge −180 bis 180", String(draft.lon, 6), 6);
    return;
  }
  if (purpose == 6) {
    char *end;
    double v = strtod(input.c_str(), &end);
    if (*end || !isfinite(v) || v < -180 || v > 180) {
      title = "Ungültige Länge";
      return;
    }
    draft.lon = v;
    keyboard("Höhe über Meer (m)",String(draft.height,0),9);
    return;
  }
  if(purpose==9){char *end;double h=strtod(input.c_str(),&end);if(*end||!isfinite(h)||h< -500||h>9000){title="Höhe −500 bis 9000 m";return;}draft.height=h;keyboard("Zeitzone (POSIX)",draft.tz,7);return;}
  if (purpose == 7) {
    if (input.isEmpty() || input.length() > 79) {
      title = "Zeitzone prüfen";
      return;
    }
    strlcpy(draft.tz, input.c_str(), 80);
    if (editPlace < 0) {
      if (cfg.placeCount == 6) {
        title = "Maximal 6 Standorte";
        return;
      }
      editPlace = cfg.placeCount++;
    }
    cfg.places[editPlace] = draft;
    cfg.place = editPlace;
    saveSettings();
    applyPlace();
    page = 5;
  }
}
struct UiButton {int x,y,w,h,action;};
static UiButton buttons[40];static int buttonCount=0;
static void control(String name,int x,int y,int w,int h,int action,uint16_t color=0x2104){if(buttonCount<40)buttons[buttonCount++]={x,y,w,h,action};button(name,x,y,w,h,color);}
static void cell(String name,int index,int action){control(name,8+(index%2)*236,74+(index/2)*48,228,42,action);}
static String metric(float n,const char*unit,int decimals=0){return isfinite(n)?String(n,decimals)+unit:String("—");}
static void aircraftPicture(int x,int y,bool rotor){
 if(rotor){
  paint.fillRoundRect(x-13,y-25,26,43,9,white);paint.fillRoundRect(x-10,y-21,20,14,6,blue);
  paint.fillTriangle(x-6,y+12,x+6,y+12,x,y+50,white);paint.drawLine(x-16,y+47,x+16,y+47,white);
  paint.drawLine(x-47,y-7,x+47,y+5,white);paint.drawLine(x-35,y+22,x+35,y-22,white);
  paint.fillCircle(x,y-1,4,muted);paint.drawLine(x-20,y-18,x-20,y+20,muted);paint.drawLine(x+20,y-18,x+20,y+20,muted);
  paint.fillCircle(x+45,y+5,2,0xf800);
 }else{
  paint.fillRoundRect(x-5,y-46,10,87,5,white);paint.fillTriangle(x,y-20,x-49,y+14,x+49,y+14,white);
  paint.fillTriangle(x,y+26,x-21,y+45,x+21,y+45,white);paint.fillRect(x-4,y-36,8,6,blue);
  for(int side:{-1,1}){paint.fillRoundRect(x+side*22-3,y-3,6,17,2,muted);paint.fillCircle(x+side*47,y+14,2,0xf800);}
 }
}
static void flightScreen(bool full){
 static int lastMode=-1;static String old[13];static uint16_t oldColor[13]={};
 int mode=!modern.aircraft?0:!flight.found?1:2;
 full=full||mode!=lastMode;lastMode=mode;
 if(full){paint.fillRect(0,34,480,246,bg);for(auto &v:old)v="";}
 auto row=[&](int i,String value,int x,int y,const UiFont &font,uint16_t color,int w){
  if(full||old[i]!=value||oldColor[i]!=color){paint.fillRect(x,y,w,((i==0||i==11)?uiFont20.height:font.height)+2,bg);label(value,x,y,font,color);old[i]=value;oldColor[i]=color;}
 };
 if(mode==0){row(0,"Flugzeugansicht ausgeschaltet",12,72,uiFont20,white,456);return;}
 if(mode==1){row(0,flight.error[0]?"Datenquelle nicht erreichbar":flight.checked?"Kein Flugzeug im Umkreis":"Flugdaten werden geladen",12,72,uiFont20,white,456);row(1,"Flugzeuge und Hubschrauber · "+String(modern.radius)+" km",12,115,uiFont14,muted,456);return;}
 String call=flight.callsign[0]?flight.callsign:flight.hex;
 row(0,call,12,42,width(call,uiFont20)>174?uiFont14:uiFont20,white,174);
 row(1,flight.type[0]?flight.type:"Typ unbekannt",190,47,uiFont14,muted,170);
 row(2,modern.approaching?"Im Anflug":"Nächstes",365,47,uiFont14,0xFFE0,108);
 int kind=int(airframeCategory(flight.category));
 String pictureKey=String(kind);
 if(full||old[3]!=pictureKey){paint.fillRect(12,78,120,130,bg);
  if(airframeCategory(flight.category)==Airframe::Unknown){paint.drawCircle(70,137,30,muted);text("?",64,125,2);}
  else aircraftPicture(70,137,flight.rotorcraft);
  label(flight.rotorcraft?"Rotorflugzeug":airframeCategory(flight.category)==Airframe::FixedWing?"Flugzeug":"Typ unbekannt",12,191,uiFont11,muted);old[3]=pictureKey;
 }
 bool routeOk=clockReady()&&routeMatches(flightRoute,flight.callsign,flight.hex,time(nullptr));
 row(11,routeOk?String(flightRoute.origin)+" → "+flightRoute.destination:String("Route nicht verfügbar"),140,79,routeOk?uiFont20:uiFont14,routeOk?white:muted,196);
 row(12,routeOk?String("Katalog · nicht live bestätigt"):String("Start / Ziel nicht bestätigt"),140,110,uiFont11,muted,196);
 row(4,metric(flight.distance," km",1),140,144,uiFont20,cyan,196);
 row(5,bearing(flight.azimuth)+" vom Standort",140,177,uiFont14,white,196);
 const int cx=406,cy=148,rad=43;int px=cx,py=cy,ex=cx,ey=cy;bool point=isfinite(flight.azimuth)&&isfinite(flight.distance),arrow=point&&isfinite(flight.track);
 if(point){double a=flight.azimuth*DEG_TO_RAD,dist=constrain(flight.distance/modern.radius,0.0f,1.0f)*rad;px=cx+lround(sin(a)*dist);py=cy-lround(cos(a)*dist);}
 if(arrow){double t=flight.track*DEG_TO_RAD;ex=px+lround(sin(t)*10);ey=py-lround(cos(t)*10);}
 String compass=String(px)+":"+String(py)+":"+String(ex)+":"+String(ey)+":"+String(point)+String(arrow)+String(flightFresh());
 if(full||old[6]!=compass){paint.fillRect(342,78,130,133,bg);paint.drawCircle(cx,cy,rad,cyan);
  label("N",cx-5,cy-rad-15,uiFont11,white);label("O",cx+rad+4,cy-5,uiFont11,white);label("W",cx-rad-15,cy-5,uiFont11,white);label("S",cx-4,cy+rad+2,uiFont11,white);paint.fillCircle(cx,cy,3,white);
  if(point){uint16_t col=flightFresh()?cyan:0xf800;paint.fillCircle(px,py,3,col);if(arrow){double t=flight.track*DEG_TO_RAD;paint.drawLine(px,py,ex,ey,col);for(int side:{-1,1})paint.drawLine(ex,ey,ex-lround(sin(t+side*.55)*5),ey+lround(cos(t+side*.55)*5),col);}}old[6]=compass;
 }
 if(full){paint.drawFastHLine(8,216,464,cyan);const char*names[]={"Höhe barom.","Geschwindigkeit","Flugrichtung"};for(int i=0;i<3;i++)label(names[i],12+i*158,221,uiFont11,muted);}
 String vals[]={metric(flight.altitude," m"),metric(flight.speed," km/h"),metric(flight.track,"°")};
 for(int i=0;i<3;i++)row(7+i,vals[i],12+i*158,237,uiFont20,white,150);
 int age=clockReady()&&flight.positionAt>0?max(0,int(time(nullptr)-flight.positionAt)):-1;
 String ageText=age<0?String("Alter unbekannt"):age<60?String(age)+" s":String(age/60)+" min";
 row(10,String(flightFresh()?"Aktuell · ":"Veraltet · ")+ageText,12,263,uiFont11,flightFresh()?cyan:0xf800,456);
}
static void detailScreen(bool full){
 static String old[12];
 auto row=[&](int i,String value,int x,int y,const UiFont &font,uint16_t color,int w){if(full||old[i]!=value){paint.fillRect(x,y,w,font.height+2,bg);label(value,x,y,font,color);old[i]=value;}};
 double az=0,alt=0,mag=NAN;String name;
 if(selected>=3000&&selected<3004){auto&s=satellites[selected-3000];
  if(full){text(s.name,12,45,2);satelliteIcon(62,118,selected-3000);}
  bool fresh=satellitePositionCurrent(s,clockReady(),time(nullptr));
  row(0,"NORAD "+String(s.catalog),115,84,uiFont14,white,350);
  row(1,fresh?"Richtung "+bearing(s.az)+" · Höhe "+String(s.alt,1)+"°":"Bahndaten fehlen / veraltet",115,112,uiFont14,white,350);
  row(2,fresh?satelliteCountdown(s):String("Keine aktuelle Position"),115,141,uiFont14,muted,350);
  row(3,fresh?"Beginn "+eventStamp(s.rise):String("Überflug nicht verfügbar"),12,181,uiFont14,white,456);
  row(4,fresh?"Maximum "+String(s.maxAlt,0)+"° · "+bearing(s.startAz)+" → "+bearing(s.endAz):String(""),12,208,uiFont14,white,456);
  row(5,satelliteCandidateSeconds(s,clockReady(),time(nullptr))?"Sichtchance* · nur bei klarem Himmel":"Sichtbarkeit nicht bestätigt",12,240,uiFont14,0xFFE0,456);
  row(6,"*Keine Garantie · Bahndaten "+stamp(s.epoch,true),12,260,uiFont11,muted,456);return;}
 if(!objectCoordinates(selected,az,alt,name)){row(0,"Objektdaten nicht verfügbar",12,65,uiFont14,muted,456);return;}
 if(selected<objectCount){auto&o=objects[selected];mag=o.mag;
  if(full){if(o.kind==1)moonIcon(85,145,48);else{if(o.kind==6)for(int a=0;a<360;a++){double t=a*DEG_TO_RAD;paint.drawPixel(85+lround(70*cos(t)),145+lround(20*sin(t)),0xEED0);}sphere(85,145,45,o.kind);}}
 }else if(selected>=2000&&selected-2000<(int)(sizeof deepSky/sizeof deepSky[0]))mag=deepSky[selected-2000].mag;
 else if(selected>=100&&selected-100<(int)(sizeof stars/sizeof stars[0])){mag=stars[selected-100].mag;if(full)paint.fillCircle(85,145,8,white);}
 if(full)text(name,12,45,2);
 row(0,"Richtung "+bearing(az)+" / "+String(az,1)+"°",175,90,uiFont14,white,295);
 row(1,"Höhe "+String(alt,1)+"°",175,125,uiFont14,white,295);
 row(2,"Helligkeit "+metric(mag," mag",1),175,160,uiFont14,white,295);
 row(3,alt>=0?"Über dem Horizont":"Unter dem Horizont",175,198,uiFont14,alt>=0?cyan:muted,295);
 if(full){bool fav=false;for(int i=0;i<modern.favoriteCount;i++)fav|=modern.favorites[i]==selected;
 control(fav?"Favorit entfernen":"Als Favorit",175,230,285,38,700);}
}
static void keyboardDraw(){
 text(title.substring(0,36),8,42);String shown=input;if(purpose==2&&!showPassword){shown="";for(unsigned i=0;i<input.length();i++)shown+='*';}
 paint.drawRect(8,67,464,35,muted);text(shown.substring(shown.length()>46?shown.length()-46:0),12,76);
 for(int k=0;k<30;k++){String ch=keyLayout?symbols[k]:letters[k];if(shifted&&!keyLayout)ch.toUpperCase();control(ch,k%10*48+2,109+k/10*38,44,34,1000+k);}
 control(shifted?"abc":"ABC",2,226,70,36,1030);control(keyLayout?"abc":"123",76,226,70,36,1031);control("Leer",150,226,100,36,1032);control("DEL",254,226,80,36,1033);control(showPassword?"Verbergen":"Anzeigen",338,226,140,36,1034);
 control("Abbruch",8,280,228,36,1035);control("OK",244,280,228,36,1036,blue);
}
static void objectListScreen(){
 control(favoritesOnly?"Favoriten":objectQuery.length()?objectQuery:"Objekt suchen",8,40,340,34,600);
 control("<",356,40,54,34,601);control(">",416,40,56,34,602);
 objectMatches=0;for(int&v:objectChoices)v=-1;String q=objectQuery;q.toLowerCase();
 if(clockReady())for(int id=0;id<100+(int)(sizeof stars/sizeof stars[0]);id++){
  double az,alt;String name;if(!objectCoordinates(id,az,alt,name))continue;bool fav=false;for(int i=0;i<modern.favoriteCount;i++)fav|=modern.favorites[i]==id;
  String lower=name;lower.toLowerCase();if(favoritesOnly?!fav:q.length()?lower.indexOf(q)<0:(id<2||id>=100||alt<0))continue;
  int row=objectMatches++-objectOffset;if(row<0||row>=4)continue;objectChoices[row]=id;control(name+" · "+bearing(az)+" "+String(alt,0)+"°",8,82+row*46,464,40,610+row);}
 if(!objectMatches)text(clockReady()?"Keine passenden Objekte":"Warte auf Uhrzeit",12,120);
}
static void menuScreen(){
 if(page==1){text("Einstellungen",12,43,2);cell("WLAN",0,2);cell("Standorte",1,5);cell("Anzeige",2,6);cell("Satelliten",3,7);cell("Touch kalibrieren",4,50);cell("180° drehen",5,51);label("Safari: "+(WiFi.status()==WL_CONNECTED?WiFi.localIP():WiFi.softAPIP()).toString(),12,241,uiFont14,cyan);}
 else if(page==2){control("WLAN suchen",8,41,150,33,100);control("Gespeicherte",165,41,150,33,3);control("Manuell",322,41,150,33,101);for(int i=0;i<6;i++){int k=networkPage*6+i;if(k<nearbyCount)cell(nearby[k],i,110+i);}control("<",8,226,80,34,102);control(">",392,226,80,34,103);label(message.substring(0,38),96,237,uiFont11,muted);}
 else if(page==3){text("Gespeicherte WLANs",12,43,2);for(int i=0;i<cfg.wifiCount;i++)cell(cfg.wifi[i].ssid,i,130+i);label("AP-Passwort: "+apPassword,12,242,uiFont14,muted);}
 else if(page==4){text(cfg.wifi[profile].ssid,12,43,2);cell("Verbinden",0,140);cell("Passwort ändern",1,141);cell("WLAN löschen",2,142);}
 else if(page==5){text("Standorte · wählen / bearbeiten",12,43,2);for(int i=0;i<cfg.placeCount;i++){int x=8+(i%2)*236,y=74+(i/2)*48;control(cfg.places[i].name,x,y,184,42,200+i,i==cfg.place?blue:0x2104);control("…",x+188,y,40,42,210+i);}control("Neuer Standort",8,230,464,38,220);}
 else if(page==9){text(cfg.places[editPlace].name,12,43,2);cell("Bearbeiten",0,221);cell("Löschen",1,222);}
 else if(page==6){text("Anzeige",12,43,2);cell("Helligkeit −",0,300);cell("Helligkeit +",1,301);cell(String("Namen: ")+(cfg.labels?"Ein":"Aus"),2,302);cell(String("Linien: ")+(cfg.lines?"Ein":"Aus"),3,303);cell(String("Milchstraße: ")+(cfg.milky?"Ein":"Aus"),4,304);cell(String("Satelliten: ")+(cfg.satellites?"Ein":"Aus"),5,305);control("Auto: "+String(cfg.autoSeconds)+" s",8,226,228,40,306);control(displayNight?"Nacht: Ein":"Nacht: Aus",244,226,228,40,307);}
 else if(page==7){text("Satelliten",12,43,2);for(int i=0;i<4;i++)cell(i==3?"Starlink":satellites[i].name,i,400+i);cell(satPaused?"API fortsetzen":"API aktiv",4,404);cell("Gesamtkarte",5,405);}
}
void uiDraw(){
 struct Timer{uint32_t at=micros();~Timer(){renderMaxUs=max(renderMaxUs,micros()-at);}} timer;
 static String lastKey;static int lastPage=-1,lastView=-1,lastSelected=-1;static bool lastNight=false;static uint32_t lastSurface=0;static time_t lastMinute=-1;
 String key=String(page)+":"+String(selected)+":"+String(surfaceRevision)+":"+String(cfg.brightness)+String(cfg.labels)+String(cfg.lines)+String(cfg.milky)+String(cfg.satellites)+String(displayNight)+String(cfg.place)+String(cfg.autoSeconds)+String(modern.favoriteCount);
 if(page==2)key+=message+String(nearbyCount);
 bool full=page!=lastPage||cfg.view!=lastView||selected!=lastSelected||lastNight!=displayNight||lastSurface!=surfaceRevision;
 bool changed=key!=lastKey;bool clockChanged=lastMinute!=time(nullptr)/60;
 if(page>0&&page!=8&&!changed){if(clockChanged){lcd.startWrite();header();lcd.endWrite();lastMinute=time(nullptr)/60;}return;}
 lastKey=key;lastPage=page;lastView=cfg.view;lastSelected=selected;lastNight=displayNight;lastSurface=surfaceRevision;
 lcd.startWrite();
 bool rebuild=full||(page>0&&page!=8&&changed);
 if(rebuild){buttonCount=0;paint.fillScreen(bg);}if(rebuild||clockChanged)header();lastMinute=time(nullptr)/60;
 if(page==0){if(cfg.view==1)skyScreen(full);else flightScreen(full);if(rebuild)nav();}
 else if(page==10)keyboardDraw();
 else {if(page==8)detailScreen(full);else if(page==12)objectListScreen();else menuScreen();if(rebuild)control("ZURÜCK",8,280,464,36,0);}
 lcd.endWrite();
}
struct QueuedTouch{int event,x,y,page,view;};static QueuedTouch queue[8];static uint8_t qr=0,qw=0;
void uiPollTouch(){static TouchGesture g;static int beganPage=0,beganView=1;int32_t x=0,y=0;bool down=lcd.getTouch(&x,&y);if(touchSleepGate(down)){g=TouchGesture();qr=qw;return;}
 int ep=beganPage,ev=beganView;uint32_t seq=g.sequence;int event=g.update(down,x,y,millis(),beganPage==0&&g.sy>=40&&g.sy<258);if(seq!=g.sequence){beganPage=page;beganView=cfg.view;}
 if(!event)return;uint8_t next=(qw+1)%8;if(next==qr)return;queue[qw]={event,g.eventX,g.eventY,ep,ev};qw=next;
}
static void action(int a){
 if(a==0){page=(page==1||page==8||page==12)?0:1;selected=-1;return;}
 if(a>=2&&a<=7){page=a;if(a==2)scanStart();return;}
 if(a==50){calibrate();return;}if(a==51){cfg.rotation=cfg.rotation==1?3:1;lcd.setRotation(cfg.rotation);saveSettings();return;}
 if(a==100){scanStart();return;}if(a==101){keyboard("WLAN-Name (SSID)","",1);return;}if(a==102){networkPage=max(0,networkPage-1);return;}if(a==103){networkPage=min(3,networkPage+1);return;}
 if(a>=110&&a<116){int i=networkPage*6+a-110;if(i<nearbyCount){wifiName=nearby[i];keyboard("Passwort: "+wifiName,"",2);}return;}
 if(a>=130&&a<136){profile=a-130;page=4;return;}if(a==140){connectProfile(profile);page=2;return;}if(a==141){wifiName=cfg.wifi[profile].ssid;keyboard("Neues Passwort","",2);return;}if(a==142){deleteWifi(profile);page=3;return;}
 if(a>=200&&a<206){cfg.place=a-200;saveSettings();applyPlace();return;}if(a>=210&&a<216){editPlace=a-210;page=9;return;}
 if(a==220){editPlace=-1;draft=cfg.places[cfg.place];keyboard("Standortname","",4);return;}if(a==221){draft=cfg.places[editPlace];keyboard("Standortname",draft.name,4);return;}
 if(a==222&&cfg.placeCount>1){for(int i=editPlace;i<cfg.placeCount-1;i++)cfg.places[i]=cfg.places[i+1];cfg.placeCount--;cfg.place=0;saveSettings();applyPlace();page=5;return;}
 if(a>=300&&a<=307){if(a<=301){cfg.brightness=constrain(cfg.brightness+(a==300?-20:20),20,255);uiDisplayBrightness();}if(a==302)cfg.labels=!cfg.labels;if(a==303)cfg.lines=!cfg.lines;if(a==304)cfg.milky=!cfg.milky;if(a==305)cfg.satellites=!cfg.satellites;if(a==306)cfg.autoSeconds=cfg.autoSeconds==0?15:cfg.autoSeconds==15?30:cfg.autoSeconds==30?60:0;if(a==307)setDisplayNight(!displayNight);saveSettings();return;}
 if(a>=400&&a<=403){selected=3000+a-400;page=8;return;}if(a==404){resumeSatellites();return;}if(a==405){skyCamera.set(1,0,0);setView(1);return;}
 if(a==600){favoritesOnly=false;keyboard("Objekt suchen",objectQuery,19);return;}if(a==601||a==602){objectOffset=max(0,objectOffset+(a==601?-4:4));if(objectOffset>=objectMatches)objectOffset=0;return;}
 if(a>=610&&a<614){selected=objectChoices[a-610];if(selected>=0){highlightedObject=selected;page=8;}return;}
 if(a==700){ModernSettings m=modern;int found=-1;for(int i=0;i<m.favoriteCount;i++)if(m.favorites[i]==selected)found=i;if(found>=0){for(int i=found;i<m.favoriteCount-1;i++)m.favorites[i]=m.favorites[i+1];m.favoriteCount--;}else if(m.favoriteCount<16)m.favorites[m.favoriteCount++]=selected;JsonDocument d;d["action"]="modern";modernJson(d["modern"].to<JsonObject>(),m);String error;modernCommand(d,error);return;}
 if(a>=1000&&a<1030&&input.length()<79){String c=keyLayout?symbols[a-1000]:letters[a-1000];if(shifted&&!keyLayout)c.toUpperCase();input+=c;return;}
 if(a==1030)shifted=!shifted;if(a==1031)keyLayout=!keyLayout;if(a==1032&&input.length()<79)input+=' ';if(a==1033&&input.length()){int n=input.length()-1;while(n>0&&((uint8_t)input[n]&0xc0)==0x80)n--;input.remove(n);}if(a==1034)showPassword=!showPassword;if(a==1035){input="";showPassword=false;page=1;}if(a==1036)submit();
}
void uiTick(){
 if(mapDeferred&&!networkOwnsMemory&&page==0&&cfg.view==1&&(int32_t)(millis()-mapRetryAt)>=0){mapRetryAt=millis()+1000;dirty=true;}
 uiPollTouch();if(qr==qw)return;auto t=queue[qr];qr=(qr+1)%8;if(t.page!=page||t.view!=cfg.view)return;manualInteraction();dirty=true;
 if(t.event==2&&page==0){setView(modern.aircraft&&cfg.view==1?2:1);return;}
 int x=t.x,y=t.y;
 if(y<40&&x>=425){page=1;surfaceRevision++;return;}
 if(page==0){if(y>=280){setView(x<240?1:2);return;}if(cfg.view!=1)return;
  if(!extra.largeMap&&y>=258){selected=3000+constrain(x/120,0,3);page=8;return;}
  if(x>=420&&y>=65&&y<203){if(y<107)skyCamera.set(min(4.0f,skyCamera.zoom+.5f),skyCamera.panX,skyCamera.panY);else if(y<155)skyCamera.set(max(1.0f,skyCamera.zoom-.5f),skyCamera.panX,skyCamera.panY);else skyCamera.set(1,0,0);return;}
  if(x<118&&y>=75&&y<155){favoritesOnly=y>=119;objectOffset=0;objectQuery="";page=12;return;}
  int hit=skyHitTarget(x,y);if(hit>=0){selected=hit;page=8;}return;
 }
 for(int i=0;i<buttonCount;i++){auto b=buttons[i];if(x>=b.x&&x<b.x+b.w&&y>=b.y&&y<b.y+b.h){action(b.action);surfaceRevision++;return;}}
}
