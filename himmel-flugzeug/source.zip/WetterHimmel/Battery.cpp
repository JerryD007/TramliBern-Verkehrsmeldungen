#include <Arduino.h>
#include "Battery.h"
BatteryReading battery;
static uint32_t sampleAt=0,total=0;static uint8_t samples=0;
void batteryBegin(){
 analogReadResolution(12);analogSetPinAttenuation(34,ADC_11db);
 // Initialize ADC/calibration before network TLS can consume temporary RAM.
 (void)analogReadMilliVolts(34);
}
void batteryTick(){
 uint32_t now=millis();if(int32_t(now-sampleAt)<0)return;
 uint32_t mv=analogReadMilliVolts(34);
 if(!mv){total=0;samples=0;battery.update(0);sampleAt=now+5000;return;}
 total+=mv;sampleAt=now+125;
 if(++samples==8){battery.update((total+2)/4);total=0;samples=0;sampleAt=now+5000;}
}
