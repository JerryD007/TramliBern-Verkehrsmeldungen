#pragma once
#include <stddef.h>
// Bounded JSON-array framer. Full object syntax is validated by ArduinoJson.
struct JsonObjectStream {
 char object[4097]{};size_t used=0;int depth=0;bool started=false,ended=false,quoted=false,escaped=false,needValue=true,hadValue=false;
 // -1 malformed/overflow, 0 pending, 1 complete object, 2 complete array.
 int feed(char c){
  if(ended)return (c==' '||c=='\r'||c=='\n'||c=='\t')?0:-1;
  if(!started){if(c==' '||c=='\r'||c=='\n'||c=='\t')return 0;if(c!='[')return -1;started=true;return 0;}
  if(!depth){
   if(c==' '||c=='\r'||c=='\n'||c=='\t')return 0;
   if(c==']'){if(needValue&&hadValue)return -1;ended=true;return 2;}
   if(c==','){if(needValue)return -1;needValue=true;return 0;}
   if(c!='{'||!needValue)return -1;depth=1;used=0;quoted=escaped=false;object[used++]=c;return 0;
  }
  if(used>=4096)return -1;object[used++]=c;
  if(quoted){if(escaped)escaped=false;else if(c=='\\')escaped=true;else if(c=='"')quoted=false;}
  else if(c=='"')quoted=true;else if(c=='{')depth++;else if(c=='}')depth--;
  if(!depth){object[used]=0;needValue=false;hadValue=true;return 1;}return 0;
 }
};
