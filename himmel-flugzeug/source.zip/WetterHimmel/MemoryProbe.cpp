#include "MemoryProbe.h"
#include <esp_heap_caps.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
// One weather worker. The failure callback can also run on the other core.
// No logging, heap calls, String creation, or blocking operation in the hook.
static portMUX_TYPE probeMux=portMUX_INITIALIZER_UNLOCKED;
static TaskHandle_t owner=nullptr;
static MemoryProbeResult result;
static bool registered=false;
static uint8_t phase=0;
static uint32_t totalFailures=0;
static MemoryFailureEvent history[4];static unsigned historyHead=0,historyCount=0;
static void allocationFailed(size_t bytes,uint32_t caps,const char *name) {
  TaskHandle_t current=xTaskGetCurrentTaskHandle();
  const char *task=pcTaskGetName(current);
  const uint32_t uptime=(uint32_t)xTaskGetTickCount()*portTICK_PERIOD_MS;
  portENTER_CRITICAL_SAFE(&probeMux);
  auto &event=history[historyHead];event={};event.uptimeMs=uptime;event.bytes=bytes;event.caps=caps;event.phase=owner?phase:0;event.worker=owner&&current==owner;
  unsigned i=0;if(task)for(;i+1<sizeof event.task&&task[i];++i)event.task[i]=task[i];
  i=0;if(name)for(;i+1<sizeof event.allocator&&name[i];++i)event.allocator[i]=name[i];
  historyHead=(historyHead+1)%4;if(historyCount<4)++historyCount;
  if(totalFailures!=UINT32_MAX)++totalFailures;
  if(owner) {
    auto &f=current==owner?result.worker:result.other;
    if(f.count==0) {
      f.bytes=bytes;f.caps=caps;f.phase=phase;
      unsigned i=0;
      if(name)for(;i+1<sizeof f.allocator && name[i];i++)f.allocator[i]=name[i];
      f.allocator[i]=0;
    }
    if(f.count!=UINT32_MAX)++f.count;
  }
  portEXIT_CRITICAL_SAFE(&probeMux);
}
void memoryProbeInit(){registered=heap_caps_register_failed_alloc_callback(allocationFailed)==ESP_OK;}
void memoryProbeBegin(){
  portENTER_CRITICAL_SAFE(&probeMux);
  result={};result.registered=registered;phase=1;owner=xTaskGetCurrentTaskHandle();
  portEXIT_CRITICAL_SAFE(&probeMux);
}
void memoryProbePhase(uint8_t value){
  portENTER_CRITICAL_SAFE(&probeMux);phase=value;portEXIT_CRITICAL_SAFE(&probeMux);
}
MemoryProbeResult memoryProbeEnd(){
  portENTER_CRITICAL_SAFE(&probeMux);
  owner=nullptr;auto copy=result;
  portEXIT_CRITICAL_SAFE(&probeMux);
  return copy;
}

uint32_t memoryFailureTotal(){portENTER_CRITICAL_SAFE(&probeMux);auto n=totalFailures;portEXIT_CRITICAL_SAFE(&probeMux);return n;}

unsigned memoryFailureHistory(MemoryFailureEvent *out,unsigned capacity){
 portENTER_CRITICAL_SAFE(&probeMux);
 unsigned n=historyCount<capacity?historyCount:capacity;
 for(unsigned i=0;i<n;++i)out[i]=history[(historyHead+4-n+i)%4];
 portEXIT_CRITICAL_SAFE(&probeMux);return n;
}
