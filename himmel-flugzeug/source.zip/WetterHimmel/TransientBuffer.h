#pragma once
#include <memory>
#include <new>
#include <cstddef>
// Owned only for the lexical scope of a scan. All exits release the workspace.
template<class T, std::size_t N> class TransientBuffer {
 std::unique_ptr<T[]> data;
public:
 TransientBuffer():data(new(std::nothrow) T[N]){}
 explicit operator bool()const{return bool(data);}
 T* get(){return data.get();}
};
