#pragma once
#include "HangarModel.h"
namespace Hangar {
// Disposable first-page index. Authoritative individual records remain unchanged.
struct Home {
 uint32_t magic=0x48484331,size=0,total=0;Record rows[12];uint32_t crc=0;
 uint32_t checksum()const{uint32_t c=0xffffffff;auto p=(const uint8_t*)this;for(size_t i=0;i<offsetof(Home,crc);++i){c^=p[i];for(int b=0;b<8;++b)c=(c>>1)^((0-(c&1))&0xedb88320);}return ~c;}
 bool valid()const{if(magic!=0x48484331||size>12||size>total||size!=(total<12?total:12)||crc!=checksum())return false;for(unsigned i=0;i<size;++i){if(!Hangar::valid(rows[i])||(i&&!before(rows[i-1],rows[i],false)))return false;}return true;}
 void observe(const Record&r,bool created){
  if(created)++total;
  for(unsigned i=0;i<size;++i)if(!strcmp(rows[i].hex,r.hex)){for(unsigned j=i+1;j<size;++j)rows[j-1]=rows[j];--size;break;}
  unsigned at=0;while(at<size&&!before(r,rows[at],false))++at;
  if(at<12){unsigned end=size<12?size:11;for(unsigned j=end;j>at;--j)rows[j]=rows[j-1];rows[at]=r;if(size<12)++size;}
 }
};
}
