#pragma once
#include <cstring>
// ADS-B emitter category describes a class, not an exact aircraft model.
enum class Airframe { Unknown, FixedWing, Rotorcraft };
inline Airframe airframeCategory(const char *category) {
 if(!category||std::strlen(category)!=2||category[0]!='A')return Airframe::Unknown;
 if(category[1]=='7')return Airframe::Rotorcraft;
 if(category[1]>='1'&&category[1]<='6')return Airframe::FixedWing;
 return Airframe::Unknown;
}
