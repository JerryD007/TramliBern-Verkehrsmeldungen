#pragma once
#include <cstdint>
#include <cstring>
#include <cstdio>
// Four bounded identity cooldowns; no allocation or disk access.
// A failed flight must not impose its five-minute cooldown on another flight.
class RouteSchedule {
 struct Entry {char call[17]={},hex[9]={};uint32_t due=0;bool used=false;};
 Entry entries[4];unsigned cursor=0;int active=-1;
 uint32_t lastStart=0;bool started=false;
 static bool reached(uint32_t now,uint32_t due){return int32_t(now-due)>=0;}
 int find(const char*call,const char*hex)const{for(int i=0;i<4;i++)if(entries[i].used&&!strcmp(entries[i].call,call)&&!strcmp(entries[i].hex,hex))return i;return -1;}
 public:
 bool gapReady(uint32_t now)const{return !started||uint32_t(now-lastStart)>=30000;}
 bool ready(const char*call,const char*hex,uint32_t now)const{int i=find(call,hex);return active<0&&gapReady(now)&&(i<0||reached(now,entries[i].due));}
 // Call only after the job was actually accepted by the worker queue.
 void begin(const char*call,const char*hex,uint32_t now){int i=find(call,hex);if(i<0)i=cursor++%4;auto&e=entries[i];snprintf(e.call,sizeof e.call,"%s",call);snprintf(e.hex,sizeof e.hex,"%s",hex);e.used=true;e.due=now+120000;active=i;lastStart=now;started=true;}
 void finish(bool ok,uint32_t now,bool limited=false){if(active>=0)entries[active].due=now+(limited?0:ok?120000:300000);active=-1;}
};
