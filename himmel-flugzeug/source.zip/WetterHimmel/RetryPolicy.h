#pragma once
#include <stdint.h>
// Shared, host-tested policy. Negative values are transport errors, not HTTP.
inline bool pauseForHttp(int status) { return status > 0 && status != 200; }
inline uint32_t satelliteDelay(bool failed, uint32_t retryAfter) {
  if(!failed) return 21600;
  return retryAfter>7200?retryAfter:7200;
}

#pragma once
#include <stdint.h>
namespace RetryPolicy {
// 0 is a valid server value; callers wait at least one second.
inline bool delta(const char *s,uint32_t &out){
 if(!s||!*s)return false;uint64_t n=0;
 for(;*s;++s){if(*s<'0'||*s>'9')return false;n=n*10+unsigned(*s-'0');if(n>UINT32_MAX)n=UINT32_MAX;}
 out=n?uint32_t(n):1;return true;
}
inline uint32_t wait(uint32_t server,unsigned consecutive){
 if(server)return server;unsigned shift=consecutive>6?6:consecutive;
 uint32_t n=60U<<shift;return n>3600?3600:n;
}
}
