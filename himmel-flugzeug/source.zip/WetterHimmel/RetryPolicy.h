#pragma once
#include <stdint.h>
// Shared, host-tested policy. Negative values are transport errors, not HTTP.
inline bool pauseForHttp(int status) { return status > 0 && status != 200; }
inline uint32_t satelliteDelay(bool failed, uint32_t retryAfter) {
  if(!failed) return 21600;
  return retryAfter>7200?retryAfter:7200;
}
