#pragma once
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <errno.h>
// OmmElements/initOmm are supplied by App.h (or the host test).
// Bounded CSV parser: one 1024-byte record, at most 40 columns. No whole-file allocation.
struct StarlinkCsv {
 int64_t epochMs=0;char line[1025]{};size_t used=0;int columns=0,map[12]{};bool header=false,failed=false;
 static int split(char *s,char **fields){
  char *read=s,*write=s;int n=0;
  for(;;){
   if(n>=40)return -1;fields[n++]=write;
   if(*read=='"'){
    ++read;bool closed=false;
    while(*read){if(*read=='"'){++read;if(*read=='"'){*write++=*read++;continue;}closed=true;break;}*write++=*read++;}
    if(!closed||(*read&&*read!=','))return -1;
   }else{while(*read&&*read!=','){if(*read=='"')return -1;*write++=*read++;}}
   bool more=*read==',';if(more)++read;*write++=0;if(!more)return n;
  }
 }
 static bool real(const char *s,double &v){if(!*s)return false;char *end;errno=0;v=strtod(s,&end);return end!=s&&!*end&&errno!=ERANGE&&isfinite(v);}
 // 1 valid record, 0 header/blank/invalid orbital row, -1 malformed CSV/schema.
 int row(uint32_t &id,char *name,size_t nameSize,OmmElements &o){
  if(used&&line[used-1]=='\r')--used;line[used]=0;
  if(!used)return 0;
  char *start=line;
  if(!header&&used>=3&&(uint8_t)start[0]==0xef&&(uint8_t)start[1]==0xbb&&(uint8_t)start[2]==0xbf)start+=3;
  char *f[40];int n=split(start,f);if(n<0)return -1;
  if(!header){
   const char *keys[]={"OBJECT_NAME","NORAD_CAT_ID","EPOCH","MEAN_MOTION","ECCENTRICITY","INCLINATION","RA_OF_ASC_NODE","ARG_OF_PERICENTER","MEAN_ANOMALY","BSTAR","MEAN_MOTION_DOT","MEAN_MOTION_DDOT"};
   for(int k=0;k<12;k++){map[k]=-1;for(int j=0;j<n;j++)if(!strcmp(f[j],keys[k])){if(map[k]>=0)return -1;map[k]=j;}if(map[k]<0)return -1;}
   columns=n;header=true;return 0;
  }
  if(n!=columns)return -1;
  const char *label=f[map[0]],*cat=f[map[1]],*epoch=f[map[2]];
  if(strncmp(label,"STARLINK",8)||!*cat)return 0;
  uint64_t number=0;for(const char *p=cat;*p;p++){if(*p<'0'||*p>'9')return 0;number=number*10+(*p-'0');if(number>999999999)return 0;}if(!number)return 0;
  o={};int consumed=0;
  if(sscanf(epoch,"%d-%d-%dT%d:%d:%lf%n",&o.year,&o.month,&o.day,&o.hour,&o.minute,&o.second,&consumed)!=6)return 0;
  if(epoch[consumed]&&strcmp(epoch+consumed,"Z"))return 0;
  if(o.year<2000||o.year>2099||o.month<1||o.month>12||o.hour<0||o.hour>23||o.minute<0||o.minute>59||!isfinite(o.second)||o.second<0||o.second>=60)return 0;
  const int days[]={31,28,31,30,31,30,31,31,30,31,30,31};int limit=days[o.month-1]+(o.month==2&&o.year%4==0&&(o.year%100!=0||o.year%400==0));if(o.day<1||o.day>limit)return 0;
  double *values[]={&o.meanMotion,&o.eccentricity,&o.inclination,&o.raan,&o.argPerigee,&o.meanAnomaly,&o.bstar,&o.ndot,&o.nddot};
  for(int k=0;k<9;k++)if(!real(f[map[k+3]],*values[k]))return 0;
  if(o.meanMotion<=0||o.meanMotion>20||o.eccentricity<0||o.eccentricity>=1||o.inclination<0||o.inclination>180)return 0;
  TLE tle{};if(!initOmm(&tle,&o))return 0;
  epochMs=tle.epoch;id=(uint32_t)number;snprintf(name,nameSize,"%s",label);return 1;
 }
 // 2 skipped orbital row, 1 valid record, 0 pending/header/blank, -1 structural failure.
 int finish(uint32_t &id,char *name,size_t size,OmmElements &o){
  if(failed)return -1;bool wasHeader=header,nonempty=used>0&&!(used==1&&line[0]=='\r');int r=row(id,name,size,o);used=0;
  if(r<0)failed=true;return r==0&&wasHeader&&nonempty?2:r;
 }
 int feed(char ch,uint32_t &id,char *name,size_t size,OmmElements &o){
  if(failed)return -1;if(ch=='\n')return finish(id,name,size,o);
  if(!ch||used>=1024){failed=true;return -1;}line[used++]=ch;return 0;
 }
};
