#pragma once
#include <math.h>
struct StarlinkSelection {
  double highest=-90;
  bool consider(double altitude) {
    if(!isfinite(altitude)||altitude<0||altitude<=highest)return false;
    highest=altitude;return true;
  }
};
