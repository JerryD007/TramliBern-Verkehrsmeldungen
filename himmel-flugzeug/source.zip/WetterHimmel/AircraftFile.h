#pragma once
#include <ArduinoJson.h>
#include <cstdlib>
#include <cstddef>
#include <cstring>
// Per-document hard allocation ceiling, including strings and ArduinoJson pools.
class AircraftAllocator : public ArduinoJson::Allocator {
  union Header { size_t size; max_align_t alignment; };
  size_t used=0;
public:
  void *allocate(size_t n) override {
    if(n>8192-used)return nullptr;
    auto h=(Header*)malloc(sizeof(Header)+n);if(!h)return nullptr;
    h->size=n;used+=n;return h+1;
  }
  void deallocate(void *p) override {if(p){auto h=(Header*)p-1;used-=h->size;free(h);}}
  void *reallocate(void *p,size_t n) override {
    if(!p)return allocate(n);
    auto h=(Header*)p-1;size_t old=h->size;
    if(n>8192-(used-old))return nullptr;
    auto next=(Header*)realloc(h,sizeof(Header)+n);if(!next)return nullptr;
    used=used-old+n;next->size=n;return next+1;
  }
};
inline void aircraftFilter(JsonDocument &filter){
 filter["now"]=true;filter["msg"]=true;
 for(const char*k:{"lat","lon","seen_pos","alt_baro","gs","track","flight","hex","t","category","desc","r"})filter["ac"][0][k]=true;
}
// File parsing is bounded in RAM and cooperative on ESP32, including the first
// metadata pass and skipped unknown fields. No dependency on SD read batching.
template<class F> class AircraftInput {
 F &source;unsigned quantum=0;
public:
 explicit AircraftInput(F &f):source(f){}
 int read(){int c=source.read();if(c>=0&&++quantum==1024){quantum=0;
#if defined(ARDUINO_ARCH_ESP32)
   vTaskDelay(1);
#endif
 }return c;}
 size_t readBytes(char *b,size_t n){size_t i=0;for(;i<n;i++){int c=read();if(c<0)break;b[i]=(char)c;}return i;}
 bool seek(size_t p){return source.seek(p);}
 size_t position(){return source.position();}
};
template<class F> static int aircraftNonspace(F &f){int c;do{c=f.read();}while(c==' '||c=='\r'||c=='\n'||c=='\t');return c;}
// First pass verifies complete JSON and source time, irrespective of property order.
// Second pass retains at most one aircraft. Output is published only after EOF validation.
template<class F> bool readAircraftFile(F &source,Flight &out,const Place &place,int radius,bool approaching,time_t now,const char *&error,bool (*visitor)(JsonVariantConst,const Flight&,void*)=nullptr,void *context=nullptr){
 AircraftInput<F> file(source);
 error=nullptr;
 auto fail=[&](const char *why){error=why;return false;};
 AircraftAllocator metadataMemory,objectMemory;
 JsonDocument meta(&metadataMemory),one(&objectMemory),filter;
 filter["now"]=true;filter["msg"]=true;
 if(!file.seek(0))return fail("SD: Seek fehlgeschlagen");
 auto parsed=deserializeJson(meta,file,DeserializationOption::Filter(filter));
 if(parsed)return fail(parsed==DeserializationError::NoMemory?"Flug-JSON: Metadaten ueber Speicherlimit":"Flug-JSON: unvollstaendig / ungueltig");
 if(aircraftNonspace(file)!=-1)return fail("Flug-JSON: Daten nach Dokumentende");
 meta["ac"].to<JsonArray>();Flight selected;
 if(!parseFlight(meta,selected,place,radius,approaching,now))return fail("Flugquelle: Zeit / Format ungueltig");
 if(!file.seek(0)||aircraftNonspace(file)!='{')return fail("Flug-JSON: Objekt fehlt");
 bool foundArray=false;
 filter.clear();aircraftFilter(filter);
 for(;;){
   parsed=deserializeJson(one,file);
   if(parsed||!one.is<const char*>())return fail("Flug-JSON: Schluessel ungueltig");
   bool aircraft=!strcmp(one.as<const char*>(),"ac");
   if(aircraftNonspace(file)!=':')return fail("Flug-JSON: Doppelpunkt fehlt");
   if(aircraft){
     if(foundArray||aircraftNonspace(file)!='[')return fail("Flug-JSON: ac fehlt / doppelt");
     foundArray=true;
     int c=aircraftNonspace(file);
     if(c!=']'){
       for(;;){
         if(c!='{'||!file.seek(file.position()-1))return fail("Flug-JSON: Flugobjekt erwartet");
         parsed=deserializeJson(one,file,DeserializationOption::Filter(filter["ac"][0].as<JsonVariantConst>()));
         if(parsed)return fail(parsed==DeserializationError::NoMemory?"Flug-JSON: Flugobjekt ueber Speicherlimit":"Flug-JSON: Flugobjekt ungueltig");
         meta["ac"].to<JsonArray>().add(one.as<JsonVariantConst>());
         if(meta.overflowed())return fail("Flug-JSON: Auswahlspeicher voll");
         Flight candidate;
         if(!parseFlight(meta,candidate,place,radius,false,now))return fail("Flugquelle: Zeit ungueltig");
         if(visitor&&candidate.found&&!visitor(one.as<JsonVariantConst>(),candidate,context))return fail("Hangar: Verarbeitung unterbrochen");
         if(candidate.found&&(!approaching||candidate.approaching)&&(!selected.found||candidate.distance<selected.distance))selected=candidate;
         c=aircraftNonspace(file);if(c==']')break;
         if(c!=',')return fail("Flug-JSON: Trenner fehlt");
         c=aircraftNonspace(file);
       }
     }
   }else{
     // All unknown root values are syntax-checked without retaining their content.
     int c=aircraftNonspace(file);bool quoted=c=='"',escape=false;
     unsigned depth=(c=='{'||c=='[')?1:0;
     if(c<0)return fail("Flug-JSON: Zusatzfeld fehlt");
     if(!quoted&&!depth){
       // A scalar number parser may read one byte ahead. Preserve the delimiter.
       while(c!=','&&c!='}'&&c>=0)c=file.read();
       if(c<0||!file.seek(file.position()-1))return fail("Flug-JSON: Skalarende fehlt");
     }else{
       for(;;){c=file.read();if(c<0)return fail("Flug-JSON: Zusatzfeld unvollstaendig");
         if(quoted){if(escape)escape=false;else if(c=='\\')escape=true;else if(c=='"'){quoted=false;if(!depth)break;}}
         else if(c=='"')quoted=true;
         else if(c=='{'||c=='[')++depth;
         else if(c=='}'||c==']'){if(--depth==0)break;}
       }
     }
   }
   int c=aircraftNonspace(file);if(c=='}')break;
   if(c!=',')return fail("Flug-JSON: Wurzeltrenner fehlt");
 }
 if(!foundArray||aircraftNonspace(file)!=-1)return fail("Flug-JSON: ac fehlt / Restdaten");
 out=selected;return true;
}
