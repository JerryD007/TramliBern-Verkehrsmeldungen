#include "App.h"
#include "RunTrace.h"
#include <esp_attr.h>
#include <esp_system.h>
#include <string.h>
static RTC_NOINIT_ATTR RunPoint retained[2][2];
struct SavedRun {uint32_t magic,reason;RunPoint main,worker;};
static SavedRun lastCrash{};static uint32_t phaseNow=0,lastBusyPhase=0,lastTouch=0,maxGap=0,gapPhase=0,gapAt=0,phaseAt=0,longestPhase=0,longestPhaseMs=0;
static const char *phaseName(uint32_t p){switch(p){case 1:return "setup";case 2:return "touch";case 3:return "web";case 4:return "extras";case 5:return "modern";case 6:return "network-main";case 7:return "starlink-main";case 8:return "satellite-main";case 9:return "passes";case 10:return "sky-update";case 11:return "render";case 12:return "idle";case 20:return "worker-idle";case 21:return "hangar-work";case 22:return "starlink-work";case 23:return "network-job";default:return "unknown";}}
void runBegin(){
 uint32_t reason=(uint32_t)esp_reset_reason();Preferences log;if(log.begin("hf-crash",false)){
  if(log.getBytesLength("last")==sizeof lastCrash)log.getBytes("last",&lastCrash,sizeof lastCrash);
  if(reason>=4&&reason<=7){int a=runNewest(retained[0]),b=runNewest(retained[1]);if(a>=0||b>=0){lastCrash={0x48333043u,reason,{}, {}};if(a>=0)lastCrash.main=retained[0][a];if(b>=0)lastCrash.worker=retained[1][b];log.putBytes("last",&lastCrash,sizeof lastCrash);}}
  log.end();
 }
 memset(retained,0,sizeof retained);runPhase(1);
}
void runPhase(uint32_t p,uint32_t aux){uint32_t now=millis();if(phaseNow&&now-phaseAt>longestPhaseMs){longestPhaseMs=now-phaseAt;longestPhase=phaseNow;}phaseAt=now;if(p!=2)lastBusyPhase=p;phaseNow=p;runStore(retained[0],p,now,aux);}
void runWorker(uint32_t p,uint32_t aux){runStore(retained[1],p,millis(),aux);}
void runTouch(uint32_t now){if(lastTouch&&now-lastTouch>maxGap){maxGap=now-lastTouch;gapPhase=phaseNow==2?lastBusyPhase:phaseNow;gapAt=now;}lastTouch=now;}
static void pointJson(JsonObject d,const RunPoint&r){bool valid=runValid(r);d["valid"]=valid;if(valid){d["phase"]=phaseName(r.phase);d["uptimeMs"]=r.at;d["detail"]=r.aux;}}
void runTraceJson(JsonObject d){d["format"]=1;d["longestPhase"]=phaseName(longestPhase);d["longestPhaseMs"]=longestPhaseMs;d["touchGapMs"]=maxGap;d["touchGapPhase"]=phaseName(gapPhase);d["touchGapAtMs"]=gapAt;
 bool valid=lastCrash.magic==0x48333043u;d["previousCrashAvailable"]=valid;
 d["scope"]="Last completed phase marker; not a stack trace or proof of cause. RTC capture requires warm reset.";
 if(valid){d["previousResetReason"]=lastCrash.reason;pointJson(d["main"].to<JsonObject>(),lastCrash.main);pointJson(d["worker"].to<JsonObject>(),lastCrash.worker);}}
