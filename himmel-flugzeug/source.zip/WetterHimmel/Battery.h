#pragma once
#include <stdint.h>
// E32R40T: BAT_ADC GPIO34, equal onboard divider resistors (x2).
// Bands indicate voltage only, not measured capacity or charging state.
struct BatteryReading {
 uint16_t millivolts=0; uint8_t band=0; uint32_t revision=0;
 void update(uint32_t mv){
  uint16_t next=(mv>=2000&&mv<=4400)?uint16_t(mv):0;
  uint8_t color=next?(next>=3800?3:next>=3500?2:1):0;
  if(next&&millivolts){if(band==3&&next>=3750)color=3;else if(band==2&&next>=3450&&next<3800)color=2;}
  if(next!=millivolts||color!=band){millivolts=next;band=color;++revision;}
 }
};
extern BatteryReading battery;
void batteryBegin();
void batteryTick();
