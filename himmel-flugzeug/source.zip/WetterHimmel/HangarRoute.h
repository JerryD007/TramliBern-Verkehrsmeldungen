#pragma once
#include "HangarModel.h"
namespace HangarRoute {
struct Record {
 uint32_t magic=0x48525431,version=1,sequence=0,pass=0;
 int64_t received=0;
 char hex[7]={},callsign[17]={},origin[5]={},destination[5]={};
 char originName[48]={},destinationName[48]={},airline[48]={};
 uint32_t crc=0;
};
constexpr unsigned slotSize=256;
static_assert(sizeof(Record)<=slotSize,"Route slot budget");
inline uint32_t checksum(const Record&r){uint32_t c=0xffffffff;auto p=(const uint8_t*)&r;for(size_t i=0;i<offsetof(Record,crc);i++){c^=p[i];for(int b=0;b<8;b++)c=(c>>1)^((0-(c&1))&0xedb88320);}return ~c;}
inline bool valid(const Record&r){return r.magic==0x48525431&&r.version==1&&r.hex[6]==0&&Hangar::hexValid(r.hex)&&r.callsign[16]==0&&r.callsign[0]&&r.origin[4]==0&&r.destination[4]==0&&r.origin[0]&&r.destination[0]&&r.originName[47]==0&&r.destinationName[47]==0&&r.airline[47]==0&&r.received>0&&r.pass>0&&r.crc==checksum(r);}
inline bool matches(const Record&r,const Hangar::Record&h){return valid(r)&&r.pass==h.passes&&!strcmp(r.hex,h.hex)&&!strcmp(r.callsign,h.callsign);}
// Two slots: never destroy the previous valid value before confirming the next.
template<class Storage> int read(Storage&sd,const char*path,Record&out){
 auto f=sd.open(path,"r");if(!f)return sd.exists(path)?-1:0;
 Record a{},b{};bool va=f.read((uint8_t*)&a,sizeof a)==sizeof a&&valid(a);
 bool vb=f.seek(slotSize)&&f.read((uint8_t*)&b,sizeof b)==sizeof b&&valid(b);f.close();
 if(!va&&!vb)return -1;
 out=va&&(!vb||int32_t(a.sequence-b.sequence)>0)?a:b;return 1;
}
template<class Storage> bool write(Storage&sd,const char*path,Record&r){
 ++r.sequence;r.crc=checksum(r);auto f=sd.open(path,sd.exists(path)?"r+":"w+");if(!f)return false;
 bool ok=f.seek(((r.sequence-1)&1)*slotSize)&&f.write((const uint8_t*)&r,sizeof r)==sizeof r;f.flush();f.close();
 Record check{};return ok&&read(sd,path,check)==1&&check.sequence==r.sequence&&check.crc==r.crc;
}
}
