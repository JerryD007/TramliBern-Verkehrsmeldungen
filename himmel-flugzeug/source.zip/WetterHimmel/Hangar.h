#pragma once
#include "Modern.h"
#include <FS.h>
void hangarObserveFile(File &file,const Place &place,int radius,time_t now);
void hangarInterrupted(const char *reason);
void hangarWork();
bool hangarBusy();
bool hangarRequest(JsonVariantConst request,String &error);
void hangarWeb();
void hangarDiagnostic(JsonDocument &d);

void hangarStoreRoute(const FlightRoute &route);

#include "HangarModel.h"
#include "HangarRoute.h"
uint32_t hangarRevision();
unsigned hangarDisplayState();
bool hangarDisplayRow(unsigned index,Hangar::Record &row,unsigned &size,unsigned &total,bool &more,String &error);
bool hangarDisplayRouteRequest(const Hangar::Record &row);
bool hangarDisplayRouteResult(HangarRoute::Record &route,String &error);
