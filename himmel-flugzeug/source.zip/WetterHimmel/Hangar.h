#pragma once
#include "Modern.h"
#include <FS.h>
void hangarObserveFile(File &file,const Place &place,int radius,time_t now);
void hangarInterrupted(const char *reason);
void hangarWork();
bool hangarBusy();
bool hangarRequest(JsonVariantConst request,String &error);
void hangarWeb();
void hangarDiagnostic(JsonDocument &d);
