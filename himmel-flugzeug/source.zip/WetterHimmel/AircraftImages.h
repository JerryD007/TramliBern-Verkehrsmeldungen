#pragma once
#include <stdint.h>
namespace AircraftImages {
struct Sprite {const uint8_t* data;unsigned size;};
extern const Sprite sprites[7];
inline int select(unsigned profile,unsigned livery){if(profile==2&&livery==1)return 0;if(profile==2&&livery==2)return 1;if(profile==2&&livery==3)return 2;if(profile==13&&livery==4)return 3;if(profile==13&&livery==5)return 4;if(profile==7&&livery==6)return 5;if(profile==22&&livery==7)return 6;return -1;}
template<class P> bool draw(P &paint,unsigned profile,unsigned livery,int x,int y){
 int id=select(profile,livery);if(id<0)return false;
 const auto&s=sprites[id];unsigned xx=0,yy=0;
 for(unsigned at=32;at<s.size;++at){unsigned code=s.data[at],n=(code>>4)+1,index=(code&15)*2;
  uint16_t color=s.data[index]|(uint16_t(s.data[index+1])<<8);
  paint.drawFastHLine(x+xx,y+yy,n,color);
  xx+=n;if(xx==210){xx=0;++yy;}
 }return true;
}
}
