#pragma once
#include <math.h>
#include <stdint.h>
// Geometric disc overlap in a common Earth-fixed frame, kilometres.
// 0 unknown, 1 below horizon, 2 umbra, 3 penumbra, 4 bright sky, 5 candidate.
inline int satelliteVisibility(const double r[3],const double sun[3],double altitude,double sunAltitude){
 double rr=0,ss=0,dot=0;for(int i=0;i<3;i++){double d=sun[i]-r[i];rr+=r[i]*r[i];ss+=d*d;dot-=r[i]*d;}
 rr=sqrt(rr);ss=sqrt(ss);
 if(!isfinite(rr)||!isfinite(ss)||!isfinite(altitude)||!isfinite(sunAltitude)||rr<=6378.137||ss<=695700)return 0;
 if(altitude<0)return 1;
 double c=dot/(rr*ss);if(c>1)c=1;if(c< -1)c=-1;
 double separation=acos(c),earthRadius=asin(6378.137/rr),sunRadius=asin(695700/ss);
 if(separation+sunRadius<=earthRadius)return 2;
 if(separation<earthRadius+sunRadius)return 3;
 return sunAltitude<=-6?5:4;
}
inline const char* visibilityLabel(int v){
 switch(v){case 1:return "Unter dem Horizont";case 2:return "Im Erdschatten";case 3:return "Teilweise im Erdschatten";case 4:return "Beleuchtet, Himmel noch hell";case 5:return "Sichtchance bei klarem Himmel*";default:return "Sichtbarkeit noch ungeprüft";}
}

// Remaining lifetime of a geometric observing candidate, never a magnitude prediction.
// No heap allocation; the same predicate feeds display and Safari.
inline unsigned satelliteCandidateSeconds(bool clock, bool valid, int64_t now,
    int64_t epoch, int64_t checked, double altitude, unsigned visibility) {
 if(!clock || !valid || !isfinite(altitude) || altitude<=0 || visibility!=5 ||
    epoch<=0 || checked<=0 || checked>now || now-checked>=20 ||
    epoch<now-7*86400 || epoch>now+7*86400) return 0;
 return unsigned(20-(now-checked));
}
template<class Sat> inline unsigned satelliteCandidateSeconds(const Sat &s,bool clock,int64_t now){
 return satelliteCandidateSeconds(clock,s.valid,now,s.epoch,s.visibilityAt,s.alt,s.visibility);
}

// A valid orbit is not evidence of a current computed position.
template<class Sat> inline bool satellitePositionCurrent(const Sat &s,bool clock,int64_t now){
 return clock&&s.valid&&s.epoch>0&&s.visibilityAt>0&&s.visibilityAt<=now&&now-s.visibilityAt<20&&s.epoch>=now-7*86400&&s.epoch<=now+7*86400;
}
