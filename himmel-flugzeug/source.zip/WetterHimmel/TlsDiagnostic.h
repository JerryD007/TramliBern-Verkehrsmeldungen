#pragma once
#include <WiFiClientSecure.h>
#include <esp_crt_bundle.h>

#include <mbedtls/x509_crt.h>
#include "NativeRoots.h"
#include <esp_heap_caps.h>
// One serialized network worker owns this state. No allocation in callback.
namespace TlsDiagnostic {
static char detail[640];
static unsigned used=0,callbacks=0;
static int (*verify)(void*,mbedtls_x509_crt*,int,uint32_t*)=nullptr;
static void *verifyContext=nullptr;
static mbedtls_x509_crt *nativeRoot=nullptr;
static bool nativeMode=false,routeMode=false;
static int observe(void*,mbedtls_x509_crt *cert,int depth,uint32_t *flags){
 const uint32_t before=*flags;
 const int result=nativeMode?0:(verify?verify(verifyContext,cert,depth,flags):MBEDTLS_ERR_X509_FATAL_ERROR);
 ++callbacks;
 if(used+1<sizeof detail){
  char issuer[160]={};mbedtls_x509_dn_gets(issuer,sizeof issuer,&cert->issuer);
  int n=snprintf(detail+used,sizeof detail-used,"X509 depth=%d flags=%08lx->%08lx verify=%d issuer=%.150s\n",depth,(unsigned long)before,(unsigned long)*flags,result,issuer);
  if(n>0)used+=min((unsigned)n,(unsigned)(sizeof detail-used-1));
 }
 // Preserve both result and flags from Espressif. Never bypass verification.
 return result;
}
static esp_err_t attach(void *config){
 esp_err_t result=esp_crt_bundle_attach(config);
 if(result==ESP_OK&&config){auto *c=static_cast<mbedtls_ssl_config*>(config);verify=c->MBEDTLS_PRIVATE(f_vrfy);verifyContext=c->MBEDTLS_PRIVATE(p_vrfy);mbedtls_ssl_conf_verify(c,observe,nullptr);}
 return result;
}
static esp_err_t attachNative(void *config){
 if(!nativeRoot||!config)return ESP_ERR_INVALID_ARG;
 int result=routeMode?parseRouteRoots(nativeRoot):parseAircraftRoots(nativeRoot);
 if(result)return result;
 auto *c=static_cast<mbedtls_ssl_config*>(config);
 mbedtls_ssl_conf_ca_chain(c,nativeRoot,nullptr);
 mbedtls_ssl_conf_verify(c,observe,nullptr);
 return ESP_OK;
}
class Client:public WiFiClientSecure {
public:
 uint32_t writes=0,shortWrites=0,txFree=0,txLargest=0,txDma=0;size_t requested=0,written=0;
 size_t write(const uint8_t *buffer,size_t size) override {
  if(!writes){txFree=heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_DEFAULT);txLargest=heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_DEFAULT);txDma=heap_caps_get_free_size(MALLOC_CAP_DMA);}
  ++writes;requested+=size;size_t n=WiFiClientSecure::write(buffer,size);written+=n;if(n<size)++shortWrites;return n;
 }

 void enableTrace(){used=callbacks=0;detail[0]=0;nativeMode=false;sslclient->bundle_attach_cb=attach;}
 void useAircraftRoot(bool route=false){routeMode=route;used=callbacks=0;detail[0]=0;nativeMode=true;nativeRoot=&sslclient->ca_cert;_use_ca_bundle=true;_use_insecure=false;sslclient->bundle_attach_cb=attachNative;}
};
}
