#include "App.h"
static astro_time_t at;
static astro_rotation_t precession;
static astro_observer_t observer() {
  auto &p = cfg.places[cfg.place];
  return Astronomy_MakeObserver(p.lat, p.lon, p.height);
}
static astro_time_t astroTime(time_t t) {
  return Astronomy_TimeFromDays((double)t / 86400.0 - 10957.5);
}
bool project(double az, double alt, int &x, int &y) {
  if (!isfinite(az) || !isfinite(alt) || alt < 0 || alt > 90)
    return false;
  double r = (90 - alt) / 90 * 108;
  x = 160 - lround(r * sin(az * DEG_TO_RAD));
  y = 174 - lround(r * cos(az * DEG_TO_RAD));
  return true;
}
void starHorizontal(double ra, double dec, double &az, double &alt) {
  astro_spherical_t s{ASTRO_SUCCESS, dec, ra * 15, 1};
  auto v = Astronomy_RotateVector(precession, Astronomy_VectorFromSphere(s, at));
  auto eq = Astronomy_EquatorFromVector(v);
  auto h = Astronomy_Horizon(&at, observer(), eq.ra, eq.dec, REFRACTION_NORMAL);
  az = h.azimuth;
  alt = h.altitude;
}
void skyUpdate() {
  if (!clockReady())
    return;
  at = astroTime(viewTime());
  precession = Astronomy_Rotation_EQJ_EQD(&at);
  objectCount = 0;
  const astro_body_t bodies[] = {BODY_SUN,     BODY_MOON,   BODY_MERCURY, BODY_VENUS,  BODY_MARS,
                                 BODY_JUPITER, BODY_SATURN, BODY_URANUS,  BODY_NEPTUNE};
  const char *names[] = {"Sonne",   "Mond",   "Merkur", "Venus", "Mars",
                         "Jupiter", "Saturn", "Uranus", "Neptun"};
  const uint16_t colors[] = {0xFFE0, 0xFFFF, 0xBDF7, 0xFFBB, 0xFA60,
                             0xFD20, 0xEED0, 0x07FF, 0x441F};
  for (int i = 0; i < 9; i++) {
#ifndef UI_HOST_PREVIEW
    uiPollTouch();
#endif
    auto eq = Astronomy_Equator(bodies[i], &at, observer(), EQUATOR_OF_DATE, ABERRATION);
    if (eq.status != ASTRO_SUCCESS)
      continue;
    auto h = Astronomy_Horizon(&at, observer(), eq.ra, eq.dec, REFRACTION_NORMAL);
    auto &o = objects[objectCount++];
    strlcpy(o.name, names[i], 36);
    o.az = h.azimuth;
    o.alt = h.altitude;
    o.color = colors[i];
    o.kind = i;
    auto illum = Astronomy_Illumination(bodies[i], at);
    o.mag = illum.mag;
    if (i == 0) {
      sunAlt = o.alt;
      o.x = o.y = 0;
    } else if (i > 1) {
      auto e = Astronomy_Ecliptic(Astronomy_HelioVector(bodies[i], at));
      o.x = e.elon;
      o.y = 0;
    }
  }
  auto m = Astronomy_MoonPhase(at);
  moonPhase = m.angle;
  auto rise = Astronomy_SearchRiseSet(BODY_SUN, observer(), DIRECTION_RISE, at, 2);
#ifndef UI_HOST_PREVIEW
  uiPollTouch();
#endif
  auto set = Astronomy_SearchRiseSet(BODY_SUN, observer(), DIRECTION_SET, at, 2);
  sunrise = rise.status == ASTRO_SUCCESS ? (time_t)((rise.time.ut + 10957.5) * 86400) : 0;
  sunset = set.status == ASTRO_SUCCESS ? (time_t)((set.time.ut + 10957.5) * 86400) : 0;
}
