#pragma once
#include "Modern.h"
// Only metadata is kept in RAM. Validated full responses use alternating SD files.
struct RadarSnapshot {
 uint32_t revision=0,generation=0,bytes=0;
 time_t received=0;
 double lat=0,lon=0;
 int radius=0;
 uint8_t slot=0;
};
extern RadarSnapshot radarSnapshot;
extern FlightRoute webFlightRoute;
extern char webRouteError[96];
const char *radarPath(unsigned slot);
void radarWeb();
bool requestWebRoute(const char *call,const char *hex,String &error);
