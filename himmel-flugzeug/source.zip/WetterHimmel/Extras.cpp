#include "Extras.h"
#include "Modern.h"
#include "NightSchedule.h"
#include "Catalog.h"
#include "StarNames.h"
#include "Starlink.h"
#include <Update.h>
#include <esp_ota_ops.h>
#include <esp_app_desc.h>
ExtraSettings extra;
int highlightedObject=-1;
bool firmwareUploading=false;
static uint32_t restartAt=0,uploadAt=0;
static String uploadError;
static const char firmwareMarker[]="WETTERHIMMEL_OTA_LAYOUT_1_9_ESP32";
static unsigned markerMatch=0;static bool markerSeen=false;
static bool manualNight=false;
static bool validExtra(const ExtraSettings &e){return e.version==1&&e.start>=0&&e.start<1440&&e.end>=0&&e.end<1440&&e.dim>=10&&e.dim<=100;}
static void sendJson(JsonDocument &d){webReplyJson(d);}
static bool fleetRoute(){return web.uri().startsWith("/fleet/");}
static void fleetCors(){if(fleetRoute()){web.sendHeader("Access-Control-Allow-Origin","*");web.sendHeader("Cache-Control","no-store");}}
static bool uploadAuthorized(){return fleetRoute()?web.header("X-WW-Key")==deviceKey:web.header("X-WW-Token")==csrf;}
static bool authorized(){fleetCors();if(uploadAuthorized())return true;web.send(403,"text/plain","Bitte Seite neu laden");return false;}
void extrasBegin(){if(prefs.getBytesLength("extras")==sizeof extra)prefs.getBytes("extras",&extra,sizeof extra);if(!validExtra(extra))extra=ExtraSettings();extra.autoNight=false;displayNight=false;manualNight=false;}
void extrasTick(){
 if(restartAt&&int32_t(millis()-restartAt)>=0){ESP.restart();return;}
 if(firmwareUploading&&millis()-uploadAt>30000){Update.abort();firmwareUploading=false;uploadError="Upload-Zeitlimit";}

}
bool objectCoordinates(int id,double &az,double &alt,String &name){
 if(!clockReady())return false;
 if(id>=0&&id<objectCount){az=objects[id].az;alt=objects[id].alt;name=objects[id].name;return true;}
 if(id>=100&&id<100+(int)(sizeof stars/sizeof stars[0])){auto &s=stars[id-100];starHorizontal(s.ra,s.dec,az,alt);name=starName(id-100);return true;}
 return false;
}
static bool extraFromJson(JsonVariantConst v,ExtraSettings &e){
 if(!v["largeMap"].is<bool>()||!v["trails"].is<bool>()||!v["autoNight"].is<bool>()||!v["start"].is<int>()||!v["end"].is<int>()||!v["dim"].is<int>())return false;
 e.largeMap=v["largeMap"];e.trails=v["trails"];e.autoNight=false;e.start=v["start"];e.end=v["end"];e.dim=v["dim"];return validExtra(e);
}
static void extraJson(JsonObject o){o["largeMap"]=extra.largeMap;o["trails"]=extra.trails;o["autoNight"]=extra.autoNight;o["start"]=extra.start;o["end"]=extra.end;o["dim"]=extra.dim;}
bool extrasCommand(JsonDocument &d,String &error){
 String a=d["action"]|"";
 if(a=="highlight"){
  if(!d["id"].is<int>()){error="Objektkennung fehlt";return false;}int id=d["id"];double az,alt;String name;
  if(id!=-1&&(!objectCoordinates(id,az,alt,name)||alt<0)){error="Objekt aktuell unter Horizont oder Uhrzeit fehlt";return false;}
  setView(1);highlightedObject=id;skyCamera.set(1,0,0);skyCamera.revision++;dirty=true;return true;
 }
 if(a=="extras"){
  ExtraSettings next=extra;if(!extraFromJson(d.as<JsonVariantConst>(),next)){error="Zeitplan/Anzeige ungültig";return false;}
  if(prefs.putBytes("extras",&next,sizeof next)!=sizeof next){error="Speichern fehlgeschlagen";return false;}
  if(!extra.autoNight&&next.autoNight)manualNight=displayNight;
  bool off=extra.autoNight&&!next.autoNight;extra=next;
  if(off)displayNight=manualNight;
  page=0;skyCamera.revision++;uiDisplayBrightness();extrasTick();dirty=true;return true;
 }
 error="Unbekannte Erweiterung";return false;
}
static const esp_partition_t *otaTarget(){
 auto next=esp_ota_get_next_update_partition(nullptr);auto running=esp_ota_get_running_partition();
 if(!next||!running||next->address==running->address||next->size!=0x1e0000||running->size!=0x1e0000)return nullptr;
 if(!((next->address==0x10000&&running->address==0x1f0000)||(next->address==0x1f0000&&running->address==0x10000)))return nullptr;
 return next;
}
void extrasState(JsonDocument &d){
 auto e=d["extras"].to<JsonObject>();extraJson(e);e["highlight"]=highlightedObject;double haz,halt;String hname;if(objectCoordinates(highlightedObject,haz,halt,hname)){e["highlightAz"]=haz;e["highlightAlt"]=halt;}
 auto partition=otaTarget();e["otaAvailable"]=partition!=nullptr;e["otaBytes"]=partition?partition->size:0;
 auto paths=d["paths"].to<JsonArray>();time_t now=time(nullptr);
 if(extra.trails&&clockReady())for(int i=0;i<SAT_COUNT;i++){
  uiPollTouch();
  if(!cfg.satellites||(i==3&&!cfg.starlink)||!satellites[i].valid||satellites[i].alt<0)continue;
  auto path=paths.add<JsonObject>();path["index"]=i;auto points=path["points"].to<JsonArray>();
  for(int t=0;t<=120;t+=20){double az,alt;if(!satelliteFuture(i,now+t,az,alt)||alt<0)break;auto point=points.add<JsonArray>();point.add(az);point.add(alt);}
 }
}
static void backup(JsonDocument &d){
 d["format"]="WetterHimmel";d["schema"]=1;
 auto c=d["config"].to<JsonObject>();c["brightness"]=cfg.brightness;c["view"]=cfg.view;c["autoSeconds"]=cfg.autoSeconds;c["place"]=cfg.place;
 c["labels"]=cfg.labels;c["lines"]=cfg.lines;c["milky"]=cfg.milky;c["satellites"]=cfg.satellites;c["starlink"]=cfg.starlink;
 auto ps=c["places"].to<JsonArray>();for(int i=0;i<cfg.placeCount;i++){auto x=ps.add<JsonObject>();auto &p=cfg.places[i];x["name"]=p.name;x["lat"]=p.lat;x["lon"]=p.lon;x["height"]=p.height;x["tz"]=p.tz;}
 auto ws=c["wifi"].to<JsonArray>();for(int i=0;i<cfg.wifiCount;i++){auto x=ws.add<JsonObject>();x["ssid"]=cfg.wifi[i].ssid;x["pass"]=cfg.wifi[i].pass;}
 extraJson(d["extras"].to<JsonObject>());modernJson(d["modern"].to<JsonObject>(),modern);
}
static bool strField(JsonVariantConst v,size_t max,bool empty=false){if(!v.is<const char*>())return false;size_t n=strlen(v.as<const char*>());return n<max&&(empty||n);}
static bool numField(JsonVariantConst v,double lo,double hi){return v.is<double>()&&isfinite(v.as<double>())&&v.as<double>()>=lo&&v.as<double>()<=hi;}
static bool restore(JsonDocument &d){
 if(strcmp(d["format"]|"","WetterHimmel")||!d["schema"].is<int>()||d["schema"]!=1)return false;
 Settings next=cfg;ExtraSettings ex=extra;ModernSettings mo=modern;auto c=d["config"];
 if(!d["modern"].isNull()&&!modernRead(d["modern"],mo))return false;
 if(!extraFromJson(d["extras"],ex)||!c["places"].is<JsonArray>()||!c["wifi"].is<JsonArray>())return false;
 int n=c["places"].size(),w=c["wifi"].size();if(n<1||n>6||w>6)return false;
 if(!c["place"].is<int>()||!numField(c["place"],0,n-1)||!c["brightness"].is<int>()||!numField(c["brightness"],20,255)||!c["view"].is<int>()||!numField(c["view"],0,2)||!c["autoSeconds"].is<int>()||!numField(c["autoSeconds"],0,3600))return false;
 if(c["autoSeconds"].as<int>()>0&&c["autoSeconds"].as<int>()<10)return false;
 for(const char *key:{"labels","lines","milky","satellites","starlink"})if(!c[key].is<bool>())return false;
 for(int i=0;i<n;i++){auto x=c["places"][i];if(!strField(x["name"],40)||!strField(x["tz"],80)||!numField(x["lat"],-90,90)||!numField(x["lon"],-180,180)||!numField(x["height"],-500,9000))return false;auto &p=next.places[i];strlcpy(p.name,x["name"],40);strlcpy(p.tz,x["tz"],80);p.lat=x["lat"];p.lon=x["lon"];p.height=x["height"];}
 for(int i=0;i<w;i++){auto x=c["wifi"][i];if(!strField(x["ssid"],33)||!strField(x["pass"],65,true))return false;strlcpy(next.wifi[i].ssid,x["ssid"],33);strlcpy(next.wifi[i].pass,x["pass"],65);}
 next.placeCount=n;next.wifiCount=w;next.place=c["place"];next.view=c["view"].as<int>()==2?2:1;next.brightness=c["brightness"];next.autoSeconds=c["autoSeconds"];
 next.labels=c["labels"];next.lines=c["lines"];next.milky=c["milky"];next.satellites=c["satellites"];next.starlink=c["starlink"];
 if(prefs.putBytes("settings",&next,sizeof next)!=sizeof next)return false;
 if(prefs.putBytes("extras",&ex,sizeof ex)!=sizeof ex){prefs.putBytes("settings",&cfg,sizeof cfg);return false;}
 JsonDocument md;modernJson(md.to<JsonObject>(),mo);String mj;serializeJson(md,mj);if(prefs.putString("modern",mj)!=mj.length()){prefs.putBytes("settings",&cfg,sizeof cfg);prefs.putBytes("extras",&extra,sizeof extra);return false;}modern=mo;
 cfg=next;extra=ex;displayNight=manualNight;extrasTick();highlightedObject=-1;page=0;skyCamera.revision++;applyPlace();uiDisplayBrightness();return true;
}
void extrasWeb(){
 for(const char* endpoint:{"/fleet/info","/fleet/firmware","/fleet/diagnostic"})web.on(endpoint,HTTP_OPTIONS,[]{fleetCors();web.sendHeader("Access-Control-Allow-Methods","GET, POST, OPTIONS");web.sendHeader("Access-Control-Allow-Headers","X-WW-Key, Content-Type");web.sendHeader("Access-Control-Max-Age","600");web.send(204);});
 web.on("/fleet/info",HTTP_GET,[]{if(!authorized()||!webMemoryAvailable())return;JsonDocument d;d["project"]="WetterHimmel";d["board"]="ESP32-ST7796";d["layout"]="WW19";d["version"]=WW_VERSION;d["boot"]=deviceBoot;d["id"]=String((uint32_t)(ESP.getEfuseMac()>>32),HEX)+String((uint32_t)ESP.getEfuseMac(),HEX);d["name"]=modern.name;auto part=otaTarget();d["otaBytes"]=part?part->size:0;d["busy"]=firmwareUploading;d["heap"]=ESP.getFreeHeap();webReplyJson(d);});
 web.on("/fleet/diagnostic",HTTP_GET,[]{if(!authorized()||!webMemoryAvailable())return;JsonDocument d;modernDiagnostic(d);webReplyJson(d);});

 web.on("/api/objects",HTTP_GET,[]{
  if(!webMemoryAvailable())return;
  String q=web.arg("q");q.toLowerCase();if(q.length()>40){web.send(400,"text/plain","Suchtext zu lang");return;}
  JsonDocument d;auto a=d["objects"].to<JsonArray>();
  if(clockReady())for(int id=0;id<100+(int)(sizeof stars/sizeof stars[0])&&a.size()<30;id++){
   if(id>=objectCount&&id<100)continue;double az,alt;String name;if(!objectCoordinates(id,az,alt,name))continue;
   String lower=name;lower.toLowerCase();if(q.length()?lower.indexOf(q)<0:(id>=100||id<2||alt<0))continue;
   auto o=a.add<JsonObject>();o["id"]=id;o["name"]=name;o["az"]=az;o["alt"]=alt;o["direction"]=bearing(az);
  }sendJson(d);
 });
 web.on("/api/backup",HTTP_POST,[]{if(!authorized())return;if(!webMemoryAvailable())return;JsonDocument d;backup(d);sendJson(d);});
 web.on("/api/restore",HTTP_POST,[]{if(!authorized())return;if(networkBusy()||firmwareUploading||starlinkImportBusy()){web.send(409,"text/plain","Bitte laufenden Abruf abwarten");return;}String body=web.arg("plain");if(body.length()>12000){web.send(413,"text/plain","Sicherung zu groß");return;}JsonDocument d;if(deserializeJson(d,body)||!restore(d)){web.send(400,"text/plain","Ungültige Sicherung oder Speicherfehler; keine erfolgreiche Wiederherstellung");return;}web.send(200,"text/plain","Wiederhergestellt. WLAN wird beim nächsten Neustart verwendet.");});
 for(const char* endpoint:{"/api/firmware","/fleet/firmware"})web.on(endpoint,HTTP_POST,[]{
  if(!authorized())return;
  if(!uploadError.length()&&!firmwareUploading)uploadError="Keine Firmware empfangen";
  bool ok=firmwareUploading&&!uploadError.length();firmwareUploading=false;
  if(!ok){Update.abort();prefs.putString("otaStage","Fehlgeschlagen: "+uploadError);web.send(400,"text/plain",uploadError);return;}
  prefs.putString("otaStage","Geschrieben; Neustart angefordert");web.send(200,"text/plain","Firmware geprüft. Neustart in zwei Sekunden.");restartAt=millis()+2000;
 },[]{
  auto &u=web.upload();
  if(u.status==UPLOAD_FILE_START){uploadError="";firmwareUploading=false;markerMatch=0;markerSeen=false;
   if(!uploadAuthorized()){uploadError="Nicht autorisiert";return;}
   if(networkBusy()||starlinkImportBusy()){uploadError="Bitte laufenden Abruf abwarten";return;}
   auto part=otaTarget();if(!part){uploadError="Einmalige USB-Installation mit OTA-Partitionen erforderlich";return;}
   if(!u.filename.endsWith(".bin")){uploadError="Nur die WetterHimmel.ino.bin auswählen";return;}
   if(!Update.begin(part->size,U_FLASH)){uploadError=Update.errorString();return;}firmwareUploading=true;uploadAt=millis();prefs.putString("otaStage","Upload begonnen");
  }else if(u.status==UPLOAD_FILE_WRITE&&firmwareUploading&&!uploadError.length()){
   uploadAt=millis();if(u.totalSize==0){
    if(u.currentSize<32+sizeof(esp_app_desc_t)){uploadError="Firmwarekopf unvollständig";Update.abort();return;}
    esp_app_desc_t desc;memcpy(&desc,u.buf+32,sizeof desc);
    if(desc.magic_word!=ESP_APP_DESC_MAGIC_WORD){uploadError="Keine passende WetterHimmel-Firmware";Update.abort();return;}
   }
   for(size_t i=0;i<u.currentSize&&!markerSeen;i++){if(u.buf[i]==firmwareMarker[markerMatch])markerMatch++;else markerMatch=u.buf[i]==firmwareMarker[0]?1:0;if(markerMatch==sizeof(firmwareMarker)-1)markerSeen=true;}
   if(Update.write(u.buf,u.currentSize)!=u.currentSize){uploadError=Update.errorString();Update.abort();}
  }else if(u.status==UPLOAD_FILE_END&&firmwareUploading&&!uploadError.length()){
   if(!markerSeen){uploadError="Firmware ist nicht für diese WetterHimmel-OTA-Aufteilung";Update.abort();}
   else if(!Update.end(true))uploadError=Update.errorString();
  }else if(u.status==UPLOAD_FILE_ABORTED){Update.abort();firmwareUploading=false;uploadError="Upload abgebrochen";}
 });
}
