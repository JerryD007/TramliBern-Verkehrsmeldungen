#include "Hangar.h"
#include "HangarModel.h"
#include "AircraftFile.h"
#include "Starlink.h"
#include <SD.h>
#include <atomic>
namespace {
using Hangar::Record;
constexpr unsigned pageSize=12,slotSize=128;
const char *folder="/wetterhimmel/hangar";
Hangar::Coverage coverage;
struct Stats {uint32_t writes=0,failures=0,recovered=0,uncertain=0,newPasses=0;char error[96]={},reason[80]={};} stats;
struct Query {char search[25]={};bool passes=false,hasCursor=false;Record cursor;};
struct Page {Record rows[pageSize];unsigned size=0,total=0,eligible=0,damaged=0,scanned=0;char error[96]={};} result;
Query query;
// Main thread publishes the request last. Worker publishes the result last.
std::atomic<unsigned> queryState{0}; // 0 idle, 1 pending, 2 scanning, 3 complete
File directory;
void failure(const char*s){++stats.failures;snprintf(stats.error,sizeof stats.error,"%s",s);coverage.interrupt();}
void pathFor(const char*hex,char*out,size_t n){snprintf(out,n,"%s/%s.bin",folder,hex);}
int readRecord(const char*path,Record &out,bool *recovered=nullptr){
 File f=SD.open(path,FILE_READ);if(!f)return SD.exists(path)?-1:0;
 Record a{},b{};bool va=f.read((uint8_t*)&a,sizeof a)==sizeof a&&Hangar::valid(a);
 bool vb=f.seek(slotSize)&&f.read((uint8_t*)&b,sizeof b)==sizeof b&&Hangar::valid(b);size_t size=f.size();f.close();
 if(!va&&!vb)return -1;
 out=va&&(!vb||int32_t(a.sequence-b.sequence)>0)?a:b;
 if(recovered)*recovered=size>slotSize&&(!va||!vb);
 return 1;
}
bool writeRecord(const char*path,Record&r){
 ++r.sequence;r.crc=Hangar::checksum(r);const unsigned slot=(r.sequence-1)&1;
 File f=SD.open(path,SD.exists(path)?"r+":"w+");if(!f)return false;
 bool ok=f.seek(slot*slotSize)&&f.write((const uint8_t*)&r,sizeof r)==sizeof r;f.flush();f.close();
 Record check{};return ok&&readRecord(path,check)==1&&check.sequence==r.sequence&&check.crc==r.crc;
}
struct ObserveContext {time_t now;bool okay=true;};
bool visit(JsonVariantConst raw,const Flight&f,void*arg){
 auto &context=*(ObserveContext*)arg;char hex[7]={};const char *source=raw["hex"]|"";
 if(strlen(source)!=6)return true;for(unsigned i=0;i<6;i++)hex[i]=tolower((unsigned char)source[i]);
 if(!Hangar::hexValid(hex)||f.positionAt<=0||f.positionAt>context.now||context.now-f.positionAt>60)return true;
 char path[64];pathFor(hex,path,sizeof path);Record r;bool recovered=false;int read=readRecord(path,r,&recovered);
 if(read<0||(read&&strcmp(r.hex,hex))){failure("Hangar-Datensatz beschaedigt / nicht lesbar");context.okay=false;return false;}
 if(recovered)++stats.recovered;
 if(read&&f.positionAt<r.last)return true;
 bool freshPass=Hangar::observe(r,hex,f.positionAt,context.now,coverage);
 Hangar::label(r.registration,sizeof r.registration,raw["r"]|"");Hangar::label(r.callsign,sizeof r.callsign,raw["flight"]|"");Hangar::label(r.type,sizeof r.type,raw["t"]|"");
 if(!writeRecord(path,r)){failure("Hangar: SD-Schreiben nicht bestaetigt (voll / entfernt?)");context.okay=false;return false;}
 ++stats.writes;if(freshPass){++stats.newPasses;snprintf(stats.reason,sizeof stats.reason,"%s: %s",hex,read?"Rueckkehr nach bestaetigter Abwesenheit":"Erste Erfassung");}
 vTaskDelay(1);return true;
}
bool contains(const char*s,const char*q){if(!*q)return true;for(;*s;s++){const char*a=s,*b=q;while(*a&&*b&&toupper((unsigned char)*a)==toupper((unsigned char)*b)){a++;b++;}if(!*b)return true;}return false;}
void finish(const char*error=nullptr){directory.close();if(error)snprintf(result.error,sizeof result.error,"%s",error);queryState.store(3,std::memory_order_release);}
}
void hangarInterrupted(const char*reason){if(coverage.previous)++stats.uncertain;coverage.interrupt();snprintf(stats.reason,sizeof stats.reason,"%s",reason);}
void hangarObserveFile(File&file,const Place&place,int radius,time_t now){
 // Called only after complete flight response validation and TLS destruction,
 // on the worker while it owns the SD lock. Never holds the whole history in RAM.
 if(!SD.exists(folder)&&!SD.mkdir(folder)){failure("Hangar nicht verfuegbar: SD-Verzeichnis");return;}
 if(coverage.previous&&(now-coverage.previous>Hangar::maximumGap||coverage.lat!=place.lat||coverage.lon!=place.lon||coverage.radius!=radius))++stats.uncertain;
 coverage.begin(now,place.lat,place.lon,radius);ObserveContext context{now};Flight ignored;const char*why=nullptr;
 if(!readAircraftFile(file,ignored,place,radius,false,now,why,visit,&context)){if(context.okay)failure(why?why:"Hangar: Dateilesefehler");return;}
 stats.error[0]=0;
}
bool hangarRequest(JsonVariantConst d,String&error){
 if(queryState.load(std::memory_order_acquire)==1||queryState.load()==2){error="Hangar wird geladen";return false;}
 const char*s=d["search"]|"";if(strlen(s)>24){error="Suchtext zu lang";return false;}
 Query next;for(unsigned i=0;s[i];i++){if(!isalnum((unsigned char)s[i])&&s[i]!='-'&&s[i]!=' '){error="Suche: Buchstaben, Zahlen, Leerzeichen oder Bindestrich";return false;}next.search[i]=s[i];}
 next.passes=d["sort"]=="passes";
 const char*hex=d["cursorHex"]|"";if(*hex){if(!Hangar::hexValid(hex)||!d["cursorLast"].is<int64_t>()||!d["cursorPasses"].is<uint32_t>()){error="Hangar-Seite ungueltig";return false;}next.hasCursor=true;snprintf(next.cursor.hex,sizeof next.cursor.hex,"%s",hex);next.cursor.last=d["cursorLast"];next.cursor.passes=d["cursorPasses"];}
 query=next;queryState.store(1,std::memory_order_release);return true;
}
bool hangarBusy(){unsigned s=queryState.load(std::memory_order_acquire);return s==1||s==2;}
void hangarWork(){
 unsigned state=queryState.load(std::memory_order_acquire);if(state!=1&&state!=2)return;
 if(!aircraftSdAcquire()){if(state==1){result=Page();finish("Hangar nicht verfügbar: SD nicht bereit");}return;}
 struct Release{~Release(){aircraftSdRelease();}}release;
 if(state==1){result=Page();directory=SD.open(folder);if(!directory){finish(SD.exists(folder)?"Hangar nicht verfügbar: Lesefehler":nullptr);return;}if(!directory.isDirectory()){finish("Hangar nicht verfügbar: Verzeichnis ungueltig");return;}queryState.store(2,std::memory_order_release);}
 for(unsigned batch=0;batch<8;batch++){
  File entry=directory.openNextFile();if(!entry){finish();return;}
  bool isDirectory=entry.isDirectory();String path=entry.path();entry.close();if(isDirectory||!path.endsWith(".bin"))continue;
  Record r;if(readRecord(path.c_str(),r)!=1){++result.damaged;continue;}
  ++result.scanned;
  if(!contains(r.hex,query.search)&&!contains(r.registration,query.search)&&!contains(r.callsign,query.search))continue;
  ++result.total;if(query.hasCursor&&!Hangar::before(query.cursor,r,query.passes))continue;++result.eligible;
  unsigned at=0;while(at<result.size&&!Hangar::before(r,result.rows[at],query.passes))++at;
  if(at<pageSize){unsigned end=result.size<pageSize?result.size:pageSize-1;for(unsigned i=end;i>at;--i)result.rows[i]=result.rows[i-1];result.rows[at]=r;if(result.size<pageSize)++result.size;}
  vTaskDelay(1);
 }
}
void hangarWeb(){web.on("/api/hangar",HTTP_GET,[]{
 if(!webMemoryAvailable())return;JsonDocument d;unsigned state=queryState.load(std::memory_order_acquire);d["ready"]=state==3;d["busy"]=state==1||state==2;
 if(state==3){d["error"]=result.error;d["total"]=result.total;d["damaged"]=result.damaged;d["more"]=result.eligible>result.size;auto rows=d["rows"].to<JsonArray>();for(unsigned i=0;i<result.size;i++){auto&r=result.rows[i];auto o=rows.add<JsonObject>();o["hex"]=r.hex;o["registration"]=r.registration;o["callsign"]=r.callsign;o["type"]=r.type;o["first"]=r.first;o["last"]=r.last;o["passes"]=r.passes;}}
 web.sendHeader("Cache-Control","no-store");webReplyJson(d);
});}
void hangarDiagnostic(JsonDocument&d){auto h=d["hangar"].to<JsonObject>();h["writes"]=stats.writes;h["writeReadErrors"]=stats.failures;h["recoveredSlots"]=stats.recovered;h["uncertainGaps"]=stats.uncertain;h["newPassesThisBoot"]=stats.newPasses;h["error"]=stats.error;h["lastReason"]=stats.reason;h["coverageStart"]=coverage.start;h["absenceSeconds"]=Hangar::absenceSeconds;h["gapMarginSeconds"]=Hangar::maximumGap;h["queryState"]=queryState.load();if(queryState.load()==3){h["lastQueryMatches"]=result.total;h["recordsAtLastScan"]=result.scanned;h["damagedAtLastScan"]=result.damaged;h["lastQueryError"]=result.error;}}
