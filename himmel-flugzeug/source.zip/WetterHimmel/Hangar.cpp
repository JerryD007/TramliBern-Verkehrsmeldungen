#include "Hangar.h"
#include "HangarModel.h"
#include "HangarHome.h"
#include "HangarRoute.h"
#include "AircraftFile.h"
#include "Starlink.h"
#include <SD.h>
#include <atomic>
namespace {
using Hangar::Record;
constexpr unsigned pageSize=12,slotSize=128;
const char *folder="/wetterhimmel/hangar";
Hangar::Coverage coverage;
uint32_t routeWrites=0,routeErrors=0;
struct Stats {uint32_t writes=0,failures=0,recovered=0,uncertain=0,newPasses=0;char error[96]={},reason[80]={};} stats;
struct Query {char search[25]={};bool passes=false,hasCursor=false,force=false;Record cursor;};
struct Page {Record rows[pageSize];unsigned size=0,total=0,eligible=0,damaged=0,scanned=0;char error[96]={};} result;
Query query;
uint32_t queryRevision=0;
HangarRoute::Record displayRoute;
char displayRouteError[96]={};
// Main thread publishes the request last. Worker publishes the result last.
std::atomic<unsigned> routeState{0};
std::atomic<unsigned> scanProgress{0};
std::atomic<unsigned> queryState{0}; // 0 idle, 1 pending, 2 scanning, 3 complete
File directory;
const char *homePath="/wetterhimmel/hangar-home.idx";
std::atomic<uint32_t> cacheHits{0},cacheBuilds{0},cacheErrors{0},queryMs{0};
uint32_t queryStarted=0;std::atomic<bool> queryCached{false};
bool homeQuery(){return !query.search[0]&&!query.passes&&!query.hasCursor;}
bool readHome(Hangar::Home &h){File f=SD.open(homePath,FILE_READ);return f&&f.size()==sizeof h&&f.read((uint8_t*)&h,sizeof h)==sizeof h&&h.valid();}
bool writeHome(Hangar::Home &h){h.crc=h.checksum();File f=SD.open(homePath,"w");bool ok=f&&f.write((const uint8_t*)&h,sizeof h)==sizeof h;f.flush();f.close();if(!ok){SD.remove(homePath);++cacheErrors;}return ok;}

void failure(const char*s){++stats.failures;snprintf(stats.error,sizeof stats.error,"%s",s);coverage.interrupt();}
void pathFor(const char*hex,char*out,size_t n){snprintf(out,n,"%s/%s.bin",folder,hex);}
int readRecord(const char*path,Record &out,bool *recovered=nullptr){
 File f=SD.open(path,FILE_READ);if(!f)return SD.exists(path)?-1:0;
 Record a{},b{};bool va=f.read((uint8_t*)&a,sizeof a)==sizeof a&&Hangar::valid(a);
 bool vb=f.seek(slotSize)&&f.read((uint8_t*)&b,sizeof b)==sizeof b&&Hangar::valid(b);size_t size=f.size();f.close();
 if(!va&&!vb)return -1;
 out=va&&(!vb||int32_t(a.sequence-b.sequence)>0)?a:b;
 if(recovered)*recovered=size>slotSize&&(!va||!vb);
 return 1;
}
bool writeRecord(const char*path,Record&r){
 ++r.sequence;r.crc=Hangar::checksum(r);const unsigned slot=(r.sequence-1)&1;
 File f=SD.open(path,SD.exists(path)?"r+":"w+");if(!f)return false;
 bool ok=f.seek(slot*slotSize)&&f.write((const uint8_t*)&r,sizeof r)==sizeof r;f.flush();f.close();
 Record check{};return ok&&readRecord(path,check)==1&&check.sequence==r.sequence&&check.crc==r.crc;
}
struct ObserveContext {time_t now;bool okay=true;Hangar::Home *home=nullptr;bool invalidated=false;};
bool visit(JsonVariantConst raw,const Flight&f,void*arg){
 auto &context=*(ObserveContext*)arg;char hex[7]={};const char *source=raw["hex"]|"";
 if(strlen(source)!=6)return true;for(unsigned i=0;i<6;i++)hex[i]=tolower((unsigned char)source[i]);
 if(!Hangar::hexValid(hex)||f.positionAt<=0||f.positionAt>context.now||context.now-f.positionAt>60)return true;
 char path[64];pathFor(hex,path,sizeof path);Record r;bool recovered=false;int read=readRecord(path,r,&recovered);
 if(read<0||(read&&strcmp(r.hex,hex))){failure("Hangar-Datensatz beschaedigt / nicht lesbar");context.okay=false;return false;}
 if(recovered)++stats.recovered;
 if(read&&f.positionAt<r.last)return true;
 bool freshPass=Hangar::observe(r,hex,f.positionAt,context.now,coverage);
 Hangar::label(r.registration,sizeof r.registration,raw["r"]|"");Hangar::label(r.callsign,sizeof r.callsign,f.callsign);Hangar::label(r.type,sizeof r.type,raw["t"]|"");
 // Remove the disposable index BEFORE changing authoritative data: a power
 // loss cannot leave a valid but outdated index. Rebuild after this whole batch.
 if(context.home&&!context.invalidated){if(!SD.remove(homePath)){failure("Hangar-Index nicht freigebbar");context.okay=false;return false;}context.invalidated=true;}
 if(!writeRecord(path,r)){failure("Hangar: SD-Schreiben nicht bestaetigt (voll / entfernt?)");context.okay=false;return false;}
 if(context.home)context.home->observe(r,read==0);
 ++stats.writes;if(freshPass){++stats.newPasses;snprintf(stats.reason,sizeof stats.reason,"%s: %s",hex,read?"Rueckkehr nach bestaetigter Abwesenheit":"Erste Erfassung");}
 vTaskDelay(1);return true;
}
bool contains(const char*s,const char*q){if(!*q)return true;for(;*s;s++){const char*a=s,*b=q;while(*a&&*b&&toupper((unsigned char)*a)==toupper((unsigned char)*b)){a++;b++;}if(!*b)return true;}return false;}
void finish(const char*error=nullptr){
 directory.close();if(error)snprintf(result.error,sizeof result.error,"%s",error);
 if(!queryCached&&homeQuery()&&!result.error[0]&&!result.damaged){Hangar::Home h;h.size=result.size;h.total=result.total;for(unsigned i=0;i<h.size;++i)h.rows[i]=result.rows[i];if(writeHome(h))++cacheBuilds;}
 queryMs.store(millis()-queryStarted);queryState.store(3,std::memory_order_release);
}
}
void hangarInterrupted(const char*reason){if(coverage.previous)++stats.uncertain;coverage.interrupt();snprintf(stats.reason,sizeof stats.reason,"%s",reason);}
void hangarObserveFile(File&file,const Place&place,int radius,time_t now){
 // Called only after complete flight response validation and TLS destruction,
 // on the worker while it owns the SD lock. Never holds the whole history in RAM.
 if(!SD.exists(folder)&&!SD.mkdir(folder)){failure("Hangar nicht verfuegbar: SD-Verzeichnis");return;}
 if(coverage.previous&&(now-coverage.previous>Hangar::maximumGap||coverage.lat!=place.lat||coverage.lon!=place.lon||coverage.radius!=radius))++stats.uncertain;
 coverage.begin(now,place.lat,place.lon,radius);Hangar::Home home;ObserveContext context{now};if(readHome(home))context.home=&home;Flight ignored;const char*why=nullptr;
 if(!readAircraftFile(file,ignored,place,radius,false,now,why,visit,&context)){if(context.okay)failure(why?why:"Hangar: Dateilesefehler");return;}
 if(context.home&&context.invalidated)writeHome(home);
 stats.error[0]=0;
}
bool hangarRequest(JsonVariantConst d,String&error){
 if(hangarBusy()){error="Hangar wird geladen";return false;}
 const char*s=d["search"]|"";if(strlen(s)>24){error="Suchtext zu lang";return false;}
 Query next;for(unsigned i=0;s[i];i++){if(!isalnum((unsigned char)s[i])&&s[i]!='-'&&s[i]!=' '){error="Suche: Buchstaben, Zahlen, Leerzeichen oder Bindestrich";return false;}next.search[i]=s[i];}
 next.passes=d["sort"]=="passes";next.force=d["force"]|false;
 const char*hex=d["cursorHex"]|"";if(*hex){if(!Hangar::hexValid(hex)||!d["cursorLast"].is<int64_t>()||!d["cursorPasses"].is<uint32_t>()){error="Hangar-Seite ungueltig";return false;}next.hasCursor=true;snprintf(next.cursor.hex,sizeof next.cursor.hex,"%s",hex);next.cursor.last=d["cursorLast"];next.cursor.passes=d["cursorPasses"];}
 routeState.store(0,std::memory_order_release);query=next;queryStarted=millis();queryCached=false;++queryRevision;queryState.store(1,std::memory_order_release);return true;
}
bool hangarBusy(){unsigned s=queryState.load(std::memory_order_acquire);unsigned r=routeState.load(std::memory_order_acquire);return s==1||s==2||r==4||r==5;}
void hangarWork(){
 unsigned state=queryState.load(std::memory_order_acquire);
 if(routeState.load(std::memory_order_acquire)==4){
  routeState.store(5,std::memory_order_release);displayRoute=HangarRoute::Record();displayRouteError[0]=0;
  if(!aircraftSdAcquire())snprintf(displayRouteError,sizeof displayRouteError,"SD nicht bereit");
  else {char path[64];snprintf(path,sizeof path,"%s/%s.route",folder,query.cursor.hex);
   int status=HangarRoute::read(SD,path,displayRoute);aircraftSdRelease();
   if(status!=1||!HangarRoute::matches(displayRoute,query.cursor)){displayRoute=HangarRoute::Record();snprintf(displayRouteError,sizeof displayRouteError,"%s",status<0?"Route nicht lesbar":"Keine gespeicherte Route");}
  }
  routeState.store(6,std::memory_order_release);return;
 }
 if(state!=1&&state!=2)return;
 if(!aircraftSdAcquire()){if(state==1){result=Page();finish("Hangar nicht verfügbar: SD nicht bereit");}return;}
 struct Release{~Release(){aircraftSdRelease();}}release;
 if(state==1){scanProgress.store(0);result=Page();
 if(homeQuery()&&!query.force){Hangar::Home h;if(readHome(h)){result.size=h.size;result.total=result.eligible=h.total;for(unsigned i=0;i<h.size;++i)result.rows[i]=h.rows[i];queryCached=true;++cacheHits;finish();return;}}
 directory=SD.open(folder);if(!directory){finish(SD.exists(folder)?"Hangar nicht verfügbar: Lesefehler":nullptr);return;}if(!directory.isDirectory()){finish("Hangar nicht verfügbar: Verzeichnis ungueltig");return;}queryState.store(2,std::memory_order_release);}
 for(unsigned batch=0;batch<8;batch++){
  File entry=directory.openNextFile();if(!entry){finish();return;}
  bool isDirectory=entry.isDirectory();String path=entry.path();entry.close();if(isDirectory||!path.endsWith(".bin"))continue;
  Record r;if(readRecord(path.c_str(),r)!=1){++result.damaged;continue;}
  ++result.scanned;scanProgress.store(result.scanned,std::memory_order_relaxed);
  if(!contains(r.hex,query.search)&&!contains(r.registration,query.search)&&!contains(r.callsign,query.search))continue;
  ++result.total;if(query.hasCursor&&!Hangar::before(query.cursor,r,query.passes))continue;++result.eligible;
  unsigned at=0;while(at<result.size&&!Hangar::before(r,result.rows[at],query.passes))++at;
  if(at<pageSize){unsigned end=result.size<pageSize?result.size:pageSize-1;for(unsigned i=end;i>at;--i)result.rows[i]=result.rows[i-1];result.rows[at]=r;if(result.size<pageSize)++result.size;}
  vTaskDelay(1);
 }
}
void hangarStoreRoute(const FlightRoute&r){
 // Shared network worker calls this only after getUrl has destroyed TLS.
 if(!r.found||!Hangar::hexValid(r.hex)||!routeCallsign(r.callsign))return;
 if(!aircraftSdAcquire()){++routeErrors;return;}
 struct Release{~Release(){aircraftSdRelease();}}release;
 char path[64];pathFor(r.hex,path,sizeof path);Record observed;
 if(readRecord(path,observed)!=1||strcmp(observed.callsign,r.callsign)||r.received<observed.last)return;
 snprintf(path,sizeof path,"%s/%s.route",folder,r.hex);
 HangarRoute::Record saved;int old=HangarRoute::read(SD,path,saved);if(old<0){++routeErrors;return;}
 saved.pass=observed.passes;saved.received=r.received;
 #define COPY_ROUTE(field) snprintf(saved.field,sizeof saved.field,"%s",r.field)
 COPY_ROUTE(hex);COPY_ROUTE(callsign);COPY_ROUTE(origin);COPY_ROUTE(destination);COPY_ROUTE(originName);COPY_ROUTE(destinationName);COPY_ROUTE(airline);
 #undef COPY_ROUTE
 if(HangarRoute::write(SD,path,saved))++routeWrites;else ++routeErrors;
}
static bool hangarWebMemory(){
 if(networkSmallReplyAllowed() && heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)>=24000 && heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)>=6000)return true;
 web.sendHeader("Retry-After","2");web.send(503,"text/plain","Warte auf Arbeitsspeicher");return false;
}
void hangarRouteWeb(){web.on("/api/hangar-route",HTTP_GET,[]{
 if(!hangarWebMemory())return;
 String hex=web.arg("hex");if(!Hangar::hexValid(hex.c_str())){web.send(400,"text/plain","ICAO ungueltig");return;}
 if(!aircraftSdAcquire()){web.send(503,"text/plain","SD nicht bereit");return;}
 JsonDocument d;d["found"]=false;
 {
 struct Release{~Release(){aircraftSdRelease();}}release;
 char path[64];pathFor(hex.c_str(),path,sizeof path);Record observed;
 int record=readRecord(path,observed);
 if(record<0)d["error"]="Hangar-Datensatz nicht lesbar";
 else if(record==1){
 snprintf(path,sizeof path,"%s/%s.route",folder,hex.c_str());HangarRoute::Record r;
 int read=HangarRoute::read(SD,path,r);
 if(read<0){d["error"]="Gespeicherte Route nicht lesbar";++routeErrors;}
 else if(read==1&&HangarRoute::matches(r,observed)){
 d["found"]=true;d["hex"]=r.hex;d["callsign"]=r.callsign;d["pass"]=r.pass;d["received"]=r.received;
 d["origin"]=r.origin;d["destination"]=r.destination;d["originName"]=r.originName;d["destinationName"]=r.destinationName;d["airline"]=r.airline;
 }
 }
 }
 webReplyJson(d);
});}

void hangarWeb(){hangarRouteWeb();web.on("/api/hangar",HTTP_GET,[]{
 if(!hangarWebMemory())return;JsonDocument d;unsigned state=queryState.load(std::memory_order_acquire);d["cached"]=queryCached.load();d["durationMs"]=queryMs.load();d["scanned"]=scanProgress.load(std::memory_order_relaxed);d["ready"]=state==3;d["busy"]=state==1||state==2;
 if(state==3){d["error"]=result.error;d["total"]=result.total;d["damaged"]=result.damaged;d["more"]=result.eligible>result.size;auto rows=d["rows"].to<JsonArray>();for(unsigned i=0;i<result.size;i++){auto&r=result.rows[i];auto o=rows.add<JsonObject>();o["hex"]=r.hex;o["registration"]=r.registration;o["callsign"]=r.callsign;o["type"]=r.type;o["first"]=r.first;o["last"]=r.last;o["passes"]=r.passes;}}
 web.sendHeader("Cache-Control","no-store");webReplyJson(d);
});}
void hangarDiagnostic(JsonDocument&d){auto h=d["hangar"].to<JsonObject>();h["cacheHits"]=cacheHits.load();h["cacheBuilds"]=cacheBuilds.load();h["cacheErrors"]=cacheErrors.load();h["queryMs"]=queryMs.load();h["writes"]=stats.writes;h["routeWrites"]=routeWrites;h["routeErrors"]=routeErrors;h["writeReadErrors"]=stats.failures;h["recoveredSlots"]=stats.recovered;h["uncertainGaps"]=stats.uncertain;h["newPassesThisBoot"]=stats.newPasses;h["error"]=stats.error;h["lastReason"]=stats.reason;h["coverageStart"]=coverage.start;h["absenceSeconds"]=Hangar::absenceSeconds;h["gapMarginSeconds"]=Hangar::maximumGap;h["queryState"]=queryState.load();if(queryState.load()==3){h["lastQueryMatches"]=result.total;h["recordsAtLastScan"]=result.scanned;h["damagedAtLastScan"]=result.damaged;h["lastQueryError"]=result.error;}}

// Main-loop-only accessors: a published request prevents reads while the worker writes.
uint32_t hangarRevision(){return queryRevision;}
unsigned hangarDisplayState(){unsigned r=routeState.load(std::memory_order_acquire);return r?r:queryState.load(std::memory_order_acquire);}
bool hangarDisplayRow(unsigned index,Hangar::Record &row,unsigned &size,unsigned &total,bool &more,String &error){
 if(queryState.load(std::memory_order_acquire)!=3)return false;
 size=result.size;total=result.total;more=result.eligible>result.size;error=result.error;
 if(index<result.size)row=result.rows[index];return true;
}
bool hangarDisplayRouteRequest(const Hangar::Record &row){
 if(hangarBusy())return false;
 query.cursor=row;++queryRevision;routeState.store(4,std::memory_order_release);return true;
}
bool hangarDisplayRouteResult(HangarRoute::Record &route,String &error){
 if(hangarDisplayState()!=6)return false;
 route=displayRoute;error=displayRouteError;return true;
}
