#pragma once
#include <math.h>
#include <stdint.h>
struct SkyCamera {
  float zoom=1,panX=0,panY=0;
  uint32_t revision=0;
  bool set(double z,double x,double y){
    if(!isfinite(z)||!isfinite(x)||!isfinite(y)||z<1||z>4)return false;
    double b=108*(z-1);x=fmax(-b,fmin(b,x));y=fmax(-b,fmin(b,y));
    if(fabs(zoom-z)>.0001||fabs(panX-x)>.0001||fabs(panY-y)>.0001){zoom=z;panX=x;panY=y;revision++;}
    return true;
  }
  void transform(int &x,int &y) const {x=lround(160+(x-160)*zoom+panX);y=lround(174+(y-174)*zoom+panY);}
  bool contains(int x,int y)const{return x>=48&&x<272&&y>=62&&y<286;}
};
