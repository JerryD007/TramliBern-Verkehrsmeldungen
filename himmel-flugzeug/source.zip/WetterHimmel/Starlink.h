#pragma once
#include "App.h"
void starlinkBegin();
void starlinkTick();
bool starlinkDownload(String &error,int &status,uint32_t &retry);
extern String starlinkStatus;
extern uint32_t starlinkCount,starlinkScanMs;
extern time_t starlinkNext;

// Snapshot copied under a short critical section; no SD lock in the web handler.
struct StarlinkFetchTrace {
 uint32_t magic=0x534C5431;bool interrupted=false;
 time_t at=0,next=0;int http=0,tls=0;uint32_t bytes=0;
 char error[160]={},tlsText[128]={};
};
struct StarlinkCatalogStatus {
 bool busy=false, sdReady=false, backup=false, attempted=false, importing=false, restored=false;
 StarlinkFetchTrace lastFetch;
 uint32_t bytes=0, total=0, accepted=0, rejected=0, stored=0, usable=0;
 int http=0, tls=0;
 time_t fetched=0, attemptAt=0;
 char phase[64]="Noch kein Download", error[160]={}, tlsText[128]={};
};
StarlinkCatalogStatus starlinkCatalogStatus();
void starlinkCatalogQueued();
bool requestStarlinkCatalog(String &error);

void starlinkCatalogCancel();

bool starlinkImportStart(uint32_t size,uint32_t &session,String &error);
bool starlinkImportChunk(uint32_t session,uint32_t offset,const uint8_t *data,size_t size,String &error);
bool starlinkImportFinish(uint32_t session,String &error);
bool starlinkImportCancel(uint32_t session,String &error);
bool starlinkImportBusy();
bool networkBusy();

extern uint32_t starlinkReadUs,starlinkComputeUs,starlinkWaitMs;

// Run one queued scan on the shared data worker, never on the display loop.
void starlinkWork();
bool aircraftSdAcquire();
void aircraftSdRelease();
