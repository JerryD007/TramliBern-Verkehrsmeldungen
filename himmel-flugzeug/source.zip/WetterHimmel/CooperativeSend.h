#pragma once
#include <stdint.h>
#include <stddef.h>
// Writer: >0 bytes accepted; 0 would block; <0 permanent failure.
// Poll is called even during socket backpressure. No response-sized RAM buffer.
template<class Write,class Poll,class Clock,class Pause>
bool cooperativeSend(const uint8_t *data,size_t size,Write write,Poll poll,Clock clock,Pause pause){
 size_t offset=0;uint32_t progress=clock();
 while(offset<size){poll();size_t n=size-offset;if(n>512)n=512;int sent=write(data+offset,n);
  if(sent<0||(size_t)sent>n)return false;
  if(sent){offset+=(size_t)sent;progress=clock();}
  else {if((uint32_t)(clock()-progress)>=5000)return false;pause();}
 }
 poll();return true;
}
