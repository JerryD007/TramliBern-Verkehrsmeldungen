#include "App.h"
#include <esp_heap_caps.h>
#include <esp_timer.h>
#include <esp_system.h>
struct HealthSample {uint32_t seconds,heap,block;int16_t rssi;bool connected;};
static HealthSample samples[49];
static unsigned count=0,head=0;
static uint32_t connections=0,disconnects=0,aircraftOK=0,aircraftFailed=0,catalogOK=0,catalogFailed=0;
static uint32_t minBlock=UINT32_MAX,maxLoopMs=0,lastLoop=0,lastSample=0,lastCheck=0;
static bool previous=false,initialized=false;
void healthResult(int kind,bool success){if(kind==9){if(success)aircraftOK++;else aircraftFailed++;}if(kind==8){if(success)catalogOK++;else catalogFailed++;}}
void healthTick(){
 uint32_t now=millis();if(initialized)maxLoopMs=max(maxLoopMs,now-lastLoop);lastLoop=now;
 bool connected=WiFi.status()==WL_CONNECTED;
 if(connected&&!previous)connections++;if(!connected&&previous)disconnects++;previous=connected;
 if(!initialized||now-lastCheck>=5000){lastCheck=now;uint32_t block=heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);minBlock=min(minBlock,block);}
 if(!initialized||now-lastSample>=900000){lastSample=now;
  samples[head]={(uint32_t)(esp_timer_get_time()/1000000),ESP.getFreeHeap(),(uint32_t)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT),(int16_t)(connected?WiFi.RSSI():0),connected};
  head=(head+1)%49;if(count<49)count++;
 }
 initialized=true;
}
void healthJson(JsonObject d,bool history){
 d["uptime"]=(uint64_t)(esp_timer_get_time()/1000000);d["heap"]=ESP.getFreeHeap();d["minBlock"]=minBlock==UINT32_MAX?0:minBlock;
 d["connections"]=connections;d["disconnects"]=disconnects;d["aircraftOK"]=aircraftOK;d["aircraftFailed"]=aircraftFailed;
 d["catalogOK"]=catalogOK;d["catalogFailed"]=catalogFailed;d["maxLoopMs"]=maxLoopMs;d["samples"]=count;d["resetReason"]=(int)esp_reset_reason();
 if(history){auto a=d["history"].to<JsonArray>();for(unsigned i=0;i<count;i++){auto &s=samples[(head+49-count+i)%49];auto o=a.add<JsonObject>();o["uptime"]=s.seconds;o["heap"]=s.heap;o["largestBlock"]=s.block;o["connected"]=s.connected;if(s.connected)o["rssi"]=s.rssi;}}
}
