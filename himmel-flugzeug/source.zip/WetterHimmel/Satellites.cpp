#include "App.h"
#include "Visibility.h"
// TEME -> Earth fixed (GMST), WGS84 observer -> local horizon.
static bool satPosition(Satellite &s, time_t t, double &az, double &alt, bool assess=false) {
  if (!s.valid || llabs((int64_t)t - s.epoch) > 7 * 86400)
    return false;
  double r[3], v[3];
  getRV(&s.tle, ((double)t - (double)s.tle.epoch / 1000.0) / 60.0, r, v);
  if (s.tle.sgp4Error)
    return false;
  double jd = (double)t / 86400 + 2440587.5, gm = gstime(jd), c = cos(gm), sn = sin(gm);
  double ex = c * r[0] + sn * r[1], ey = -sn * r[0] + c * r[1], ez = r[2];
  auto &p = cfg.places[cfg.place];
  double lat = p.lat * DEG_TO_RAD, lon = p.lon * DEG_TO_RAD,
         n = 6378.137 / sqrt(1 - 0.00669437999014 * sq(sin(lat))), h = p.height / 1000;
  double dx = ex - (n + h) * cos(lat) * cos(lon), dy = ey - (n + h) * cos(lat) * sin(lon),
         dz = ez - (n * (1 - 0.00669437999014) + h) * sin(lat);
  double east = -sin(lon) * dx + cos(lon) * dy,
         north = -sin(lat) * cos(lon) * dx - sin(lat) * sin(lon) * dy + cos(lat) * dz,
         up = cos(lat) * cos(lon) * dx + cos(lat) * sin(lon) * dy + sin(lat) * dz;
  az = fmod(atan2(east, north) * RAD_TO_DEG + 360, 360);
  alt = atan2(up, hypot(east, north)) * RAD_TO_DEG;
  if(assess){
    static time_t solarAt=0;static uint32_t solarGeneration=UINT32_MAX;static double solar[3],solarAltitude;static bool solarValid=false;
    if(solarAt!=t||solarGeneration!=generation){solarGeneration=generation;
      solarAt=t;auto at=Astronomy_TimeFromDays((double)t/86400-10957.5);
      auto gv=Astronomy_GeoVector(BODY_SUN,at,ABERRATION);
      auto eqd=Astronomy_RotateVector(Astronomy_Rotation_EQJ_EQD(&at),gv);
      auto ob=Astronomy_MakeObserver(p.lat,p.lon,p.height);
      auto eq=Astronomy_Equator(BODY_SUN,&at,ob,EQUATOR_OF_DATE,ABERRATION);
      solarAltitude=Astronomy_Horizon(&at,ob,eq.ra,eq.dec,REFRACTION_NONE).altitude;
      double gast=Astronomy_SiderealTime(&at)*15*DEG_TO_RAD;
      solar[0]=(cos(gast)*eqd.x+sin(gast)*eqd.y)*149597870.7;
      solar[1]=(-sin(gast)*eqd.x+cos(gast)*eqd.y)*149597870.7;
      solar[2]=eqd.z*149597870.7;
      solarValid=gv.status==ASTRO_SUCCESS&&eqd.status==ASTRO_SUCCESS&&eq.status==ASTRO_SUCCESS;
    }
    double earthFixed[]={ex,ey,ez};s.visibility=solarValid?satelliteVisibility(earthFixed,solar,alt,solarAltitude):0;s.visibilityAt=t;
  }
  return true;
}
static int predictionSat = 0;
static time_t cursor = 0, limit = 0;
static bool inPass = false;
void resetSatPrediction() {
  predictionSat = 0;
  cursor = 0;
  inPass = false;
  for (auto &s : satellites) {
    s.rise = s.set = s.peak = 0;
    s.maxAlt = 0;
    s.passOngoing=false;
  }
}
void resetStarlinkPrediction() {
  if(predictionSat>=3){predictionSat=3;cursor=0;inPass=false;}
}
void satTick() {
  if (!clockReady())
    return;
  static uint32_t last = 0;
  time_t now = time(nullptr);
  if (millis() - last > 10000) {
    last = millis();
    bool changed=false;
    for (auto &s : satellites) {
      double oldAz=s.az,oldAlt=s.alt;
      if (!satPosition(s, now, s.az, s.alt, true))
        s.alt = -90;
      changed=changed || (s.valid && (fabs(s.az-oldAz)>0.05 || fabs(s.alt-oldAlt)>0.05));
    }
    if (changed && cfg.view == 1 && cfg.satellites)
      dirty = true;
  }
  if (predictionSat >= SAT_COUNT) {
    static time_t retry = 0;
    if (now - retry > 600) {
      retry = now;
      resetSatPrediction();
    }
    return;
  }
  auto &s = satellites[predictionSat];
  if (!s.valid || llabs((int64_t)now - s.epoch) > 7 * 86400) {
    predictionSat++;
    cursor = 0;
    return;
  }
  if (!cursor) {
    cursor = now;
    limit = now + 48 * 3600;
    inPass = false;
  }
  for (int k = 0; k < 8 && cursor < limit; k++, cursor += 30) {
    double a, h;
    if (!satPosition(s, cursor, a, h)) {
      predictionSat++;
      cursor = 0;
      inPass = false;
      return;
    }
    if (h >= 0) {
      if (!inPass) {
        inPass = true;
        s.rise = cursor;
        s.passOngoing=(cursor==now);
        s.startAz = a;
      }
      if (h > s.maxAlt) {
        s.maxAlt = h;
        s.peak = cursor;
      }
    } else if (inPass) {
      s.set = cursor;
      s.endAz = a;
      predictionSat++;
      cursor = 0;
      dirty = true;
      return;
    }
  }
  if (cursor >= limit) {
    predictionSat++;
    cursor = 0;
    dirty = true;
  }
}

String satelliteCountdown(const Satellite &s){
 if(!clockReady())return "Warte auf Uhrzeit";
 time_t now=time(nullptr);
 if(!s.valid||llabs((int64_t)now-s.epoch)>7*86400)return "Bahndaten fehlen / veraltet";
 if(s.alt>=0)return "Jetzt über dem Horizont";
 if(s.set<=now||s.rise<=now)return "Überflug wird berechnet";
 long seconds=s.rise-now,minutes=(seconds+59)/60;
 if(minutes<60)return "In "+String(minutes)+" Minuten";
 return "In "+String(minutes/60)+" h "+String(minutes%60)+" min";
}

bool satelliteFuture(int index,time_t t,double &az,double &alt){if(index<0||index>=SAT_COUNT)return false;Satellite copy=satellites[index];return satPosition(copy,t,az,alt);}

// Independent optical-condition search: never overwrites current positions or geometric passes.
struct PossiblePass {int catalog=0;time_t epoch=0,start=0,end=0,peak=0,searched=0;double az=0,maxAlt=0;bool complete=false;};
static PossiblePass possible[4];
static int visibleIndex=0;static time_t visibleCursor=0,visibleLimit=0;static uint32_t visibleGeneration=UINT32_MAX;
void visiblePassTick(){
 if(!clockReady())return;time_t now=time(nullptr);
 if(visibleGeneration!=generation){visibleGeneration=generation;for(auto &p:possible)p={};visibleIndex=0;visibleCursor=0;}
 if(visibleIndex>=4){visibleIndex=0;visibleCursor=0;}
 int i=visibleIndex;auto &s=satellites[i];auto &p=possible[i];
 if(p.catalog!=s.catalog||p.epoch!=s.epoch||(p.complete&&((p.end&&p.end<=now)||now-p.searched>600))){p={};visibleCursor=0;}
 if(!s.valid||(i==3&&!cfg.starlink)||llabs((int64_t)now-s.epoch)>7*86400||p.complete){visibleIndex++;visibleCursor=0;return;}
 if(!visibleCursor){p={};p.catalog=s.catalog;p.epoch=s.epoch;p.searched=now;visibleCursor=now;visibleLimit=now+48*3600;}
 Satellite copy=s;double az,alt;
 // One sample per loop bounds work and gives the touch queue frequent service.
 bool valid=satPosition(copy,visibleCursor,az,alt,true);
 bool visible=valid&&copy.visibility==5;
 if(visible){if(!p.start){p.start=visibleCursor;p.az=az;}if(alt>p.maxAlt){p.maxAlt=alt;p.peak=visibleCursor;}}
 else if(p.start){p.end=visibleCursor;p.complete=true;visibleIndex++;visibleCursor=0;return;}
 visibleCursor+=30;if(visibleCursor>=visibleLimit){p.complete=true;visibleIndex++;visibleCursor=0;}
}
void visiblePassJson(JsonObject d){
 time_t now=time(nullptr);int best=-1;bool searching=false;
 for(int i=0;i<4;i++){auto &p=possible[i];auto &s=satellites[i];bool current=s.valid&&(i!=3||cfg.starlink)&&llabs((int64_t)now-s.epoch)<=7*86400;bool eligible=current&&p.catalog==s.catalog&&p.epoch==s.epoch;
 if(current&&(!eligible||!p.complete))searching=true;
 if(eligible&&p.complete&&p.start&&p.end>now&&(best<0||p.start<possible[best].start))best=i;
 }
 d["searching"]=searching;d["found"]=best>=0;d["windowHours"]=48;d["stepSeconds"]=30;
 if(best>=0){auto&p=possible[best];d["name"]=satellites[best].name;d["start"]=(int64_t)p.start;d["end"]=(int64_t)p.end;d["begin"]=eventStamp(p.start);d["direction"]=bearing(p.az);d["maxAlt"]=p.maxAlt;d["seconds"]=max((time_t)0,p.start-now);}
}
